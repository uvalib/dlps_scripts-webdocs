<?php

/*
  start.php - presents login form (if not logged in) or welcome page (if logged in)
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-05-11
  Last modified: 2005-07-12

  Posts data to: authenticate.php
*/

include 'inc/tracksys.php';
include 'inc/maxlengths.php';

if ($loginMode) {
  session_start();

  if (empty($_SESSION['username'])) {
    $mode = 'unauth';
    $pageTitle = "Log In - $appTitle";
  } else {
    $mode = 'auth';
    $pageTitle = "Welcome - $appTitle";
  }
} else {
  $mode = 'neutral';
}

// connect to db
$connection = connect();

// get db server version
$server = mysql_get_server_info();

?>
<html>
<head>
<title><?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="inc/tracksys.css">
<!--<base href="/bin/cgi-dl/dlps/tracksys/">-->
</head>

<?php
if ($mode == 'unauth') {
  // not logged in; show login form
?>
<body onload="document.frm.username.focus();">
<h2>Log In</h2>
<form name="frm" method="POST" action="authenticate.php">
<table cellpadding="4">
<tr>
<td></td>
<td align="right"><a href="help.php?helpId=login" target="help">Help</a></td>
</tr>
<tr>
<td class="label">Username:</td>
<td><input type="text" name="username" maxlength="<?=$usernameMaxLength?>"></td>
</tr>
<tr>
<td class="label">Password:</td>
<td><input type="password" name="password" maxlength="<?=$passwordMaxLength?>"></td>
</tr>
<tr>
<td colspan="2" align="right">
<input type="submit" value="Log In">
</td>
</tr>
</table>
</form>
<?php
} else {
  // either logged in, or login mode is disabled; show welcome page
  echo "<body>\n";
  echo "<h2>Welcome to the $appTitle</h2>\n";

  if ($mode == 'auth') {
    echo '<p>You are logged in as "' . $_SESSION['alias'] . '".</p>' . "\n";
  }

?>

<p>Click a heading at left to get started.</p>
<p><a href='help.php'>Help</a></p>


<?php
  if ($_SESSION['username'] == 'debug') {
?>

  <table cellpadding="4">
  <tr>
  <td class="label"><b>PHP version:</b></td>
  <td><?=PHP_VERSION?></td>
  </tr>

  <tr>
  <td class="label"><b>MySQL version:</b></td>
  <td><?=$server?></td>
  </tr>
  </table>

<?php
  }
}  // END if ($mode == 'unauth') ... else ...
?>

</body>
</html>
