<?php

/*
  followSaveType.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-12-01
  Last modified: 2005-10-07

  This page is displayed upon successful insert/update of a type. It
  simply displays non-editable values for the record.

  Receives data from: saveType.php
*/

import_request_variables('G');
include '../../../inc/tracksys.php';
include '../../../inc/auth.php';

$siteArea = 'Goodwill Projects - Setup';
$pageTitle = 'Project Type - Update Status';

// connect to db
$connection = connect();

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
// get data from database and display for confirmation
$sql = "SELECT * FROM goodwillProjectTypes WHERE typeId = '$typeId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) == 1 ) {
  if ($mode == 'delete') {
    echo "<p class='error'>WARNING: The type was <b>not</b> deleted (type ID: $typeId).
      Contact the $appTitle administrator.</p>
      </body></html>";
    exit;
  }

  if ($affected == '0') {
    echo "<p class='updated'>No changes were needed.</p>";
  } else {
    if ($mode == 'insert') {
      echo "<p class='updated'>New project type added successfully</p>\n";
    } else {
      echo "<p class='updated'>Project type updated successfully</p>\n";
    }
  }
  $row = mysql_fetch_array($result);
?>

<table cellpadding='6' cellspacing='0'>
<tr>
<td class='label'>Name:</td>
<td><?=$row['typeName']?></td>
</tr><tr>
<td class='label'>Description:</td>
<td><?=$row['typeDesc']?></td>
</tr>
</table>

<?php
} else {
  if ($mode == 'delete') {
    echo "<p class='updated'>Project type deleted successfully.</p>\n";
  } else {
    echo "<p>Project type ID '$typeId' not found in database. Contact the $appTitle administrator.</p>\n";
  }
}  // END if ( mysql_num_rows($result) == 1 )

echo "<p>";
if (getPerm('goodwillInsert')) {
  echo "<a href='types.php?typeId=new'>Enter new project type</a>";
} else {
  echo "<span class='disabled'>Enter new project type</span>";
}
?>
<br><a href='types.php'>View list of project types</a>
</p>

</body>
</html>
