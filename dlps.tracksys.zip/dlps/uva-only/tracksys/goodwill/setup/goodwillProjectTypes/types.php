<?php

/*
  types.php - page for managing types of goodwill projects
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-11-23
  Last modified: 2005-11-23

  If no 'typeId' parameter, lists types already defined.
  If ID is 'new', displays add-new form for defining a type.
  If ID is a number, displays edit form for editing an existing type.
*/

import_request_variables('PG');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Goodwill Projects - Setup';

if ( empty($typeId) ) {
  // list existing types
  $mode = 'list';
  $pageTitle = 'Project Types';

  // test permissions
  testPerm('goodwillSelect');
} else {
  if ($typeId == 'new') {
    // display enter-new form
    $mode = 'insert';
    $pageTitle = 'Enter New Project Type';
    $submitCaption = ' Add ';

    // test permissions
    testPerm('goodwillInsert');
  } else {
    // display edit form
    $mode = 'update';
    $pageTitle = 'Edit Project Type';
    $submitCaption = 'Update';

    // test permissions; need Select to view item details, Update to enable submit button
    testPerm('goodwillSelect');
    if (!getPerm('goodwillUpdate')) { $submitAppearance = ' disabled'; }
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
<script type="text/javascript" src="../../../inc/tracksys.js"></script>
</head>

<?php
if ($mode == 'list') {
  // list existing types

/*
  if (getPerm('goodwillInsert')) {
    $addNewLink = "<p><a href='?typeId=new'>Enter new project type</a></p>";
  } else {
    $addNewLink = "<p><span class='disabled'>Enter new project type</span></p>";
  }
*/
?>

<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<?=$addNewLink?>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>Name</td>
<td>Description</td>
</tr>

<?php
  $sql = "SELECT * FROM goodwillProjectTypes ORDER BY typeName";
  $result = query($sql, $connection);
  $num = mysql_num_rows($result);
  if ($num == 0) { echo "<tr><td cols='2'><b>0</b> items</td></tr>\n"; }
  while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);
      echo "<tr$class>\n";
      //echo "<td><a href='?typeId=$row[typeId]'>$row[typeName]</a></td>\n";
      echo "<td><b>$row[typeName]</b></td>\n";
      echo "<td>$row[typeDesc]</td>\n";
      echo "</tr>\n";
  }
  echo "</table>\n";
}  // END if ($mode == 'list')

else {
  if ($mode == 'update') {
    $sql = "SELECT * FROM goodwillProjectTypes WHERE typeId = '$typeId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $typeId = $row['typeId'];
    }
  }

  if ($deleteEnabled and $mode == 'update' and getPerm('goodwillDelete')) {
    $onSubmit = " onsubmit='return confirmDelete(document.frm, \"Goodwill Project Type\");'";
  }
?>

<body onload='document.frm.typeName.focus();'>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name='frm' method='POST' action='saveType.php'<?=$onSubmit?>>
<input type='hidden' name='mode' value='<?=$mode?>'>
<input type='hidden' name='typeId' value='<?=$typeId?>'>
<table cellpadding='4'>
<tr>
<td class='label'>Name:</td>
<td><input type='text' name='typeName' value='<?=$row[typeName]?>' maxlength='<?=$typeNameMaxLength?>'></td>
</tr>
<tr>
<td class='label'>Description:</td>
<td><input type='text' name='typeDesc' value='<?=$row[typeDesc]?>' size='60' maxlength='<?=$typeDescMaxLength?>'></td>
</tr>
<?php
  if ($deleteEnabled and $mode == 'update' and getPerm('goodwillDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>
<tr>
<td></td>
<td>
<input type='submit' name='go' value='<?=$submitCaption?>'<?=$submitAppearance?>>
<input type='button' value='Cancel' onclick='history.back();'>
</td>
</tr>
</table>
</form>
<?php
}  // END if ($mode == 'list') { ... } else
?>
</body>
</html>
