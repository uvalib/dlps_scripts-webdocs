<?php

/*
  saveType.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-11-23
  Last modified: 2006-05-23

  Saves user-entered data to database, either by inserting a new
  record or updating an existing record, as appropriate.

  Receives data from: types.php
  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: followSaveType.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// validate user input

$location = 'Location: ../../../err/badInput.php?msg=';

// name
if (empty($typeName)) {
  header($location . urlencode('Name of type is required'));
  exit;
}

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}

// ID
if ($mode == 'update') {
  if (empty($typeId)) {
    header($location . urlencode('Type ID is required'));
    exit;
  }
}

// connect to db
$connection = connect();

// prep user input
$typeName = clean2($typeName, $connection, $typeNameMaxLength);
$typeDesc = clean2($typeDesc, $connection, $typeDescMaxLength);

// build SQL statement

if ($mode == 'update') {
  if ($chkDelete) {
    testPerm('goodwillDelete');
    $mode = 'delete';
    $sql = "DELETE FROM goodwillProjectTypes";
  } else {
    testPerm('goodwillUpdate');
    $sql = "UPDATE goodwillProjectTypes SET";
  }
  $where = " WHERE typeId = $typeId";
} else {
  testPerm('goodwillInsert');
  $sql = "INSERT INTO goodwillProjectTypes SET";
  $where = '';
}

if ($mode == 'delete') {
  $values = '';
} else {
  if (empty($typeName)) { $value = "NULL"; } else { $value = "'$typeName'"; }
  $values = " typeName = $value";

  if (empty($typeDesc)) { $value = "NULL"; } else { $value = "'$typeDesc'"; }
  $values .= ", typeDesc = $value";
}

$sql .= $values . $where;

// execute SQL statement
if ( mysql_query($sql, $connection) ) {
  if ( $mode == 'insert' ) {
    $typeId = mysql_insert_id();
  }
  $affected = mysql_affected_rows();

  // redirect, indicating success
  header("Location: followSaveType.php?mode=$mode&typeId=$typeId&affected=$affected");
} else {
  die($dbErrorPreface . "Unable to $mode type '$typeName': " . mysql_error($connection) . "<br><br>$sql");
}

?>