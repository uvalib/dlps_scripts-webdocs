<?php

/*
  saveGoodwillItem.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-10-25
  Last modified: 2006-05-23

  Saves user-entered data to database, either by inserting a new
  record or updating an existing record, as appropriate.

  Receives data from: goodwillItem.php
  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: followSaveGoodwillItem.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

// connect to db
$connection = connect();

//--------------------
// validate user input
//--------------------

$location = 'Location: ../err/badInput.php?msg=';

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}

// goodwill project ID
if (empty($projectId)) {
  header($location . urlencode('Goodwill Project ID is required'));
  exit;
}

// goodwill project type ID
if (empty($typeId)) {
  header($location . urlencode('Project Type ID is required'));
  exit;
}

if ($typeId == GOODWILL_TYPE_TEXT) {
  // text item; DLPS ID is required
  if (empty($dlpsId)) {
    header($location . urlencode('DLPS ID is required'));
    exit;
  }

  // validate DLPS ID
  if (! preg_match('/^[A-Za-z0-9\_\-\.]+$/', $dlpsId) ) {
    header($location . urlencode("DLPS ID '$dlpsId' is invalid. DLPS ID must contain only letters, numbers, underscore, hyphen, or period."));
    exit;
  }

  // test whether this DLPS ID already exists as a text item; it must, in order to assocaite it with a project
  $sql = "SELECT dlpsId FROM textItems WHERE dlpsId = '$dlpsId'";
  $result = query($sql, $connection);
  if ( mysql_num_rows($result) < 1 ) {
    // can't add an item that doesn't exist
    header($location . urlencode("DLPS ID '$dlpsId' does not exist as a text-workflow item, so it cannot be added to the project"));
    exit;
  }

  // test whether this DLPS ID has already been associated with this project
  $sql = "SELECT dlpsId FROM goodwillItems WHERE dlpsId = '$dlpsId' AND projectId = $projectId";
  $result = query($sql, $connection);
  if ( mysql_num_rows($result) >= 1 ) {
    if ($mode == 'insert') {
      // can't insert a DLPS ID that already exists
      header($location . urlencode("DLPS ID '$dlpsId' has already been added to this project; it cannot be added again"));
      exit;
    }
  }

} else {
  // not a text item; item name is required
  if (empty($itemName)) {
    header($location . urlencode('Item Name is required'));
    exit;
  }

  // test whether this item name has already been associated with this project
  $sql = "SELECT itemName FROM goodwillItems WHERE itemName = '$itemName' AND projectId = $projectId";
  $result = query($sql, $connection);
  if ( mysql_num_rows($result) >= 1 ) {
    if ($mode == 'insert') {
      // can't insert an item name that already exists
      header($location . urlencode("Item Name '$itemName' has already been added to this project; it cannot be added again"));
      exit;
    }
  }

  // number of DVDs must be an integer
  $dvdCount = trim($dvdCount);
  if ($dvdCount) {
    if (! preg_match('/^\d+$/', $dvdCount) ) {
      header($location . urlencode("If provided, 'Number of DVDs' must be a whole number"));
      exit;
    }
  }

  // date received
  if (!empty($dateReceived)) {
    $test = formatDateISO($dateReceived);
    if ( empty($test) ) {
      header($location . urlencode("Value '$dateReceived' for Date Received is not a valid date"));
      exit;
    } else {
      $dateReceived = $test;
    }
  }

  // date finished
  if (!empty($dateFinished)) {
    $test = formatDateISO($dateFinished);
    if ( empty($test) ) {
      header($location . urlencode("Value '$dateFinished' for Date Finished is not a valid date"));
      exit;
    } else {
      $dateFinished = $test;
    }
  }
}

// prep user input
$dlpsId = clean2($dlpsId, $connection, $dlpsIdMaxLength);
$itemName = clean2($itemName, $connection, $nameMaxLength);
$itemDesc = clean2($itemDesc, $connection, $descMaxLength);
$notes = clean2($notes, $connection);


//--------------------
// build SQL statement
//--------------------

if ($mode == 'update') {
  if ($chkDelete) {
    testPerm('goodwillDelete');
    $mode = 'delete';
    $sql = "DELETE FROM goodwillItems";
  } else {
    testPerm('goodwillUpdate');
    $sql = "UPDATE goodwillItems SET";
  }

  if ($typeId == GOODWILL_TYPE_TEXT) {
    $where = " WHERE dlpsId = '$originalDlpsId' AND projectId = $projectId LIMIT 1";
  } else {
    $where = " WHERE itemName = '$originalItemName' AND projectId = $projectId LIMIT 1";
  }
} else {
  testPerm('goodwillInsert');
  $sql = "INSERT INTO goodwillItems SET";
}

if ($mode == 'delete') {
  $values = '';
} else {
  if (empty($dlpsId)) { $value = "NULL"; } else { $value = "'$dlpsId'"; }
  $values = " dlpsId = $value";

  if (empty($projectId)) { $value = "0"; } else { $value = $projectId; }
  $values .= ", projectId = $value";

  if (empty($typeId)) { $value = "0"; } else { $value = $typeId; }
  $values .= ", typeId = $value";

  if (empty($itemName)) { $value = "NULL"; } else { $value = "'$itemName'"; }
  $values .= ", itemName = $value";

  if (empty($itemDesc)) { $value = "NULL"; } else { $value = "'$itemDesc'"; }
  $values .= ", itemDesc = $value";

  if (empty($dvdCount)) { $value = "0"; } else { $value = $dvdCount; }
  $values .= ", dvdCount = $value";

  if (empty($notes)) { $value = "NULL"; } else { $value = "'$notes'"; }
  $values .= ", notes = $value";

  if (empty($dateReceived)) { $value = "NULL"; } else { $value = "'$dateReceived'"; }
  $values .= ", dateReceived = $value";

  if (empty($isFinished)) { $value = "0"; } else { $value = "1"; }
  $values .= ", isFinished = $value";

  if (empty($dateFinished)) { $value = "NULL"; } else { $value = "'$dateFinished'"; }
  $values .= ", dateFinished = $value";
}

$sql .= $values . $where;


//----------------------
// execute SQL statement
//----------------------

if ( mysql_query($sql, $connection) ) {
  $affected = mysql_affected_rows();

  // store SQL statement in session variable for later display in debugging mode
  $_SESSION['saveGoodwillItem']['sql'] = $sql;

  // redirect, indicating success
  header("Location: goodwillProjects.php?projectId=$projectId&status=$mode&affected=$affected");
} else {
  die($dbErrorPreface . mysql_error($connection) . "<br><br>$sql");
}
?>