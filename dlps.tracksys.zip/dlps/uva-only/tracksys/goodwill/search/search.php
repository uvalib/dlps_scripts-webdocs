<?php

/*
  search.php - queries database and displays search results
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-11-21
  Last modified: 2005-11-23

*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Goodwill Projects';
$pageTitle = 'Search Results';

// connect to db
$connection = connect();

// test permissions
testPerm('goodwillSelect');

// get associative array representing table 'goodwillProjects'
$goodwillProjects = getHashGoodwillProjects($connection);

// get associative array representing table 'goodwillProjectTypes'
$types = getHashGoodwillProjectTypes($connection);

// get associative array representing table 'selectors'
$selectors = getHashSelectors($connection);

// get associative array representing table 'requestors'
$requestors = getHashRequestors($connection);


//-------------------------
// prepare SQL query string
//-------------------------

$sql = 'SELECT goodwillProjects.* FROM goodwillProjects';

$where = '';

// basic criteria
$where .= $_SESSION['searchGoodwillSql']['projectName'];
$where .= $_SESSION['searchGoodwillSql']['typeId'];
$where .= $_SESSION['searchGoodwillSql']['projectDesc'];
$where .= $_SESSION['searchGoodwillSql']['notes'];

// misc criteria
$where .= $_SESSION['searchGoodwillSql']['selectorId'];
$where .= $_SESSION['searchGoodwillSql']['requestorId'];
$where .= $_SESSION['searchGoodwillSql']['priority'];
$where .= $_SESSION['searchGoodwillSql']['dateReceivedFrom'];
$where .= $_SESSION['searchGoodwillSql']['dateReceivedTo'];
$where .= $_SESSION['searchGoodwillSql']['forRepo'];
$where .= $_SESSION['searchGoodwillSql']['isFinished'];
$where .= $_SESSION['searchGoodwillSql']['dateFinishedFrom'];
$where .= $_SESSION['searchGoodwillSql']['dateFinishedTo'];

if (!empty($where)) {
  $where = preg_replace('/^ +AND +/', '', $where);  // remove the initial ' AND'
  $sql .= ' WHERE ' . $where;
}

// sort order
if ( $_GET['orderBy'] ) {
  $orderBy = $_GET['orderBy'];
} elseif ( $_SESSION['searchGoodwill']['orderBy'] ) {
  $orderBy = $_SESSION['searchGoodwill']['orderBy'];
} else {
  $orderBy = 'projectName';
}
$_SESSION['searchGoodwill']['orderBy'] = $orderBy;
switch ($orderBy) {
  case 'projectName':
    $_SESSION['searchGoodwillSql']['orderBy'] = ' ORDER BY projectName';
    break;
  default:
    $_SESSION['searchGoodwillSql']['orderBy'] = " ORDER BY $orderBy, projectName";
}
$sql .= $_SESSION['searchGoodwillSql']['orderBy'];

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
<script type="text/javascript">
function setCheckboxes(onOrOff) {
  for (i = 0; i < document.frm.elements.length; i++) {
    if (document.frm.elements[i].type == "checkbox") {
      document.frm.elements[i].checked = onOrOff;
    }
  }
}
</script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
if ($debugMode) {
  echo "<p>$sql</p>\n";
}

// execute query
$result = query($sql, $connection);

$num = mysql_num_rows($result);
if ($num == 1) { $plural = ''; } else { $plural = 's'; }
echo "<p>Found <b>$num</b> item$plural</p>\n";

$newSearchLink = "<p><a href='search1.php'>Adjust this search</a><br>
<a href='search0.php'>Start a new search</a></p>\n";
echo $newSearchLink;

if ($num >= 1) {
  echo "<form name='frm' method='POST'>\n";
  echo "<table cellpadding='6' cellspacing='0' class='list'>\n";
  echo "<tr class='head'>\n";
  //echo "<td>&nbsp;</td>\n";

  if ($orderBy == 'projectName') {
    echo "<td><i>Name</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=projectName'>Name</a></td>\n";
  }

  if ($orderBy == 'typeId') {
    echo "<td><i>Type</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=typeId'>Type</a></td>\n";
  }

  if ($orderBy == 'projectDesc') {
    echo "<td><i>Description</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=projectDesc'>Description</a></td>\n";
  }

  if ($orderBy == 'dateReceived') {
    echo "<td><i>Date Received</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=dateReceived'>Date Received</a></td>\n";
  }

  if ($orderBy == 'dateFinished') {
    echo "<td><i>Date Finished</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=dateFinished'>Date Finished</a></td>\n";
  }

  $colspan = 5;

  if ( (!empty($_SESSION['searchGoodwillSql']['selectorId']))
    || (!empty($_SESSION['searchGoodwillSql']['requestorId'])) ) {
    echo "<td>Selector</td>";
    echo "<td>Requestor</td>";
    $colspan += 2;
  }

  echo "</tr>\n";

  //$c = 1;
  $c = 0;
  $class = getRowClass($c);
  $colspan--;
/*
  echo "<tr$class>
<td style='white-space: nowrap'>
<img name='checkAll' src='../../img/check.gif' hspace='0' onclick='setCheckboxes(true);' title='Check All'>
<img name='clearAll' border='0' src='../../img/square.gif' hspace='0' onclick='setCheckboxes(false);' title='Clear All'>
</td>
<td colspan='$colspan'>&nbsp;</td>
</tr>\n";
*/

  // display query results
  while ( $row = mysql_fetch_array($result) ) {
    $c++;
    $class = getRowClass($c);

    $typeName = '';
    foreach ($types as $id => $name) {
      if ($row['typeId'] == $id) {
	$typeName = $name;
      }
    }

    $dateReceived = formatDateUS($row['dateReceived']);
    $dateFinished = formatDateUS($row['dateFinished']);

    echo "<tr$class>\n";
    echo "<td style='white-space: nowrap'><a href='../goodwillProjects.php?projectId=$row[projectId]'>$row[projectName]</a></td>\n";
    echo "<td>$typeName</td>\n";
    echo "<td>$row[projectDesc]</td>\n";
    echo "<td>$dateReceived</td>\n";
    echo "<td>$dateFinished</td>\n";

    if ( (!empty($_SESSION['searchGoodwill']['selectorId']))
      || (!empty($_SESSION['searchGoodwill']['requestorId'])) ) {
      if ( empty($row['selectorId']) ) {
        $selectorName = '';
      } else {
        foreach ($selectors as $selectorId => $name) {
          if ($row['selectorId'] == $selectorId) {
            $selectorName = $name;
          }
        }
      }
      echo "<td style='white-space: nowrap'>$selectorName</td>\n";

      if ( empty($row['requestorId']) ) {
        $requestorName = '';
      } else {
        foreach ($requestors as $requestorId => $name) {
          if ($row['requestorId'] == $requestorId) {
            $requestorName = $name;
          }
        }
      }
      echo "<td style='white-space: nowrap'>$requestorName</td>\n";
    }

    echo "</tr>\n";
  }
  echo "</table>
</form>\n";
echo $newSearchLink;
}  // END if ($num >= 1)
?>
</body>
</html>
