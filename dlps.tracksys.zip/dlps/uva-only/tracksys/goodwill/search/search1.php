<?php

/*
  search1.php - first page of search interface for goodwill projects - basic criteria
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-11-21
  Last modified: 2005-11-23

  Submits data to: search2.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Goodwill Projects';
$pageTitle = 'Search - Basic Criteria';

// connect to db
$connection = connect();

// get associative array representing table 'goodwillProjects'
$goodwillProjects = getHashGoodwillProjects($connection);

// get associative array representing table 'goodwillProjectTypes'
$types = getHashGoodwillProjectTypes($connection);

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body onload="document.frm.projectName.focus();">
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<form name="frm" method="GET" action="search2.php">
<table cellpadding="4">
<tr>
<td class="label">Name:</td>
<td><input type="text" name="projectName" value="<?=$_SESSION['searchGoodwill']['projectName']?>"></td>
</tr>

<tr>
<td class="label">Type:</td>
<td><select name="typeId">
<option value=''>All items</option>
<?php
foreach ($types as $id => $name) {
  $selected = '';
  if ( $id == $_SESSION['searchGoodwill']['typeId'] ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td class="label">Description:</td>
<td><input type="text" name="projectDesc" value="<?=$_SESSION['searchGoodwill']['projectDesc']?>"></td>
</tr>

<tr>
<td class="label">Notes:</td>
<td><input type="text" name="notes" value="<?=$_SESSION['searchGoodwill']['notes']?>"></td>
</tr>

<tr>
<td></td>
<td>
<input type="button" value="Clear" onclick="clearForm();">
<input type="button" value="Search Now" onclick="document.frm.searchNow.value='true'; document.frm.submit();">
<input type="submit" value="Next &gt;"  onclick="document.frm.searchNow.value='';">
<input type="hidden" name="searchNow">
</td>
</tr>
</table>

<br>
<p><strong>Wildcards:</strong> Use * for zero or more characters, ? for
exactly one character.</p>

</form>
</body>
</html>
