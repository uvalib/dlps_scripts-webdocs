<?php

/*
  search2.php - second page of search interface for goodwill projects - misc criteria
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-11-21
  Last modified: 2006-05-23

  Receives data from: search1.php
  Submits data to: search3.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Goodwill Projects';
$pageTitle = 'Search - Other Criteria';

// connect to db
$connection = connect();

// get associative array representing table 'selectors'
$selectors = getHashSelectors($connection);

// get associative array representing table 'requestors'
$requestors = getHashRequestors($connection);

//-------------------------------------
// process form data from previous page
//-------------------------------------

if ($clear) {
  unset($_SESSION['searchGoodwill']);
  unset($_SESSION['searchGoodwillSql']);
}

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// name
if (empty($projectName)) {
  unset($_SESSION['searchGoodwill']['projectName']);
  unset($_SESSION['searchGoodwillSql']['projectName']);
} else {
  $_SESSION['searchGoodwill']['projectName'] = $projectName;
  $projectNameSql = clean2(translateWildcards($projectName), $connection);
  if (!ereg('%$', $projectNameSql)) { $projectNameSql .= '%'; }
  $_SESSION['searchGoodwillSql']['projectName'] = " AND projectName LIKE '$projectNameSql'";
}

// type
if (empty($typeId)) {
  unset($_SESSION['searchGoodwill']['typeId']);
  unset($_SESSION['searchGoodwillSql']['typeId']);
} else {
  $_SESSION['searchGoodwill']['typeId'] = $typeId;
  $_SESSION['searchGoodwillSql']['typeId'] = " AND typeId = $typeId";
}

// description
if (empty($projectDesc)) {
  unset($_SESSION['searchGoodwill']['projectDesc']);
  unset($_SESSION['searchGoodwillSql']['projectDesc']);
} else {
  $_SESSION['searchGoodwill']['projectDesc'] = $projectDesc;
  $projectDescSql = clean2(translateWildcards($projectDesc), $connection);
  if (!ereg('^%', $projectDescSql)) { $projectDescSql = '%' .  $projectDescSql; }
  if (!ereg('%$', $projectDescSql)) { $projectDescSql .= '%'; }
  $_SESSION['searchGoodwillSql']['projectDesc'] = " AND projectDesc LIKE '$projectDescSql'";
}

// notes
if (empty($notes)) {
  unset($_SESSION['searchGoodwill']['notes']);
  unset($_SESSION['searchGoodwillSql']['notes']);
} else {
  $_SESSION['searchGoodwill']['notes'] = $notes;
  $notesSql = clean2(translateWildcards($notes), $connection);
  if (!ereg('^%', $notesSql)) { $notesSql = '%' .  $notesSql; }
  if (!ereg('%$', $notesSql)) { $notesSql .= '%'; }
  $_SESSION['searchGoodwillSql']['notes'] = " AND notes LIKE '$notesSql'";
}

// redirect to search form, if immediate search was requested
if ($searchNow) {
  header('Location: search.php');
}

//---------------------------
// display form for this page
//---------------------------
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="GET" action="search3.php">
<table cellpadding="4">

<tr>
<td class="label">Selector:</td>
<td><select name="selectorId">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchGoodwill']['selectorId'] == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items from any selector</option>\n";

$selected = '';
if ($_SESSION['searchGoodwill']['selectorId'] == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not from a selector</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($selectors as $id => $name) {
  $selected = '';
  if ( $id == $_SESSION['searchGoodwill']['selectorId'] ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td class="label">Requestor:</td>
<td><select name="requestorId">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchGoodwill']['requestorId'] == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items from any requestor</option>\n";

$selected = '';
if ($_SESSION['searchGoodwill']['requestorId'] == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not from a requestor</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($requestors as $id => $name) {
  $selected = '';
  if ( $id == $_SESSION['searchGoodwill']['requestorId'] ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td class="label">Priority:</td>
<td><select name="priority">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchGoodwill']['priority'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>high</option>\n";

$selected = '';
if ($_SESSION['searchGoodwill']['priority'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>normal</option>\n";

$selected = '';
if ($_SESSION['searchGoodwill']['priority'] == '-1') { $selected = ' selected'; }
echo "<option value='-1'$selected>low</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Date received:</td>
<td><input type="text" name="dateReceivedFrom" size="10" value="<?=$_SESSION['searchGoodwill']['dateReceivedFrom']?>">
to <input type="text" name="dateReceivedTo" size="10" value="<?=$_SESSION['searchGoodwill']['dateReceivedTo']?>"></td>
</tr>

<tr>
<td class="label">Destined for repository:</td>
<td><select name="forRepo">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchGoodwill']['forRepo'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Yes</option>\n";

$selected = '';
if ($_SESSION['searchGoodwill']['forRepo'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>No</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Finished status:</td>
<td><select name="isFinished">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchGoodwill']['isFinished'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Finished</option>\n";

$selected = '';
if ($_SESSION['searchGoodwill']['isFinished'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>Not finished</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Date finished:</td>
<td><input type="text" name="dateFinishedFrom" size="10" value="<?=$_SESSION['searchGoodwill']['dateFinishedFrom']?>">
to <input type="text" name="dateFinishedTo" size="10" value="<?=$_SESSION['searchGoodwill']['dateFinishedTo']?>"></td>
</tr>

<tr>
<td></td>
<td>
<input type="button" value="&lt; Back" onclick="history.back();">
<input type="button" value="Clear" onclick="clearForm();">
<input type="submit" value="Search &gt;">
</td>
</tr>
</table>
</form>
</body>
</html>
