<?php

/*
  search3.php - final page of search interface for goodwill projects -
    processes form data and redirects to search page
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-11-21
  Last modified: 2005-11-23

  Receives data from: search2.php
  Redirects to: search.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$location = 'Location: ../../err/badInput.php?msg=';

// connect to db
$connection = connect();

//-------------------------------------
// process form data from previous page
//-------------------------------------

if ($clear) {
  unset($_SESSION['searchGoodwill']);
  unset($_SESSION['searchGoodwillSql']);
}

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// selector
if (empty($selectorId)) {
  unset($_SESSION['searchGoodwill']['selectorId']);
  unset($_SESSION['searchGoodwillSql']['selectorId']);
} else {
  $_SESSION['searchGoodwill']['selectorId'] = $selectorId;
  $_SESSION['searchGoodwillSql']['selectorId'] = ' AND ';
  if ($selectorId == 'any') {
    // select items from any selector
    $_SESSION['searchGoodwillSql']['selectorId'] .= 'selectorId != 0';
  } elseif ($selectorId == 'none') {
    // select items not assigned to a selector
    $_SESSION['searchGoodwillSql']['selectorId'] .= 'selectorId = 0';
  } else {
    $_SESSION['searchGoodwillSql']['selectorId'] .= "selectorId = $selectorId";
  }
}

// requestor
if (empty($requestorId)) {
  unset($_SESSION['searchGoodwill']['requestorId']);
  unset($_SESSION['searchGoodwillSql']['requestorId']);
} else {
  $_SESSION['searchGoodwill']['requestorId'] = $requestorId;
  $_SESSION['searchGoodwillSql']['requestorId'] = ' AND ';
  if ($requestorId == 'any') {
    // select items from any requestor
    $_SESSION['searchGoodwillSql']['requestorId'] .= 'requestorId != 0';
  } elseif ($requestorId == 'none') {
    // select items not assigned to a requestor
    $_SESSION['searchGoodwillSql']['requestorId'] .= 'requestorId = 0';
  } else {
    $_SESSION['searchGoodwillSql']['requestorId'] .= "requestorId = $requestorId";
  }
}

// priority
if ($priority == '1' or $priority == '0' or $priority == '-1') {
  $_SESSION['searchGoodwill']['priority'] = $priority;
  $_SESSION['searchGoodwillSql']['priority'] = " AND priority = $priority";
} else {
  unset($_SESSION['searchGoodwill']['priority']);
  unset($_SESSION['searchGoodwillSql']['priority']);
}

// destined for repository
if ($forRepo == '0' or $forRepo == '1') {
  $_SESSION['searchGoodwill']['forRepo'] = $forRepo;
  $_SESSION['searchGoodwillSql']['forRepo'] = " AND forRepo = $forRepo";
} else {
  unset($_SESSION['searchGoodwill']['forRepo']);
  unset($_SESSION['searchGoodwillSql']['forRepo']);
}

// date received -- date range start date
if (empty($dateReceivedFrom)) {
  unset($_SESSION['searchGoodwill']['dateReceivedFrom']);
  unset($_SESSION['searchGoodwillSql']['dateReceivedFrom']);
} else {
  $dateReceivedFromISO = formatDateISO($dateReceivedFrom);
  if ( empty($dateReceivedFromISO) ) {
    header($location . urlencode("Value '$dateReceivedFrom' for date received is not a valid date"));
    exit;
  } else {
    $_SESSION['searchGoodwill']['dateReceivedFrom'] = $dateReceivedFrom;
    $_SESSION['searchGoodwillSql']['dateReceivedFrom'] = " AND dateReceived >= '$dateReceivedFromISO'";
  }
}

// date received -- date range end date
if (empty($dateReceivedTo)) {
  unset($_SESSION['searchGoodwill']['dateReceivedTo']);
  unset($_SESSION['searchGoodwillSql']['dateReceivedTo']);
} else {
  $dateReceivedToISO = formatDateISO($dateReceivedTo);
  if ( empty($dateReceivedToISO) ) {
    header($location . urlencode("Value '$dateReceivedTo' for date received is not a valid date"));
    exit;
  } else {
    $_SESSION['searchGoodwill']['dateReceivedTo'] = $dateReceivedTo;
    $_SESSION['searchGoodwillSql']['dateReceivedTo'] = " AND dateReceived <= '$dateReceivedToISO'";
  }
}

// finished status
if ($isFinished == '0' or $isFinished == '1') {
  $_SESSION['searchGoodwill']['isFinished'] = $isFinished;
  $_SESSION['searchGoodwillSql']['isFinished'] = " AND isFinished = $isFinished";
} else {
  unset($_SESSION['searchGoodwill']['isFinished']);
  unset($_SESSION['searchGoodwillSql']['isFinished']);
}

// date finished -- date range start date
if (empty($dateFinishedFrom)) {
  unset($_SESSION['searchGoodwill']['dateFinishedFrom']);
  unset($_SESSION['searchGoodwillSql']['dateFinishedFrom']);
} else {
  $dateFinishedFromISO = formatDateISO($dateFinishedFrom);
  if ( empty($dateFinishedFromISO) ) {
    header($location . urlencode("Value '$dateFinishedFrom' for date finished is not a valid date"));
    exit;
  } else {
    $_SESSION['searchGoodwill']['dateFinishedFrom'] = $dateFinishedFrom;
    $_SESSION['searchGoodwillSql']['dateFinishedFrom'] = " AND dateFinished >= '$dateFinishedFromISO'";
  }
}

// date finished -- date range end date
if (empty($dateFinishedTo)) {
  unset($_SESSION['searchGoodwill']['dateFinishedTo']);
  unset($_SESSION['searchGoodwillSql']['dateFinishedTo']);
} else {
  $dateFinishedToISO = formatDateISO($dateFinishedTo);
  if ( empty($dateFinishedToISO) ) {
    header($location . urlencode("Value '$dateFinishedTo' for date finished is not a valid date"));
    exit;
  } else {
    $_SESSION['searchGoodwill']['dateFinishedTo'] = $dateFinishedTo;
    $_SESSION['searchGoodwillSql']['dateFinishedTo'] = " AND dateFinished <= '$dateFinishedToISO'";
  }
}

// redirect to search form
header('Location: search.php');
?>