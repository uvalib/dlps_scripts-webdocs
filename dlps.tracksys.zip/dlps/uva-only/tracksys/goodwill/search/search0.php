<?php

/*
  search0.php - preliminary page of search interface for goodwill
    projects - clears saved search criteria
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-11-21
  Last modified: 2005-11-21

  Receives data from: Not applicable
  Redirects to: search1.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

unset($_SESSION['searchGoodwill']);
unset($_SESSION['searchGoodwillSql']);

// redirect to first page of search form
header('Location: search1.php');
?>