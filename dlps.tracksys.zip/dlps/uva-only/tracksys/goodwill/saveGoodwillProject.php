<?php

/*
  saveGoodwillProject.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-11-22
  Last modified: 2006-05-23

  Saves user-entered data to database, either by inserting a new
  record or updating an existing record, as appropriate.

  Receives data from: goodwillProjects.php
  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: followSaveGoodwillProject.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

//--------------------
// validate user input
//--------------------

$location = 'Location: ../err/badInput.php?msg=';

// name
if (empty($projectName)) {
  header($location . urlencode('Name of project is required'));
  exit;
}

// type
if (empty($typeId)) {
  header($location . urlencode('Type of project is required'));
  exit;
}

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}

// ID
if ($mode == 'update') {
  if (empty($projectId)) {
    header($location . urlencode('Project ID is required'));
    exit;
  }
}

// number of DVDs must be an integer
$dvdTotal = trim($dvdTotal);
if ($dvdTotal) {
  if (! preg_match('/^\d+$/', $dvdTotal) ) {
    header($location . urlencode("If provided, 'Total number of DVDs' must be a whole number"));
    exit;
  }
}

// date received
if (!empty($dateReceived)) {
  $test = formatDateISO($dateReceived);
  if ( empty($test) ) {
    header($location . urlencode("Value '$dateReceived' for Date Received is not a valid date"));
    exit;
  } else {
    $dateReceived = $test;
  }
}

// date finished
if (!empty($dateFinished)) {
  $test = formatDateISO($dateFinished);
  if ( empty($test) ) {
    header($location . urlencode("Value '$dateFinished' for Date Finished is not a valid date"));
    exit;
  } else {
    $dateFinished = $test;
  }
}


// connect to db
$connection = connect();

// prep user input
$projectName = clean2($projectName, $connection, $projectNameMaxLength);
$projectDesc = clean2($projectDesc, $connection, $projectDescMaxLength);
$notes = clean2($notes, $connection);


//--------------------
// build SQL statement
//--------------------

if ($mode == 'update') {
  if ($chkDelete) {
    testPerm('goodwillDelete');
    $mode = 'delete';
    $sql = "DELETE FROM goodwillProjects";
  } else {
    testPerm('goodwillUpdate');
    $sql = "UPDATE goodwillProjects SET";
  }
  $where = " WHERE projectId = $projectId";
} else {
  testPerm('goodwillInsert');
  $sql = "INSERT INTO goodwillProjects SET";
  $where = '';
}

if ($mode == 'delete') {
  $values = '';
} else {
  if (empty($projectName)) { $value = "NULL"; } else { $value = "'$projectName'"; }
  $values = " projectName = $value";

  if (empty($typeId)) { $value = "0"; } else { $value = $typeId; }
  $values .= ", typeId = $value";

  if (empty($projectDesc)) { $value = "NULL"; } else { $value = "'$projectDesc'"; }
  $values .= ", projectDesc = $value";

  if (empty($selectorId)) { $value = "0"; } else { $value = $selectorId; }
  $values .= ", selectorId = $value";

  if (empty($requestorId)) { $value = "0"; } else { $value = $requestorId; }
  $values .= ", requestorId = $value";

  // can't use empty() for priority, because string "0" evaluates to true (is empty);
  // instead, test explicitly for appropriate values
  if ( ($priority == '-1') || ($priority == '0') || ($priority == '1') ) {
    $values .= ", priority = $priority";
  }

  if (empty($dvdTotal)) { $value = "0"; } else { $value = $dvdTotal; }
  $values .= ", dvdTotal = $value";

  if (empty($dateReceived)) { $value = "NULL"; } else { $value = "'$dateReceived'"; }
  $values .= ", dateReceived = $value";

  if (empty($forRepo)) { $value = "0"; } else { $value = "1"; }
  $values .= ", forRepo = $value";

  if (empty($notes)) { $value = "NULL"; } else { $value = "'$notes'"; }
  $values .= ", notes = $value";

  if (empty($isFinished)) { $value = "0"; } else { $value = "1"; }
  $values .= ", isFinished = $value";

  if (empty($dateFinished)) { $value = "NULL"; } else { $value = "'$dateFinished'"; }
  $values .= ", dateFinished = $value";
}

$sql .= $values . $where;


//----------------------
// execute SQL statement
//----------------------

if ( mysql_query($sql, $connection) ) {
  if ( $mode == 'insert' ) {
    $projectId = mysql_insert_id();
  }
  $affected = mysql_affected_rows();

  // store SQL statement in session variable for later display in debugging mode
  $_SESSION['saveGoodwillProject']['sql'] = $sql;

  // redirect, indicating success
  header("Location: followSaveGoodwillProject.php?mode=$mode&projectId=$projectId&affected=$affected");
} else {
  die($dbErrorPreface . "Unable to $mode goodwill project '$projectName': " . mysql_error($connection) . "<br><br>$sql");
}

?>