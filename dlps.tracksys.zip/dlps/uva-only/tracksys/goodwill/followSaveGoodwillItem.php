<?php

/*
  followSaveGoodwillItem.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-10-25
  Last modified: 2005-11-23

  This page is displayed upon successful insert/update of a goodwill
  item. It simply displays non-editable values for the record.

  Receives data from: saveGoodwillItem.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/auth.php';

$siteArea = 'Goodwill Projects';
$pageTitle = "Update Status";

// connect to db
$connection = connect();

// get associative array representing table 'goodwillProjects'
$goodwillProjects = getHashGoodwillProjects($connection);

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
// get data from database and display for confirmation
$sql = "SELECT * FROM goodwillItems WHERE dlpsId = '$dlpsId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) == 1 ) {
  if ($mode == 'delete') {
    echo "<p class='error'>WARNING: The text item was <b>not</b> deleted (ID: $dlpsId).
      Contact the $appTitle administrator.</p>
      </body></html>";
    exit;
  }

  if ($affected == '0') {
    echo "<p class='updated'>No changes were needed.</p>";
  } else {
    if ($mode == 'insert') {
      echo "<p class='updated'>New item added successfully</p>\n";
    } else {
      echo "<p class='updated'>Item updated successfully</p>\n";
    }
  }
  $row = mysql_fetch_array($result);
?>

<table cellpadding='6' cellspacing='0'>
<tr>
<td class='label'>Item ID:</td>
<td><?=$row['dlpsId']?></td>
</tr>

<?php
  $goodwillProject = '';
  foreach ($goodwillProjects as $id => $name) {
    if ($row['projectId'] == $id) {
      $goodwillProject = $name;
    }
  }
?>
<tr>
<td class='label'>Goodwill project:</td>
<td><?=$goodwillProject?></td>
</tr>

<tr>
<td class='label'>Title:</td>
<td><?=$row['title']?></td>
</tr>

<tr>
<td class='label'>Volume or issue number:</td>
<td><?=$row['volumeNumber']?></td>
</tr>

<tr>
<td class='label' valign='top'>Notes:</td>
<td><pre><?=$row['notes']?></pre></td>
</tr>
</table>

<?php
} else {
  if ($mode == 'delete') {
    echo "<p class='updated'>Record deleted successfully.</p>\n";
  } else {
    echo "<p>Item ID '$dlpsId' not found in database. Contact the $appTitle administrator.</p>\n";
  }
}  // END if ( mysql_num_rows($result) == 1 ) ... else ...

if (getPerm('goodwillInsert')) {
  echo "<p><a href='goodwillItem.php'>Add new item</a></p>\n";
} else {
  echo "<p><span class='disabled'>Add new item</span></p>\n";
}

if ($mode == 'update') { $again = ' again'; } else { $again = ''; }
if ($mode != 'delete') {
  echo "<p><a href='goodwillItem.php?dlpsId=$dlpsId'>Edit this item$again</a></p>\n";
}
?>
<p><a href='search/search.php'>Return to search results</a></p>
</body>
</html>
