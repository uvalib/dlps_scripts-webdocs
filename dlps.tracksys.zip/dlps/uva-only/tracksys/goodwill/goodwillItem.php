<?php

/*
  goodwillItem.php - shows data pertaining to a particular item from a goodwill project
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-10-06
  Last modified: 2005-11-30

  If a DLPS ID is passed on the query string, this page serves as an
  edit-existing-item form. Otherwise, it serves as an enter-new-item
  form.

  Posts to: saveGoodwillItem.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

$siteArea = 'Goodwill Projects';

// connect to db
$connection = connect();

// get associative array representing table 'goodwillProjects'
$goodwillProjects = getHashGoodwillProjects($connection);

// set defaults
switch ($typeId) {
  case GOODWILL_TYPE_ARCHIVING:
    $itemId = $itemName;
    $idField = 'itemName';
    $itemType = 'Archiving';
    $onload = ' onload="document.frm.itemName.focus();"';
    break;
  case GOODWILL_TYPE_IMAGE:
    $itemId = $itemName;
    $idField = 'itemName';
    $itemType = 'Image';
    $onload = ' onload="document.frm.itemName.focus();"';
    break;
  case GOODWILL_TYPE_TEXT:
    $itemId = $dlpsId;
    $idField = 'dlpsId';
    $itemType = 'Text';
    $onload = ' onload="document.frm.dlpsId.focus();"';
    break;
}

if ( empty($itemId) ) {
  // enter new item
  $mode = 'insert';
  $pageTitle = "Add $itemType Item to Project";
  $submitCaption = ' Add ';
  $required = "<span class='required'>(required)</span>";

  // test permissions
  testPerm('goodwillInsert');
} else {
  // edit existing item
  $mode = 'update';
  $pageTitle = "Edit $itemType Item";
  $submitCaption = 'Update';
  $onload = '';

  // test permissions; need Select to view item details, Update to enable submit button
  testPerm('goodwillSelect');
  if (!getPerm('goodwillUpdate')) { $submitAppearance = ' disabled'; }
}

$itemType = strtolower($itemType);

// get data for item to be edited, if in update mode
if ($mode == 'update') {
  $sql = "SELECT * FROM goodwillItems WHERE $idField = '$itemId' AND projectId = $projectId";
  $result = query($sql, $connection);
  if (mysql_num_rows($result) == 1) {
    $row = mysql_fetch_array($result);
  } else {
    die($dbErrorPreface . "Item ID '$dlpsId' does not exist");
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
<script type="text/javascript" src="../inc/tracksys.js"></script>
</head>
<body<?=$onload?>>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
if ($mode == 'update' and $debugMode) {
  echo "<p>$sql</p>\n";
}

if ($deleteEnabled and $mode == 'update' and getPerm('goodwillDelete')) {
  $onSubmit = " onsubmit='return confirmDelete(document.frm, \"$itemType item from the project\");'";
}
if ($mode == 'insert' and getPerm('goodwillInsert')) {
  $onSubmit = " onsubmit='return testDlpsId(document.frm.dlpsId.value);'";
}
?>
<form name="frm" method="POST" action="saveGoodwillItem.php"<?=$onSubmit?>>

<table cellpadding="4">

<?php
if ($typeId == GOODWILL_TYPE_TEXT) {
  // text item; only show DLPS ID field
  echo <<<END
<tr>
<td class='label'>DLPS ID:</td>
<td><input type='text' name='dlpsId' maxlength='$dlpsIdMaxLength' value='$row[dlpsId]'>
$required
<input type='hidden' name='originalDlpsId' value='$row[dlpsId]'>
</td>
</tr>
END;

} else {
  // not a text item; show all fields except DLPS ID
  echo <<<END
<tr>
<td class='label'>Name:</td>
<td><input type='text' name='itemName' maxlength='$nameMaxLength' value='$row[itemName]'>
$required
<input type='hidden' name='originalItemName' value='$row[itemName]'>
</td>
</tr>

<tr>
<td class='label'>Description:</td>
<td><input type='text' name='itemDesc' size='60' maxlength='$descMaxLength' value='$row[itemDesc]'></td>
</tr>
END;

  if ($typeId == GOODWILL_TYPE_ARCHIVING) {
    if ($row['dvdCount'] == 0) {
      $dvdCount = '';
    } else {
      $dvdCount = $row['dvdCount'];
    }
    echo <<<END
<tr>
<td class='label'>Number of DVDs:</td>
<td><input type='text' name='dvdCount' size='4' maxlength='4' value='$dvdCount'></td>
</tr>
END;
  }

  if ($mode == 'insert') {
    //$dateReceived = date("n/j/Y");  // today's date as m/d/yyyy
    $dateReceived = '';
  } else {
    if (empty($row['dateReceived'])) {
      $dateReceived = '';
    } else {
      if ($row['dateReceived'] == '0000-00-00') {
	$dateReceived = '';
      } else {
	if ( preg_match('/\d{4}-\d{2}-\d{2}/', $row['dateReceived']) ) {
	  $dateReceived = formatDateUS($row['dateReceived']);
	} else {
	  $dateReceived = $row['dateReceived'];
	}
      }
    }
  }
  echo <<<END
<tr>
<td class='label'>Date received:</td>
<td><input type='text' name='dateReceived' size='10' maxlength='10' value='$dateReceived'></td>
</tr>

<tr>
<td class='label' style='vertical-align: top'>Notes:</td>
<td><textarea name='notes' cols='60' rows='6'>$row[notes]</textarea></td>
</tr>
END;

  if ($row['isFinished']) {
    $isFinishedChecked = ' checked';
  }
  echo <<<END
<tr>
<td class='label' valign='top'>Finished:</td>
<td><input type='checkbox' name='isFinished'$isFinishedChecked> </td>
</tr>
END;

  if ($mode == 'insert') {
    $dateFinished = '';
  } else {
    if (empty($row['dateFinished'])) {
      $dateFinished = '';
    } else {
      if ($row['dateFinished'] == '0000-00-00') {
	$dateFinished = '';
      } else {
	if ( preg_match('/\d{4}-\d{2}-\d{2}/', $row['dateFinished']) ) {
	  $dateFinished = formatDateUS($row['dateFinished']);
	} else {
	  $dateFinished = $row['dateFinished'];
	}
      }
    }
  }
  echo <<<END
<tr>
<td class='label'>Date finished:</td>
<td><input type='text' name='dateFinished' size='10' maxlength='10' value='$dateFinished'></td>
</tr>
END;
}  // END if ($typeId == GOODWILL_TYPE_TEXT) { ... } else { ... }

if ($deleteEnabled and $mode == 'update' and getPerm('goodwillDelete')) {
  if ($typeId == GOODWILL_TYPE_TEXT) {
    $temp = 'from project';
  } else {
    $temp = '';
  }
  echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'>
Delete $itemType item $temp</td>
</tr>\n";
}
?>

<tr>
<td></td>
<td>
<input type="submit" name="go" value="<?=$submitCaption?>"<?=$submitAppearance?>>
<input type="reset" value="Reset">
<input type="button" value="Cancel" onclick="history.back();">
</td>
</tr>
</table>
<input type='hidden' name='mode' value='<?=$mode?>'>
<input type='hidden' name='projectId' value='<?=$projectId?>'>
<input type='hidden' name='typeId' value='<?=$typeId?>'>
</form>
</body>
</html>
