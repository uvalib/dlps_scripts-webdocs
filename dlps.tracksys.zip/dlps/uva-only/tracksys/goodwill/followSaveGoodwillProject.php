<?php

/*
  followSaveGoodwillProject.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-11-22
  Last modified: 2005-11-30

  This page is displayed upon successful insert/update of a project. It
  simply displays non-editable values for the record.

  Receives data from: saveGoodwillProject.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/auth.php';

$siteArea = 'Goodwill Projects - Setup';
$pageTitle = 'Project - Update Status';

// connect to db
$connection = connect();

// get associative array representing table 'goodwillProjectTypes'
$types = getHashGoodwillProjectTypes($connection);

// get associative array representing table 'selectors'
$selectors = getHashSelectors($connection);

// get associative array representing table 'requestors'
$requestors = getHashRequestors($connection);

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
if ($debugMode) {
  echo "<p>" . $_SESSION['saveGoodwillProject']['sql'] . "</p>\n";
}

// get data from database and display for confirmation
$sql = "SELECT * FROM goodwillProjects WHERE projectId = '$projectId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) == 1 ) {
  if ($mode == 'delete') {
    echo "<p class='error'>WARNING: The project was <b>not</b> deleted (project ID: $projectId).
      Contact the $appTitle administrator.</p>
      </body></html>";
    exit;
  }

  if ($affected == '0') {
    echo "<p class='updated'>No changes were needed.</p>";
  } else {
    if ($mode == 'insert') {
      echo "<p class='updated'>New project added successfully</p>\n";
    } else {
      echo "<p class='updated'>Project updated successfully</p>\n";
    }
  }
  $row = mysql_fetch_array($result);
?>

<table cellpadding='6' cellspacing='0'>
<tr>
<td class='label'>Name:</td>
<td><?=$row['projectName']?></td>
</tr>

<?php
  $typeName = '';
  foreach ($types as $id => $name) {
    if ($row['typeId'] == $id) {
      $typeName = $name;
    }
  }
?>
<tr>
<td class='label'>Type:</td>
<td><?=$typeName?></td>
</tr>

<tr>
<td class='label'>Description:</td>
<td><?=$row['projectDesc']?></td>
</tr>

<?php
  $selectorName = '';
  foreach ($selectors as $id => $name) {
    if ($row['selectorId'] == $id) {
      $selectorName = $name;
    }
  }
?>
<tr>
<td class='label'>Selector:</td>
<td><?=$selectorName?></td>
</tr>

<?php
  $requestorName = '';
  foreach ($requestors as $id => $name) {
    if ($row['requestorId'] == $id) {
      $requestorName = $name;
    }
  }
?>
<tr>
<td class='label'>Requestor:</td>
<td><?=$requestorName?></td>
</tr>

<?php
  switch ($row['priority']) {
    case -1:
      $priority = 'low';
      break;
    case 1:
      $priority = 'high';
      break;
    default:
      $priority = 'normal';
  }
?>
<tr>
<td class='label'>Priority:</td>
<td><?=$priority?></td>
</tr>

<?php
  if ($row['dvdTotal'] == 0) {
    $dvdTotal = '';
  } else {
    $dvdTotal = $row['dvdTotal'];
  }
  echo <<<END
<tr>
<td class='label'>Total number of DVDs:</td>
<td>$dvdTotal</td>
</tr>
END;
?>

<tr>
<td class='label'>Date received:</td>
<td><?=formatDateUS($row['dateReceived'])?></td>
</tr>

<?php
  if ($row['forRepo'] == 1) {
    $forRepoChecked = ' checked';
  }
?>
<tr>
<td class='label'>Destined for repository:</td>
<td><input type='checkbox'<?=$forRepoChecked?> disabled> </td>
</tr>

<tr>
<td class='label' valign='top'>Notes:</td>
<td><pre><?=formatNotes($row['notes'])?></pre></td>
</tr>

<?php
  if ($row['isFinished'] == 1) {
    $isFinishedChecked = ' checked';
  }
?>
<tr>
<td class='label'>Finished:</td>
<td><input type='checkbox'<?=$isFinishedChecked?> disabled> </td>
</tr>

<tr>
<td class='label'>Date finished:</td>
<td><?=formatDateUS($row['dateFinished'])?></td>
</tr>
</table>

<?php
} else {
  if ($mode == 'delete') {
    echo "<p class='updated'>Project deleted successfully.</p>\n";
  } else {
    echo "<p>Project ID '$projectId' not found in database. Contact the $appTitle administrator.</p>\n";
  }
}  // END if ( mysql_num_rows($result) == 1 ) ... else ...

echo "<p>";

if (getPerm('goodwillInsert')) {
  echo "<a href='goodwillProjects.php?projectId=new'>Enter new project</a>";
} else {
  echo "<span class='disabled'>Enter new project</span>";
}

if ($mode == 'update') { $again = ' again'; } else { $again = ''; }
if ($mode != 'delete') {
  echo "<br><a href='goodwillProjects.php?projectId=$projectId'>Edit this project$again</a>";
}
?>
<br><a href='goodwillProjects.php'>Browse projects</a>
<br><a href='search/search.php'>Return to search results</a>
</p>
</body>
</html>
