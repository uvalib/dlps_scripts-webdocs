<?php

/*
  goodwillProjects.php - page for managing goodwill projects
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-11-22
  Last modified: 2005-11-30

  If no 'projectId' parameter, lists projects already defined.
  If ID is 'new', displays add-new form for defining a project.
  If ID is a number, displays edit form for editing an existing project.
*/

import_request_variables('PG');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

$siteArea = 'Goodwill Projects';

// connect to db
$connection = connect();

// get associative array representing table 'goodwillProjectTypes'
$types = getHashGoodwillProjectTypes($connection);

// get associative array representing table 'selectors'
$selectors = getHashSelectors($connection);

// get associative array representing table 'requestors'
$requestors = getHashRequestors($connection);

if ( empty($projectId) ) {
  // list existing projects
  $pageTitle = 'Projects';
  testPerm('goodwillSelect');
} else {
  if ($projectId == 'new') {
    // display enter-new form
    $mode = 'insert';
    $pageTitle = 'Enter New Project';
    $submitCaption = ' Add ';
    $required = "<span class='required'>(required)</span>";

    // test permissions
    testPerm('goodwillInsert');
  } else {
    // display edit form
    $mode = 'update';
    $pageTitle = 'Edit Project';
    $submitCaption = 'Update';

    // test permissions; need Select to view item details, Update to enable submit button
    testPerm('goodwillSelect');
    if (!getPerm('goodwillUpdate')) { $submitAppearance = ' disabled'; }
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
<script type="text/javascript" src="../inc/tracksys.js"></script>
</head>

<?php
if ( empty($projectId) ) {
  // list existing projects

  if (getPerm('goodwillInsert')) {
    $addNewLink = "<p><a href='?projectId=new'>Enter new project</a></p>";
  } else {
    $addNewLink = "<p><span class='disabled'>Enter new project</span></p>";
  }
?>

<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<?=$addNewLink?>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>Name</td>
<td>Type</td>
<td>Description</td>
</tr>

<?php
  $sql = "SELECT * FROM goodwillProjects ORDER BY projectName";
  $result = query($sql, $connection);
  $num = mysql_num_rows($result);
  if ($num == 0) { echo "<tr><td cols='2'><b>0</b> items</td></tr>\n"; }
  while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);

      $typeName = '';
      foreach ($types as $id => $name) {
	if ($row['typeId'] == $id) {
	  $typeName = $name;
	}
      }

      echo "<tr$class>
<td><a href='?projectId=$row[projectId]'>$row[projectName]</a></td>
<td>$typeName</td>
<td>$row[projectDesc]</td>
</tr>\n";
  }
  echo "</table>\n";
}  // END if ( empty($projectId) )

else {
  if ($mode == 'update') {
    $sql = "SELECT * FROM goodwillProjects WHERE projectId = '$projectId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $projectId = $row['projectId'];
    }
  }

  if ($deleteEnabled and $mode == 'update' and getPerm('goodwillDelete')) {
    $onSubmit = " onsubmit='return confirmDelete(document.frm, \"Goodwill Project\");'";
  }
?>

<body onload='document.frm.projectName.focus();'>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
  // display status message, if we're returning here after saveGoodwillItem.php
  if (!empty($status)) {
    echo "<p class='updated'>";
    if ($affected == '0') {
      echo "No changes were needed.";
    } else {
      if ($status == 'insert') {
        echo "New item added successfully";
      } elseif ($status == 'delete') {
	echo "Item deleted successfully";
      } else {
        echo "Item updated successfully";
      }
    }
    echo "</p>\n";

    if ($debugMode) {
      echo "<p>" . $_SESSION['saveGoodwillItem']['sql'] . "</p>\n";
    }
  }
?>

<form name='frm' method='POST' action='saveGoodwillProject.php'<?=$onSubmit?>>
<input type='hidden' name='mode' value='<?=$mode?>'>
<input type='hidden' name='projectId' value='<?=$projectId?>'>
<table cellpadding='4'>
<tr>
<td class='label'>Name:</td>
<td>
<input type='text' name='projectName' size='40' value='<?=$row[projectName]?>' maxlength='<?=$projectNameMaxLength?>'>
<?=$required?></td>
</tr>

<tr>
<td class="label">Type:</td>
<td class="nowrap"><select name="typeId">
<option value='0'></option>
<?php
  foreach ($types as $typeId => $name) {
    $selected = '';
    if ( ! empty($row['typeId']) ) {
      if ( $typeId == $row['typeId'] ) { $selected = ' selected'; }
    }
    echo "<option value='$typeId'$selected>$name</option>\n";
  }
?>
</select>
<?=$required?></td>
</tr>

<tr>
<td class='label'>Description:</td>
<td><input type='text' name='projectDesc' value='<?=$row[projectDesc]?>' size='60' maxlength='<?=$projectDescMaxLength?>'></td>
</tr>

<tr>
<td class="label">Selector:</td>
<td class="nowrap"><select name="selectorId">
<option value='0'></option>
<?php
  foreach ($selectors as $selectorId => $name) {
    $selected = '';
    if ( ! empty($row['selectorId']) ) {
      if ( $selectorId == $row['selectorId'] ) { $selected = ' selected'; }
    }
    echo "<option value='$selectorId'$selected>$name</option>\n";
  }
?>
</select>
</td>
</tr>

<tr>
<td class="label">Requestor:</td>
<td class="nowrap"><select name="requestorId">
<option value='0'></option>
<?php
  foreach ($requestors as $requestorId => $name) {
    $selected = '';
    if ( ! empty($row['requestorId']) ) {
      if ( $requestorId == $row['requestorId'] ) { $selected = ' selected'; }
    }
    echo "<option value='$requestorId'$selected>$name</option>\n";
  }
?>
</select>
</td>
</tr>

<tr>
<td class="label">Priority:</td>
<td><select name="priority">
<?php
  if ( empty($row['priority']) ) {
    $selectedNormal = ' selected';
  } else {
    switch ($row['priority']) {
      case -1:
        $selectedLow = ' selected';
        break;
      case 1:
        $selectedHigh = ' selected';
        break;
      default:
        $selectedNormal = ' selected';
    }
  }
echo <<<END
<option value='1'$selectedHigh>high</option>
<option value='0'$selectedNormal>normal</option>
<option value='-1'$selectedLow>low</option>
END;
?>
</select></td>
</tr>

<?php
  if ($row['dvdTotal'] == 0) {
    $dvdTotal = '';
  } else {
    $dvdTotal = $row['dvdTotal'];
  }
  echo <<<END
<tr>
<td class='label'>Total number of DVDs:</td>
<td><input type='text' name='dvdTotal' size='4' maxlength='4' value='$dvdTotal'></td>
</tr>
END;

  if ($mode == 'insert') {
    //$dateReceived = date("n/j/Y");  // today's date as m/d/yyyy
    $dateReceived = '';
  } else {
    if (empty($row['dateReceived'])) {
      $dateReceived = '';
    } else {
      if ($row['dateReceived'] == '0000-00-00') {
	$dateReceived = '';
      } else {
	if ( preg_match('/\d{4}-\d{2}-\d{2}/', $row['dateReceived']) ) {
	  $dateReceived = formatDateUS($row['dateReceived']);
	} else {
	  $dateReceived = $row['dateReceived'];
	}
      }
    }
  }
?>
<tr>
<td class="label">Date received:</td>
<td><input type="text" name="dateReceived" size="10" maxlength="10" value="<?=$dateReceived?>"></td>
</tr>

<?php
  if ($row['forRepo']) {
    $forRepoChecked = ' checked';
  }
?>
<tr>
<td class="label" valign="top">Destined for repository:</td>
<td><input type="checkbox" name="forRepo"<?=$forRepoChecked?>> </td>
</tr>

<tr>
<td class="label" style="vertical-align: top">Notes:</td>
<td><textarea name="notes" cols="60" rows="6"><?=$row['notes']?></textarea></td>
</tr>

<?php
  if ($row['isFinished']) {
    $isFinishedChecked = ' checked';
  }
?>
<tr>
<td class="label" valign="top">Finished:</td>
<td><input type="checkbox" name="isFinished"<?=$isFinishedChecked?>> </td>
</tr>

<?php
  if ($mode == 'insert') {
    $dateFinished = '';
  } else {
    if (empty($row['dateFinished'])) {
      $dateFinished = '';
    } else {
      if ($row['dateFinished'] == '0000-00-00') {
	$dateFinished = '';
      } else {
	if ( preg_match('/\d{4}-\d{2}-\d{2}/', $row['dateFinished']) ) {
	  $dateFinished = formatDateUS($row['dateFinished']);
	} else {
	  $dateFinished = $row['dateFinished'];
	}
      }
    }
  }
?>
<tr>
<td class="label">Date finished:</td>
<td><input type="text" name="dateFinished" size="10" maxlength="10" value="<?=$dateFinished?>"></td>
</tr>

<?php
  if ($deleteEnabled and $mode == 'update' and getPerm('goodwillDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>

<tr>
<td></td>
<td>
<input type='submit' name='go' value='<?=$submitCaption?>'<?=$submitAppearance?>>
<input type='button' value='Cancel' onclick='history.back();'>
</td>
</tr>

<?php
  if ($mode == 'update') {

    if ($row['typeId'] == GOODWILL_TYPE_ARCHIVING) {

      //--------------------------------------------------
      // list archiving items associated with this project
      //--------------------------------------------------

      if (getPerm('goodwillUpdate')) {
        $addNewLink = "<a href='goodwillItem.php?projectId=$projectId&typeId=$row[typeId]'>Add archiving item to project</a>";
      } else {
	$addNewLink = "<span class='disabled'>Add archiving item to project</span>";
      }
?>
<tr>
<td colspan="2"><hr></td>
</tr>
<tr>
<td colspan="2">

  <h3>Archiving Items in This Project</h3>
  <p><?=$addNewLink?></p>

  <table cellpadding="6" cellspacing="0" class="list">
  <tr class="head">
  <td>Name</td>
  <td>Description</td>
  <td>DVDs</td>
  <td>Date Received</td>
  <td>Date Finished</td>
  </tr>

<?php
      $typeId = $row['typeId'];

      $sql = "SELECT * FROM goodwillItems WHERE projectId = $projectId ORDER BY dlpsId";
      $result = query($sql, $connection);
      $num = mysql_num_rows($result);
      if ($num == 0) { echo "<tr><td colspan='2'><b>0</b> items</td></tr>\n"; }
      while ( $row = mysql_fetch_array($result) ) {
	$c++;
	$class = getRowClass($c);
	$temp = urlencode($row['itemName']);
        if ($row['dvdCount'] == 0) { $dvdCount = ''; } else { $dvdCount = $row['dvdCount']; }
	$dateReceived = formatDateUS($row['dateReceived']);
	$dateFinished = formatDateUS($row['dateFinished']);
	echo "  <tr$class>
  <td><a href='goodwillItem.php?itemName=$temp&projectId=$row[projectId]&typeId=$typeId'>$row[itemName]</a></td>
  <td>$row[itemDesc]</td>
  <td>$dvdCount</td>
  <td>$dateReceived</td>
  <td>$dateFinished</td>
  </tr>\n";
      }
    }  // END if ($row['typeId'] == GOODWILL_TYPE_ARCHIVING)

    if ($row['typeId'] == GOODWILL_TYPE_TEXT) {

      //---------------------------------------------
      // list text items associated with this project
      //---------------------------------------------

      if (getPerm('goodwillUpdate')) {
        $addNewLink = "<a href='goodwillItem.php?projectId=$projectId&typeId=$row[typeId]'>Add text item to project</a>";
      } else {
	$addNewLink = "<span class='disabled'>Add text item to project</span>";
      }
?>
<tr>
<td colspan="2"><hr></td>
</tr>
<tr>
<td colspan="2">

  <h3>Text Items in This Project</h3>
  <p><?=$addNewLink?></p>

  <table cellpadding="6" cellspacing="0" class="list">
  <tr class="head">
  <td>DLPS ID</td>
  <td>Title</td>
  <td>Volume</td>
  <td>Author</td>
  <td>View text item</td>
  </tr>

<?php
      $typeId = $row['typeId'];

      $sql = "SELECT goodwillItems.dlpsId, goodwillItems.projectId,
        textItems.title, textItems.volumeNumber, textItems.authorNameLast, textItems.authorNameFirst
        FROM goodwillItems LEFT JOIN textItems USING (dlpsId)
        WHERE goodwillItems.projectId = $projectId ORDER BY goodwillItems.dlpsId";
      $result = query($sql, $connection);
      $num = mysql_num_rows($result);
      if ($num == 0) { echo "<tr><td colspan='2'><b>0</b> items</td></tr>\n"; }
      while ( $row = mysql_fetch_array($result) ) {
	$c++;
	$class = getRowClass($c);
	$author = formatName($row['authorNameLast'], $row['authorNameFirst']);
	echo "  <tr$class>
  <td><a href='goodwillItem.php?dlpsId=$row[dlpsId]&projectId=$row[projectId]&typeId=$typeId'>$row[dlpsId]</a></td>
  <td>$row[title]</td>
  <td>$row[volumeNumber]</td>
  <td>$author</td>
  <td><a href='../text/textItem.php?dlpsId=$row[dlpsId]'>View text item</a></td>
  </tr>\n";
      }
    }  // END if ($row['typeId'] == GOODWILL_TYPE_TEXT)
?>

  </table>
</td>
</tr>

<?php
  } // END if ($mode == 'update')
?>


</table>
</form>
<?php
}  // END if ( empty($projectId) ) { ... } else
?>
</body>
</html>
