<?php

/*
  nav.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-06-21
  Last modified: 2006-05-30

  Main navigation page. Provides a link for each major page/area of
  the application.
*/

import_request_variables('G');
include 'inc/tracksys.php';

if ($loginMode) {
  session_start();
}
?>
<html>
<head>
<title><?=$appTitle?></title>
<link rel="stylesheet" type="text/css" href="inc/nav.css">
<base target="content">
</head>
<body>
<table cellpadding="2">
<tr><td><a href="start.php" class="navHeadingMain"><span class="navHeadingMain"><?=$appTitle?></span></a></td></tr>

<?php

//============================
// Module Group: Text Tracking
//============================

if ($moduleGroup == 'text') {
  echo "<tr><td class='moduleGroupFirst'>Text Tracking</td></tr>\n";
} else {
  echo "<tr><td class='moduleGroupFirst'><a href='nav.php?moduleGroup=text&module=text' target='nav'>";
  echo "<span class='headingMain'>Text Tracking</span></a></td></tr>\n";
}

if ($moduleGroup == 'text') {

  //----------------------
  // Module: Text Workflow
  //----------------------

  if ($module == 'text') {
    echo "<tr><td class='module'>Text Workflow</td></tr>\n";
  } else {
    echo "<tr><td class='module'><a href='nav.php?moduleGroup=text&module=text' target='nav'>";
    echo "<span class='headingMain'>Text Workflow</span></a></td></tr>\n";
  }

  if ($module == 'text') {
?>
<tr><td><a class="indent2" href="text/newTextItem.php">Enter New Item</a></td></tr>
<tr><td><a class="indent2" href="text/search/search0.php">Search</a></td></tr>
<tr><td><a class="indent2" href="text/exportTextItems.php">Export</a></td></tr>

<tr><td class="moduleSection">Setup</td></tr>

<tr><td><a class="indent3" href="text/setup/sets/sets.php">Multi-volume Sets</a></td></tr>
<tr><td><a class="indent3" href="text/setup/projects/projects.php">Projects</a></td></tr>
<tr><td><a class="indent3" href="text/setup/groups/groups.php">Groups</a></td></tr>
<tr><td><a class="indent3" href="text/setup/batches/batches.php">Vendor Batches</a></td></tr>
<tr><td><a class="indent3" href="text/setup/selectors/selectors.php">Selectors</a></td></tr>
<tr><td><a class="indent3" href="text/setup/requestors/requestors.php">Requestors</a></td></tr>
<tr><td><a class="indent3" href="text/setup/pageImagesResps/pageImagesResps.php">Page-image Creators</a></td></tr>
<tr><td><a class="indent3" href="text/setup/transcriptionResps/transcriptionResps.php">Text Creators</a></td></tr>

<?php
  }  // END if ($module == 'text')

  //-------------------------------
  // Module: EAF Supplementary Data
  //-------------------------------

  if ($module == 'eafSupp') {
    echo "<tr><td class='module'>EAF Supplementary Data</td></tr>\n";
  } else {
    echo "<tr><td class='module'><a href='nav.php?moduleGroup=text&module=eafSupp' target='nav'>";
    echo "<span class='headingMain'>EAF Supplementary Data</span></a></td></tr>\n";
  }

  if ($module == 'eafSupp') {
?>

<!--<tr><td><a class="indent2" href="eaf/eafSupp.php">Enter New Data</a></td></tr>-->
<tr><td><a class="indent2" href="eaf/search/search0.php">Search</a></td></tr>

<?php
  }  // END if ($module == 'eafSupp')
}  // END if ($moduleGroup == 'text')
?>


<tr><td><hr noshade></td></tr>


<?php

//=============================
// Module Group: Image Tracking
//=============================

if ($moduleGroup == 'image') {
  echo "<tr><td class='moduleGroup'>Image Tracking</td></tr>\n";
} else {
  echo "<tr><td class='moduleGroup'><a href='nav.php?moduleGroup=image&module=imageProjects' target='nav'>";
  echo "<span class='headingMain'>Image Tracking</span></a></td></tr>\n";
}

if ($moduleGroup == 'image') {

  //-----------------------
  // Module: Image Projects
  //-----------------------

  if ($module == 'imageProjects') {
    echo "<tr><td class='module'>Image Projects</td></tr>\n";
  } else {
    echo "<tr><td class='module'><a href='nav.php?moduleGroup=image&module=imageProjects' target='nav'>";
    echo "<span class='headingMain'>Image Projects</span></a></td></tr>\n";
  }

  if ($module == 'imageProjects') {
?>
<tr><td><a class="indent2" href="imageProjects/imageProjects.php?projectId=new">Enter New Project</a></td></tr>
<tr><td><a class="indent2" href="imageProjects/imageProjects.php">Browse</a></td></tr>
<tr><td><a class="indent2" href="imageProjects/search/search0.php">Search</a></td></tr>

<tr><td class="moduleSection">Setup</td></tr>

<tr><td><a class="indent3" href="imageProjects/setup/imageProjectContacts/contacts.php">Contact Persons</a></td></tr>

<?php
   }  // END if ($module == 'imageProjects')
}  // END if ($moduleGroup == 'image')
?>


<tr><td><hr noshade></td></tr>


<?php

//=============================
// Module Group: Other Tracking
//=============================

if ($moduleGroup == 'other') {
  echo "<tr><td class='moduleGroup'>Other Tracking</td></tr>\n";
} else {
  echo "<tr><td class='moduleGroup'><a href='nav.php?moduleGroup=other&module=archivalDiscs' target='nav'>";
  echo "<span class='headingMain'>Other Tracking</span></a></td></tr>\n";
}

if ($moduleGroup == 'other') {

  //-----------------------
  // Module: Archival Discs
  //-----------------------

  if ($module == 'archivalDiscs') {
    echo "<tr><td class='module'>Archival Discs</td></tr>\n";
  } else {
    echo "<tr><td class='module'><a href='nav.php?moduleGroup=other&module=archivalDiscs' target='nav'>";
    echo "<span class='headingMain'>Archival Discs</span></a></td></tr>\n";
  }

  if ($module == 'archivalDiscs') {
?>

<tr><td><a class="indent2" href="archivalDiscs/setupImportRimageLog.php">Import Rimage Log Files</a></td></tr>
<tr><td><a class="indent2" href="archivalDiscs/archivalDisc.php">Enter New Disc</a></td></tr>
<tr><td><a class="indent2" href="archivalDiscs/search/search0.php">Search</a></td></tr>

<tr><td class="moduleSection">Setup</td></tr>

<tr><td><a class="indent3" href="archivalDiscs/setup/rooms/rooms.php">Rooms</a></td></tr>

<?php
  }  // END if ($module == 'archivalDiscs')

  //--------------------------
  // Module: Goodwill Projects
  //--------------------------

  if ($module == 'goodwill') {
    echo "<tr><td class='module'>Goodwill Projects</td></tr>\n";
  } else {
    echo "<tr><td class='module'><a href='nav.php?moduleGroup=other&module=goodwill' target='nav'>\n";
    echo "<span class='headingMain'>Goodwill Projects</span></a></td></tr>\n";
  }

  if ($module == 'goodwill') {
?>

<tr><td><a class="indent2" href="goodwill/goodwillProjects.php?projectId=new">Enter New Project</a></td></tr>
<tr><td><a class="indent2" href="goodwill/goodwillProjects.php">Browse</a></td></tr>
<tr><td><a class="indent2" href="goodwill/search/search0.php">Search</a></td></tr>

<tr><td class="moduleSection">Setup</td></tr>

<tr><td><a class="indent3" href="goodwill/setup/goodwillProjectTypes/types.php">Project Types</a></td></tr>

<?php
  }  // END if ($module == 'goodwill')

  //---------------------------
  // Module: Migration Projects
  //---------------------------

  if ($_SESSION['username'] == 'debug') {

  if ($module == 'migration') {
    echo "<tr><td class='module'>Migration Projects [alpha]</td></tr>\n";
  } else {
    echo "<tr><td class='module'><a href='nav.php?moduleGroup=other&module=migration' target='nav'>";
    echo "<span class='headingMain'>Migration Projects [alpha]</span></a></td></tr>\n";
  }

  if ($module == 'migration') {
?>

<tr><td><a class="indent2" href="migration/migration.php">Enter New Item</a></td></tr>
<tr><td><a class="indent2" href="migration/search/search0.php">Search</a></td></tr>

<?php
  }  // END if ($module == 'migration')
  }  // END if ($_SESSION['username'] == 'debug')
}  // END if ($moduleGroup == 'other')
?>

</table>
</body>
</html>
