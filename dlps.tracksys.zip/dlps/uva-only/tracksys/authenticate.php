<?php

/*
  authenticate.php - validates username and password submitted by user
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-05-11
  Last modified: 2006-01-27

  Receives data from: login.php
  If username and password are not valid, redirects to: err/badInput.php
  If username and password are valid, redirects to: start.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the authentication process transparent to the
  user and helps avoid the possibility of the user re-submitting the
  same data by refreshing the browser.
*/

session_start();
import_request_variables('P');
include 'inc/tracksys.php';
include 'inc/maxlengths.php';

// validate user input

$location = 'Location: err/badInput.php?msg=';

// username
if (empty($username)) {
  header($location . urlencode('Username is required')); exit;
}

// password
if (empty($password)) {
  header($location . urlencode('Password is required')); exit;
}

// connect to db
$connection = connect();

$sql =  "SELECT userAliases.alias, users.username FROM userAliases LEFT JOIN users USING (userId) ";
$sql .= "WHERE userAliases.alias = '$username' AND userAliases.password = '$password'";
$result = query($sql, $connection);
if (mysql_num_rows($result) == 1) {
  $row = mysql_fetch_array($result);

  // set session variables
  $_SESSION['username'] = $row['username'];
  $_SESSION['alias'] = $row['alias'];

  // redirect to start page
  header("Location: start.php"); exit;
} else {
  // redirect to error page
  header($location . urlencode('Username or password is invalid')); exit;
}

?>