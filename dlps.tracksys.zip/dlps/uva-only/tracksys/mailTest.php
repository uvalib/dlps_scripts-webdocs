<?php

$to = 'gpm2a@virginia.edu';
$headers = "From: gpm2a@virginia.edu";
$subject = "mail test";
$body = "Test.\n";
$body = wordwrap($body, 70);
mail($to, $subject, $body, $headers);

?>
<p>Mail sent.</p>
