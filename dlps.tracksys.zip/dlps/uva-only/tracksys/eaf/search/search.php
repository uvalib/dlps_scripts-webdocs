<?php

/*
  search.php - queries database and displays search results
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-10-04
  Last modified: 2005-10-07

*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to db
$connection = connect();

testPerm('eafSuppSelect');
$siteArea = 'Text Workflow - EAF Supplementary Data';
$pageTitle = 'Search Results';

//-------------------------
// prepare SQL query string
//-------------------------

// use a left (outer) join, since textItems might or might not contain corresponding rows
$sql = 'SELECT eafSupp.*, textItems.title, textItems.volumeNumber';
$sql .= ' FROM eafSupp LEFT JOIN textItems USING (dlpsId)';

$where = '';

// basic criteria
$where .= $_SESSION['searchEafSql']['dlpsId'];
$where .= $_SESSION['searchEafSql']['eafNumber'];
$where .= $_SESSION['searchEafSql']['xmlFilename'];
$where .= $_SESSION['searchEafSql']['loadedItemName'];
$where .= $_SESSION['searchEafSql']['notes'];

// misc criteria
$where .= $_SESSION['searchEafSql']['subset'];
$where .= $_SESSION['searchEafSql']['access'];
$where .= $_SESSION['searchEafSql']['isOnPrintList'];
$where .= $_SESSION['searchEafSql']['pagesChecked'];
$where .= $_SESSION['searchEafSql']['iviewBuilt'];
$where .= $_SESSION['searchEafSql']['rescansNeeded'];
$where .= $_SESSION['searchEafSql']['rescanPages'];
$where .= $_SESSION['searchEafSql']['rescansFinished'];
$where .= $_SESSION['searchEafSql']['isMissingCovers'];
$where .= $_SESSION['searchEafSql']['fixedCDs'];

if (!empty($where)) {
  $where = preg_replace('/^ +AND +/', '', $where);  // remove the initial ' AND'
  $sql .= ' WHERE ' . $where;
}

// sort order
if ( $_GET['orderBy'] ) {
  $orderBy = $_GET['orderBy'];
} elseif ( $_SESSION['searchEaf']['orderBy'] ) {
  $orderBy = $_SESSION['searchEaf']['orderBy'];
} else {
  $orderBy = 'dlpsId';
}
$_SESSION['searchEaf']['orderBy'] = $orderBy;
switch ($orderBy) {
  case 'dlpsId':
    $_SESSION['searchEafSql']['orderBy'] = ' ORDER BY dlpsId';
    break;
  case 'title':
    $_SESSION['searchEafSql']['orderBy'] = ' ORDER BY title, volumeNumber, dlpsId';
    break;
  default:
    $_SESSION['searchEafSql']['orderBy'] = " ORDER BY $orderBy, dlpsId";
}
$sql .= $_SESSION['searchEafSql']['orderBy'];

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
<script type="text/javascript">
function setCheckboxes(onOrOff) {
  for (i = 0; i < document.frm.elements.length; i++) {
    if (document.frm.elements[i].type == "checkbox") {
      document.frm.elements[i].checked = onOrOff;
    }
  }
}
</script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
if ($debugMode) {
  echo "<p>$sql</p>\n";
}

// execute query
$result = query($sql, $connection);

$num = mysql_num_rows($result);
if ($num == 1) { $plural = ''; } else { $plural = 's'; }
echo "<p>Found <b>$num</b> item$plural</p>\n";

$newSearchLink = "<p><a href='search1.php'>Adjust this search</a><br>
<a href='search0.php'>Start a new search</a></p>\n";
echo $newSearchLink;

if ($num >= 1) {
  echo "<form name='frm' method='POST'>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>&nbsp;</td>\n";

  if ($orderBy == 'dlpsId') {
    echo "<td><i>DLPS ID</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=dlpsId'>DLPS ID</a></td>\n";
  }

  if ($orderBy == 'title') {
    echo "<td><i>Title</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=title'>Title</a></td>\n";
  }

  echo "<td>Volume</td>\n";

  if ($orderBy == 'subset') {
    echo "<td><i>Subset</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=subset'>Subset</a></td>\n";
  }

  if ($orderBy == 'access') {
    echo "<td><i>Access</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=access'>Access</a></td>\n";
  }

  $colspan = 6;

  if (!empty($_SESSION['searchEafSql']['eafNumber'])) {
    if ($orderBy == 'eafNumber') {
      echo "<td><i>EAF number</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=eafNumber'>EAF number</a></td>\n";
    }
    $colspan++;
  }

  if (!empty($_SESSION['searchEafSql']['xmlFilename'])) {
    if ($orderBy == 'xmlFilename') {
      echo "<td><i>XML filename</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=xmlFilename'>XML filename</a></td>\n";
    }
    $colspan++;
  }

  if (!empty($_SESSION['searchEafSql']['loadedItemName'])) {
    if ($orderBy == 'loadedItemName') {
      echo "<td><i>Loaded item number</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=loadedItemName'>Loaded item number</a></td>\n";
    }
    $colspan++;
  }

  echo "<td>&nbsp;</td>\n";
  echo "</tr>\n";

  $c = 1;
  $class = getRowClass($c);
  $colspan--;
  echo "<tr$class>
<td style='white-space: nowrap'>
<img name='checkAll' src='../../img/check.gif' hspace='0' onclick='setCheckboxes(true);' title='Check All'>
<img name='clearAll' border='0' src='../../img/square.gif' hspace='0' onclick='setCheckboxes(false);' title='Clear All'>
</td>
<td colspan='$colspan'>&nbsp;</td>
</tr>\n";

  // display query results
  while ( $row = mysql_fetch_array($result) ) {
    $c++;
    $class = getRowClass($c);
    $subset = getEafSubset($row['subset']);
    $access = getEafAccess($row['access']);
    echo "<tr$class>
<td><input type='checkbox' name='dlpsId_$row[dlpsId]' checked></td>
<td><a href='../eafSupp.php?dlpsId=$row[dlpsId]'>$row[dlpsId]</a></td>
<td>$row[title]</td>
<td style='white-space: nowrap'>$row[volumeNumber]</td>
<td>$subset</td>
<td>$access</td>\n";

    if (!empty($_SESSION['searchEaf']['eafNumber'])) {
      echo "<td>$row[eafNumber]</td>\n";
    }

    if (!empty($_SESSION['searchEaf']['xmlFilename'])) {
      echo "<td>$row[xmlFilename]</td>\n";
    }

    if (!empty($_SESSION['searchEaf']['loadedItemName'])) {
      echo "<td>$row[loadedItemName]</td>\n";
    }

    if ($row['title']) {
      echo "<td><a href='../../text/textItem.php?dlpsId=$row[dlpsId]'>View&nbsp;text&nbsp;item</a></td>\n";
    } else {
      echo "<td>&nbsp;</td>\n";
    }
    echo "</tr>\n";
  }
  echo "</table>

<!--
<p> </p>
<table cellpadding='4' border='0'>
<tr>
<td class='tableSectionHeading' colspan='2'>Actions:</td>
</tr>

<tr>
<td align='right'>View checked items:
<select name='workflow'>
<option value='bookScanning'>Book scanning workflow</option>
<option value='migration'>Migration workflow</option>
<option value='teiHeader'>TEI header workflow</option>
<option value='postkb'>Post-keyboarding workflow</option>
<option value='markupQA'>Markup QA workflow</option>
<option value='finalization'>Finalization workflow</option>
</select>
</td>
<td valign='bottom'>
<input type='submit' value='View Workflow' onclick='return setFormAction(document.frm);'>
<input type='hidden' name='orderBy' value='$orderBy'>
</td>
</tr>
</table>
-->
</form>\n";
echo $newSearchLink;
}  // END if ($num >= 1)
?>
</body>
</html>
