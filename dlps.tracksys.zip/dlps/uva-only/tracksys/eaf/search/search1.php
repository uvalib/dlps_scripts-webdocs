<?php

/*
  search1.php - first page of search interface for EAF supplementary data - basic criteria
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-10-04
  Last modified: 2005-10-07

  Submits data to: search2.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow - EAF Supplementary Data';
$pageTitle = 'Search - Basic Criteria';

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body onload="document.frm.dlpsId.focus();">
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<form name="frm" method="GET" action="search2.php">
<table cellpadding="4">
<tr>
<td class="label">DLPS ID:</td>
<td><input type="text" name="dlpsId" value="<?=$_SESSION['searchEaf']['dlpsId']?>"></td>
</tr>

<tr>
<td class="label">EAF number:</td>
<td><input type="text" name="eafNumber" value="<?=$_SESSION['searchEaf']['eafNumber']?>"></td>
</tr>

<tr>
<td class="label">XML filename:</td>
<td><input type="text" name="xmlFilename" value="<?=$_SESSION['searchEaf']['xmlFilename']?>"></td>
</tr>

<tr>
<td class="label">Loaded item number:</td>
<td><input type="text" name="loadedItemName" value="<?=$_SESSION['searchEaf']['loadedItemName']?>"></td>
</tr>


<tr>
<td class="label">Notes:</td>
<td><input type="text" name="notes" value="<?=$_SESSION['searchEaf']['notes']?>"></td>
</tr>

<tr>
<td></td>
<td>
<input type="button" value="Clear" onclick="clearForm();">
<input type="button" value="Search Now" onclick="document.frm.searchNow.value='true'; document.frm.submit();">
<input type="submit" value="Next &gt;"  onclick="document.frm.searchNow.value='';">
<input type="hidden" name="searchNow">
</td>
</tr>
</table>

<br>
<p><strong>Wildcards:</strong> Use * for zero or more characters, ? for
exactly one character.</p>

<p><strong>DLPS ID:</strong> To search for multiple DLPS IDs, enter
the IDs separated by commas or semicolons.</p>

</form>
</body>
</html>
