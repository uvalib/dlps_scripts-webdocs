<?php

/*
  search0.php - preliminary page of search interface for EAF
    supplementary data - clears saved search criteria
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-10-04
  Last modified: 2005-10-04

  Receives data from: Not applicable
  Redirects to: search1.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

unset($_SESSION['searchEaf']);
unset($_SESSION['searchEafSql']);

// redirect to first page of search form
header('Location: search1.php');
?>