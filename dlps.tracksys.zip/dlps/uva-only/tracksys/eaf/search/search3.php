<?php

/*
  search3.php - final page of search interface for EAF supplementary
    data - processes form data and redirects to search page
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-10-04
  Last modified: 2006-05-23

  Receives data from: search2.php
  Redirects to: search.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$location = 'Location: ../../err/badInput.php?msg=';

// connect to db
$connection = connect();

//-------------------------------------
// process form data from previous page
//-------------------------------------

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// subset
if ($subset == '0' or $subset == '1' or $subset == '2') {
  $_SESSION['searchEaf']['subset'] = $subset;
  $_SESSION['searchEafSql']['subset'] = " AND subset = $subset";
} else {
  unset($_SESSION['searchEaf']['subset']);
  unset($_SESSION['searchEafSql']['subset']);
}

// access
if ($access == '0' or $access == '1' or $access == '2') {
  $_SESSION['searchEaf']['access'] = $access;
  $_SESSION['searchEafSql']['access'] = " AND eafSupp.access = $access";
} else {
  unset($_SESSION['searchEaf']['access']);
  unset($_SESSION['searchEafSql']['access']);
}

// print list
if ($isOnPrintList == '0' or $isOnPrintList == '1') {
  $_SESSION['searchEaf']['isOnPrintList'] = $isOnPrintList;
  $_SESSION['searchEafSql']['isOnPrintList'] = " AND isOnPrintList = $isOnPrintList";
} else {
  unset($_SESSION['searchEaf']['isOnPrintList']);
  unset($_SESSION['searchEafSql']['isOnPrintList']);
}

// pages checked
if ($pagesChecked == '0' or $pagesChecked == '1') {
  $_SESSION['searchEaf']['pagesChecked'] = $pagesChecked;
  $_SESSION['searchEafSql']['pagesChecked'] = " AND pagesChecked = $pagesChecked";
} else {
  unset($_SESSION['searchEaf']['pagesChecked']);
  unset($_SESSION['searchEafSql']['pagesChecked']);
}

// number of pages missing
if (empty($numberOfPagesMissing)) {
  unset($_SESSION['searchEaf']['numberOfPagesMissing']);
  unset($_SESSION['searchEafSql']['numberOfPagesMissing']);
} else {
  if ( preg_match('/^\d+$/', $numberOfPagesMissing) ) {
    $_SESSION['searchEaf']['numberOfPagesMissing'] = $numberOfPagesMissing;
    $_SESSION['searchEafSql']['numberOfPagesMissing'] = " AND numberOfPagesMissing = $numberOfPagesMissing";
  } else {
    header($location . urlencode("'Number of text pages missing' must be a whole number."));
    exit;
  }
}

// iView catalog built
if ($iviewBuilt == '0' or $iviewBuilt == '1') {
  $_SESSION['searchEaf']['iviewBuilt'] = $iviewBuilt;
  $_SESSION['searchEafSql']['iviewBuilt'] = " AND iviewBuilt = $iviewBuilt";
} else {
  unset($_SESSION['searchEaf']['iviewBuilt']);
  unset($_SESSION['searchEafSql']['iviewBuilt']);
}

// rescans needed
if ($rescansNeeded == '0' or $rescansNeeded == '1') {
  $_SESSION['searchEaf']['rescansNeeded'] = $rescansNeeded;
  $_SESSION['searchEafSql']['rescansNeeded'] = " AND rescansNeeded = $rescansNeeded";
} else {
  unset($_SESSION['searchEaf']['rescansNeeded']);
  unset($_SESSION['searchEafSql']['rescansNeeded']);
}

// rescan pages
if (empty($rescanPages)) {
  unset($_SESSION['searchEaf']['rescanPages']);
  unset($_SESSION['searchEafSql']['rescanPages']);
} else {
  $_SESSION['searchEaf']['rescanPages'] = $rescanPages;
  $rescanPagesSql = clean2(translateWildcards($rescanPages), $connection);
  if (!ereg('^%', $rescanPagesSql)) { $rescanPagesSql = '%' .  $rescanPagesSql; }
  if (!ereg('%$', $rescanPagesSql)) { $rescanPagesSql .= '%'; }
  $_SESSION['searchEafSql']['rescanPages'] = " AND rescanPages LIKE '$rescanPagesSql'";
}

// rescans finished
if ($rescansFinished == '0' or $rescansFinished == '1') {
  $_SESSION['searchEaf']['rescansFinished'] = $rescansFinished;
  $_SESSION['searchEafSql']['rescansFinished'] = " AND rescansFinished = $rescansFinished";
} else {
  unset($_SESSION['searchEaf']['rescansFinished']);
  unset($_SESSION['searchEafSql']['rescansFinished']);
}

// number of rescans
if (empty($numberOfRescans)) {
  unset($_SESSION['searchEaf']['numberOfRescans']);
  unset($_SESSION['searchEafSql']['numberOfRescans']);
} else {
  if ( preg_match('/^\d+$/', $numberOfRescans) ) {
    $_SESSION['searchEaf']['numberOfRescans'] = $numberOfPagesRescans;
    $_SESSION['searchEafSql']['numberOfRescans'] = " AND numberOfRescans = $numberOfRescans";
  } else {
    header($location . urlencode("'Number of images rescanned' must be a whole number."));
    exit;
  }
}

// missing covers
if ($isMissingCovers == '0' or $isMissingCovers == '1') {
  $_SESSION['searchEaf']['isMissingCovers'] = $isMissingCovers;
  $_SESSION['searchEafSql']['isMissingCovers'] = " AND isMissingCovers = $isMissingCovers";
} else {
  unset($_SESSION['searchEaf']['isMissingCovers']);
  unset($_SESSION['searchEafSql']['isMissingCovers']);
}

// fixed CDs
if (empty($fixedCDs)) {
  unset($_SESSION['searchEaf']['fixedCDs']);
  unset($_SESSION['searchEafSql']['fixedCDs']);
} else {
  if ( preg_match('/^\d\d?$/', $fixedCDs) ) {
    $_SESSION['searchEaf']['fixedCDs'] = $fixedCDs;
    $_SESSION['searchEafSql']['fixedCDs'] = " AND fixedCDs = $fixedCDs";
  } else {
    header($location . urlencode("'Fixed CDs' must be a 1-digit or 2-digit number."));
    exit;
  }
}

// redirect to search form
header('Location: search.php');
?>