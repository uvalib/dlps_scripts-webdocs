<?php

/*
  search2.php - second page of search interface for EAF supplementary data - misc criteria
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-10-04
  Last modified: 2006-05-23

  Receives data from: search1.php
  Submits data to: search3.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow - EAF Supplementary Data';
$pageTitle = 'Search - Other Criteria';

// connect to db
$connection = connect();

//-------------------------------------
// process form data from previous page
//-------------------------------------

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// DLPS ID
if (empty($dlpsId)) {
  unset($_SESSION['searchEaf']['dlpsId']);
  unset($_SESSION['searchEafSql']['dlpsId']);
} else {
    $_SESSION['searchEaf']['dlpsId'] = $dlpsId;
    //$dlpsId = normalizeDlpsId($dlpsId);
    $dlpsId = clean2($dlpsId, $connection);

  // check for comma or semicolon indicating multiple DLPS IDs to search for
  if (ereg('[,;]', $dlpsId)) {
    $dlpsIds = preg_split('/[,;] ?/', $dlpsId);
    $like = '';
    foreach($dlpsIds as $id) {
      if (!empty($id)) {
        $id = translateWildcards($id);
        if (!ereg('%$', $id)) { $id .= '%'; }
        $like .= "(eafSupp.dlpsId LIKE '$id') OR ";
      }
    }
    $like = preg_replace('/ OR $/', '', $like);
    $_SESSION['searchEafSql']['dlpsId'] = " AND $like";
  } else {
    $dlpsIdSql = translateWildcards($dlpsId);
    if (!ereg('%$', $dlpsIdSql)) { $dlpsIdSql .= '%'; }
    $_SESSION['searchEafSql']['dlpsId'] = " AND eafSupp.dlpsId LIKE '$dlpsIdSql'";
  }
}

// EAF number
if (empty($eafNumber)) {
  unset($_SESSION['searchEaf']['eafNumber']);
  unset($_SESSION['searchEafSql']['eafNumber']);
} else {
  $_SESSION['searchEaf']['eafNumber'] = $eafNumber;
  $eafNumberSql = clean2(translateWildcards($eafNumber), $connection);
  if (!ereg('%$', $eafNumberSql)) { $eafNumberSql .= '%'; }
  $_SESSION['searchEafSql']['eafNumber'] = " AND eafNumber LIKE '$eafNumberSql'";
}

// XML filename
if (empty($xmlFilename)) {
  unset($_SESSION['searchEaf']['xmlFilename']);
  unset($_SESSION['searchEafSql']['xmlFilename']);
} else {
  $_SESSION['searchEaf']['xmlFilename'] = $xmlFilename;
  $xmlFilenameSql = clean2(translateWildcards($xmlFilename), $connection);
  if (!ereg('%$', $xmlFilenameSql)) { $xmlFilenameSql .= '%'; }
  $_SESSION['searchEafSql']['xmlFilename'] = " AND xmlFilename LIKE '$xmlFilenameSql'";
}

// loaded item name
if (empty($loadedItemName)) {
  unset($_SESSION['searchEaf']['loadedItemName']);
  unset($_SESSION['searchEafSql']['loadedItemName']);
} else {
  $_SESSION['searchEaf']['loadedItemName'] = $loadedItemName;
  $loadedItemNameSql = clean2(translateWildcards($loadedItemName), $connection);
  if (!ereg('%$', $loadedItemNameSql)) { $loadedItemNameSql .= '%'; }
  $_SESSION['searchEafSql']['loadedItemName'] = " AND loadedItemName LIKE '$loadedItemNameSql'";
}

// notes
if (empty($notes)) {
  unset($_SESSION['searchEaf']['notes']);
  unset($_SESSION['searchEafSql']['notes']);
} else {
  $_SESSION['searchEaf']['notes'] = $notes;
  $notesSql = clean2(translateWildcards($notes), $connection);
  if (!ereg('^%', $notesSql)) { $notesSql = '%' .  $notesSql; }
  if (!ereg('%$', $notesSql)) { $notesSql .= '%'; }
  $_SESSION['searchEafSql']['notes'] = " AND eafSupp.notes LIKE '$notesSql'";
}

// redirect to search form, if immediate search was requested
if ($searchNow) {
  header('Location: search.php');
}

//---------------------------
// display form for this page
//---------------------------
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="GET" action="search3.php">
<table cellpadding="4">

<tr>
<td class="label">Subset:</td>
<td><select name="subset">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchEaf']['subset'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>EAF 1</option>\n";

$selected = '';
if ($_SESSION['searchEaf']['subset'] == '2') { $selected = ' selected'; }
echo "<option value='2'$selected>EAF 2</option>\n";

$selected = '';
if ($_SESSION['searchEaf']['subset'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>Subset unknown</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Access:</td>
<td><select name="access">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchEaf']['access'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Private</option>\n";

$selected = '';
if ($_SESSION['searchEaf']['access'] == '2') { $selected = ' selected'; }
echo "<option value='2'$selected>Public</option>\n";

$selected = '';
if ($_SESSION['searchEaf']['access'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>Access uknown</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">On print list?</td>
<td><select name="isOnPrintList">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchEaf']['isOnPrintList'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Yes</option>\n";

$selected = '';
if ($_SESSION['searchEaf']['isOnPrintList'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>No</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Pages checked?</td>
<td><select name="pagesChecked">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchEaf']['pagesChecked'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Yes</option>\n";

$selected = '';
if ($_SESSION['searchEaf']['pagesChecked'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>No</option>\n";
?>
</select></td>
</tr>

<!--
<tr>
<td class="label">Number of text pages missing:</td>
<td><input type="text" name="numberOfPagesMissing" size="5" maxlength="5" value="<?=$_SESSION['searchEaf']['numberOfPagesMissing']?>"></td>
</tr>
-->

<tr>
<td class="label">iView catalog built?</td>
<td><select name="iviewBuilt">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchEaf']['iviewBuilt'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Yes</option>\n";

$selected = '';
if ($_SESSION['searchEaf']['iviewBuilt'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>No</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Rescans needed?</td>
<td><select name="rescansNeeded">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchEaf']['rescansNeeded'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Yes</option>\n";

$selected = '';
if ($_SESSION['searchEaf']['rescansNeeded'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>No</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Pages to rescan:</td>
<td><input type="text" name="rescanPages" value="<?=$_SESSION['searchEaf']['rescanPages']?>"></td>
</tr>

<tr>
<td class="label">Rescans finished?</td>
<td><select name="rescansFinished">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchEaf']['rescansFinished'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Yes</option>\n";

$selected = '';
if ($_SESSION['searchEaf']['rescansFinished'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>No</option>\n";
?>
</select></td>
</tr>

<!--
<tr>
<td class="label">Number of images rescanned:</td>
<td><input type="text" name="numberOfRescans" size="5" maxlength="5" value="<?=$_SESSION['searchEaf']['numberOfRescans']?>"></td>
</tr>
-->

<tr>
<td class="label">Covers missing?</td>
<td><select name="isMissingCovers">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchEaf']['isMissingCovers'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Yes</option>\n";

$selected = '';
if ($_SESSION['searchEaf']['isMissingCovers'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>No</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Fixed CDs:</td>
<td><input type="text" name="fixedCDs" size="3" value="<?=$_SESSION['searchEaf']['fixedCDs']?>"></td>
</tr>

<tr>
<td></td>
<td>
<input type="button" value="&lt; Back" onclick="history.back();">
<input type="button" value="Clear" onclick="clearForm();">
<input type="submit" value="Search &gt;">
</td>
</tr>
</table>
</form>
</body>
</html>
