<?php

/*
  eafSupp.php - shows supplementary data pertaining to EAF items
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-10-03
  Last modified: 2005-10-27

  If a DLPS ID is passed on the query string, this page serves as an
  edit-existing-item form. Otherwise, it serves as an enter-new-item
  form.

  Posts to: saveEafSupp.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Text Workflow - EAF Supplementary Data';

// set defaults
if ( empty($dlpsId) ) {
  // enter new item
  $mode = 'insert';
  $pageTitle = 'Enter New Record';
  $onload = ' onload="document.frm.dlpsId.focus();"';
  $submitCaption = ' Add ';

  // test permissions
  testPerm('eafSuppInsert');
} else {
  // edit existing item
  $mode = 'update';
  $pageTitle = 'Edit Record';
  $onload = '';
  $submitCaption = 'Update';
  $returnToSearchResults = "<p><a href='search/search.php'>Return to search results</a></p>\n";

  // test permissions; need Select to view item details, Update to enable submit button
  testPerm('eafSuppSelect');
  if (!getPerm('eafSuppUpdate')) { $submitAppearance = ' disabled'; }
}

// determine whether item exists in table textItems
if (!empty($dlpsId)) {
  $sql = "SELECT dlpsId FROM textItems WHERE dlpsId = '$dlpsId'";
  $result = query($sql, $connection);
  if (mysql_num_rows($result) == 1) {
    $viewTextItem = "<p><a href='../text/textItem.php?dlpsId=$dlpsId'>View text item</a></p>\n";
  }
}

// get data for item to be edited, if in update mode
if (!empty($dlpsId)) {
  $sql = "SELECT * FROM eafSupp WHERE dlpsId = '$dlpsId'";
  $result = query($sql, $connection);
  if (mysql_num_rows($result) == 1) {
    $row = mysql_fetch_array($result);
  } else {
    die($dbErrorPreface . "DLPS ID '$dlpsId' does not exist in table 'eafSupp'");
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>

<?php
if ($deleteEnabled and $mode == 'update' and getPerm('eafSuppDelete')) {
  $onSubmit = " onsubmit='return confirmDelete(document.frm, \"EAF Supplementary Data\");'";
}
if ($mode == 'insert' and getPerm('eafSuppInsert')) {
  $onSubmit = " onsubmit='return testDlpsId(document.frm.dlpsId.value);'";
}
?>
<body<?=$onload?>>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<?=$returnToSearchResults?>
<?=$viewTextItem?>
<form name="frm" method="POST" action="saveEafSupp.php"<?=$onSubmit?>>
<table cellpadding="4">
<?php

if ($mode == 'insert') {
  // include DLPS ID entry textbox
  echo <<<END
<tr>
<td class='label'>DLPS ID:</td>
<td><input type='text' name='dlpsId' maxlength='$dlpsIdMaxLength'>
<span class='required'>(required)</span></td>
</tr>
END;
} else {
  // DLPS ID is not editable here
  echo <<<END
<tr>
<td class='label'>DLPS ID:</td>
<td>$row[dlpsId] <input type='hidden' name='dlpsId' value='$row[dlpsId]'>
END;
  echo "</td>
</tr>\n";
}

?>
<tr>
<td class="label">EAF number:</td>
<td><input type="text" name="eafNumber" maxlength="20" value="<?=$row['eafNumber']?>"></td>
</tr>

<tr>
<td class="label">Subset:</td>
<td><select name="subset">
<option value=''></option>
<?php
if ($row['subset'] == 1) { $selected = ' selected'; } else { $selected = ''; }
echo "<option value='1'$selected>EAF 1</option>\n";

if ($row['subset'] == 2) { $selected = ' selected'; } else { $selected = ''; }
echo "<option value='2'$selected>EAF 2</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Access:</td>
<td><select name="access">
<option value=''></option>
<?php
if ($row['access'] == 1) { $selected = ' selected'; } else { $selected = ''; }
echo "<option value='1'$selected>Private</option>\n";

if ($row['access'] == 2) { $selected = ' selected'; } else { $selected = ''; }
echo "<option value='2'$selected>Public</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">XML filename:</td>
<td><input type="text" name="xmlFilename" maxlength="20" value="<?=$row['xmlFilename']?>"></td>
</tr>

<tr>
<td class="label">Number of text pages missing:</td>
<?php
if ($row['numberOfPagesMissing'] == 0) {
  $numberOfPagesMissing = '';
} else {
  $numberOfPagesMissing = $row['numberOfPagesMissing'];
}
?>
<td>
<input type="text" name="numberOfPagesMissing" size="5" maxlength="5" value="<?=$numberOfPagesMissing?>">
</td>
</tr>

<tr>
<td class="label">Loaded item number:</td>
<td><input type="text" name="loadedItemName" maxlength="20" value="<?=$row['loadedItemName']?>"></td>
</tr>

<tr>
<td class="label"></td>
<?php
if ($row['isOnPrintList'] == 1) { $checked = ' checked'; } else { $checked = ''; }
echo "<td><input type='checkbox' name='isOnPrintList'$checked> On print list?</td>\n";
?>
</tr>

<tr>
<td class="label"></td>
<?php
if ($row['pagesChecked'] == 1) { $checked = ' checked'; } else { $checked = ''; }
echo "<td><input type='checkbox' name='pagesChecked'$checked> Pages checked?</td>\n";
?>
</tr>

<tr>
<td class="label"></td>
<?php
if ($row['iviewBuilt'] == 1) { $checked = ' checked'; } else { $checked = ''; }
echo "<td><input type='checkbox' name='iviewBuilt'$checked> iView catalog built?</td>\n";
?>
</tr>

<tr>
<td class="label"></td>
<?php
if ($row['rescansNeeded'] == 1) { $checked = ' checked'; } else { $checked = ''; }
echo "<td><input type='checkbox' name='rescansNeeded'$checked> Rescans needed?</td>\n";
?>
</tr>

<tr>
<td class="label">Pages to rescan:</td>
<td><input type="text" name="rescanPages" size="60" maxlength="100" value="<?=$row['rescanPages']?>"></td>
</tr>

<tr>
<td class="label"></td>
<?php
if ($row['rescansFinished'] == 1) { $checked = ' checked'; } else { $checked = ''; }
echo "<td><input type='checkbox' name='rescansFinished'$checked> Rescans finished?</td>\n";
?>
</tr>

<tr>
<td class="label">Number of images rescanned:</td>
<?php
if ($row['numberOfRescans'] == 0) {
  $numberOfRescans = '';
} else {
  $numberOfRescans = $row['numberOfRescans'];
}
?>
<td>
<input type="text" name="numberOfRescans" size="5" maxlength="5" value="<?=$numberOfRescans?>">
</td>
</tr>

<tr>
<td class="label"></td>
<?php
if ($row['isMissingCovers'] == 1) { $checked = ' checked'; } else { $checked = ''; }
echo "<td><input type='checkbox' name='isMissingCovers'$checked> Covers missing?</td>\n";
?>
</tr>

<tr>
<td class="label">Fixed CDs:</td>
<?php
if ($row['fixedCDs'] == 0) { $fixedCDs = ''; } else { $fixedCDs = $row['fixedCDs']; }
?>
<td><input type="text" name="fixedCDs" size="3" maxlength="2" value="<?=$fixedCDs?>"></td>
</tr>

<tr>
<td class="label" style="vertical-align: top">Notes:</td>
<td><textarea name="notes" cols="60" rows="6"><?=$row['notes']?></textarea></td>
</tr>

<?php
/*
  if ($deleteEnabled and $mode == 'update' and getPerm('eafSuppDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
*/
?>

<tr>
<td></td>
<td>
<input type="submit" name="go" value="<?=$submitCaption?>"<?=$submitAppearance?>>
<input type="reset" value="Reset">
<input type="button" value="Cancel" onclick="history.back();">
</td>
</tr>
</table>
<input type='hidden' name='mode' value='<?=$mode?>'>
</form>
<?=$returnToSearchResults?>
</body>
</html>
