<?php

/*
  saveEafSupp.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-10-05
  Last modified: 2005-10-27

  Saves user-entered data to database, either by inserting a new
  record or updating an existing record, as appropriate.

  Receives data from: eafSupp.php
  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: followSaveEafSupp.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

//--------------------
// validate user input
//--------------------

$location = 'Location: ../err/badInput.php?msg=';

// DLPS ID
if (empty($dlpsId)) {
  header($location . urlencode('DLPS ID is required'));
  exit;
}

if (! preg_match('/^[A-Za-z0-9\_\-\.]+$/', $dlpsId) ) {
  header($location . urlencode('DLPS ID is invalid. DLPS ID must contain only letters, numbers, underscore, hyphen, or period.'));
  exit;
}

// number of pages missing
$numberOfPagesMissing = trim($numberOfPagesMissing);
if ($numberOfPagesMissing) {
  if (! preg_match('/^\d+$/', $numberOfPagesMissing) ) {
    header($location . urlencode("If provided, 'Number of text pages missing' must be a whole number."));
    exit;
  }
}

// number of rescans
$numberOfRescans = trim($numberOfRescans);
if ($numberOfRescans) {
  if (! preg_match('/^\d+$/', $numberOfRescans) ) {
    header($location . urlencode("If provided, 'Number of images rescanned' must be a whole number."));
    exit;
  }
}

// fixed CDs
$fixedCDs = trim($fixedCDs);
if ($fixedCDs) {
  if (! preg_match('/^\d\d?$/', $fixedCDs) ) {
    header($location . urlencode("If provided, 'Fixed CDs' must be a 1-digit or 2-digit number."));
    exit;
  }
}

// pages to rescan
if ( empty($rescansNeeded) and !empty($rescanPages) ) {
    header($location . urlencode('When "Rescans needed?" is false, "Pages to rescan" must be blank.'));
    exit;
}
if ( $rescansNeeded and empty($rescanPages) ) {
    header($location . urlencode('When "Rescans needed?" is true, "Pages to rescan" cannot be blank.'));
    exit;
}

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}


// connect to db
$connection = connect();

// prep user input
$dlpsId = clean2($dlpsId, $connection, $dlpsIdMaxLength);
$eafNumber = clean2($eafNumber, $connection);
$xmlFilename = clean2($xmlFilename, $connection);
$loadedItemName = clean2($loadedItemName, $connection);
$rescanPages = clean2($rescanPages, $connection);
$notes = clean2($notes, $connection);

// test whether this DLPS ID already exists

/* Of course, since dlpsId is the primary key, MySQL will not allow
inserting a new record with an existing dlpsId. But this is the most
common reason an insert would fail, so we handle it specially and
provide a friendlier status message. */

$sql = "SELECT dlpsId FROM eafSupp WHERE dlpsId = '$dlpsId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) >= 1 ) {
  if ($mode == 'insert') {
    // can't insert a DLPS ID that already exists
    header($location . urlencode('DLPS ID "' . $dlpsId . '" already exists, so it cannot be added'));
    exit;
  }
} else {
  if ($mode == 'update') {
    // can't update a record that doesn't exist
    header($location . urlencode('DLPS ID "' . $dlpsId . '" does not exist, so it cannot be updated'));
    exit;
  }
}


//--------------------
// build SQL statement
//--------------------

if ($mode == 'update') {
  if ($chkDelete) {
    testPerm('eafSuppDelete');
    $mode = 'delete';
    $sql = "DELETE FROM eafSupp";
  } else {
    testPerm('eafSuppUpdate');
    $sql = "UPDATE eafSupp SET";
  }
  $where = " WHERE dlpsId = '$dlpsId' LIMIT 1";
} else {
  testPerm('eafSuppInsert');
  $sql = "INSERT INTO eafSupp SET";
}

if ($mode == 'delete') {
  $values = '';
} else {
  if (empty($dlpsId)) {
    // this should never occur due to prior tests; this is a last-ditch
    // check that will cause the insert or update to fail (since dlpsId cannot be null)
    $value = "NULL";
  } else {
    $value = "'$dlpsId'";
  }
  $values = " dlpsId = $value";

  if (empty($eafNumber)) { $value = "NULL"; } else { $value = "'$eafNumber'"; }
  $values .= ", eafNumber = $value";

  if (empty($subset)) { $value = "0"; } else { $value = "$subset"; }
  $values .= ", subset = $value";

  if (empty($access)) { $value = "0"; } else { $value = "$access"; }
  $values .= ", access = $value";

  if (empty($xmlFilename)) { $value = "NULL"; } else { $value = "'$xmlFilename'"; }
  $values .= ", xmlFilename = $value";

  if (empty($numberOfPagesMissing)) { $value = "0"; } else { $value = $numberOfPagesMissing; }
  $values .= ", numberOfPagesMissing = $value";

  if (empty($loadedItemName)) { $value = "NULL"; } else { $value = "'$loadedItemName'"; }
  $values .= ", loadedItemName = $value";

  if (empty($isOnPrintList)) { $value = "0"; } else { $value = "1"; }
  $values .= ", isOnPrintList = $value";

  if (empty($pagesChecked)) { $value = "0"; } else { $value = "1"; }
  $values .= ", pagesChecked = $value";

  if (empty($iviewBuilt)) { $value = "0"; } else { $value = "1"; }
  $values .= ", iviewBuilt = $value";

  if (empty($rescansNeeded)) { $value = "0"; } else { $value = "1"; }
  $values .= ", rescansNeeded = $value";

  if (empty($rescanPages)) { $value = "NULL"; } else { $value = "'$rescanPages'"; }
  $values .= ", rescanPages = $value";

  if (empty($rescansFinished)) { $value = "0"; } else { $value = "1"; }
  $values .= ", rescansFinished = $value";

  if (empty($numberOfRescans)) { $value = "0"; } else { $value = $numberOfRescans; }
  $values .= ", numberOfRescans = $value";

  if (empty($isMissingCovers)) { $value = "0"; } else { $value = "1"; }
  $values .= ", isMissingCovers = $value";

  if (empty($fixedCDs)) { $value = "0"; } else { $value = $fixedCDs; }
  $values .= ", fixedCDs = $value";

  if (empty($notes)) { $value = "NULL"; } else { $value = "'$notes'"; }
  $values .= ", notes = $value";
}

$sql .= $values . $where;


//----------------------
// execute SQL statement
//----------------------

if ( mysql_query($sql, $connection) ) {
  $affected = mysql_affected_rows();

  // redirect, indicating success
  header("Location: followSaveEafSupp.php?mode=$mode&dlpsId=$dlpsId&affected=$affected");
} else {
  die($dbErrorPreface . mysql_error($connection) . "<br><br>$sql");
}
?>