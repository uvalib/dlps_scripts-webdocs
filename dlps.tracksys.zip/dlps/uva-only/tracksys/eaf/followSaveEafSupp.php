<?php

/*
  followSaveEafSupp.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-10-05
  Last modified: 2005-10-27

  This page is displayed upon successful insert/update of an
  EAF-supplementary-data record. It simply displays non-editable
  values for the record.

  Receives data from: saveEafSupp.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/auth.php';

$siteArea = 'Text Workflow - EAF Supplementary Data';
$pageTitle = 'Update Status';

// connect to db
$connection = connect();

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
// get data from database and display for confirmation
$sql = "SELECT * FROM eafSupp WHERE dlpsId = '$dlpsId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) == 1 ) {
  if ($mode == 'delete') {
    echo "<p class='error'>WARNING: The record was <b>not</b> deleted (DLPS ID: $dlpsId).
      Contact the $appTitle administrator.</p>
      </body></html>";
    exit;
  }

  if ($affected == '0') {
    echo "<p class='updated'>No changes were needed.</p>";
  } else {
    if ($mode == 'insert') {
      echo "<p class='updated'>New item added successfully</p>\n";
    } else {
      echo "<p class='updated'>Item updated successfully</p>\n";
    }
  }
  $row = mysql_fetch_array($result);
?>

<table cellpadding='6' cellspacing='0'>
<tr>
<td class='label'>DLPS ID:</td>
<td><?=$row['dlpsId']?></td>
</tr>

<tr>
<td class='label'>EAF number:</td>
<td><?=$row['eafNumber']?></td>
</tr>

<tr>
<td class='label'>Subset:</td>
<td><?=getEafSubset($row['subset'])?></td>
</tr>

<tr>
<td class='label'>Access:</td>
<td><?=getEafAccess($row['access'])?></td>
</tr>

<tr>
<td class='label'>XML filename:</td>
<td><?=$row['xmlFilename']?></td>
</tr>

<?php
  if ($row['numberOfPagesMissing'] == 0) {
    $numberOfPagesMissing = '';
  } else {
    $numberOfPagesMissing = $row['numberOfPagesMissing'];
  }
?>
<tr>
<td class='label'>Number of text pages missing:</td>
<td><?=$numberOfPagesMissing?></td>
</tr>

<tr>
<td class='label'>Loaded item number:</td>
<td><?=$row['loadedItemName']?></td>
</tr>

<?php
  if ($row['isOnPrintList'] == 1) {
    $checked = ' checked';
  } else {
    $checked = '';
  }
?>
<tr>
<td class='label'></td>
<td><input type='checkbox'<?=$checked?> disabled> On print list?</td>
</tr>

<?php
  if ($row['pagesChecked'] == 1) {
    $checked = ' checked';
  } else {
    $checked = '';
  }
?>
<tr>
<td class='label'></td>
<td><input type='checkbox'<?=$checked?> disabled> Pages checked?</td>
</tr>

<?php
  if ($row['iviewBuilt'] == 1) {
    $checked = ' checked';
  } else {
    $checked = '';
  }
?>
<tr>
<td class='label'></td>
<td><input type='checkbox'<?=$checked?> disabled> iView catalog built?</td>
</tr>

<?php
  if ($row['rescansNeeded'] == 1) {
    $checked = ' checked';
  } else {
    $checked = '';
  }
?>
<tr>
<td class='label'></td>
<td><input type='checkbox'<?=$checked?> disabled> Rescans needed?</td>
</tr>

<tr>
<td class='label'>Pages to rescan:</td>
<td><?=$row['rescanPages']?></td>
</tr>

<?php
  if ($row['rescansFinished'] == 1) {
    $checked = ' checked';
  } else {
    $checked = '';
  }
?>
<tr>
<td class='label'></td>
<td><input type='checkbox'<?=$checked?> disabled> Rescans finished?</td>
</tr>

<?php
  if ($row['numberOfRescans'] == 0) {
    $numberOfRescans = '';
  } else {
    $numberOfRescans = $row['numberOfRescans'];
  }
?>
<tr>
<td class='label'>Number of images rescanned:</td>
<td><?=$numberOfRescans?></td>
</tr>

<?php
  if ($row['isMissingCovers'] == 1) {
    $checked = ' checked';
  } else {
    $checked = '';
  }
?>
<tr>
<td class='label'></td>
<td><input type='checkbox'<?=$checked?> disabled> Covers missing?</td>
</tr>

<?php
  if ($row['fixedCDs'] == 0) {
    $fixedCDs = '';
  } else {
    $fixedCDs = $row['fixedCDs'];
  }
?>
<tr>
<td class='label'>Fixed CDs:</td>
<td><?=$fixedCDs?></td>
</tr>

<tr>
<td class='label' valign='top'>Notes:</td>
<td><pre><?=formatNotes($row['notes'])?></pre></td>
</tr>
</table>

<?php
} else {
  if ($mode == 'delete') {
    echo "<p class='updated'>Record deleted successfully.</p>\n";
  } else {
    echo "<p>DLPS ID '$dlpsId' not found in database. Contact the $appTitle administrator.</p>\n";
  }
}  // END if ( mysql_num_rows($result) == 1 ) ... else ...

/*
if (getPerm('eafSuppInsert')) {
  echo "<p><a href='eafSupp.php'>Add new record</a></p>\n";
} else {
  echo "<p><span class='disabled'>Add new record</span></p>\n";
}
*/

echo "<p>";
if ($mode == 'update') { $again = ' again'; } else { $again = ''; }
if ($mode != 'delete') {
  echo "<a href='eafSupp.php?dlpsId=$dlpsId'>Edit this item$again</a><br>";
}
echo "<a href='search/search.php'>Return to search results</a></p>";
?>

</body>
</html>
