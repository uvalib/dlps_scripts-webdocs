<?php

/*
  saveContact.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-01-26
  Last modified: 2006-01-26

  Saves user-entered data to database, either by inserting a new
  record or updating an existing record, as appropriate.

  Receives data from: contacts.php
  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: followSaveContact.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// validate user input

$location = 'Location: ../../../err/badInput.php?msg=';

// ID
if (empty($contactId)) {
  header($location . urlencode('UVA email ID of contact person is required'));
  exit;
}

// first name
if (empty($contactNameFirst)) {
  header($location . urlencode('First name of contact person is required'));
  exit;
}

// last name
if (empty($contactNameLast)) {
  header($location . urlencode('Last name of contact person is required'));
  exit;
}

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}

// connect to db
$connection = connect();

// prep user input
$contactId = clean2($contactId, $connection, $contactIdMaxLength);
$contactNameFirst = clean2($contactNameFirst, $connection, $nameFirstMaxLength);
$contactNameLast = clean2($contactNameLast, $connection, $nameLastMaxLength);
$contactDesc = clean2($contactDesc, $connection, $descMaxLength);


// build SQL statement

if ($mode == 'update') {
  if ($chkDelete) {
    testPerm('imageProjectsDelete');
    $mode = 'delete';
    $sql = "DELETE FROM imageProjectContacts";
  } else {
    testPerm('imageProjectsUpdate');
    $sql = "UPDATE imageProjectContacts SET";
  }
  $where = " WHERE contactId = '$contactId' LIMIT 1";
} else {
  testPerm('imageProjectsInsert');
  $sql = "INSERT INTO imageProjectContacts SET";
  $where = '';
}

if ($mode == 'delete') {
  $values = '';
} else {
  if (empty($contactId)) { $value = "NULL"; } else { $value = "'$contactId'"; }
  $values = " contactId = $value";

  if (empty($contactNameFirst)) { $value = "NULL"; } else { $value = "'$contactNameFirst'"; }
  $values .= ", contactNameFirst = $value";

  if (empty($contactNameLast)) { $value = "NULL"; } else { $value = "'$contactNameLast'"; }
  $values .= ", contactNameLast = $value";

  if (empty($contactDesc)) { $value = "NULL"; } else { $value = "'$contactDesc'"; }
  $values .= ", contactDesc = $value";
}

$sql .= $values . $where;

// execute SQL statement
if ( mysql_query($sql, $connection) ) {
  $affected = mysql_affected_rows();

  // redirect, indicating success
  header("Location: followSaveContact.php?mode=$mode&contactId=$contactId&affected=$affected");
} else {
  die($dbErrorPreface . "Unable to $mode contact '$contactId': " . mysql_error($connection) . "<br><br>$sql");
}

?>