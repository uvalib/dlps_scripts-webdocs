<?php

/*
  followSaveContact.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-01-26
  Last modified: 2006-01-26

  This page is displayed upon successful insert/update of a contact. It
  simply displays non-editable values for the record.

  Receives data from: saveContact.php
*/

import_request_variables('G');
include '../../../inc/tracksys.php';
include '../../../inc/auth.php';

$siteArea = 'Image Projects - Setup';
$pageTitle = 'Contact Person - Update Status';

// connect to db
$connection = connect();

echo <<<EOD
<html>
<head>
<title>$siteArea - $pageTitle</title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
</head>
<body>
<h1>$siteArea</h1>
<h2>$pageTitle</h2>
EOD;

// get data from database and display for confirmation
$sql = "SELECT * FROM imageProjectContacts WHERE contactId = '$contactId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) == 1 ) {
  if ($mode == 'delete') {
    echo "<p class='error'>WARNING: The contact person was <b>not</b> deleted (ID: $contactId).
      Contact the $appTitle administrator.</p>
      </body></html>";
    exit;
  }

  if ($affected == '0') {
    echo "<p class='updated'>No changes were needed.</p>";
  } else {
    if ($mode == 'insert') {
      echo "<p class='updated'>New contact person added successfully</p>\n";
    } else {
      echo "<p class='updated'>Contact person updated successfully</p>\n";
    }
  }
  $row = mysql_fetch_array($result);
?>

<table cellpadding='6' cellspacing='0'>
<tr>
<td class='label'>ID:</td>
<td><?=$row['contactId']?></td>
</tr>
<tr>
<td class='label'>First name:</td>
<td><?=$row['contactNameFirst']?></td>
</tr>
<tr>
<td class='label'>Last name:</td>
<td><?=$row['contactNameLast']?></td>
</tr>
<tr>
<td class='label'>Comments:</td>
<td><?=$row['contactDesc']?></td>
</tr>
</table>

<?php
} else {
  if ($mode == 'delete') {
    echo "<p class='updated'>Contact person deleted successfully.</p>\n";
  } else {
    echo "<p>Contact ID '$contactId' not found in database. Contact the $appTitle administrator.</p>\n";
  }
}  // END if ( mysql_num_rows($result) == 1 )

echo "<p>";
if (getPerm('imageProjectsInsert')) {
  echo "<a href='contacts.php?contactId=new'>Enter new contact person</a>";
} else {
  echo "<span class='disabled'>Enter new contact person</span>";
}

if ($mode == 'update') { $again = ' again'; } else { $again = ''; }
if ($mode != 'delete') {
  echo "<br><a href='contacts.php?contactId=$contactId'>Edit this item$again</a>";
}
?>
<br><a href='contacts.php'>View list of contact persons</a>
</p>

</body>
</html>
