<?php

/*
  contacts.php - page for managing contact persons for image projects
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-01-26
  Last modified: 2006-01-26

  If no 'contactId' parameter, lists contacts already defined.
  If ID is 'new', displays add-new form for defining a contact.
  Otherwise, displays edit form for editing an existing contact.
*/

import_request_variables('PG');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Image Projects - Setup';

if ( empty($contactId) ) {
  // list existing contacts
  $mode = 'list';
  $pageTitle = 'Contact Persons';

  // test permissions
  testPerm('imageProjectsSelect');
} else {
  if ($contactId == 'new') {
    // display enter-new form
    $mode = 'insert';
    $pageTitle = 'Enter New Contact Person';
    $submitCaption = ' Add ';
    $onload = ' onload="document.frm.contactId.focus();"';

    // test permissions
    testPerm('imageProjectsInsert');
  } else {
    // display edit form
    $mode = 'update';
    $pageTitle = 'Edit Contact Person';
    $submitCaption = 'Update';
    $onload = ' onload="document.frm.contactNameFirst.focus();"';

    // test permissions; need Select to view item details, Update to enable submit button
    testPerm('imageProjectsSelect');
    if (!getPerm('imageProjectsUpdate')) { $submitAppearance = ' disabled'; }
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
<script type="text/javascript" src="../../../inc/tracksys.js"></script>
</head>

<?php
if ($mode == 'list') {
  // list existing contacts
  if (getPerm('imageProjectsInsert')) {
    $addNewLink = "<p><a href='?contactId=new'>Enter new contact person</a></p>";
  } else {
    $addNewLink = "<p><span class='disabled'>Enter new contact person</span></p>";
  }

  echo <<<EOD
<body$onload>
<h1>$siteArea</h1>
<h2>$pageTitle</h2>
$addNewLink
EOD;
?>

<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>ID</td>
<td>Name</td>
<td>Comments</td>
</tr>

<?php
  $sql = "SELECT * FROM imageProjectContacts ORDER BY contactNameLast, contactNameFirst";
  $result = query($sql, $connection);
  $num = mysql_num_rows($result);
  if ($num == 0) { echo "<tr><td cols='2'><b>0</b> items</td></tr>\n"; }
  while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);
      echo "<tr$class>\n";
      echo "<td><a href='?contactId=$row[contactId]'>$row[contactId]</a></td>\n";
      echo "<td>" . formatName($row['contactNameLast'], $row['contactNameFirst']) . "</td>\n";
      echo "<td>$row[contactDesc]</td>\n";
      echo "</tr>\n";
  }
  echo "</table>\n";
}  // END if ($mode == 'list')

else {
  if ($mode == 'update') {
    $sql = "SELECT * FROM imageProjectContacts WHERE contactId = '$contactId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $contactId = $row['contactId'];
    }
  }

  if ($deleteEnabled and $mode == 'update' and getPerm('imageProjectsDelete')) {
    $onSubmit = " onsubmit='return confirmDelete(document.frm, \"Contact Person\");'";
  }
?>

<body<?=$onload?>>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name='frm' method='POST' action='saveContact.php'<?=$onSubmit?>>
<input type='hidden' name='mode' value='<?=$mode?>'>
<table cellpadding='4'>
<tr>
<td class='label'>UVA email ID:</td>
<td>
<?php
  if ($mode == 'update') {
    echo "$contactId <input type='hidden' name='contactId' value='$contactId'>";
  } else {
    echo "<input type='text' name='contactId' size='6' maxlength='$contactIdMaxLength'>";
  }
?>
</td>
</tr>
<tr>
<td class='label'>First name:</td>
<td><input type='text' name='contactNameFirst' value='<?=$row[contactNameFirst]?>' maxlength='<?=$nameFirstMaxLength?>'></td>
</tr>
<tr>
<td class='label'>Last name:</td>
<td><input type='text' name='contactNameLast' value='<?=$row[contactNameLast]?>' maxlength='<?=$nameLastMaxLength?>'></td>
</tr>
<tr>
<td class='label'>Comments:</td>
<td><input type='text' name='contactDesc' value='<?=$row[contactDesc]?>' size='40' maxlength='<?=$descMaxLength?>'></td>
</tr>
<?php
  if ($deleteEnabled and $mode == 'update' and getPerm('imageProjectsDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>
<tr>
<td></td>
<td>
<input type='submit' name='go' value='<?=$submitCaption?>'<?=$submitAppearance?>>
<input type='button' value='Cancel' onclick='history.back();'>
</td>
</tr>
</table>
</form>
<?php
}  // END if ($mode == 'list') { ... } else
?>
</body>
</html>
