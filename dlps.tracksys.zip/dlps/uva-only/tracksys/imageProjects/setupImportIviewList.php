<?php

/*
  setupImportIviewList.php - form for importing iView text files, each
    of which contains a list of image files in that iView catalog

  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-05-21
  Last modified: 2006-05-24

  Posts to: itself (if still gathering setup info) or to
    importIviewList.php (if ready to import)
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

$siteArea = 'Image Projects';
$pageTitle = 'Import iView File Lists';

// delete session variables for imports succeeded/failed
unset($_SESSION['imageProjectsImportGood']);
unset($_SESSION['imageProjectsImportBad']);

// test permissions
$connection = connect();
testPerm('imageProjectsUpdate');

// get associative array representing table 'imageProjects'
$imageProjects = getHashImageProjects($connection);

// build string of <option> elements for project-selection drop-down menu
$imageProjectsOptions = "<option value=''></option>\n";
foreach ($imageProjects as $id => $name) {
  if ($id == $projectId) { $selected = ' selected'; } else { $selected = ''; }
  $imageProjectsOptions .= "<option value='$id'$selected>$name</option>\n";
}

//--------------------
// validate user input
//--------------------

$location = 'Location: ../err/badInput.php?msg=';

// number of files to import
if (empty($importCount)) {
  // display first page of form, asking for number of files to import
  $mode = 'page1';
} else {
  // display second page of form, to get paths of import files
  $mode = 'page2';

  if (preg_match('/^\d\d?$/', $importCount) ) {
    if ($importCount > 0 and $importCount < 100) {
      // ok, 1 - 99 files
    } else {
      header($location . urlencode('Number of files to import must be between 1 and 99.'));
      exit;
    }
  } else {
    header($location . urlencode('Number of files to import must be a whole number, 2 digits or less.'));
    exit;
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<?php

if ($mode == 'page1') {

?>
<body onload="document.frm.importCount.focus();">
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="GET" action="setupImportIviewList.php">
<input type="hidden" name="projectId" value="<?=$projectId?>">
<table cellpadding="4">
<tr>
<td class='label'>Number of files to import:</td>
<td><input type='text' name='importCount' value='1' maxlength='2' size='3'></td>
</tr>

<tr>
<td colspan='2' align='right'>
<input type='button' value='Cancel' onclick='history.back();'>
<input type='submit' value='Next &gt;'>
</td>
</tr>
</table>
</form>
</body>
<?php

} else {
  // show page 2

?>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="POST" enctype="multipart/form-data" action="importIviewList.php">
<input type='hidden' name='importCount' value='<?=$importCount?>'>
<table cellpadding="4">

<?php
  if ($importCount == 1) {
    // only one file to import
    $colspan = " colspan='2'";
?>
<tr>
<td class="label">Image project:</td>
<td><select name="projectId">
<?=$imageProjectsOptions?>
</select>
</td>
</tr>

<tr>
<td class='label'><span class='nowrap'>iView file list:</span></td>
<td><input type='file' name='file1' size='40'></td>
</tr>

<?php
  } else {
    // more than one file to import
    $colspan = '';
?>
<tr>
<td>
  <table cellpadding="4">
  <tr>
  <td class='label'>Image project:</td>
  <td><select name="projectId">
  <?=$imageProjectsOptions?>
  </select>
  </td>
  </tr>
  </table>
</td>
</tr>

<tr>
<td>
  <table cellpadding='6' cellspacing='0' class='list'>
<?php
    for ($i = 1; $i <= $importCount; $i++) {
      $class = getRowClass($i);
?>
  <tr<?=$class?>>
  <td class='label'><span class='nowrap'>iView file list <?=$i?>:</span></td>
  <td><input type='file' name='file<?=$i?>' size='40'></td>
  </tr>
<?php
    }  // END for
?>
  </table>
</td>
</tr>
<?php

  }  // END if ($importCount == 1)

?>
<tr>
<td<?=$colspan?> align='right'>
<input type='submit' value='Import'>
<input type='reset' value='Reset'>
<input type='button' value='Cancel' onclick='history.back();'>
</td>
</tr>
</table>
</form>
</body>
<?php

}  // END if ($mode == 'page1')

?>
</html>
