<?php

/*
  followSaveImageProject.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-01-27
  Last modified: 2007-03-20

  This page is displayed upon successful insert/update of a project. It
  simply displays non-editable values for the record.

  Receives data from: saveImageProject.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/auth.php';

$siteArea = 'Image Projects - Setup';
$pageTitle = 'Project - Update Status';

// connect to db
$connection = connect();

// get associative array representing table 'imageProjectContacts'
$imageProjectContacts = getHashImageProjectContacts($connection);

// get associative array of tracking system users
$users = getHashUsers($connection);

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
if ($debugMode) {
  echo "<p>" . $_SESSION['saveImageProject']['sql'] . "</p>\n";
}

// get data from database and display for confirmation
$sql = "SELECT * FROM imageProjects WHERE projectId = '$projectId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) == 1 ) {
  if ($mode == 'delete') {
    echo "<p class='error'>WARNING: The project was <b>not</b> deleted (project ID: $projectId).
      Contact the $appTitle administrator.</p>
      </body></html>";
    exit;
  }

  if ($affected == '0') {
    echo "<p class='updated'>No changes were needed.</p>";
  } else {
    if ($mode == 'insert') {
      echo "<p class='updated'>New project added successfully</p>\n";
    } else {
      echo "<p class='updated'>Project updated successfully</p>\n";
    }
  }
  $row = mysql_fetch_array($result);
?>

<table cellpadding='6' cellspacing='0'>
<tr>
<td class='label'>Project name:</td>
<td><?=$row['projectName']?></td>
</tr>

<tr>
<td class='label'>Description:</td>
<td><?=$row['projectDesc']?></td>
</tr>

<?php
  $contact = '';
  foreach ($imageProjectContacts as $id => $name) {
    if ($row['contactId'] == $id) {
      $contact = "$name ($id)";
      break;
    }
  }
?>
<tr>
<td class='label'>Contact person:</td>
<td><?=$contact?></td>
</tr>

<tr>
<td class='label'>Content model:</td>
<td><?=$row['contentModel']?></td>
</tr>

<tr>
<td class='label'>Materials due date:</td>
<td><?=formatDateUS($row['dateMaterialsDue'])?></td>
</tr>

<tr>
<td class='label'>Materials returned on:</td>
<td><?=formatDateUS($row['dateMaterialsReturned'])?></td>
</tr>

<?php
  if ($row['numberBooks'] == 0) {
    $numberBooks = '';
  } else {
    $numberBooks = $row['numberBooks'];
  }
  echo <<<END
<tr>
<td class='label'>Number of books:</td>
<td>$numberBooks</td>
</tr>
END;

  if ($row['numberDigitalMedia'] == 0) {
    $numberDigitalMedia = '';
  } else {
    $numberDigitalMedia = $row['numberDigitalMedia'];
  }
  echo <<<END
<tr>
<td class='label'>Number of discs/media:</td>
<td>$numberDigitalMedia</td>
</tr>
END;

  if ($row['numberSlides'] == 0) {
    $numberSlides = '';
  } else {
    $numberSlides = $row['numberSlides'];
  }
  echo <<<END
<tr>
<td class='label'>Number of slides:</td>
<td>$numberSlides</td>
</tr>
END;

  if ($row['numberBookPages'] == 0) {
    $numberBookPages = '';
  } else {
    $numberBookPages = $row['numberBookPages'];
  }
  echo <<<END
<tr>
<td class='label'>Number of book pages:</td>
<td>$numberBookPages</td>
</tr>
END;

  if ($row['numberDigitalImages'] == 0) {
    $numberDigitalImages = '';
  } else {
    $numberDigitalImages = $row['numberDigitalImages'];
  }
  echo <<<END
<tr>
<td class='label'>Number of digital images:</td>
<td>$numberDigitalImages</td>
</tr>
END;

?>

<tr>
<td class='label' valign='top'>Notes:</td>
<td><pre><?=formatNotes($row['notes'])?></pre></td>
</tr>

<tr>
<td class='label'>Date/time created:</td>
<td><?=formatDateTimeUS($row['dateTimeCreated'])?></td>
</tr>

<?php
  $user = '';
  foreach ($users as $id => $name) {
    if ($row['createdByUser'] == $id) {
      $user = "$name ($id)";
    }
  }
?>
<tr>
<td class='label'>Created by:</td>
<td><?=$user?></td>
</tr>

</table>

<?php
} else {
  if ($mode == 'delete') {
    echo "<p class='updated'>Project deleted successfully.</p>\n";
  } else {
    echo "<p>Project ID '$projectId' not found in database. Contact the $appTitle administrator.</p>\n";
  }
}  // END if ( mysql_num_rows($result) == 1 ) ... else ...

echo "<p>";

if (getPerm('imageProjectsInsert')) {
  echo "<a href='imageProjects.php?projectId=new'>Enter new project</a>";
} else {
  echo "<span class='disabled'>Enter new project</span>";
}

echo "<br><a href='imageProjects.php'>Browse projects</a>\n";
//echo "<br><a href='search/search.php'>Return to search results</a>\n";

if ($mode == 'update') { $again = ' again'; } else { $again = ''; }
if ($mode != 'delete') {
  echo "<br><a href='imageProjects.php?projectId=$projectId'>Edit this project$again</a>\n";
  echo "<br><a href='viewWorkflow.php?projectId=$projectId'>View this project's workflow</a>\n";
}
?>
</p>
</body>
</html>
<?php

  // send email notification if inserting a new project
  if ($mode == 'insert') {
    $to = $newImageProjectEmailRecipients;
    $headers = "From: $emailFrom";
    $subject = "$appTitle - new Image Project added";

    $body = "User " . getUserDesc() . " has added a new Image Project to the $appTitle.\n";
    $body .= "\n";
    $body .= "Project details:\n";
    $body .= "\tProject name: $row[projectName]\n";
    $body .= "\tDescription: $row[projectDesc]\n";
    $body .= "\tContact person: $contact\n";
    $body .= "\tContent model: $row[contentModel]\n";
    $body .= "\tNumber of slides: $numberSlides\n";
    $body .= "\tNumber of book pages: $numberBookPages\n";
    $body .= "\tNumber of digital images: $numberDigitalImages\n";
    $body .= "\tNotes: $row[notes]\n";
    $body .= "\tDate/time created: " . formatDateTimeUS($row['dateTimeCreated']) . "\n";
    $body .= "\tCreated by: $user\n";
    $body .= "\n";
    $body .= "Materials info:\n";
    $body .= "\tMaterials due date: " . formatDateUS($row['dateMaterialsDue']) . "\n";
    $body .= "\tNumber of books: $numberBooks\n";
    $body .= "\tNumber of discs/media: $numberDigitalMedia\n";
    $body .= "\n";

    $body = wordwrap($body, 70);
    mail($to, $subject, $body, $headers);
  }

?>
