<?php

/*
  confirmScanning.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-05-16
  Last modified: 2006-06-01

  Displays changes proposed for image projects in the context of the
  scanning workflow. Allows user to commit changes to database, or
  cancel.

  Receives data from: workflowScanning.php
  Posts data to: saveScanning.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Image Projects';
$pageTitle = 'Scanning Workflow - Confirm Changes';

// connect to database
$connection = connect();

// test permissions
testPerm('imageProjectsUpdate');

// get IDs of projects to be displayed
$ids = array();
if ($_GET['projectId']) {
  // a single ID was specified
  $projectId = $_GET['projectId'];
  $ids[] = $projectId;
} else {
  // get multiple IDs from form on preceding page
  foreach ($_GET as $name => $value) {
    if ( preg_match('/^projectId_/', $name) ) {
      $ids[] = $value;
    }
  }
}

// test for required parameters
if (empty($ids)) {
  $location = 'Location: ../../err/badInput.php?msg=';
  header($location . urlencode('At least one Project ID is required'));
  exit;
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<p>Do you want to make the following changes?</p>
<form name="form" method="POST" action="saveScanning.php">

<?php
if ($projectId) {
  echo "<input type='hidden' name='projectId' value='$projectId'>\n";
}
?>

<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td class='nowrap'>Project name</td>
<td align='center'>Scanner prep</td>
<td align='center'>Materials prep</td>
<td align='center'>Scan</td>
<td align='center'>Dropcrop (slides)</td>
<td align='center'>Transfer to pogo</td>
<td align='center'>Finished</td>
</tr>

<?php
$colspan = 7;  // total number of columns

// for each ID, query database to determine whether the record actually requires updating
$changes = array();
foreach ($ids as $id) {
  $sql = "SELECT imageProjectsScanning.*, imageProjects.projectName
          FROM imageProjectsScanning LEFT JOIN imageProjects USING (projectId)
          WHERE imageProjectsScanning.projectId = $id";
  $result = query($sql, $connection);
  if ( mysql_num_rows($result) == 1 ) {
    $row = mysql_fetch_array($result);

    for ($i = 1; $i <= 6; $i++) {
      switch ($i) {
        case 1: $columnName = 'scannerPrep'; break;
        case 2: $columnName = 'materialsPrep'; break;
        case 3: $columnName = 'scan'; break;
        case 4: $columnName = 'dropcrop'; break;
        case 5: $columnName = 'transfer'; break;
        case 6: $columnName = 'finished'; break;
      }

      if ( (!empty($_GET[$columnName . '_' . $id])) && ($row[$columnName] == 0) ) {
	// form = true, database = false
	$changes[$id] .= "$columnName=1|";
      }
      if ( (empty($_GET[$columnName . '_' . $id])) && ($row[$columnName] == 1) ) {
	// form = false, database = true
	$changes[$id] .= "$columnName=0|";
      }
    }

    if (!empty($changes[$id])) {
      $changes[$id] = preg_replace('/\|$/', '', $changes[$id]);
      $c++;
      $class = getRowClass($c);
      echo "<tr$class>\n<td>$row[projectName] <input type='hidden' name='projectId_$id' value='$id'></td>\n";
      for ($i = 1; $i <= 6; $i++) {
	switch ($i) {
	  case 1: $columnName = 'scannerPrep'; break;
	  case 2: $columnName = 'materialsPrep'; break;
	  case 3: $columnName = 'scan'; break;
	  case 4: $columnName = 'dropcrop'; break;
	  case 5: $columnName = 'transfer'; break;
	  case 6: $columnName = 'finished'; break;
	}

	if ( preg_match("/$columnName=(0|1)/", $changes[$id], $refs) ) {
	  if ($refs[1] == '1') {
	    $checked = ' checked';
	    $tf = 'true';
	  } else {
	    $checked = '';
	    $tf = 'false';
	  }
	  // checkboxes are for display only; value is passed via hidden textbox
	  echo "<td align='center'><input type='checkbox'$checked disabled>
<input type='hidden' name='{$columnName}_$id' value='$tf'></td>\n";
	} else {
	  echo "<td>&nbsp;</td>\n";
	}
      }
      echo "</tr>\n";
    }
  }
}

if (empty($changes)) {
  echo "<tr><td colspan='$colspan'>[No changes indicated]</td></tr>\n";
}

echo "</table>\n";

if (empty($changes)) {
  echo "<p><input type='button' value=' Back ' onclick='history.back();'></p>\n";
} else {
  echo "<p><input type='submit' name='update' value='Update'>
<input type='button' name='cancel' value='Cancel' onclick='history.back();'></p>\n";
}
?>
</form>
</body>
</html>
