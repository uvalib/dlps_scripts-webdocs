<?php

/*
  search0.php - preliminary page of search interface for image
    projects - clears saved search criteria
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-05-31
  Last modified: 2006-05-31

  Receives data from: Not applicable
  Redirects to: search1.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

unset($_SESSION['searchImageProjects']);
unset($_SESSION['searchImageProjectsSql']);

// redirect to first page of search form
header('Location: search1.php');
?>