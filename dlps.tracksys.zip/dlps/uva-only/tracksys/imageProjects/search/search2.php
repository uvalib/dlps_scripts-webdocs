<?php

/*

  search2.php - final page of search interface for image projects -
  processes form data and redirects to search page

  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-05-31
  Last modified: 2006-05-31

  Receives data from: search1.php
  Submits data to: search.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to db
$connection = connect();

//-------------------------------------
// process form data from previous page
//-------------------------------------

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// project name
if (empty($projectName)) {
  unset($_SESSION['searchImageProjects']['projectName']);
  unset($_SESSION['searchImageProjectsSql']['projectName']);
} else {
  $_SESSION['searchImageProjects']['projectName'] = $projectName;
  $projectNameSql = clean2(translateWildcards($projectName), $connection);
  if (!ereg('%$', $projectNameSql)) { $projectNameSql .= '%'; }
  $_SESSION['searchImageProjectsSql']['projectName'] = " AND projectName LIKE '$projectNameSql'";
}

// project description
if (empty($projectDesc)) {
  unset($_SESSION['searchImageProjects']['projectDesc']);
  unset($_SESSION['searchImageProjectsSql']['projectDesc']);
} else {
  $_SESSION['searchImageProjects']['projectDesc'] = $projectDesc;
  $projectDescSql = clean2(translateWildcards($projectDesc), $connection);
  if (!ereg('^%', $projectDescSql)) { $projectDescSql = '%' . $projectDescSql; }
  if (!ereg('%$', $projectDescSql)) { $projectDescSql .= '%'; }
  $_SESSION['searchImageProjectsSql']['projectDesc'] = " AND projectDesc LIKE '$projectDescSql'";
}

// notes
if (empty($notes)) {
  unset($_SESSION['searchImageProjects']['notes']);
  unset($_SESSION['searchImageProjectsSql']['notes']);
} else {
  $_SESSION['searchImageProjects']['notes'] = $notes;
  $notesSql = clean2(translateWildcards($notes), $connection);
  if (!ereg('^%', $notesSql)) { $notesSql = '%' . $notesSql; }
  if (!ereg('%$', $notesSql)) { $notesSql .= '%'; }
  $_SESSION['searchImageProjectsSql']['notes'] = " AND notes LIKE '$notesSql'";
}

// image filename
if (empty($filename)) {
  unset($_SESSION['searchImageProjects']['filename']);
  unset($_SESSION['searchImageProjectsSql']['filename']);
} else {
  $_SESSION['searchImageProjects']['filename'] = $filename;
  $filenameSql = clean2(translateWildcards($filename), $connection);
  if (!ereg('^%', $filenameSql)) { $filenameSql = '%' . $filenameSql; }
  if (!ereg('%$', $filenameSql)) { $filenameSql .= '%'; }
  $_SESSION['searchImageProjectsSql']['filename'] = " AND filename LIKE '$filenameSql'";
}

// image file Iris number
if (empty($irisNumber)) {
  unset($_SESSION['searchImageProjects']['irisNumber']);
  unset($_SESSION['searchImageProjectsSql']['irisNumber']);
} else {
  $_SESSION['searchImageProjects']['irisNumber'] = $irisNumber;
  $irisNumberSql = clean2(translateWildcards($irisNumber), $connection);
  //if (!ereg('%$', $irisNumberSql)) { $irisNumberSql .= '%'; }
  $_SESSION['searchImageProjectsSql']['irisNumber'] = " AND irisNumber LIKE '$irisNumberSql'";
}

// redirect to search form
header('Location: search.php');
?>