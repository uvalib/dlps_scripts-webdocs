<?php

/*
  search1.php - first page of search interface for image projects
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-05-31
  Last modified: 2006-05-31

  Submits data to: search2.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Image Projects';
$pageTitle = 'Search';

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body onload="document.frm.projectName.focus();">
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<form name="frm" method="GET" action="search2.php">
<table cellpadding="4">
<tr>
<td class="label">Project name:</td>
<td><input type="text" name="projectName" value="<?=$_SESSION['searchImageProjects']['projectName']?>"></td>
</tr>

<tr>
<td class="label">Project description:</td>
<td><input type="text" name="projectDesc" value="<?=$_SESSION['searchImageProjects']['projectDesc']?>"></td>
</tr>

<tr>
<td class="label">Notes:</td>
<td><input type="text" name="notes" value="<?=$_SESSION['searchImageProjects']['notes']?>"></td>
</tr>

<tr>
<td class="label">Image filename:</td>
<td><input type="text" name="filename" value="<?=$_SESSION['searchImageProjects']['filename']?>"></td>
</tr>

<tr>
<td class="label">Image file Iris number:</td>
<td><input type="text" name="irisNumber" value="<?=$_SESSION['searchImageProjects']['irisNumber']?>"></td>
</tr>


<tr>
<td></td>
<td>
<input type="button" value="Clear" onclick="clearForm();">
<input type="submit" value="Search &gt;">
<!--
<input type="button" value="Search Now" onclick="document.frm.searchNow.value='true'; document.frm.submit();">
<input type="submit" value="Next &gt;"  onclick="document.frm.searchNow.value='';">
<input type="hidden" name="searchNow">
-->
</td>
</tr>
</table>

<br>
<p><strong>Wildcards:</strong> Use * for zero or more characters, ? for
exactly one character.</p>

</form>
</body>
</html>
