<?php

/*
  search.php - queries database and displays search results
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-05-31
  Last modified: 2006-05-31

*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to db
$connection = connect();

testPerm('imageProjectsSelect');
$siteArea = 'Image Projects';
$pageTitle = 'Search Results';

//------------------------------------------------------------------
// query table imageProjectsImageFiles to get project IDs associated
// with the specified image files (if any)
//------------------------------------------------------------------

$criteriaUsed = false;
$sql = 'SELECT DISTINCT projectId FROM imageProjectsImageFiles';
$where = '';

// image filename
if (!empty($_SESSION['searchImageProjectsSql']['filename'])) {
  $criteriaUsed = true;
  $where .= $_SESSION['searchImageProjectsSql']['filename'];
}

// image file Iris number
if (!empty($_SESSION['searchImageProjectsSql']['irisNumber'])) {
  $criteriaUsed = true;
  $where .= $_SESSION['searchImageProjectsSql']['irisNumber'];
}

$projectIds = array();
if (!empty($where)) {
  $where = preg_replace('/^ AND/', '', $where);  // remove the initial ' AND', if any
  $sql .= ' WHERE' . $where;
  $sql .= ' ORDER BY projectId';
  $subquery = $sql;

  // execute query
  $result = query($sql, $connection);
  while ( $row = mysql_fetch_array($result) ) {
    $projectIds[] = $row['projectId'];
  }
}


//-------------------------
// prepare SQL query string
//-------------------------

$sql = 'SELECT projectId, projectName, projectDesc, step10a FROM imageProjects';
$where = '';

$where .= $_SESSION['searchImageProjectsSql']['projectName'];
$where .= $_SESSION['searchImageProjectsSql']['projectDesc'];
$where .= $_SESSION['searchImageProjectsSql']['notes'];

// project IDs associated with specific image files
if (empty($projectIds)) {
  if ($criteriaUsed) {
    // image-file criteria were used but returned no project IDs; thus overall query must fail
    $where .= " AND 0";
  }
} else {
  $where .= " AND projectId IN (";
  foreach ($projectIds as $id) {
    $where .= "$id,";
  }
  $where = preg_replace('/,$/', '', $where);  // remove final comma
  $where .= ")";
}

if (!empty($where)) {
  $where = preg_replace('/^ +AND +/', '', $where);  // remove the initial ' AND'
  $sql .= ' WHERE ' . $where;
}

// sort order
if ( $_GET['orderBy'] ) {
  $orderBy = $_GET['orderBy'];
} elseif ( $_SESSION['searchImageProjects']['orderBy'] ) {
  $orderBy = $_SESSION['searchImageProjects']['orderBy'];
} else {
  $orderBy = 'projectName';
}
$_SESSION['searchImageProjects']['orderBy'] = $orderBy;
switch ($orderBy) {
  case 'projectName':
    $_SESSION['searchImageProjectsSql']['orderBy'] = ' ORDER BY projectName';
    break;
  default:
    $_SESSION['searchImageProjectsSql']['orderBy'] = " ORDER BY $orderBy, projectName";
}
$sql .= $_SESSION['searchImageProjectsSql']['orderBy'];

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/imageProjects.js"></script>
<script type="text/javascript">
function setCheckboxes(onOrOff) {
  for (i = 0; i < document.frm.elements.length; i++) {
    if (document.frm.elements[i].type == "checkbox") {
      document.frm.elements[i].checked = onOrOff;
    }
  }
}
</script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
if ($debugMode) {
  echo "<p>$sql</p>\n";
  if (!empty($subquery)) {
    echo "<p>[$subquery]</p>\n";
  }
}

// execute query
$result = query($sql, $connection);

$num = mysql_num_rows($result);
if ($num == 1) { $plural = ''; } else { $plural = 's'; }
echo "<p>Found <b>$num</b> item$plural</p>\n";

$newSearchLink = "<p><a href='search1.php'>Adjust this search</a><br>
<a href='search0.php'>Start a new search</a></p>\n";
echo $newSearchLink;

if ($num >= 1) {
  echo "<form name='frm' method='GET'>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>&nbsp;</td>\n";

  if ($orderBy == 'projectName') {
    echo "<td><i>Project name</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=projectName'>Project name</a></td>\n";
  }

  $colspan = 2;

  //if (!empty($_SESSION['searchImageProjectsSql']['projectDesc'])) {
    if ($orderBy == 'projectDesc') {
      echo "<td><i>Description</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=projectDesc'>Description</a></td>\n";
    }
    $colspan++;
  //}

  echo "<td>Finished</td>\n"; $colspan++;
  echo "<td>&nbsp;</td>\n"; $colspan++;
  echo "</tr>\n";

  $c = 1;
  $class = getRowClass($c);
  $colspan--;
  echo "<tr$class>
<td style='white-space: nowrap'>
<img name='checkAll' src='../../img/check.gif' hspace='0' onclick='setCheckboxes(true);' title='Check All'>
<img name='clearAll' border='0' src='../../img/square.gif' hspace='0' onclick='setCheckboxes(false);' title='Clear All'>
</td>
<td colspan='$colspan'>&nbsp;</td>
</tr>\n";

  // display query results
  while ( $row = mysql_fetch_array($result) ) {
    $c++;
    $class = getRowClass($c);
    if ($row['step10a']) { $isFinished = 'Yes'; } else { $isFinished = 'No'; }
    echo "<tr$class>
<td><input type='checkbox' name='projectId_$row[projectId]' value='$row[projectId]' checked></td>
<td><a href='../viewWorkflow.php?projectId=$row[projectId]'>$row[projectName]</a></td>\n";

    //if (!empty($_SESSION['searchImageProjects']['projectDesc'])) {
      echo "<td>$row[projectDesc]</td>\n";
    //}

    echo "<td>$isFinished</td>\n";
    echo "<td class='nowrap'><a href='../imageProjects.php?projectId=$row[projectId]'>Edit project details</a></td>\n";
    echo "</tr>\n";
  }
  echo "</table>

<p> </p>
<table cellpadding='4' border='0'>
<!--
<tr>
<td class='tableSectionHeading' colspan='2'>Actions:</td>
</tr>
-->
<tr>
<td align='right'>View checked items:
<select name='workflow'>
<option value='scanning'>Scanning</option>
<option value='processing'>Processing</option>
<option value='postProcessing'>Post-processing</option>
<option value='finalization'>Finalization</option>
</select>
</td>
<td valign='bottom'>
<input type='submit' value='View Workflow' onclick='return setFormActionImageProjects(document.frm);'>
<input type='hidden' name='orderBy' value='$orderBy'>
</td>
</tr>
</table>

</form>\n";
echo $newSearchLink;
}  // END if ($num >= 1)
?>
</body>
</html>
