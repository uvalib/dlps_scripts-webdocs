<?php

/*
  saveImageProject.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-01-27
  Last modified: 2007-03-20

  Saves user-entered data to database, either by inserting a new
  record or updating an existing record, as appropriate.

  Receives data from: imageProjects.php
  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: followSaveImageProject.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

//--------------------
// validate user input
//--------------------

$location = 'Location: ../err/badInput.php?msg=';

// name
if (empty($projectName)) {
  header($location . urlencode('Name of project is required'));
  exit;
}

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}

// ID
if ($mode == 'update') {
  if (empty($projectId)) {
    header($location . urlencode('Project ID is required'));
    exit;
  }
}

// content model
// this is probably unnecessary, since this value comes from a drop-down menu, but just to be sure...
if (!empty($contentModel)) {
  if ( ($contentModel == 'uvaHighRes') || ($contentModel == 'uvaLowRes') ) {
    // ok
  } else {
    header($location . urlencode("Content model cannot be '$contentModel'; must be either 'uvaHighRes' or 'uvaLowRes'"));
    exit;
  }
}

// date materials due
if (!empty($dateMaterialsDue)) {
  $test = formatDateISO($dateMaterialsDue);
  if ( empty($test) ) {
    header($location . urlencode("Value '$dateMaterialsDue' for Materials Due Date is not a valid date"));
    exit;
  } else {
    $dateMaterialsDue = $test;
  }
}

// date materials returned
if (!empty($dateMaterialsReturned)) {
  $test = formatDateISO($dateMaterialsReturned);
  if ( empty($test) ) {
    header($location . urlencode("Value '$dateMaterialsReturned' for Materials Returned Date is not a valid date"));
    exit;
  } else {
    $dateMaterialsReturned = $test;
  }
}

// "Number of ..." fields: must be an integer
$numberSlides = trim($numberSlides);
if ($numberSlides) {
  if (! preg_match('/^\d+$/', $numberSlides) ) {
    header($location . urlencode("If provided, 'Number of slides' must be a whole number"));
    exit;
  }
}

$numberBookPages = trim($numberBookPages);
if ($numberBookPages) {
  if (! preg_match('/^\d+$/', $numberBookPages) ) {
    header($location . urlencode("If provided, 'Number of book pages' must be a whole number"));
    exit;
  }
}

$numberDigitalImages = trim($numberDigitalImages);
if ($numberDigitalImages) {
  if (! preg_match('/^\d+$/', $numberDigitalImages) ) {
    header($location . urlencode("If provided, 'Number of digital images' must be a whole number"));
    exit;
  }
}

$numberBooks = trim($numberBooks);
if ($numberBooks) {
  if (! preg_match('/^\d+$/', $numberBooks) ) {
    header($location . urlencode("If provided, 'Number of books' must be a whole number"));
    exit;
  }
}

$numberDigitalMedia = trim($numberDigitalMedia);
if ($numberDigitalMedia) {
  if (! preg_match('/^\d+$/', $numberDigitalMedia) ) {
    header($location . urlencode("If provided, 'Number of discs/media' must be a whole number"));
    exit;
  }
}

// connect to db
$connection = connect();

// prep user input
$projectName = clean2($projectName, $connection, $projectNameMaxLength);
$projectDesc = clean2($projectDesc, $connection, $projectDescMaxLength);
$notes = clean2($notes, $connection);


//--------------------
// build SQL statement
//--------------------

if ($mode == 'update') {
  if ($chkDelete) {
    testPerm('imageProjectsDelete');
    $mode = 'delete';
    $sql = "DELETE FROM imageProjects";
  } else {
    testPerm('imageProjectsUpdate');
    $sql = "UPDATE imageProjects SET";
  }
  $where = " WHERE projectId = $projectId LIMIT 1";
} else {
  testPerm('imageProjectsInsert');
  $sql = "INSERT INTO imageProjects SET";
  $where = '';
}

if ($mode == 'delete') {
  $values = '';
} else {
  if (empty($projectName)) { $value = "NULL"; } else { $value = "'$projectName'"; }
  $values = " projectName = $value";

  if (empty($projectDesc)) { $value = "NULL"; } else { $value = "'$projectDesc'"; }
  $values .= ", projectDesc = $value";

  if (empty($dateMaterialsDue)) { $value = "NULL"; } else { $value = "'$dateMaterialsDue'"; }
  $values .= ", dateMaterialsDue = $value";

  if (empty($contactId)) { $value = "NULL"; } else { $value = "'$contactId'"; }
  $values .= ", contactId = $value";

  if (empty($contentModel)) { $value = "NULL"; } else { $value = "'$contentModel'"; }
  $values .= ", contentModel = $value";

  if (empty($numberSlides)) { $value = "0"; } else { $value = $numberSlides; }
  $values .= ", numberSlides = $value";

  if (empty($numberBookPages)) { $value = "0"; } else { $value = $numberBookPages; }
  $values .= ", numberBookPages = $value";

  if (empty($numberDigitalImages)) { $value = "0"; } else { $value = $numberDigitalImages; }
  $values .= ", numberDigitalImages = $value";

  if (empty($dateMaterialsReturned)) { $value = "NULL"; } else { $value = "'$dateMaterialsReturned'"; }
  $values .= ", dateMaterialsReturned = $value";

  if (empty($numberBooks)) { $value = "0"; } else { $value = $numberBooks; }
  $values .= ", numberBooks = $value";

  if (empty($numberDigitalMedia)) { $value = "0"; } else { $value = $numberDigitalMedia; }
  $values .= ", numberDigitalMedia = $value";

  if (empty($notes)) { $value = "NULL"; } else { $value = "'$notes'"; }
  $values .= ", notes = $value";

  if ($mode == 'insert') {
    $values .= ", dateTimeCreated = NOW()";
    $values .= ", createdByUser = '$_SESSION[alias]'";
  }
}

$sql .= $values . $where;


//----------------------
// execute SQL statement
//----------------------

if ( mysql_query($sql, $connection) ) {
  if ($mode == 'insert') {
    $projectId = mysql_insert_id();
  }
  $affected = mysql_affected_rows();

  // store SQL statement in session variable for later display in debugging mode
  $_SESSION['saveImageProject']['sql'] = $sql;

  if ($mode == 'insert') {

    // add corresponding new record to each workflow table

    // add to scanning table
    $sql = "INSERT INTO imageProjectsScanning SET projectId = $projectId";
    query($sql, $connection);

    // add to processing table
    $sql = "INSERT INTO imageProjectsProcessing SET projectId = $projectId";
    query($sql, $connection);

    // add to post-processing table
    $sql = "INSERT INTO imageProjectsPostProcessing SET projectId = $projectId";
    query($sql, $connection);

    // add to finalization table
    $sql = "INSERT INTO imageProjectsFinalization SET projectId = $projectId";
    query($sql, $connection);

  } elseif ($mode == 'delete') {

    // delete corresponding record from each workflow table

    // delete from scanning table
    $sql = "DELETE FROM imageProjectsScanning WHERE projectId = $projectId LIMIT 1";
    query($sql, $connection);

    // delete from processing table
    $sql = "DELETE FROM imageProjectsProcessing WHERE projectId = $projectId LIMIT 1";
    query($sql, $connection);

    // delete from post-processing table
    $sql = "DELETE FROM imageProjectsPostProcessing WHERE projectId = $projectId LIMIT 1";
    query($sql, $connection);

    // delete from finalization table
    $sql = "DELETE FROM imageProjectsFinalization WHERE projectId = $projectId LIMIT 1";
    query($sql, $connection);
  }

  // redirect, indicating success
  header("Location: followSaveImageProject.php?mode=$mode&projectId=$projectId&affected=$affected");
} else {
  die($dbErrorPreface . "Unable to $mode image project '$projectName': " . mysql_error($connection) . "<br><br>$sql");
}

?>