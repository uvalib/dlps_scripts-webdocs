<?php

/*
  imageProjects.php - page for managing image projects
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-01-25
  Last modified: 2007-03-20

  If no 'projectId' parameter, lists projects already defined.
  If ID is 'new', displays add-new form for defining a project.
  If ID is a number, displays edit form for editing an existing project.
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

$siteArea = 'Image Projects';

// connect to db
$connection = connect();

// get associative array representing table 'imageProjectContacts'
$imageProjectContacts = getHashImageProjectContacts($connection);

// get associative array of tracking system users
$users = getHashUsers($connection);

if ( empty($projectId) ) {
  // list existing projects
  $mode = 'list';
  $pageTitle = 'Projects';
  testPerm('imageProjectsSelect');
} else {
  if ($projectId == 'new') {
    // display enter-new form
    $mode = 'insert';
    $pageTitle = 'Enter New Project';
    $submitCaption = ' Add ';
    $required = "<span class='required'>(required)</span>";
    testPerm('imageProjectsInsert');
  } else {
    // display edit form
    $mode = 'update';
    $pageTitle = 'Edit Project';
    $submitCaption = 'Update';
    $returnToSearchResults = "<p><a href='search/search.php'>Return to search results</a></p>\n";

    // test permissions; need Select to view item details, Update to enable submit button
    testPerm('imageProjectsSelect');
    if (!getPerm('imageProjectsUpdate')) { $submitAppearance = ' disabled'; }
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
<script type="text/javascript" src="../inc/tracksys.js"></script>
</head>

<?php
if ($mode == 'list') {
  // list existing projects

  if (getPerm('imageProjectsInsert')) {
    $addNewLink = "<p><a href='?projectId=new'>Enter new project</a></p>";
  } else {
    $addNewLink = "<p><span class='disabled'>Enter new project</span></p>";
  }

  echo <<<EOD
<body>
<h1>$siteArea</h1>
<h2>$pageTitle</h2>
$addNewLink
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
EOD;

  if (empty($orderBy) or $orderBy == 'projectName') {
    echo "<td>Name</td>\n";
    $orderBySql = "ORDER BY projectName";
  } else {
    echo "<td><a class='head' href='?orderBy=projectName' title='Sort by Name'>Name</a></td>\n";
  }

  if ($orderBy == 'projectDesc') {
    echo "<td>Description</td>\n";
    $orderBySql = "ORDER BY projectDesc";
  } else {
    echo "<td><a class='head' href='?orderBy=projectDesc' title='Sort by Description'>Description</a></td>\n";
  }

  if ($orderBy == 'isFinished') {
    echo "<td>Finished</td>\n";
    $orderBySql = "ORDER BY step10a";
  } else {
    echo "<td><a class='head' href='?orderBy=isFinished' title='Sort by finished status'>Finished</a></td>\n";
  }
?>

<td></td>
</tr>

<?php
  $sql = "SELECT * FROM imageProjects $orderBySql";
  $result = query($sql, $connection);
  $num = mysql_num_rows($result);
  if ($num == 0) { echo "<tr><td cols='2'><b>0</b> items</td></tr>\n"; }
  while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);
      if ($row['step10a']) { $isFinished = 'Yes'; } else { $isFinished = 'No'; }

      echo "<tr$class>
<td class='nowrap'><a href='viewWorkflow.php?projectId=$row[projectId]'>$row[projectName]</a></td>
<td>$row[projectDesc]</td>
<td>$isFinished</td>
<td><a href='?projectId=$row[projectId]'>Edit project details</a></td>
</tr>\n";
  }
  echo "</table>\n";

  if ($debugMode) {
    //echo "<p>SQL: $sql</p>\n";
  }
}  // END if ($mode == 'list')

else {
  if ($mode == 'update') {
    $sql = "SELECT * FROM imageProjects WHERE projectId = '$projectId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $projectId = $row['projectId'];
    }
  }

  if ($deleteEnabled and $mode == 'update' and getPerm('imageProjectsDelete')) {
    $onSubmit = " onsubmit='return confirmDelete(document.frm, \"Image Project\");'";
  }
?>

<body onload='document.frm.projectName.focus();'>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
  $viewWorkflowLink = "<p><a href='viewWorkflow.php?projectId=$projectId'>View workflow</a></p>\n";
  if ($mode == 'update') {
    echo $viewWorkflowLink;
  }

  if ($_SESSION['searchImageProjectsSql']) {
    echo $returnToSearchResults;
  }
?>

<form name="frm" method="POST" action="saveImageProject.php"<?=$onSubmit?>>
<input type="hidden" name="mode" value="<?=$mode?>">
<input type="hidden" name="projectId" value="<?=$projectId?>">
<table cellpadding="4">
<tr>
<td class="label">Project name:</td>
<td>
<input type="text" name="projectName" size="40" value="<?=$row[projectName]?>" maxlength="<?=$projectNameMaxLength?>">
<?=$required?></td>
</tr>

<tr>
<td class="label">Description:</td>
<td><input type="text" name="projectDesc" value="<?=$row[projectDesc]?>" size="60" maxlength="<?=$projectDescMaxLength?>"></td>
</tr>

<tr>
<td class="label">Contact person:</td>
<td class="nowrap">
<select name="contactId">
<option value=''></option>
<?php
  foreach ($imageProjectContacts as $contactId => $contactName) {
    $selected = '';
    if ( ! empty($row['contactId']) ) {
      if ( $contactId == $row['contactId'] ) { $selected = ' selected'; }
    }
    echo "<option value='$contactId'$selected>$contactName ($contactId)</option>\n";
  }
?>
</select>
</td>
</tr>

<tr>
<td class="label">Content model:</td>
<td class="nowrap">
<select name="contentModel">
<option value=''></option>
<?php
  $selected = '';
  if ($row['contentModel'] == 'uvaHighRes') { $selected = ' selected'; }
  echo "<option value='uvaHighRes'$selected>uvaHighRes</option>\n";

  $selected = '';
  if ($row['contentModel'] == 'uvaLowRes') { $selected = ' selected'; }
  echo "<option value='uvaLowRes'$selected>uvaLowRes</option>\n";
?>
</select>
</td>
</tr>

<?php
  if ($mode == 'insert') {
    $dateMaterialsDue = '';
  } else {
    if (empty($row['dateMaterialsDue'])) {
      $dateMaterialsDue = '';
    } else {
      if ($row['dateMaterialsDue'] == '0000-00-00') {
	$dateMaterialsDue = '';
      } else {
	if ( preg_match('/\d{4}-\d{2}-\d{2}/', $row['dateMaterialsDue']) ) {
	  $dateMaterialsDue = formatDateUS($row['dateMaterialsDue']);
	} else {
	  $dateMaterialsDue = $row['dateMaterialsDue'];
	}
      }
    }
  }
?>
<tr>
<td class="label">Materials due date:</td>
<td><input type="text" name="dateMaterialsDue" size="10" maxlength="10" value="<?=$dateMaterialsDue?>"></td>
</tr>

<?php
  if ($mode == 'insert') {
    $dateMaterialsReturned = '';
  } else {
    if (empty($row['dateMaterialsReturned'])) {
      $dateMaterialsReturned = '';
    } else {
      if ($row['dateMaterialsReturned'] == '0000-00-00') {
	$dateMaterialsReturned = '';
      } else {
	if ( preg_match('/\d{4}-\d{2}-\d{2}/', $row['dateMaterialsReturned']) ) {
	  $dateMaterialsReturned = formatDateUS($row['dateMaterialsReturned']);
	} else {
	  $dateMaterialsReturned = $row['dateMaterialsReturned'];
	}
      }
    }
  }
?>
<tr>
<td class="label">Materials returned on:</td>
<td><input type="text" name="dateMaterialsReturned" size="10" maxlength="10" value="<?=$dateMaterialsReturned?>"></td>
</tr>

<?php
  // number of books (from which book pages are to be digitized)
  if ($row['numberBooks'] == 0) {
    $numberBooks = '';
  } else {
    $numberBooks = $row['numberBooks'];
  }
  echo <<<EOD
<tr>
<td class="label">Number of books:</td>
<td><input type="text" name="numberBooks" size="5" maxlength="10" value="$numberBooks" title="Number of books (from which book pages are to be digitized)"></td>
</tr>
EOD;
  echo "\n\n";

  // number of DVDs or other media (from which digital images for the project are taken)
  if ($row['numberDigitalMedia'] == 0) {
    $numberDigitalMedia = '';
  } else {
    $numberDigitalMedia = $row['numberDigitalMedia'];
  }
  echo <<<EOD
<tr>
<td class="label">Number of discs/media:</td>
<td><input type="text" name="numberDigitalMedia" size="5" maxlength="10" value="$numberDigitalMedia" title="Number of DVDs or other media (from which digital images for the project are taken)"></td>
</tr>
EOD;
  echo "\n\n";

  // number of slides
  if ($row['numberSlides'] == 0) {
    $numberSlides = '';
  } else {
    $numberSlides = $row['numberSlides'];
  }
  echo <<<EOD
<tr>
<td class="label">Number of slides:</td>
<td><input type="text" name="numberSlides" size="5" maxlength="10" value="$numberSlides"></td>
</tr>
EOD;
  echo "\n\n";

  // number of book pages
  if ($row['numberBookPages'] == 0) {
    $numberBookPages = '';
  } else {
    $numberBookPages = $row['numberBookPages'];
  }
  echo <<<EOD
<tr>
<td class="label">Number of book pages:</td>
<td><input type="text" name="numberBookPages" size="5" maxlength="10" value="$numberBookPages"></td>
</tr>
EOD;
  echo "\n\n";

  // number of digital images
  if ($row['numberDigitalImages'] == 0) {
    $numberDigitalImages = '';
  } else {
    $numberDigitalImages = $row['numberDigitalImages'];
  }
  echo <<<EOD
<tr>
<td class="label">Number of digital images:</td>
<td><input type="text" name="numberDigitalImages" size="5" maxlength="10" value="$numberDigitalImages"></td>
</tr>
EOD;
  echo "\n\n";

  if ($mode == 'update') {

    // total number of images
    $totalImages = $row['numberSlides'] + $row['numberBookPages'] + $row['numberDigitalImages'];
    echo <<<EOD
<tr>
<td class="label">Total number of images:</td>
<td>$totalImages</td>
</tr>
EOD;
    echo "\n";

    // number of metadata files
    $warning = '';
    $numberMetadataFiles = '';
    if ($row['numberMetadataFiles']) {
      $numberMetadataFiles = $row['numberMetadataFiles'];
      if ($numberMetadataFiles != $totalImages) {
	$warning = "<span style='color: #990000'><b>WARNING:</b> The number of metadata files does not equal the total number of images for this project.</span>";
      }
    }
    echo <<<EOD
<tr>
<td class="label">Number of metadata files:</td>
<td>$numberMetadataFiles $warning</td>
</tr>
EOD;
    echo "\n";

  }  // END if ($mode == 'update')
?>

<tr>
<td class="label" style="vertical-align: top">Notes:</td>
<td><textarea name="notes" cols="60" rows="3"><?=$row['notes']?></textarea></td>
</tr>

<?php
  if ($mode == 'update') {
    $dateTimeCreated = formatDateTimeUS($row['dateTimeCreated']);

    $user = '';
    foreach ($users as $id => $name) {
      if ($row['createdByUser'] == $id) {
        $user = "$name ($id)";
      }
    }

    echo <<<EOD
<tr>
<td class="label">Project created:</td>
<td>$dateTimeCreated by $user</td>
</tr>
EOD;
  }

  if ($row['step10a']) {
    $dateTimeFinished = formatDateTimeUS($row['step10aDateTime']);

    $user = '';
    foreach ($users as $id => $name) {
      if ($row['step10aByUser'] == $id) {
        $user = "$name ($id)";
      }
    }

    echo <<<EOD
<tr>
<td class="label">Project declared finished:</td>
<td>$dateTimeFinished by $user</td>
</tr>
EOD;
  }

  if ($deleteEnabled and $mode == 'update' and getPerm('imageProjectsDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>

<tr>
<td></td>
<td>
<input type='submit' name='go' value='<?=$submitCaption?>'<?=$submitAppearance?>>
<input type='button' value='Cancel' onclick='history.back();'>
</td>
</tr>

<?php
  if ($mode == 'update') {
    // show list of image files associated with this project
?>

<tr>
<td></td>
<td><hr></td>
</tr>

<tr>
<td class="label" style="vertical-align: top">List of files:</td>
<td>

<?php
    // get image files associated with this project
    $sql = "SELECT filename, irisNumber FROM imageProjectsImageFiles WHERE projectId = $projectId ORDER BY filename";
    $result = query($sql, $connection);
    $num = mysql_num_rows($result);
    if ($num) {
      // show list of image files (non-editable)
      echo <<<EOD
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>Filename</td>
<td>Iris number</td>
</tr>
EOD;

      $c = 0;
      $irisNumberWarning = '';
      while ( $row = mysql_fetch_array($result) ) {
        $c++;
        $class = getRowClass($c);

        if (empty($row['irisNumber'])) {
	  $irisNumber = '<span class="attn">MISSING</span>';
	  $irisNumberWarning = "<p style='color:#990000'><b>WARNING:</b> One or more filenames has no associated Iris number</p>\n";
        } else {
	  $irisNumber = $row['irisNumber'];
        }

        echo <<<EOD
<tr$class>
<td>$row[filename]</td>
<td>$irisNumber</td>
</tr>
EOD;
      }
      echo "</table>\n";
      echo "<p>Total number of image files: $c</p>\n";
      if ($c != $totalImages) {
        echo "<p style='color:#990000'><b>WARNING:</b> The total number of <i>images</i> associated with this project (<b>$totalImages</b>) does NOT equal the number of <i>image files</i> listed here (<b>$c</b>).</p>\n";
      }
      echo $irisNumberWarning;
    }

    // provide link for importing file list
    echo "<p><a href='setupImportIviewList.php?projectId=$projectId'>Import iView file lists</a></p>\n";
?>

</td>
</tr>

<?php
  }  // END if ($mode == 'update')
?>

</table>
</form>
<?php
  if ($mode == 'update') {
    echo $viewWorkflowLink;
  }

  if ($_SESSION['searchImageProjectsSql']) {
    echo $returnToSearchResults;
  }
}  // END if ($mode == 'list') { ... } else
?>
</body>
</html>
