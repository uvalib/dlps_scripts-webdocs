<?php

/*
  followImportRimageLog.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-05-21
  Last modified: 2006-06-09

  This page is displayed after successfully importing one or more
  iView text files (lists of image files in an iView catalog).

  Receives data from: importIviewList.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/auth.php';

$location = 'Location: ../err/badInput.php?msg=';

if (empty($importCount)) {
  header($location . urlencode('Number of files to import is required'));
  exit;
}

if (empty($projectId)) {
  header($location . urlencode('Image project to use is required'));
  exit;
}

// connect to db
$connection = connect();

$siteArea = 'Image Projects';
$pageTitle = 'Import Status';

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
// display failed imports, if any
if ($_SESSION['imageProjectsImportBad']) {
  echo "<p class='error'><b>Import FAILED for the following files:</b></p>\n";
  echo "<table cellpadding='4' class='error'>\n";

  for ($i = 1; $i <= $importCount; $i++) {
    $key = "file$i";
    if ($_SESSION['imageProjectsImportBad'][$key]) {
      echo "<tr><td class='label'>File $i:</td>";
      echo "<td>" . $_SESSION['imageProjectsImportBad'][$key] . "</td>";
      echo "</tr>\n";
    }
  }

  echo "</table>\n";
}

// display imports succeeded
if ($_SESSION['imageProjectsImportGood']) {
  echo "<p class='updated'><b>Import succeeded for the following files:</b></p>\n";
  echo "<table cellpadding='4' class='updated'>\n";

  for ($i = 1; $i <= $importCount; $i++) {
    $key = "file$i";
    if ($_SESSION['imageProjectsImportGood'][$key]) {
      $volumeId = $_SESSION['imageProjectsImportGood'][$key];
      echo "<tr><td class='label'>File $i</td>";
      echo "</tr>\n";
    }
  }

  echo "</table>\n";
}

// get project name
$sql = "SELECT projectName FROM imageProjects WHERE projectId = $projectId";
$result = query($sql, $connection);
if (mysql_num_rows($result) == 1) {
  $row = mysql_fetch_array($result);
  $projectName = $row['projectName'];
} else {
  $projectName = '';
}

// provide navigation link
echo "<p><a href='imageProjects.php?projectId=$projectId'>Return to project $projectName</a></p>\n";

/*
// display all image files associated with this project
$sql = "SELECT * FROM imageProjectsImageFiles WHERE projectId = $projectId ORDER BY filename";
$result = query($sql, $connection);
$num = mysql_num_rows($result);
if ($num) {
  echo <<<EOD
<p>Image files associated with project <b><a href="imageProjects.php?projectId=$projectId">$projectName</a></b>:</p>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>Filename</td>
<td>Iris number</td>
</tr>
EOD;

  while ( $row = mysql_fetch_array($result) ) {
    $c++;
    $class = getRowClass($c);
    echo <<<EOD
<tr$class>
<td>$row[filename]</td>
<td>$row[irisNumber]</td>
</tr>
EOD;
  }
  echo "</table>\n";

  if ($debugMode) {
    //echo "<p>SQL: $sql</p>\n";
  }
}
*/
?>
</body>
</html>
