<?php

/*
  saveFinalization.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-05-18
  Last modified: 2006-10-31

  Saves changes to database for finalization workflow steps (image projects).

  Receives data from: confirmFinalization.php
  Redirects to: workflowFinalization.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to database
$connection = connect();

// test permissions
testPerm('imageProjectsUpdate');

// get all IDs from the posted form
$ids = array();
if ($_POST['projectId']) {
  // a single ID was specified
  $projectId = $_POST['projectId'];
  $ids[] = $projectId;
} else {
  // get multiple IDs from form on preceding page
  foreach ($_POST as $name => $value) {
    if ( preg_match('/^projectId_/', $name) ) {
      $ids[] = $value;
    }
  }
}

// test for required parameters
if (empty($ids)) {
  $location = 'Location: ../../err/badInput.php?msg=';
  header($location . urlencode('At least one Project ID is required'));
  exit;
}

// for each ID, update values as needed
$updatedIds = array();
$projectNames = array();
foreach ($ids as $id) {
  $updates = '';
  for ($i = 1; $i <= 7; $i++) {
    switch ($i) {
    case 1: $columnName = 'makeDerivatives'; break;
    case 2: $columnName = 'extractMetadata'; break;
    case 3: $columnName = 'copyToRepo'; break;
    case 4: $columnName = 'burn'; break;
    case 5: $columnName = 'importLogs'; break;
    case 6: $columnName = 'pogo2archive'; break;
    case 7: $columnName = 'finished'; break;
    }

    if (!empty($_POST[$columnName . '_' . $id])) {
      $value = $_POST[$columnName . '_' . $id];
      if ($value == 'true') {
	$updates .= " $columnName = 1,";
      } else {
	$updates .= " $columnName = 0,";
      }
    }
  }

  if (empty($updates)) {
    // no updates for this ID; continue with next ID
    continue;
  }

  $updates = preg_replace('/,$/', '', $updates);  // strip final comma

  // determine whether to send email notification for "Copy to ReadyRepo" step completion
  if ( preg_match('/copyToRepo = 1/', $updates) ) {
    $sql = "SELECT imageProjects.projectName
            FROM imageProjectsFinalization LEFT JOIN imageProjects USING (projectId)
            WHERE imageProjectsFinalization.projectId = $id AND imageProjectsFinalization.copyToRepo = 0";
    $result = query($sql, $connection);
    if ( mysql_num_rows($result) == 1 ) {
      $row = mysql_fetch_array($result);
      $projectNames[] = $row['projectName'];
    }
  }

  // perform update for this ID
  $sql = "UPDATE imageProjectsFinalization SET $updates WHERE projectId = $id LIMIT 1";
  $msg = "Unable to update record for project ID '$id' in table imageProjectsFinalization: ";
  if ( mysql_query($sql, $connection) ) {
    if (mysql_affected_rows() == 1) {
      $updatedIds[$id] = $id;
    } else {
      die($dbErrorPreface . $msg . "ID not found");
    }
  } else {
    die($dbErrorPreface . $msg . mysql_error($connection) . "<br><br>$sql");
  }
}

// send email notification if applicable
if ($projectNames) {
  $to = $imageProjectsEmailRecipients;
  $headers = "From: $emailFrom";
  $subject = "$appTitle - Finalization update for image projects";

  $body = "User " . getUserDesc() . " has updated the $appTitle as follows:\n";
  $body .= "          Module: Image Tracking\n";
  $body .= "        Workflow: Finalization\n";
  $body .= "  Step completed: Copy to ReadyRepo\n";

  $temp = '';
  foreach ($projectNames as $projectName) {
    $temp .= "                  $projectName\n";
  }
  $temp = ltrim($temp);  // strip leading whitespace
  $body .= "   Image project: $temp\n";

  $body = wordwrap($body, 70);
  mail($to, $subject, $body, $headers);
}

// redirect, indicating success
$ids = '';
foreach ($updatedIds as $id) {
  $ids .= $id . '|';
}
$ids = preg_replace('/\|$/', '', $ids);  // strip final |
header("Location: workflowFinalization.php?status=updated&ids=$ids");
?>