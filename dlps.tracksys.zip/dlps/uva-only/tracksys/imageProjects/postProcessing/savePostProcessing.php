<?php

/*
  savePostProcessing.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-05-18
  Last modified: 2006-08-04

  Saves changes to database for post-processing workflow steps (image projects).

  Receives data from: confirmPostProcessing.php
  Redirects to: workflowPostProcessing.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to database
$connection = connect();

// test permissions
testPerm('imageProjectsUpdate');

// get all IDs from the posted form
$ids = array();
if ($_POST['projectId']) {
  // a single ID was specified
  $projectId = $_POST['projectId'];
  $ids[] = $projectId;
} else {
  // get multiple IDs from form on preceding page
  foreach ($_POST as $name => $value) {
    if ( preg_match('/^projectId_/', $name) ) {
      $ids[] = $value;
    }
  }
}

// test for required parameters
if (empty($ids)) {
  $location = 'Location: ../../err/badInput.php?msg=';
  header($location . urlencode('At least one Project ID is required'));
  exit;
}

// for each ID, update values as needed
$updatedIds = array();
$projectNames_copyWeb = array();
$projectNames_finished = array();
foreach ($ids as $id) {
  $updates = '';
  for ($i = 1; $i <= 5; $i++) {
    switch ($i) {
      case 1: $columnName = 'postProcessing'; break;
      case 2: $columnName = 'qa'; break;
      case 3: $columnName = 'buildWeb'; break;
      case 4: $columnName = 'copyWeb'; break;
      case 5: $columnName = 'finished'; break;
    }

    if (!empty($_POST[$columnName . '_' . $id])) {
      $value = $_POST[$columnName . '_' . $id];
      if ($value == 'true') {
	$updates .= " $columnName = 1,";
      } else {
	$updates .= " $columnName = 0,";
      }
    }
  }

  if (empty($updates)) {
    // no updates for this ID; continue with next ID
    continue;
  }

  $updates = preg_replace('/,$/', '', $updates);  // strip final comma

  // determine whether to send email notification for "Copy web to dropbox" step completion
  if ( preg_match('/copyWeb = 1/', $updates) ) {
    $sql = "SELECT imageProjects.projectName
            FROM imageProjectsPostProcessing LEFT JOIN imageProjects USING (projectId)
            WHERE imageProjectsPostProcessing.projectId = $id AND imageProjectsPostProcessing.copyWeb = 0";
    $result = query($sql, $connection);
    if ( mysql_num_rows($result) == 1 ) {
      $row = mysql_fetch_array($result);
      $projectNames_copyWeb[] = $row['projectName'];
    }
  }

  // determine whether to send email notification for "Finished" step completion
  if ( preg_match('/finished = 1/', $updates) ) {
    $sql = "SELECT imageProjects.projectName
            FROM imageProjectsPostProcessing LEFT JOIN imageProjects USING (projectId)
            WHERE imageProjectsPostProcessing.projectId = $id AND imageProjectsPostProcessing.finished = 0";
    $result = query($sql, $connection);
    if ( mysql_num_rows($result) == 1 ) {
      $row = mysql_fetch_array($result);
      $projectNames_finished[] = $row['projectName'];
    }
  }

  // perform update for this ID
  $sql = "UPDATE imageProjectsPostProcessing SET $updates WHERE projectId = $id LIMIT 1";
  $msg = "Unable to update record for project ID '$id' in table imageProjectsPostProcessing: ";
  if ( mysql_query($sql, $connection) ) {
    if (mysql_affected_rows() == 1) {
      $updatedIds[$id] = $id;
    } else {
      die($dbErrorPreface . $msg . "ID not found");
    }
  } else {
    die($dbErrorPreface . $msg . mysql_error($connection) . "<br><br>$sql");
  }
}

// send email notification if applicable
if ($projectNames_copyWeb) {
  $to = $imageProjectsEmailRecipients;
  $headers = "From: $emailFrom";
  $subject = "$appTitle - Post-processing update for image projects";

  $body = "User " . getUserDesc() . " has updated the $appTitle as follows:\n";
  $body .= "          Module: Image Tracking\n";
  $body .= "        Workflow: Post-processing\n";
  $body .= "  Step completed: Copy web to dropbox\n";

  $temp = '';
  foreach ($projectNames_copyWeb as $projectName) {
    $temp .= "                  $projectName\n";
  }
  $temp = ltrim($temp);  // strip leading whitespace
  $body .= "   Image project: $temp\n\n";

  $body = wordwrap($body, 70);
  mail($to, $subject, $body, $headers);
}

if ($projectNames_finished) {
  $to = $imageProjectsEmailRecipients;
  $headers = "From: $emailFrom";
  $subject = "$appTitle - Post-processing update for image projects";

  $body = "User " . getUserDesc() . " has updated the $appTitle as follows:\n";
  $body .= "          Module: Image Tracking\n";
  $body .= "        Workflow: Post-processing\n";
  $body .= "  Step completed: Finished\n";

  $temp = '';
  foreach ($projectNames_finished as $projectName) {
    $temp .= "                  $projectName\n";
  }
  $temp = ltrim($temp);  // strip leading whitespace
  $body .= "   Image project: $temp\n\n";

  $body .= "These projects should be ready for generation of derivatives.\n\n";

  $body = wordwrap($body, 70);
  mail($to, $subject, $body, $headers);
}

// redirect, indicating success
$ids = '';
foreach ($updatedIds as $id) {
  $ids .= $id . '|';
}
$ids = preg_replace('/\|$/', '', $ids);  // strip final |
header("Location: workflowPostProcessing.php?status=updated&ids=$ids");
?>