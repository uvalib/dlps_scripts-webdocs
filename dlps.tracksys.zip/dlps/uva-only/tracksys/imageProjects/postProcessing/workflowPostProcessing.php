<?php

/*
  workflowPostProcessing.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-05-17
  Last modified: 2006-06-05

  Displays steps in the post-processing workflow for image
  projects. Allows user to check or uncheck the various steps in the
  workflow, to indicate completion or incompletion of the steps.

  Receives data from: viewWorkflow.php
  Posts data to: confirmPostProcessing.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Image Projects';
$pageTitle = 'Post-processing Workflow';

// connect to db
$connection = connect();

// test permissions; need Select to view item details, Update to enable submit button
testPerm('imageProjectsSelect');
if (!getPerm('imageProjectsUpdate')) { $submitAppearance = ' disabled'; }

// get IDs of projects to be displayed
if ($_GET['status'] == 'updated') {
  // we are returning here after an update; get IDs from query string
  $ids = explode('|', $_GET['ids']);
} else {
  $ids = array();
  if ($_GET['projectId']) {
    // a single ID was specified (coming from View Workflow page: viewWorkflow.php)
    $projectId = $_GET['projectId'];
    $ids[] = $projectId;
  } else {
    // get multiple IDs from form on preceding page (coming from Search Results page: search.php)
    foreach ($_GET as $name => $value) {
      if ( preg_match('/^projectId_/', $name) ) {
        $ids[] = $value;
      }
    }
  }
}

// test for required parameters
if (empty($ids)) {
  $location = 'Location: ../../err/badInput.php?msg=';
  header($location . urlencode('At least one Project ID is required'));
  exit;
}

// build SQL statement
$sql = "SELECT imageProjectsPostProcessing.*, imageProjects.projectName
  FROM imageProjectsPostProcessing LEFT JOIN imageProjects USING (projectId)
  WHERE imageProjectsPostProcessing.projectId IN (";
foreach ($ids as $id) {
  $sql .= "$id,";
}
$sql = preg_replace('/,$/', '', $sql);  // remove final comma
$sql .= ")";

// execute query
$result = query($sql, $connection);
if (! mysql_num_rows($result) >= 1) {
  $location = 'Location: ../../err/error.php?msg=';
  header($location . urlencode("No matching projects found in table <b>imageProjectsScanning</b>"));
  exit;
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/imageProjects.js"></script>
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="GET" action="confirmPostProcessing.php">

<?php
//if ($debugMode) { echo "<p>$sql</p>\n"; }

if ($_GET['status'] == 'updated') {
  echo "<p class='updated'>Updated</p>\n";
}

if ($projectId) {
  echo "<input type='hidden' name='projectId' value='$projectId'>\n";
} else {
  echo $workflowNewSearchLink;
}

echo "<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td class='nowrap'>Project name</td>
<td align='center'>Post-processing</td>
<td align='center'>QA</td>
<td align='center'>Build web</td>
<td align='center'>Copy web to dropbox</td>
<td align='center'>Finished</td>
<td>&nbsp;</td>
</tr>\n";

$colspan = 7;   // total number of columns
$colspan1 = 3;  // half or so of total columns
$colspan2 = 4;  // second half of total columns

if (count($ids) > 1) {
  // include 'Check all' and 'Clear all' controls
  $c = 1;
  $class = getRowClass($c);
  echo "<tr$class><td>&nbsp;</td>\n";

  echoCheckAllClearAll('postProcessing');
  echoCheckAllClearAll('qa');
  echoCheckAllClearAll('buildWeb');
  echoCheckAllClearAll('copyWeb');
  echoCheckAllClearAll('finished');

  echo "<td>&nbsp;</td>\n</tr>\n";
}

while ( $row = mysql_fetch_array($result) ) {
  $c++;
  $class = getRowClass($c);
  $id = $row['projectId'];
  $idArg = '"' . $row['projectId'] . '"';

  if ($row['postProcessing'] == 0) { $postProcessingChecked = ''; } else { $postProcessingChecked = 'checked'; }
  if ($row['qa'] == 0)             { $qaChecked = ''; }             else { $qaChecked = 'checked'; }
  if ($row['buildWeb'] == 0)       { $buildWebChecked = ''; }       else { $buildWebChecked = 'checked'; }
  if ($row['copyWeb'] == 0)        { $copyWebChecked = ''; }        else { $copyWebChecked = 'checked'; }
  if ($row['finished'] == 0)       { $finishedChecked = ''; }       else { $finishedChecked = 'checked'; }

  echo "<tr$class>
<td><a href='../viewWorkflow.php?projectId=$id'>$row[projectName]</a>
<input type='hidden' name='projectId_$id' value='$id'></td>
<td align='center'><input type='checkbox' name='postProcessing_$id' $postProcessingChecked></td>
<td align='center'><input type='checkbox' name='qa_$id'             $qaChecked></td>
<td align='center'><input type='checkbox' name='buildWeb_$id'       $buildWebChecked></td>
<td align='center'><input type='checkbox' name='copyWeb_$id'        $copyWebChecked></td>
<td align='center'><input type='checkbox' name='finished_$id'       $finishedChecked></td>\n";

  if (count($ids) > 1) {
    echo "<td class='controls' nowrap>
<img src='../../img/check.gif' onclick='setCheckboxesRow(true, $idArg);' title='Check all for this row'>
<img src='../../img/square.gif' onclick='setCheckboxesRow(false, $idArg);' title='Clear all for this row'>
</td>\n";
  } else {
    echo "<td>&nbsp;</td>\n";
  }
  echo "</tr>\n";
}

$c++;
$class = getRowClass($c);

$temp = "<input type='submit' value='Update'$submitAppearance> <input type='reset' value='Reset'> ";
if ($_GET['status'] != 'updated') {
  $temp .= "<input type='button' value='Cancel' onclick='history.back();'>";
}
echo "<tr$class>
<td colspan='$colspan1' style='white-space: nowrap;'>$temp</td>
<td colspan='$colspan2' style='white-space: nowrap;' align='right'>$temp</td>
</tr>
</table>\n";

echo "<p></p><hr>
<table cellpadding='4'>
<tr>
<td align='right'>Change view:
<select name='workflow'>
<option value='scanning'>Scanning</option>
<option value='processing'>Processing</option>
<option value='finalization' selected>Finalization</option>
</select>
</td>
<td valign='bottom'>
<input type='button' value='View Workflow' onclick='if ( setFormActionImageProjects(document.frm) ) { document.frm.submit(); }'>
</td>
</tr>
</table>\n";

if (!$projectId) {
  echo $workflowNewSearchLink;
}
?>
</form>
</body>
</html>
