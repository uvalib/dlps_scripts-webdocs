<?php

/*
  importIviewList.php - reads an iView text file (list of image files
    in an iView catalog) and adds records to table imageProjectsImageFiles

  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-05-21
  Last modified: 2008-10-24

  2008-10-24: gpm2a: Import now works with Mac line endings as well as PC.

  Receives data from: setupImportIviewList.php
  If data is not valid, redirects to: err/badInput.php
  If uploaded file is imported successfully, redirects to: followImportIviewList.php
*/

import_request_variables('P');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

$location = 'Location: ../err/badInput.php?msg=';

if (empty($importCount)) {
  header($location . urlencode('Number of files to import is required'));
  exit;
}

if (empty($projectId)) {
  header($location . urlencode('Image project to use is required'));
  exit;
}

// test permissions (use update permission, because adding to list of files is updating the image project)
//testPerm('imageProjectsUpdate');  // DEBUG

// read each uploaded file
for ($i = 1; $i <= $importCount; $i++) {
  $key = "file$i";

  //-------------------
  // test uploaded file
  //-------------------

  if ( is_uploaded_file($_FILES[$key]['tmp_name']) ) {
    $size = $_FILES[$key]['size'];
    if ($size > 0) {
      // proceed
    } else {
      $_SESSION['imageProjectsImportBad'][$key] = "File $i is empty (0 bytes)";
      continue;
    }
  } else {
    $_SESSION['imageProjectsImportBad'][$key] = "File $i is not accessible as an uploaded file";
    continue;
  }


  //-------------------
  // read uploaded file
  //-------------------

  // read file into an array
  ini_set('auto_detect_line_endings', true);
  $lines = file($_FILES[$key]['tmp_name'], FILE_IGNORE_NEW_LINES);

  if (empty($lines)) {
    $_SESSION['imageProjectsImportBad'][$key] = "Cannot open file $i";
    continue;
  }


  //--------------------
  // parse uploaded file
  //--------------------

  // connect to db
  $connection = connect();

  $filenames = array(); $c = 0;
  foreach ($lines as $line) {
    $line = trim($line);
    if ( preg_match('/^([\w\-]+\.\w{3,4})\t/', $line, $matches) ) {
      // line appears to start with the expected "filename[tab]"
      $filename = clean2($matches[1], $connection);
      if ( preg_match('/^([\w\-]+\.\w{3,4})\t(\d+)/', $line, $matches) ) {
	$irisNumber = $matches[2];
      } else {
	$irisNumber = '';
      }
      if ($filename) {
	$record = array();
	$record[0] = $filename;
	$record[1] = $irisNumber;
	$filenames[$c] = $record;
	$c++;
      }
    }
  }


  //---------------------------------
  // validate data from uploaded file
  //---------------------------------

  if (empty($filenames)) {
    $_SESSION['imageProjectsImportBad'][$key] = "No filenames found in uploaded file";
    continue;
  }


  //-----------------------
  // write data to database
  //-----------------------

  // use a single INSERT statement to add multiple records, one for each image file
  $sql = "INSERT INTO imageProjectsImageFiles (projectId,filename,irisNumber) VALUES ";

  foreach ($filenames as $record) {
    $filename = $record[0];
    if ($record[1]) { $irisNumber = "'" . $record[1] . "'"; } else { $irisNumber = "NULL"; }
    if ($projectId && $filename) {
      $sql .= "($projectId,'$filename',$irisNumber),";
    }
  }

  $sql = preg_replace('/,$/', '', $sql);  // strip final comma

  if ( mysql_query($sql, $connection) ) {
    $_SESSION['imageProjectsImportGood'][$key] = $projectId;
  } else {
    $_SESSION['imageProjectsImportBad'][$key] = "Cannot import file $i: " . mysql_error($connection);
  }
}  // end for

// redirect
header("Location: followImportIviewList.php?importCount=$importCount&projectId=$projectId");
?>