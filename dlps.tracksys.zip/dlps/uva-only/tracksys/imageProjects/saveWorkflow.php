<?php

/*
  saveWorkflow.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-01-30
  Last modified: 2006-08-04

  Saves to database the completion of the image-project-workflow step
  specified.

  Receives data from: viewWorkflow.php
  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: viewWorkflow.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

//-----------------------------
// test for required parameters
//-----------------------------

$location = 'Location: ../err/badInput.php?msg=';

// ID of record to update
if (empty($projectId)) {
  header($location . urlencode('Missing parameter: Project ID is required'));
  exit;
}

// name of image project
if (empty($projectName)) {
  header($location . urlencode('Missing parameter: Project name is required'));
  exit;
}

// workflow step to update
if (empty($step)) {
  header($location . urlencode('Missing parameter: Workflow step to update is required'));
  exit;
}

// for step 4, number of new works and number of updates must be integers (or zero)
if ($step == 'step4') {
  if (empty($step4New)) {
    $step4New = 0;
  } else {
    if (! preg_match('/^\d+$/', $step4New) ) {
      header($location . urlencode("When approving step 4, number of new works must be a whole number"));
      exit;
    }
  }

  if (empty($step4Updates)) {
    $step4Updates = 0;
  } else {
    if (! preg_match('/^\d+$/', $step4Updates) ) {
      header($location . urlencode("When approving step 4, number of updates must be a whole number"));
      exit;
    }
  }
}

// connect to db
$connection = connect();

// test permissions
testPerm('imageProjectsUpdate');


//---------------------------------------------------
// perform tasks related to this step, as appropriate
//---------------------------------------------------

if ($step == 'step1a') {
  // run external script that creates directory structure for project
  // redirect standard output and standard error to a temp file
  //exec("/www/doc/dlps/uva-only/tracksys/bin/createProjectFinalDirectory.pl $projectName uvaHighRes >& /usr/tmp/tracksys", $output, $retval);

  // test exit value of script; die on failure
  if ($retval) {
    echo "<p>$scriptErrorPreface Failed to create directory structure for project '$projectName':</p>\n<pre>";
    $bytes = @readfile("/usr/tmp/tracksys");
    echo "</pre>\n";
    die;
  }

  // delete temp file
  unlink("/usr/tmp/tracksys");
}


//--------------------
// build SQL statement
//--------------------

testPerm('imageProjectsUpdate');
$sql = "UPDATE imageProjects SET";
$where = " WHERE projectId = $projectId LIMIT 1";

$values = " $step = 1";
$values .= ", ${step}DateTime = NOW()";
$values .= ", ${step}ByUser = '$_SESSION[alias]'";

if ($step == 'step4') {
  $values .= ", step4New = $step4New";
  $values .= ", step4Updates = $step4Updates";
}

$sql .= $values . $where;


//----------------------
// execute SQL statement
//----------------------

if ( mysql_query($sql, $connection) ) {
  $affected = mysql_affected_rows();

  // store SQL statement in session variable for later display in debugging mode
  $_SESSION['saveWorkflow']['sql'] = $sql;

  // redirect, indicating success
  header("Location: viewWorkflow.php?mode=update&projectId=$projectId&affected=$affected");
} else {
  die($dbErrorPreface . "Unable to update image project with ID '$projectId': " . mysql_error($connection) . "<br><br>$sql");
}
?>