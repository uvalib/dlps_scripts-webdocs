<?php

/*
  viewWorkflow.php - shows steps completed for an image project; allows approving next step
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-01-30
  Last modified: 2007-03-20
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

$siteArea = 'Image Projects';
$pageTitle = 'View Workflow';
$returnToSearchResults = "<p><a href='search/search.php'>Return to search results</a></p>\n";

// connect to db
$connection = connect();

// get associative array representing table 'imageProjectContacts'
$imageProjectContacts = getHashImageProjectContacts($connection);

// get associative array of tracking-system users
$users = getHashUsers($connection);

// test permissions; need Select to view item details, Update to enable submit button
testPerm('imageProjectsSelect');
if (!getPerm('imageProjectsUpdate')) { $submitAppearance = ' disabled'; }

// test for required parameters
$location = 'Location: ../err/badInput.php?msg=';
if (empty($projectId)) {
  header($location . urlencode('Project ID is required for viewing project details'));
  exit;
}

// get data for this project
$sql = "SELECT * FROM imageProjects WHERE projectId = '$projectId'";
$result = query($sql, $connection);
if (mysql_num_rows($result) == 1) {
  $row = mysql_fetch_array($result);
} else {
  $location = 'Location: ../err/error.php?msg=';
  header($location . urlencode("Project with ID '$projectId' not found in database"));
  exit;
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
<script type="text/javascript" src="../inc/imageProjects.js"></script>
<script type="text/javascript">
function go(step) {
  var msg = 'Approve step?';
  switch (step) {
    case 'step1':
      msg = 'Approve Step 1?'; break;
    case 'step1a':
      msg = 'Accept project?'; break;
    case 'step2':
      msg = 'Approve Step 2?'; break;
    case 'step3':
      msg = 'Approve Step 3?'; break;
    case 'step4':
      msg = 'Approve Step 4?'; break;
    case 'step5':
      msg = 'Approve Step 5?'; break;
    case 'step6':
      msg = 'Approve Step 6?'; break;
    case 'step7':
      msg = 'Approve Step 7?'; break;
    case 'step8':
      msg = 'Approve Step 8?'; break;
    case 'step9':
      msg = 'Approve Step 9?'; break;
    case 'step10':
      msg = 'Approve Step 10?'; break;
    case 'step10a':
      msg = 'Declare project finished?'; break;
  }

  if ( confirm(msg) ) {
    document.frm.step.value = step;
    document.frm.submit();
  }
}
</script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
if ($mode == 'update') {
  if ($debugMode) {
    echo "<p>" . $_SESSION['saveWorkflow']['sql'] . "</p>\n";
  }
  echo "<p class='updated'>Project updated successfully</p>\n";
}

if ($_SESSION['searchImageProjectsSql']) {
  echo $returnToSearchResults;
}
?>

<table>
<?php

//---------------------
// show project details
//---------------------

echo <<<EOD
<tr>
<td class='label'>Project name:</td>
<td><a href='imageProjects.php?projectId=$projectId'>$row[projectName]</a></td>
</tr>
EOD;
?>

<tr>
<td class='label'>Description or Full Title:</td>
<td><?=$row['projectDesc']?></td>
</tr>

<?php
$contact = '';
foreach ($imageProjectContacts as $id => $name) {
  if ($row['contactId'] == $id) {
    $contact = "$name ($id)";
    break;
  }
}
?>
<tr>
<td class='label'>Contact person:</td>
<td><?=$contact?></td>
</tr>

<tr>
<td class='label'>Content model:</td>
<td><?=$row['contentModel']?></td>
</tr>

<tr>
<td class='label'>Materials due date:</td>
<td>
<?php
// highlight due date in red if overdue
if ( $row['dateMaterialsDue'] < date('Y-m-d') ) {
  echo "<span style='color: #990000; font-weight: bold;'>" . formatDateUS($row['dateMaterialsDue']) . "</span>";
} else {
  echo formatDateUS($row['dateMaterialsDue']);
}
?>
</td>
</tr>

<tr>
<td class='label'>Materials returned on:</td>
<td><?=formatDateUS($row['dateMaterialsReturned'])?></td>
</tr>

<tr>
<td class='label'>Number of materials:</td>
<td>Books: <?=$row['numberBooks']?> &nbsp;&nbsp;
Discs/media: <?=$row['numberDigitalMedia']?></td>
</tr>

<?php
$totalImages = $row['numberSlides'] + $row['numberBookPages'] + $row['numberDigitalImages'];
?>

<tr>
<td class='label'>Number of images:</td>
<td>Slides: <?=$row['numberSlides']?> &nbsp;&nbsp;
Book pages: <?=$row['numberBookPages']?> &nbsp;&nbsp;
Digital images: <?=$row['numberDigitalImages']?> &nbsp;&nbsp;
Total: <?=$totalImages?></td>
</tr>

<?php
$warning = '';
$numberMetadataFiles = '';
if ($row['numberMetadataFiles']) {
  $numberMetadataFiles = $row['numberMetadataFiles'];
  if ($numberMetadataFiles != $totalImages) {
    $warning = "<span style='color: #990000'><b>WARNING:</b> The number of metadata files does not equal the total number of images for this project.</span>";
  }
}
echo <<<EOD
<tr>
<td class="label">Number of metadata files:</td>
<td>$numberMetadataFiles $warning</td>
</tr>
EOD;
echo "\n";
?>


<?php
if ($row['step4']) {
?>
<tr>
<td class='label'>Iris cataloging process:</td>
<td>New: <?=$row['step4New']?> &nbsp;&nbsp; Updates: <?=$row['step4Updates']?></td>
</tr>
<?php
}

if ($row['notes']) {
?>
<tr>
<td class='label' valign='top'>Notes:</td>
<td><pre><?=formatNotes($row['notes'])?></pre></td>
</tr>
<?php
}

$user = '';
foreach ($users as $id => $name) {
  if ($row['createdByUser'] == $id) {
    $user = "$name ($id)";
    break;
  }
}
?>
<tr>
<td class='label'>Project created:</td>
<td><?=formatDateTimeUS($row['dateTimeCreated'])?> by <?=$user?></td>
</tr>
</table>

<hr>

<form name="frm" method="POST" action="saveWorkflow.php">
<input type="hidden" name="projectId" value="<?=$projectId?>">
<input type="hidden" name="projectName" value="<?=$row['projectName']?>">
<input type="hidden" name="step">
<table cellpadding="4">

<?php

//---------------------
// show steps completed
//---------------------

for ($i = 1; $i <= 12; $i++) {
  switch ($i) {
    case  1: $stepName = 'step1';   $label = 'Step 1 - Project definition process'; break;
    case  2: $stepName = 'step1a';  $label = 'Project accepted'; break;
    case  3: $stepName = 'step2';   $label = 'Step 2 - Image digitizing process'; break;
    case  4: $stepName = 'step3';   $label = 'Step 3 - Image editing process'; break;
    case  5: $stepName = 'step4';   $label = 'Step 4 - Iris cataloging process'; break;
    case  6: $stepName = 'step5';   $label = 'Step 5 - Delivery versions processing'; break;
    case  7: $stepName = 'step6';   $label = 'Step 6 - Archiving process'; break;
    case  8: $stepName = 'step7';   $label = 'Step 7 - Metadata processing'; break;
    case  9: $stepName = 'step8';   $label = 'Step 8 - Move project to ReadyRepo'; break;
    case 10: $stepName = 'step9';   $label = 'Step 9 - Object update process'; break;
    case 11: $stepName = 'step10';  $label = 'Step 10 - Object creation process'; break;
    case 12: $stepName = 'step10a'; $label = 'Project declared finished'; break;
  }

  if ($row[$stepName]) {
    $when = formatDateTimeUS($row["${stepName}DateTime"]);

    $user = '';
    foreach ($users as $id => $name) {
      if ($row["${stepName}ByUser"] == $id) {
	$user = "$name ($id)";
	break;
      }
    }

    echo <<<EOD
<tr>
<td class="label">$label:</td>
<td>Approved $when by $user</td>
</tr>
EOD;
  }
}


//-------------------------------
// show step(s) awaiting approval
//-------------------------------

if ($row['step10a']) {
  // done
} else {

  //----------------------------------------------------------------------
  if ($row['step9'] and $row['step10']) {
    echo <<<EOD
<tr>
<td class="label">Declare project finished</td>
<td><input type="button" value="Approve" onclick="go('step10a');"$submitAppearance></td>
</tr>
EOD;

  //----------------------------------------------------------------------
  } elseif ($row['step8']) {
    if (!$row['step9']) {
      echo <<<EOD
<tr>
<td class="label">Step 9 - Object update process</td>
<td><input type="button" value="Approve" onclick="go('step9');"$submitAppearance></td>
</tr>
EOD;
    }
    if (!$row['step10']) {
      echo <<<EOD
<tr>
<td class="label">Step 10 - Object creation process</td>
<td><input type="button" value="Approve" onclick="go('step10');"$submitAppearance></td>
</tr>
EOD;
    }

  //----------------------------------------------------------------------
  } elseif ($row['step5'] and $row['step6'] and $row['step7']) {
      echo <<<EOD
<tr>
<td class="label">Step 8 - Move project to ReadyRepo</td>
<td><input type="button" value="Approve" onclick="go('step8');"$submitAppearance></td>
</tr>
EOD;

  //----------------------------------------------------------------------
  } elseif ($row['step3']) {
    if (!$row['step4']) {
      $step4Appearance = $submitAppearance;
      if ($warning) {
	$step4Appearance = ' disabled';
      }
      echo <<<EOD
<tr>
<td class="label">Step 4 - Iris cataloging process</td>
<td>Number of works to be exported:
New <input type="text" name="step4New" size="4" maxlength="6"> &nbsp;&nbsp;
Updates <input type="text" name="step4Updates" size="4" maxlength="6">
<br>
<input type="button" value="Approve" onclick="go('step4');"$step4Appearance> $warning</td>
</tr>
EOD;
    }

    if (!$row['step5']) {
      echo <<<EOD
<tr>
<td class="label">Step 5 - Delivery versions processing</td>
<td><input type="button" value="Approve" onclick="go('step5');"$submitAppearance></td>
</tr>
EOD;
    }

    if (!$row['step6']) {
      echo <<<EOD
<tr>
<td class="label">Step 6 - Archiving process</td>
<td><input type="button" value="Approve" onclick="go('step6');"$submitAppearance></td>
</tr>
EOD;
    }

    if ($row['step4'] and !$row['step7']) {
      echo <<<EOD
<tr>
<td class="label">Step 7 - Metadata processing</td>
<td><input type="button" value="Approve" onclick="go('step7');"$submitAppearance></td>
</tr>
EOD;
    }

  //----------------------------------------------------------------------
  } elseif ($row['step2']) {
    echo <<<EOD
<tr>
<td class="label">Step 3 - Image editing</td>
<td><input type="button" value="Approve" onclick="go('step3');"$submitAppearance></td>
</tr>
EOD;

  //----------------------------------------------------------------------
  } elseif ($row['step1a']) {
    echo <<<EOD
<tr>
<td class="label">Step 2 - Image digitizing process</td>
<td><input type="button" value="Approve" onclick="go('step2');"$submitAppearance></td>
</tr>
EOD;

  //----------------------------------------------------------------------
  } elseif ($row['step1']) {
    echo <<<EOD
<tr>
<td class="label">Accept project</td>
<td><input type="button" value="Approve" onclick="go('step1a');"$submitAppearance></td>
</tr>
EOD;

  //----------------------------------------------------------------------
  } else {
    echo <<<EOD
<tr>
<td class="label">Step 1 - Project definition process</td>
<td><input type="button" value="Approve" onclick="go('step1');"$submitAppearance></td>
</tr>
EOD;
  }
}
?>

</table>
</form>

<hr>
<form name="viewSteps" method="GET">
<table cellpadding='4' border='0'>
<tr>
<td align='right'>View detailed workflow:</td>
<td><select name='workflow'>
<option value='scanning'>Scanning</option>
<option value='processing'>Processing</option>
<option value='postProcessing'>Post-processing</option>
<option value='finalization'>Finalization</option>
</select>
</td>
<td valign='bottom'>
<input type='button' value='View Workflow' onclick='if ( setFormActionImageProjects(document.viewSteps) ) { document.viewSteps.submit(); }'>
<input type='hidden' name='projectId' value='<?=$projectId?>'>
</td>
</tr>
</table>
</form>

<?php
if ($_SESSION['searchImageProjectsSql']) {
  echo $returnToSearchResults;
}
?>

</body>
</html>
