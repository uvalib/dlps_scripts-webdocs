<?php

/*
  help.php - displays help info
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-07-12
  Last modified: 2005-07-12

*/

import_request_variables('G');
include 'inc/tracksys.php';

// if no help ID (or unknown help ID), show all help topics
switch ($helpId) {
  case 'login':
    break;

  default:
    $helpId = 'all';
}

?>
<html>
<head>
<title>Help - <?=$appTitle?></title>
<link rel="stylesheet" type="text/css" href="inc/tracksys.css">
</head>
<body>
<h2>Help</h2>

<?php
// LOGIN HELP =======================================================
if ($helpId == 'login' or $helpId == 'all') {
?>
<h3>Logging In</h3>

<p>The type of authentication used by the <?=$appTitle?> requires a
<b>session cookie</b>, which is a small file saved to your hard disk
temporarily and then deleted when you close your web browser. You
control whether or not your web browser will allow the use of a
session cookie. If session cookies are disallowed, you will not be
able to use the <?=$appTitle?>.</p>

<p>The session cookie created by the <?=$appTitle?> is safe and does
not pose a security or privacy problem. It only stores your login
name, and the cookie is automatically deleted when you close the
browser.</p>

<h4>Internet Explorer</h4>

<p>The simplest option is to allow session cookies from all web
sites:</p>

<ul>
<li>From the <b>Tools</b> menu, choose <b>Internet Options...</b></li>
<li>Click the <b>Privacy</b> tab</li>
<li>Click the <b>Advanced...</b> button</li>
<li>Check <b>Override automatic cookie handling</b></li>
<li>Check <b>Always allow session cookies</b></li>
<li>Click <b>OK</b></li>
<li>Click <b>OK</b></li>
</ul>

<p>Alternatively, if you prefer to allow session cookies only from
certain web sites:</p>

<ul>
<li>From the <b>Tools</b> menu, choose <b>Internet Options...</b></li>
<li>Click the <b>Privacy</b> tab</li>
<li>Click the <b>Sites...</b> button</li>
<li>Enter the web address: <tt>http://pogo.lib.virginia.edu/dlps/uva-only/tracksys/</tt></li>
<li>Click the <b>Allow</b> button</li>
<li>Click <b>OK</b></li>
<li>Click <b>OK</b></li>
</ul>

<h4>Firefox</h4>

<p>The simplest option is to allow session cookies from all web
sites:</p>

<ul>
<li>From the <b>Tools</b> menu, choose <b>Options...</b></li>
<li>Click <b>Privacy</b></li>
<li>Click <b>Cookies</b></li>
<li>Check <b>Allow sites to set cookies</b></li>
<li>For higher security, you can set the following options, although
these are not required to be able to use the <?=$appTitle?>:
  <ul>
  <li>Check <b>for the originating web site only</b></li>
  <li>For <b>Keep Cookies:</b>, select <b>until I close Firefox</b></li>
  </ul>
</li>
<li>Click <b>OK</b></li>
</ul>

<p>Alternatively, if you prefer to allow session cookies only from
certain web sites:</p>

<ul>
<li>From the <b>Tools</b> menu, choose <b>Options...</b></li>
<li>Click <b>Privacy</b></li>
<li>Click <b>Cookies</b></li>
<li>Clear (uncheck) <b>Allow sites to set cookies</b></li>
<li>Click the <b>Exceptions</b> button</li>
<li>Enter the web address: <tt>http://pogo.lib.virginia.edu/dlps/uva-only/tracksys/</tt></li>
<li>Click the <b>Allow for Session</b> button</li>
<li>Click <b>Close</b></li>
<li>Click <b>OK</b></li>
</ul>

<?php
}  // END if ($helpId == 'login' or $helpId == 'all')
?>

</body>
</html>
