<?php

/*
  badInput.php - displays an 'invalid input' message
  Greg Murray <gpm2a@virginia.edu>
  Last modified: 2005-11-23
*/

$msg = $_GET['msg'];

?>
<html>
<head>
<title>Invalid Input - DLPS Tracking System</title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<body>
<h2 class="error">Invalid Input</h2>

<p><span class="error"><b>Input error: </b></span><?=$msg?></p>

<p><input type="button" value=" Back " onclick="history.back();"></p>

</body>
</html>
