<?php

/*
  badPerm.php - displays a 'permission denied' message
  Greg Murray <gpm2a@virginia.edu>
  Last modified: 2005-11-23
*/

import_request_variables('G');
session_start();

?>
<html>
<head>
<title>Permission denied - DLPS Tracking System</title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<body>
<h2 class="error">Permission denied</h2>

<p>You are logged in as "<?=$_SESSION['alias']?>" and do not have
permission to perform the requested action (<?=$p?>).</p>

<p><input type="button" value=" Back " onclick="history.back();"></p>

</body>
</html>
