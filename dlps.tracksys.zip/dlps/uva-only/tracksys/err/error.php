<?php

$msg = $_GET['msg'];

?>
<html>
<head>
<title>Error - DLPS Workflow Tracking System</title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<body>
<h2 class="error">Error</h2>

<p><span class="error"><b>Error: </b></span><?=$msg?></p>

<p><input type="button" value=" Back " onclick="history.back();"></p>

</body>
</html>
