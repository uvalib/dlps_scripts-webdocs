<?php

function connect() {
  /*  defaults (host:port, user, password) for local MAMP. Replace with actual values for your mysql server connection  */ 
  $connection = mysql_connect('localhost:8889', 'root', 'root') or die("<p><font color='red'>ERROR: Cannot connect to database server</font></p></body></html>");
  mysql_select_db('gpm2a_tracksys', $connection) or die("<p><font color='red'>ERROR: Cannot select database: " . mysql_error($connection) . "</font></p></body></html>");
  return $connection;
}

function query($sql, $connection) {
  $result = mysql_query($sql, $connection)
    or die("<p><span style='color: #990000;'><b>DATABASE ERROR:</b></span> Cannot execute SQL statement: "
	. mysql_error($connection) . "</p>\n<p><b>SQL:</b> $sql</p>\n");

  return $result;
}

?>