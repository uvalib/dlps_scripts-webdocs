<?php

/*
  tracksys.php - shared functions and global variables supporting the DLPS Tracking System
  Greg Murray <gpm2a@virginia.edu>
  Last modified: 2007-06-19
*/

$debugMode = 0;
$loginMode = 1;
$deleteEnabled = 1;

$appTitle = 'DLPS Tracking System';
$appBaseUrl = '/dlps/uva-only/tracksys';

$userErrorPreface = "<span style='color: #990000;'><b>USER ERROR: </b></span>";
$dbErrorPreface   = "<span style='color: #990000;'><b>DATABASE ERROR: </b></span>";
$scriptErrorPreface   = "<span style='color: #990000;'><b>EXTERNAL SCRIPT ERROR: </b></span>";

$workflowNewSearchLink = "<p><a href='../search/search.php'>Return to search results</a><br>
<a href='../search/search1.php'>Adjust this search</a><br>
<a href='../search/search0.php'>Start a new search</a></p>\n";

// variables for email notifications
$emailFrom = "$appTitle <ul-dlpsscripts@virginia.edu>";

$emailTo = 'ul-dlpsscripts@virginia.edu';

$teiHeaderDoneEmailRecipients = 'Kristy Hibbs <kwh8s@virginia.edu>, Lorrie Chisholm <lsc6v@virginia.edu>, Andrew Curley <aec6v@virginia.edu>';

$to80FinalEmailRecipients = 'Kristy Hibbs <kwh8s@virginia.edu>, Ray Johnson <rpj2f@virginia.edu>, Lorrie Chisholm <lsc6v@virginia.edu>';

$makeWebImagesEmailRecipients = 'Janis Kessler <jak9f@virginia.edu>';

$newImageProjectEmailRecipients = 'Kristy Hibbs <kwh8s@virginia.edu>';

$imageProjectsEmailRecipients = 'Kristy Hibbs <kwh8s@virginia.edu>';

$imageViewerUrl = '/cgi-dlps/uva-only/proofreader/imageview.pl';

// vendor batch types
define("BATCH_TYPE_TEXTS", 1);
define("BATCH_TYPE_IMAGES", 2);
define("BATCH_TYPE_BOTH", 3);

// text genres
define("GENRE_PROSE_NONFICTION", 0);
define("GENRE_PROSE_FICTION", 1);
define("GENRE_POETRY", 2);
define("GENRE_DRAMA", 3);
define("GENRE_DICTIONARY", 4);
define("GENRE_ENCYCLOPEDIA", 5);
define("GENRE_MANUSCRIPT", 6);
define("GENRE_NEWSPAPER", 7);
define("GENRE_SHEET_MUSIC", 8);
define("GENRE_MAP", 9);

// goodwill project types
define("GOODWILL_TYPE_ARCHIVING", 1);
define("GOODWILL_TYPE_IMAGE", 2);
define("GOODWILL_TYPE_TEXT", 3);

include 'db.php';

//--------------------------------------------------------------------
/*
function clean($input, $maxlength = 0) {
   // "cleans" form data so it can be written to database

   // NOTE: This function uses mysql_escape_string(), which has been
   // deprecated as of PHP 4.3.0. Use clean2() instead (see below).

   // escape single quotes, etc. so value can be used in a SQL statement
   $out = mysql_escape_string($input);

   // trim leading and trailing whitespace
   $out = trim($out);

   // optionally truncate to max length
   if ($maxlength > 0) {
      $out = substr($out, 0, $maxlength);
   }

   return $out;
}
*/
//--------------------------------------------------------------------

function clean2($input, $connection, $maxlength = 0) {
   // "cleans" form data so it can be written to database

   // NOTE: clean2() uses mysql_real_escape_string() rather than
   // mysql_escape_string(), which has been deprecated as of PHP 4.3.0

   // escape single quotes, etc. so value can be used in a SQL statement
   $out = mysql_real_escape_string($input);

   // trim leading and trailing whitespace
   $out = trim($out);

   // optionally truncate to max length
   if ($maxlength > 0) {
      $out = substr($out, 0, $maxlength);
   }

   return $out;
}

//--------------------------------------------------------------------

function echoCheckAllClearAll($colName) {
  // prints a table column with check-all-checkboxes and clear-all-checkboxes controls

  $colName = '"' . $colName . '"';
  echo "<td align='center' nowrap>
<img src='../../img/check.gif' onclick='setCheckboxesCol(true, $colName);' title='Check all for this column'>
<img src='../../img/square.gif' onclick='setCheckboxesCol(false, $colName);' title='Clear all for this column'>
</td>\n";
}

//--------------------------------------------------------------------

function formatDateISO($in) {

  // takes a string, returns a string representing a ISO yyyy-mm-dd formatted date

  // a return value of empty string indicates that the input string is not a valid date

  // allows slash, dot, or hyphen as delimiter
  // assumes US month/day/year format unless first number is 4 digits indicating ISO year/month/day format

  // also allows dates in this form: Apr 26 2004

  if ( preg_match('#(\d{4}|\d{2}|\d)[/.-](\d{2}|\d)[/.-](\d{4}|\d{2}|\d)#', $in, $parts) ) {
    // input string is a numeric date
    if ( strlen($parts[1]) == 4 ) {
      // input string is in ISO format
      $year = $parts[1];
      $month = $parts[2];
      $day = $parts[3];
    } else {
      // assume US format
      $month = $parts[1];
      $day = $parts[2];
      $year = $parts[3];
    }
  } elseif ( preg_match('/([A-Z][a-z]{2}) (\d{2}) (\d{4})/', $in, $parts) ) {
    // input string is in 'Apr 26 2004' format

    $month = $parts[1];
    $day = $parts[2];
    $year = $parts[3];

    if     ($month == 'Jan') { $month = '1'; }
    elseif ($month == 'Feb') { $month = '2'; }
    elseif ($month == 'Mar') { $month = '3'; }
    elseif ($month == 'Apr') { $month = '4'; }
    elseif ($month == 'May') { $month = '5'; }
    elseif ($month == 'Jun') { $month = '6'; }
    elseif ($month == 'Jul') { $month = '7'; }
    elseif ($month == 'Aug') { $month = '8'; }
    elseif ($month == 'Sep') { $month = '9'; }
    elseif ($month == 'Oct') { $month = '10'; }
    elseif ($month == 'Nov') { $month = '11'; }
    elseif ($month == 'Dec') { $month = '12'; }
    else { $month = ''; }
  } else {
    return '';
  }

  $month = str_pad($month, 2, '0', STR_PAD_LEFT);
  $day = str_pad($day, 2, '0', STR_PAD_LEFT);
  if ( strlen($year) == 2 ) {
    $year = '20' . $year;
  }

  if ( checkdate($month, $day, $year) ) {
    return $year . '-' . $month . '-' . $day;
  } else {
    return '';
  }
}

//--------------------------------------------------------------------

function formatDateUS($in) {

  // returns a string representing a date formatted as a US m/d/yyyy date;
  // input string must be an ISO-formatted yyyy-mm-dd string

  // this function is used to take dates coming out of MySQL and
  // format them for display

  // a return value of empty string indicates that the input string
  // either is "0000-00-00" or is not an ISO-formatted date

  if ( preg_match('/0000-00-00/', $in, $parts) ) {
    $out = '';
  } elseif ( preg_match('/(\d{4})-(\d{2})-(\d{2})/', $in, $parts) ) {
    $year = $parts[1];
    $month = $parts[2];
    $day = $parts[3];

    $month = preg_replace('/^0/', '', $month);  // strip leading zero, if present
    $day  =  preg_replace('/^0/', '', $day);    // strip leading zero, if present

    $out = "$month/$day/$year";
  } else {
    $out = '';
  }
  return $out;
}

//--------------------------------------------------------------------

function formatDateTimeUS($in) {

  // takes an ISO-formatted datetime string

  // returns a string formatted as m/d/yyyy h:mm - for example, 3/19/2006 9:01 am

  // if input string has unexpected format, returns input string as is

  if ( preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}/', $in) ) {
    $out = date('n/j/Y g:i a', strtotime($in));
  } else {
    $out = $in;
  }
  return $out;
}

//--------------------------------------------------------------------

function formatName($last, $first) {
  // format name as "last, first" for display
  if ( empty($first) ) {
    $out = $last;
  } else {
    $out = "$last, $first";
  }
  return $out;
}

//--------------------------------------------------------------------

function formatNotes($stringIn) {

  // format a "notes" value (entered via HTML <textarea>, stored as
  // MySQL TEXT field) for display

  $out = $stringIn;

  // escape markup characters
  $out = preg_replace('/&/', "&amp;", $out);
  $out = preg_replace('/</', "&lt;", $out);
  $out = preg_replace('/>/', "&gt;", $out);

  $out = preg_replace('/\r?\n/', "<br>", $out);  // replace newlines with <br> tags
  $out = wordwrap($out, 70, "<br>");             // wrap to 70 characters max

  return $out;
}

//--------------------------------------------------------------------

function formatTitle($title, $volume) {
  // append volume number to title
  if ( empty($volume) ) {
    $out = $title;
  } else {
    if ( preg_match('/^[Vv](ol)?\./', $volume) ) {
      $volumeIndicator = '';
    } else {
      $volumeIndicator = 'Vol. ';
    }
    $out = "$title ($volumeIndicator$volume)";
  }
  return $out;
}

//--------------------------------------------------------------------

function getAccess($int) {
  // takes an integer; returns a string label indicating access status
  switch ($int) {
    case 0:
      $out = 'public';
      break;
    case 1:
      $out = 'VIVA only';
      break;
    case 2:
      $out = 'UVA only';
      break;
    case 3:
      $out = 'restricted';
      break;
    default:
      $out = '';
  }

  return $out;
}

//--------------------------------------------------------------------

function getCurrentYear($stringIn) {
  // returns a 4-digit year, either current fiscal year or current calendar year, as appropriate
  if ( preg_match('/fiscal/', $stringIn) ) {
    if ( date('n') >= 7 ) {
      // month is July or later; fiscal year is calendar year + 1
      $out = date('Y') + 1;
    } else {
      $out = date('Y');
    }
  } else {
    $out = date('Y');
  }

  return $out;
}

//--------------------------------------------------------------------

function getEafAccess($int) {
  // takes an integer; returns a string label indicating EAF access (private or public)
  switch ($int) {
    case 0:
      $out = 'Access unknown';
      break;
    case 1:
      $out = 'Private';
      break;
    case 2:
      $out = 'Public';
      break;
    default:
      $out = '';
  }

  return $out;
}

//--------------------------------------------------------------------

function getEafSubset($int) {
  // takes an integer; returns a string label indicating EAF subset (EAF1 or EAF2)
  switch ($int) {
    case 0:
      $out = 'Subset unknown';
      break;
    case 1:
      $out = 'EAF 1';
      break;
    case 2:
      $out = 'EAF 2';
      break;
    default:
      $out = '';
  }

  return $out;
}

//--------------------------------------------------------------------

function getGenre($int) {
  // takes an integer indicating a genre; returns a string for display
  switch ($int) {
    case GENRE_PROSE_NONFICTION:
      $out = 'prose non-fiction';
      break;
    case GENRE_PROSE_FICTION:
      $out = 'prose fiction';
      break;
    case GENRE_POETRY:
      $out = 'poetry';
      break;
    case GENRE_DRAMA:
      $out = 'drama';
      break;
    case GENRE_DICTIONARY:
      $out = 'dictionary';
      break;
    case GENRE_ENCYCLOPEDIA:
      $out = 'encyclopedia';
      break;
    case GENRE_MANUSCRIPT:
      $out = 'manuscript';
      break;
    case GENRE_NEWSPAPER:
      $out = 'newspaper issue';
      break;
    case GENRE_SHEET_MUSIC:
      $out = 'printed music';
      break;
    case GENRE_MAP:
      $out = 'map';
      break;
    default:
      $out = '';
  }

  return $out;
}

//--------------------------------------------------------------------

function getHashBatches($connection) {

    // returns an associative array representing table 'batches' where
    // each key is 'batchId' and each value is 'batchName'

    $out = array();
    $sql = "SELECT * FROM batches ORDER BY batchName";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['batchId']] = $row['batchName'];
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashBoxes($connection) {

    // returns an associative array representing table 'boxes' where
    // each key is 'boxId' and each value is 'roomName|boxName'

    $out = array();
    $sql = "SELECT boxes.*, rooms.roomName FROM boxes, rooms WHERE boxes.roomId = rooms.roomId ORDER BY roomName, boxName";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['boxId']] = $row['roomName'] . '|' . $row['boxName'];
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashGoodwillProjects($connection) {

    // returns an associative array representing table 'goodwillProjects' where
    // each key is 'projectId' and each value is 'projectName'

    $out = array();
    $sql = "SELECT * FROM goodwillProjects ORDER BY projectName";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['projectId']] = $row['projectName'];
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashGoodwillProjectTypes($connection) {

    // returns an associative array representing table 'goodwillProjectTypes' where
    // each key is 'typeId' and each value is 'typeName'

    $out = array();
    $sql = "SELECT * FROM goodwillProjectTypes ORDER BY typeName";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['typeId']] = $row['typeName'];
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashGroups($connection) {

    // returns an associative array representing table 'groups' where
    // each key is 'groupId' and each value is 'groupName'

    $out = array();
    $sql = "SELECT * FROM groups ORDER BY groupName";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['groupId']] = $row['groupName'];
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashImageProjectContacts($connection) {

    // returns an associative array representing table 'imageProjectContacts' where
    // each key is contactId and each value is contactNameLast, contactNameFirst

    $out = array();
    $sql = "SELECT * FROM imageProjectContacts ORDER BY contactNameLast, contactNameFirst";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['contactId']] = formatName($row['contactNameLast'], $row['contactNameFirst']);
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashImageProjects($connection) {

    // returns an associative array representing table 'imageProjects' where
    // each key is 'projectId' and each value is 'projectName'

    $out = array();
    $sql = "SELECT projectId, projectName FROM imageProjects ORDER BY projectName";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['projectId']] = $row['projectName'];
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashPageImagesResps($connection) {

    // returns an associative array representing table 'pageImagesResps' where
    // each key is 'pageImagesRespId' and each value is 'pageImagesRespName'

    $out = array();
    $sql = "SELECT * FROM pageImagesResps ORDER BY pageImagesRespName";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['pageImagesRespId']] = $row['pageImagesRespName'];
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashProjects($connection) {

    // returns an associative array representing table 'projects' where
    // each key is 'projectId' and each value is 'projectName'

    $out = array();
    $sql = "SELECT * FROM projects ORDER BY projectName";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['projectId']] = $row['projectName'];
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashRequestors($connection) {

    // returns an associative array representing table 'requestors' where
    // each key is requestorId and each value is requestorNameLast, requestorNameFirst

    $out = array();
    $sql = "SELECT * FROM requestors ORDER BY requestorNameLast, requestorNameFirst";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['requestorId']] = formatName($row['requestorNameLast'], $row['requestorNameFirst']);
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashRooms($connection) {

    // returns an associative array representing table 'rooms' where
    // each key is 'roomId' and each value is 'roomName'

    $out = array();
    $sql = "SELECT * FROM rooms ORDER BY roomName";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['roomId']] = $row['roomName'];
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashSelectors($connection) {

    // returns an associative array representing table 'selectors' where
    // each key is selectorId and each value is selectorNameLast, selectorNameFirst

    $out = array();
    $sql = "SELECT * FROM selectors ORDER BY selectorNameLast, selectorNameFirst";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['selectorId']] = formatName($row['selectorNameLast'], $row['selectorNameFirst']);
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashSets($connection) {

    // returns an associative array representing table 'sets' where
    // each key is 'setId' and each value is 'setName'

    $out = array();
    $sql = "SELECT * FROM sets ORDER BY setName";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['setId']] = $row['setName'];
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashTranscriptionResps($connection) {

    // returns an associative array representing table 'transcriptionResps' where
    // each key is 'transcriptionRespId' and each value is 'transcriptionRespName'

    $out = array();
    $sql = "SELECT * FROM transcriptionResps ORDER BY transcriptionRespName";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['transcriptionRespId']] = $row['transcriptionRespName'];
    }

    return $out;
}

//--------------------------------------------------------------------

function getHashUsers($connection) {

    // returns an associative array representing table 'userAliases' where
    // each key is user-login-name and each value is "nameLast, nameFirst"

    $out = array();
    $sql = "SELECT alias, nameFirst, nameLast FROM userAliases ORDER BY nameLast, nameFirst";
    $result = query($sql, $connection);
    while ( $row = mysql_fetch_array($result) ) {
        $out[$row['alias']] = formatName($row['nameLast'], $row['nameFirst']);
    }

    return $out;
}

//--------------------------------------------------------------------

function getItemType($int) {
  // takes an integer; returns a string label indicating text item type
  switch ($int) {
    case 0:
      $out = 'Production';
      break;
    case 1:
      $out = 'Migration';
      break;
    default:
      $out = '';
  }

  return $out;
}

//--------------------------------------------------------------------

function getJumpToUrl($stringIn) {
  // takes a string from a <select name="jumpTo"> element; returns the corresponding URL
  switch ($stringIn) {
    case 'start':
      $out = 'search0.php';
      break;
    case 'basic':
      $out = 'search1.php';
      break;
    case 'groupings':
      $out = 'search2.php';
      break;
    case 'responsibility':
      $out = 'search3.php';
      break;
    case 'dates':
      $out = 'search4.php';
      break;
    case 'misc':
      $out = 'search5.php';
      break;
    case 'status':
      $out = 'search6.php';
      break;
    case 'output':
      $out = 'search7.php';
      break;
    default:
      $out = 'search.php';
  }

  return $out;
}

//--------------------------------------------------------------------

function getPageImagesType($int) {
  // takes an integer; returns a string label indicating page image type
  switch ($int) {
    case 0:
      $out = 'none';
      break;
    case 1:
      $out = 'bitonal';
      break;
    case 2:
      $out = 'color';
      break;
    default:
      $out = '';
  }

  return $out;
}

//--------------------------------------------------------------------

function getPriority($int) {
  // takes an integer; returns a string label indicating priority
  switch ($int) {
    case -1:
      $out = 'low';
      break;
    case 0:
      $out = 'normal';
      break;
    case 1:
      $out = 'high';
      break;
    default:
      $out = '';
  }

  return $out;
}

//--------------------------------------------------------------------

function getRowClass($int) {
    // for even-numbered HTML table rows, highlight row by assigning CSS class 'hi'
    if ($int % 2 == 0) {
        $out = " class='hi'";
    } else {
        $out = '';
    }
    return $out;
}

//--------------------------------------------------------------------

function getTranscriptionType($int) {
  // takes an integer; returns a string label indicating transcription type
  switch ($int) {
    case 0:
      $out = 'none';
      break;
    case 1:
      $out = 'vendor';
      break;
    case 2:
      $out = 'OCR';
      break;
    case 3:
      $out = 'other';
      break;
    default:
      $out = '';
  }

  return $out;
}

//--------------------------------------------------------------------

function normalizeDlpsId($in) {
  // for DLPS IDs starting with 'b' or 'z', supply leading zeros as needed
  $out = $in;
  $matches = array();
  if ( preg_match('/^(b|z)(\d+)/', $in, $matches) ) {
    if ( strlen($matches[2]) < 9 ) {
      // format as 9 digits; use 0 as padding character
      $out = $matches[1] . str_pad($matches[2], 9, '0', STR_PAD_LEFT);
    }
  }
  return $out;
}

//--------------------------------------------------------------------

function setSearchTextOutputDefaults() {

  // Sets defaults for display of search results when searching for
  // text-digitization items.
  // In: nothing
  // Out: nothing

  unset($_SESSION['searchTextOutput']);
  $_SESSION['searchTextOutput']['useSearchColumns'] = 1;
  $_SESSION['searchTextOutput']['dlpsId'] = 1;
  $_SESSION['searchTextOutput']['title'] = 1;
  $_SESSION['searchTextOutput']['authorNameLast'] = 1;
  $_SESSION['searchTextOutput']['pageCount'] = 1;
  $_SESSION['searchTextOutput']['dateReceived'] = 1;
  $_SESSION['searchTextOutput']['isFinished'] = 1;
}

//--------------------------------------------------------------------

function translateWildcards($in) {
  // replace user-friendly wildcards with SQL wildcards
  $in = ereg_replace('\*', '%', $in);
  $in = ereg_replace('\?', '_', $in);

  // replace any characters not within ASCII range ! (33) to ~ (126) with underscore wildcard
  $in = ereg_replace('[^!-~]', '_', $in);

  return $in;
}

//--------------------------------------------------------------------

function truncate($in, $max = 50, $append = '...') {
  // truncate string to max length
  if (strlen($in) > $max) {
    $out = substr_replace($in, $append, $max);
  } else {
    $out = $in;
  }

  return $out;
}

//--------------------------------------------------------------------

/*
function validateDay($year, $month, $day) {
  $ok = false;

  $year = $year + 0;
  $month = $month + 0;
  $day = $day + 0;

  switch ($month) {
    case 2:
      if ($day == 29) {
        if ($year % 4 == 0) {
          $ok = true;
        }
      } elseif ($day >= 1 && $day <= 28) {
          $ok = true;
      }
      break;

    case 4:
    case 6:
    case 9:
    case 11:
      if ($day >= 1 && $day <= 30) {
        $ok = true;
      }
      break;

    default:
      if ($day >= 1 && $day <= 31) {
        $ok = true;
      }
  }

  return $ok;
}
*/

?>