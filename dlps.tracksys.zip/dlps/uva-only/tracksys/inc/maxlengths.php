<?php

// login/authentication
$usernameMaxLength = '20';
$passwordMaxLength = '20';

// textItems
$dlpsIdMaxLength = '20';
$virgoIdMaxLength = '15';
$titleControlNumberMaxLength = '15';
$titleMaxLength = '150';
$authorNameLastMaxLength = '50';
$authorNameFirstMaxLength = '50';
$volumeNumberMaxLength = '20';
$callNumberMaxLength = '150';
$pageCountMaxLength = '5';

// sets
$setNameMaxLength = '50';
$setDescMaxLength = '100';

// projects
$projectNameMaxLength = '50';
$projectDescMaxLength = '100';

// groups
$groupNameMaxLength = '50';
$groupDescMaxLength = '100';

// batches
$batchNameMaxLength = '50';
$batchDescMaxLength = '100';

// selectors
$selectorNameFirstMaxLength = '20';
$selectorNameLastMaxLength = '20';
$selectorDescMaxLength = '100';

// requestors
$requestorNameFirstMaxLength = '20';
$requestorNameLastMaxLength = '20';
$requestorDescMaxLength = '100';

// pageImagesResps
$pageImagesRespNameMaxLength = '20';
$pageImagesRespDescMaxLength = '100';

// transcriptionResps
$transcriptionRespNameMaxLength = '20';
$transcriptionRespDescMaxLength = '100';

// archivalDiscs
$volumeIdMaxLength = '25';
$mediaMaxLength = '5';
$formatMaxLength = '10';
$projectDirMaxLength = '255';
$projectLabelMaxLength = '20';
$editlistFileMaxLength = '255';

// rooms
$roomNameMaxLength = '50';
$roomDescMaxLength = '100';

// boxes
$boxNameMaxLength = '50';
$boxDescMaxLength = '100';

// goodwill project types
$typeNameMaxLength = '50';
$typeDescMaxLength = '100';

// image projects - contact persons
$contactIdMaxLength = '5';

// generic
$nameMaxLength = '50';
$descMaxLength = '100';
$nameFirstMaxLength = '20';
$nameLastMaxLength = '20';
?>