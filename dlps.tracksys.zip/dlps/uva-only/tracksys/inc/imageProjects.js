/*
  imageProjects.js - shared JavaScript functions used in the image
    projects module of the DLPS tracking system

  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-05-16
  Last modified: 2006-05-16
*/

var baseUrl = "/dlps/uva-only/tracksys";

//----------------------------------------------------------------------

function setFormActionImageProjects(formObject) {

  // determines which workflow is selected and sets action attribute
  // of form to corresponding page; returns a boolean

  switch (formObject.workflow.options[formObject.workflow.selectedIndex].value) {
    case 'scanning':
      formObject.action = baseUrl + "/imageProjects/scanning/workflowScanning.php";
      return true;
      break;
    case 'processing':
      formObject.action = baseUrl + "/imageProjects/processing/workflowProcessing.php";
      return true;
      break;
    case 'postProcessing':
      formObject.action = baseUrl + "/imageProjects/postProcessing/workflowPostProcessing.php";
      return true;
      break;
    case 'finalization':
      formObject.action = baseUrl + "/imageProjects/finalization/workflowFinalization.php";
      return true;
      break;
    default:
      alert("Please select which workflow to view.");
      return false;
  }
}

//----------------------------------------------------------------------

