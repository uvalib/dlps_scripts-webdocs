<?php

/*
  auth.php - shared functions supporting authentication in the DLPS Tracking System
  Greg Murray <gpm2a@virginia.edu>
  Last modified: 2006-01-25
*/

if ($loginMode) {

  // start session
  session_start();

  // test login
  if (empty($_SESSION['username'])) {
    header("Location: $appBaseUrl/err/badLogin.html"); exit;
  }

  // enable debug mode if applicable
  if ($_SESSION['username'] == 'debug') {
    $debugMode = 1;
  }
}


//--------------------------------------------------------------------

function getUserDesc() {

  // returns a string containing the user's alias (such as 'gpm2a') if
  // available, or username (such as 'dlpsUser') otherwise

  global $loginMode;

  if ($loginMode) {
    if ($_SESSION['alias']) {
      return "'$_SESSION[alias]'";
    } else {
      return "'$_SESSION[username]'";
    }
  } else {
    return '';
  }
}

//--------------------------------------------------------------------

function getPerm($perm) {

  // checks user's permissions and returns a boolean
  // string parameter $perm must be the column name of the requested action in table 'users'
  // returns 0 on failure, 1 on success

  global $loginMode, $connection;

  if ($loginMode) {
    $sql = "SELECT username FROM users WHERE username = '$_SESSION[username]' AND $perm = 1";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) >= 1) {
      return 1;
    } else {
      return 0;
    }
  } else {
    // login mode disabled; all permissions always on; always return true
    return 1;
  }
}

//--------------------------------------------------------------------

function testPerm($perm) {

  // tests user's permissions to perform requested action
  // string parameter $perm must be the column name of the requested action in table 'users'
  // redirects to 'bad permissions' page on failure

  global $loginMode, $connection, $appBaseUrl;

  if ($loginMode) {
    $sql = "SELECT username FROM users WHERE username = '$_SESSION[username]' AND $perm = 1";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) >= 1) {
      // ok
    } else {
      header("Location: $appBaseUrl/err/badPerm.php?p=$perm"); exit;
    }
  }
}

?>