/*
  textItem.js - JavaScript functions used with textItem.php

  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-06-21
  Last modified: 2006-03-09
*/

function changeGroup() {
  if (document.frm.groupId.selectedIndex == document.frm.groupId.length - 1) {
    if (IE) { spanNewGroup.style.display = "inline"; }
    document.frm.groupName.focus();
  } else {
    if (IE) { spanNewGroup.style.display = "none"; }
  }
}

//----------------------------------------------------------------------

function changePageImagesResp() {
  if (document.frm.pageImagesRespId.selectedIndex == document.frm.pageImagesRespId.length - 1) {
    if (IE) { spanNewPageImagesResp.style.display = "inline"; }
    document.frm.pageImagesRespName.focus();
  } else {
    if (IE) { spanNewPageImagesResp.style.display = "none"; }
  }

  /*
  if (document.frm.pageImagesRespId.selectedIndex == 0) {
    if (document.frm.pageImagesType.selectedIndex == 0) {
      document.frm.hasPageImages.checked = false;
    }
  } else {
    document.frm.hasPageImages.checked = true;
  }
  */
}

//----------------------------------------------------------------------

function changePageImagesType() {
  if (document.frm.pageImagesType.selectedIndex == 0) {
    //if (document.frm.pageImagesRespId.selectedIndex == 0) {
      document.frm.hasPageImages.checked = false;
    //}
  } else {
    document.frm.hasPageImages.checked = true;
  }
}

//----------------------------------------------------------------------

function changeProject() {
  if (document.frm.projectId.selectedIndex == document.frm.projectId.length - 1) {
    if (IE) { spanNewProject.style.display = "inline"; }
    document.frm.projectName.focus();
  } else {
    if (IE) { spanNewProject.style.display = "none"; }
  }
}

//----------------------------------------------------------------------

function changeRequestor() {
  if (document.frm.requestorId.selectedIndex == document.frm.requestorId.length - 1) {
    if (IE) { spanNewRequestor.style.display = "inline"; }
    document.frm.requestorNameLast.focus();
  } else {
    if (IE) { spanNewRequestor.style.display = "none"; }
  }
}

//----------------------------------------------------------------------

function changeSelector() {
  if (document.frm.selectorId.selectedIndex == document.frm.selectorId.length - 1) {
    if (IE) { spanNewSelector.style.display = "inline"; }
    document.frm.selectorNameLast.focus();
  } else {
    if (IE) { spanNewSelector.style.display = "none"; }
  }
}

//----------------------------------------------------------------------

function changeSet() {
  if (document.frm.setId.selectedIndex == document.frm.setId.length - 1) {
    if (IE) { spanNewSet.style.display = "inline"; }
    document.frm.setName.focus();
  } else {
    if (IE) { spanNewSet.style.display = "none"; }
  }
}

//----------------------------------------------------------------------

function changeTranscriptionResp() {
  if (document.frm.transcriptionRespId.selectedIndex == document.frm.transcriptionRespId.length - 1) {
    if (IE) { spanNewTranscriptionResp.style.display = "inline"; }
    document.frm.transcriptionRespName.focus();
  } else {
    if (IE) { spanNewTranscriptionResp.style.display = "none"; }
  }

  /*
  if (document.frm.transcriptionRespId.selectedIndex == 0) {
    if (document.frm.transcriptionType.selectedIndex == 0) {
      document.frm.hasTranscription.checked = false;
    }
  } else {
    document.frm.hasTranscription.checked = true;
  }
  */
}

//----------------------------------------------------------------------

function changeTranscriptionType() {
  if (document.frm.transcriptionType.selectedIndex == 0) {
    //if (document.frm.transcriptionRespId.selectedIndex == 0) {
      document.frm.hasTranscription.checked = false;
    //}
  } else {
    document.frm.hasTranscription.checked = true;
  }
}

//----------------------------------------------------------------------

function init() {
  changePageImagesResp();
  changeTranscriptionResp();
  changeSet();
  changeProject();
  changeGroup();
  changeSelector();
  changeRequestor();
}
