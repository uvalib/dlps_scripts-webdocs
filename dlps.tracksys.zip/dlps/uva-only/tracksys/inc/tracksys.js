/*
  tracksys.js - shared JavaScript functions used in the DLPS tracking system

  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-11-19
  Last modified: 2007-04-10
*/

var baseUrl = "/dlps/uva-only/tracksys";

//----------------------------------------------------------------------

function chkDelete_onClick(formObject) {

  // fires when a Delete checkbox is clicked;
  // sets caption of submit button as appropriate

  if (formObject.chkDelete.checked) {
    formObject.go.value = "Delete";
  } else {
    formObject.go.value = "Update";
  }
}

//----------------------------------------------------------------------

function clearForm() {
  for (i = 0; i < document.frm.elements.length; i++) {
    // clear textboxes
    if (document.frm.elements[i].type == "text") {
      document.frm.elements[i].value = "";
    }

    // clear drop-downs
    if (document.frm.elements[i].type == "select-one") {
      if (document.frm.elements[i].name == "priority") {
        document.frm.elements[i].selectedIndex = 1;  // select 'normal'
      } else {
        document.frm.elements[i].selectedIndex = 0;
      }
    }

    // clear textareas
    if (document.frm.elements[i].type == "textarea") {
      document.frm.elements[i].value = "";
    }

    // clear checkboxes
    if (document.frm.elements[i].type == "checkbox") {
      document.frm.elements[i].checked = false;
    }
  }

  // set focus to first textbox, if any
  for (i = 0; i < document.frm.elements.length; i++) {
    if (document.frm.elements[i].type == "text") {
      document.frm.elements[i].select();
      break;
    }
  }
}

//----------------------------------------------------------------------

function confirmDelete(formObject, itemType) {

  // fires when submitting a form on which a Delete checkbox appears;
  // asks for user confirmation and returns a boolean

  if (!itemType) {
    itemType = "data";
  }

  var msg = "WARNING: This action cannot be undone, and the data cannot be recovered.\n\n";
  msg += "Delete this " + itemType + " anyway?";

  if (formObject.chkDelete.checked) {
    return confirm(msg);
  } else {
    return true;
  }

}

//----------------------------------------------------------------------

function setCheckboxesCol(onOrOff, colName) {
  // checks or clears checkboxes for a specified column
  for (i = 0; i < document.frm.elements.length; i++) {
    if (document.frm.elements[i].type == "checkbox") {
      var pos = document.frm.elements[i].name.indexOf("_", 0);
      var test = document.frm.elements[i].name.substring(0, pos);
      if (test == colName) {
        document.frm.elements[i].checked = onOrOff;
      }
    }
  }
}

//----------------------------------------------------------------------

function setCheckboxesRow(onOrOff, rowId) {
  // checks or clears checkboxes for a specified row
  for (i = 0; i < document.frm.elements.length; i++) {
    if (document.frm.elements[i].type == "checkbox") {
      var pos = document.frm.elements[i].name.indexOf("_", 0);
      var test = document.frm.elements[i].name.substring(pos+1);
      if (test == rowId) {
        document.frm.elements[i].checked = onOrOff;
      }
    }
  }
}

//----------------------------------------------------------------------

function setFormAction(formObject) {

  // determines which workflow is selected and sets action attribute
  // of form to corresponding page; returns a boolean

  switch (formObject.workflow.options[formObject.workflow.selectedIndex].value) {
    case 'bookScanning':
      formObject.action = baseUrl + "/text/bookScanning/workflowBookScanning.php";
      return true;
      break;
    case 'teiHeader':
      formObject.action = baseUrl + "/text/teiHeader/workflowTeiHeader.php";
      return true;
      break;
    case 'postkb':
      formObject.action = baseUrl + "/text/postkb/workflowPostkb.php";
      return true;
      break;
    case 'markupQA':
      formObject.action = baseUrl + "/text/markupQA/workflowMarkupQA.php";
      return true;
      break;
    case 'finalization':
      formObject.action = baseUrl + "/text/finalization/workflowFinalization.php";
      return true;
      break;
    case 'migration':
      formObject.action = baseUrl + "/text/migration/workflowMigration.php";
      return true;
      break;
    case 'pageBook':
      formObject.action = baseUrl + "/text/pageBook/workflowPageBook.php";
      return true;
      break;
    default:
      alert("Please select which workflow to view.");
      return false;
  }
}

//----------------------------------------------------------------------

function testDlpsId(s) {

  // If DLPS ID value starts with b or z followed by one or more
  // digits, user is probably attempting to input a typical DLPS ID
  // (b or z plus nine digits). If not nine digits, ask user for
  // confirmation.

  // In:  string to test
  // Out: boolean

  var msg = "This DLPS ID value starts with 'b' or 'z', but it does not conform";
  msg += " to the normal pattern of 'b' or 'z' followed by nine digits.\n\n";
  msg += "Use this DLPS ID anyway?";

  if (s.search(/^[bz]\d+/) != -1) {
    // value is b or z followed by 1 or more digits
    if (s.search(/^[bz]\d{9}$/) == -1) {
      // value is NOT b or z followed by 9 digits
      return confirm(msg);
    }
  }

  return true;
}
