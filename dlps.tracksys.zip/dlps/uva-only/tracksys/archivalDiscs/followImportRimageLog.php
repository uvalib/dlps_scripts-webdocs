<?php

/*
  followImportRimageLog.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-09-14
  Last modified: 2005-10-07

  This page is displayed after successfully importing one or more
  Rimage log files. It simply displays links to the newly added discs.

  Receives data from: importRimageLog.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/auth.php';

$location = 'Location: ../err/badInput.php?msg=';

if (empty($importCount)) {
    header($location . urlencode('Number of files to import is required.'));
    exit;
}

// connect to db
$connection = connect();

$siteArea = 'Archival Discs';
$pageTitle = 'Import Status';

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
// check database to verify successful imports
if ($_SESSION['importGood']) {
  for ($i = 1; $i <= $importCount; $i++) {
    $key = "logfile$i";
    $volumeId = $_SESSION['importGood'][$key];
    if ($volumeId) {
      $sql = "SELECT * FROM archivalDiscs WHERE volumeId = '$volumeId'";
      $result = query($sql, $connection);
      if ( mysql_num_rows($result) != 1 ) {
        unset($_SESSION['importGood'][$key]);
        $_SESSION['importBad'][$key] = 'Reason for failure unknown';
      }
    }
  }
}

// display imports failed, if any
if ($_SESSION['importBad']) {
  echo "<p class='error'><b>Import FAILED for the following log files:</b></p>\n";
  echo "<table cellpadding='4' class='error'>\n";

  for ($i = 1; $i <= $importCount; $i++) {
    $key = "logfile$i";
    if ($_SESSION['importBad'][$key]) {
      echo "<tr><td class='label'>Log file $i:</td>";
      echo "<td>" . $_SESSION['importBad'][$key] . "</td></tr>\n";
    }
  }

  echo "</table>\n";
}

// display imports succeeded
if ($_SESSION['importGood']) {
  echo "<p class='updated'><b>Import succeeded for the following log files:</b></p>\n";
  echo "<table cellpadding='4' class='updated'>\n";

  for ($i = 1; $i <= $importCount; $i++) {
    $key = "logfile$i";
    if ($_SESSION['importGood'][$key]) {
      $volumeId = $_SESSION['importGood'][$key];
      echo "<tr><td class='label'>Log file $i:</td>";
      echo "<td><a href='archivalDisc.php?volumeId=$volumeId'>$volumeId</a></td></tr>\n";
    }
  }

  echo "</table>\n";
}
?>
</body>
</html>
