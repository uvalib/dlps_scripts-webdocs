<?php

/*
  archivalDisc.php - shows data pertaining to a particular archival disc
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-11-01
  Last modified: 2006-06-20

  If a disc ID is passed on the query string, this page serves as an
  edit-existing-item form. Otherwise, it serves as an enter-new-item
  form.

  Receives data from: URL query string (hyperlink) or importRimageLog.php or saveArchivalDisc.php
  Posts to: saveArchivalDisc.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Archival Discs';

// set defaults
if ( empty($volumeId) ) {
  // enter new item
  $mode = 'insert';
  $pageTitle = 'Enter New Disc';
  $subheading = '';
  $onload = ' onload="document.frm.volumeId.focus();"';
  $submitCaption = ' Add ';
  $mediaDvdSelected = ' selected';

  // test permissions
  testPerm('discInsert');
} else {
  // show or edit existing item
  if ( empty($mode) ) {
    $mode = 'update';
  }
  $pageTitle = "Disc $volumeId";
  $onload = '';
  $submitCaption = 'Update';
  $returnToSearchResults = "<p><a href='search/search.php'>Return to search results</a></p>";

  // test permissions; need Select to view item details, Update to enable submit button
  testPerm('discSelect');
  if (!getPerm('discUpdate')) { $submitAppearance = ' disabled'; }
}

// get associative array representing table 'boxes'
$boxes = getHashBoxes($connection);

// get data for item to be edited, if in update mode
if (!empty($volumeId)) {
  // query table archivalDiscs to get record for volume ID specified
  $sql = "SELECT * FROM archivalDiscs WHERE volumeId = '$volumeId'";
  $result = query($sql, $connection);

  if (mysql_num_rows($result) == 1) {
    $row = mysql_fetch_array($result);

    $copies = $row['copies'];
    $boxId1 = $row['boxId1'];
    $boxId2 = $row['boxId2'];

    switch ( $row['media'] ) {
      case 'DVDR':
        $mediaDvdSelected = ' selected';
        break;
      case 'CDR':
        $mediaCdSelected = ' selected';
        break;
    }

    if (empty($row['dateBurned'])) {
      $dateBurned = '';
    } else {
      if ($row['dateBurned'] == '0000-00-00') {
        $dateBurned = '';
      } else {
        if ( preg_match('/\d{4}-\d{2}-\d{2}/', $row['dateBurned']) ) {
          $dateBurned = formatDateUS($row['dateBurned']);
        } else {
          $dateBurned = $row['dateBurned'];
        }
      }
    }

    if (empty($row['dateExpires'])) {
      $dateExpires = '';
    } else {
      if ($row['dateExpires'] == '0000-00-00') {
        $dateExpires = '';
      } else {
        if ( preg_match('/\d{4}-\d{2}-\d{2}/', $row['dateExpires']) ) {
          $dateExpires = formatDateUS($row['dateExpires']);
        } else {
          $dateExpires = $row['dateExpires'];
        }
      }
    }
  } else {
    die($dbErrorPreface . "Disc '$volumeId' does not exist");
  }
}
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
<script type="text/javascript" src="../inc/tracksys.js"></script>
</head>
<?php
echo <<<EOD
<body$onload>
<h1>$siteArea</h1>
<h2>$pageTitle</h2>
EOD;

if ($debugMode) { echo "<p>$sql</p>\n"; }

if ($status == 'changed') {
  if (!empty($volumeId)) {
    $sql = "SELECT * FROM archivalDiscs WHERE volumeId = '$volumeId'";
    $result = query($sql, $connection);
    if ( mysql_num_rows($result) == 1 ) {
      if ($mode == 'delete') {
        echo "<p class='error'>WARNING: The archival disc was <b>not</b> deleted (disc ID: $volumeId).";
        echo " Contact the $appTitle administrator.</p>\n";
        echo "</body></html>";
        exit;
      }
    } else {
      if ($mode == 'delete') {
        echo "<p class='updated'>Archival disc deleted successfully</p>\n";
        echo "</body></html>";
        exit;
      }
    }
  }

  if ($affected == '0') {
    echo "<p class='updated'>No changes were needed.</p>\n";
  } else {
    if ($mode == 'import')
    {
      echo "<p class='updated'>Log file imported successfully</p>\n";
      // now that importing is complete, mode options are 'update' or 'insert'; change to 'update'
      $mode = 'update';
    }
    elseif ($mode == 'insert')
    {
      echo "<p class='updated'>Archival disc added successfully</p>\n";
    }
    else
    {
      echo "<p class='updated'>Archival disc updated successfully</p>\n";
    }
  }
}

echo $returnToSearchResults;

if ($deleteEnabled and $mode == 'update' and getPerm('discDelete')) {
  $onSubmit = " onsubmit='return confirmDelete(document.frm, \"archival disc\");'";
}
?>
<form name='frm' method='POST' action='saveArchivalDisc.php'<?=$onSubmit?>>
<input type='hidden' name='mode' value='<?=$mode?>'>
<table cellpadding='4'>
<tr>
<td class='label'>Disc ID:</td>

<?php
if ($mode == 'insert') {
  // disc ID is editable
  echo "<td><input type='text' name='volumeId' maxlength='$volumeIdMaxLength'></td>\n";
} else {
  // disc ID not editable
  echo "<td>$row[volumeId] <input type='hidden' name='volumeId' value='$row[volumeId]'></td>\n";
}
?>

</tr>

<tr>
<td class='label'>Media:</td>

<?php
if ($row['isRimage']) {
  echo "<td>$row[media]</td>\n";
} else {
  echo "<td><select name='media'>
<option value=''></option>
<option value='DVDR'$mediaDvdSelected>DVD</option>
<option value='CDR'$mediaCdSelected>CD</option>
</select></td>\n";
}
?>

</tr>

<?php
if ($row['isRimage']) {
?>
<tr>
<td class='label'>Format:</td>
<td><?=$row['format']?></td>
</tr>

<tr>
<td class='label'>Project directory:</td>
<td><?=$row['projectDir']?></td>
</tr>

<tr>
<td class='label'>Project label:</td>
<td><input type="text" name="projectLabel" maxlength="<?=$projectLabelMaxLength?>" value="<?=$row['projectLabel']?>"></td>
</tr>
<?php
}
?>

<tr>
<td class='label'>Number of copies burned:</td>

<?php
if ($row['isRimage']) {
  echo "<td>$copies <input type='hidden' name='copies' value='$copies'></td>\n";
} else {
  echo "<td><input type='text' name='copies' maxlength='2' size='5' value='$copies'></td>\n";
}
?>

</tr>

<?php
if ($mode != 'insert') {
?>
<tr>
<td class='label'>Date burned:</td>
<td><?=$dateBurned?></td>
</tr>

<tr>
<td class='label'>Date expires:</td>
<td><?=$dateExpires?></td>
</tr>
<?php
}
?>

<tr>
<td class='label'>Number of files:</td>

<?php
if ($row['isRimage']) {
  echo "<td>$row[fileCount]<input type='hidden' name='fileCount' value='$row[fileCount]'></td>\n";
} else {
  echo "<td><input type='text' name='fileCount' maxlength='5' size='5' value='$row[fileCount]'></td>\n";
}
?>

</tr>

<tr>
<td class='label'>Location 1:</td>
<td><select name="boxId1">
<option value='0'></option>
<?php
foreach ($boxes as $id => $name) {
  $selected = '';
  if ( ! empty($boxId1) ) {
    if ( $id == $boxId1 ) { $selected = ' selected'; }
  }
  $temp = explode('|', $name);
  $roomName = $temp[0];
  $boxName = $temp[1];
  echo "<option value='$id'$selected>$roomName, $boxName</option>\n";
}
?>
</select>
</td>
</tr>

<tr>
<td class='label'>Location 2:</td>
<td><select name="boxId2">
<option value='0'></option>
<?php
foreach ($boxes as $id => $name) {
  $selected = '';
  if ( ! empty($boxId2) ) {
    if ( $id == $boxId2 ) { $selected = ' selected'; }
  }
  $temp = explode('|', $name);
  $roomName = $temp[0];
  $boxName = $temp[1];
  echo "<option value='$id'$selected>$roomName, $boxName</option>\n";
}
?>
</select>
</td>
</tr>

<?php
  if ($deleteEnabled and $mode == 'update' and getPerm('discDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>
<tr>
<td></td>
<td colspan="2">
<input type="submit" name="go" value="<?=$submitCaption?>"<?=$submitAppearance?>>
<input type="reset" value="Reset">
<input type="button" value="Cancel" onclick="history.back();">
</td>
</tr>

<tr>
<td></td>
<td><hr></td>
</tr>

<tr>
<td align='right' valign='top'>List of files:</td>

<?php
if ($row['isRimage']) {
  echo "<td><pre>$row[fileList]</pre></td>\n";
} else {
  echo "<td><textarea name='fileList' cols='40' rows='10'>$row[fileList]</textarea></td>\n";
}
?>

</tr>
</table>

<input type="hidden" name="isRimage" value="<?=$row['isRimage']?>">
</form>
<?=$returnToSearchResults?>
</body>
</html>
