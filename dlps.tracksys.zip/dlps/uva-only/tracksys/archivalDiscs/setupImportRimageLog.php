<?php

/*
  setupImportRimageLog.php - form for importing Rimage log files
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-08-02
  Last modified: 2006-03-29

  Posts to: itself (if still gathering setup info) or to
    importRimageLog.php (if ready to import)
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

// delete session variables for imports succeeded/failed
unset($_SESSION['importGood']);
unset($_SESSION['importBad']);

// test permissions
$connection = connect();
testPerm('discInsert');

// get associative array representing table 'boxes'
$boxes = getHashBoxes($connection);

// build string of <option> elements for Location drop-down menus
$boxOptions = "<option value='0'></option>\n";
foreach ($boxes as $id => $name) {
  $temp = explode('|', $name);
  $roomName = $temp[0];
  $boxName = $temp[1];
  $boxOptions .= "<option value='$id'>$roomName, $boxName</option>\n";
}


//--------------------
// validate user input
//--------------------

$location = 'Location: ../err/badInput.php?msg=';

// number of files to import
if (empty($importCount)) {
  // display first page of form, asking for number of files to import
  $mode = 'page1';
} else {
  // display second page of form, to get paths of import files
  $mode = 'page2';

  if (preg_match('/^\d\d?$/', $importCount) ) {
    if ($importCount > 0 and $importCount < 100) {
      // ok, 1 - 99 files
    } else {
      header($location . urlencode('Number of files to import must be between 1 and 99.'));
      exit;
    }
  } else {
    header($location . urlencode('Number of files to import must be a whole number, 2 digits or less.'));
    exit;
  }
}

$siteArea = 'Archival Discs';
$pageTitle = 'Import Rimage Log Files';

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<?php

if ($mode == 'page1') {

?>
<body onload="document.frm.importCount.select();">
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="GET" action="setupImportRimageLog.php">
<table cellpadding="4">
<tr>
<td class='label'>Number of files to import:</td>
<td><input type='text' name='importCount' maxlength='2' size='3'></td>
</tr>

<tr>
<td colspan='2' align='right'>
<input type='button' value='Cancel' onclick='history.back();'>
<input type='submit' value='Next &gt;'>
</td>
</tr>
</table>
</form>
</body>
<?php

} else {

?>
<body onload="document.frm.projectLabelMain.select();">
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="POST" enctype="multipart/form-data" action="importRimageLog.php">
<table cellpadding="4">
<tr>
<td>
  <table cellpadding="4">
  <tr>
  <td class='label'>Project label:</td>
  <td>
  <input type='text' name='projectLabelMain' maxlength='<?=$projectLabelMaxLength?>'>
  <input type='hidden' name='importCount' value='<?=$importCount?>'>
  </td>
  </tr>

  <tr>
  <td class='label'>Location 1:</td>
  <td><select name="boxId1Main">
  <?=$boxOptions?>
  </select>
  </td>
  </tr>

  <tr>
  <td class='label'>Location 2:</td>
  <td><select name="boxId2Main">
  <?=$boxOptions?>
  </select>
  </td>
  </tr>
  </table>
</td>
</tr>

<tr>
<td>
  <table cellpadding="6" cellspacing="0" class="list">
<?php

  for ($i = 1; $i <= $importCount; $i++) {
    $class = getRowClass($i);
?>
  <tr<?=$class?>>
  <td class='label'>Log&nbsp;file&nbsp;<?=$i?>:</td>
  <td><input type='file' name='logfile<?=$i?>' accept='text/log' size='40'></td>
  </tr>
  <tr<?=$class?>>
  <td class='label'></td>
  <td>
    <table>
    <tr>
      <td colspan="3"><input type='radio' name='useProjectInfo_<?=$i?>' value='main' checked>Use project info specified above</td>
    </tr>
    <tr>
      <td colspan="3"><input type='radio' name='useProjectInfo_<?=$i?>' value='other'>Use this project info:</td>
    </tr>
    <tr>
      <td width="25">&nbsp;</td>
      <td>Project label:</td>
      <td><input type='text' name='projectLabel_<?=$i?>' maxlength='<?=$projectLabelMaxLength?>'></td>
    </tr>
    <tr>
      <td></td>
      <td>Location 1:</td>
      <td><select name="boxId1_<?=$i?>"><?=$boxOptions?></select></td>
    </tr>
    <tr>
      <td></td>
      <td>Location 2:</td>
      <td><select name="boxId2_<?=$i?>"><?=$boxOptions?></select></td>
    </tr>
    </table>
  </td>
  </tr>
<?php

  }  // end for

?>
  </table>
</td>
</tr>

<tr>
<td colspan='2' align='right'>
<input type='submit' value='Import'>
<input type='reset' value='Reset'>
<input type='button' value='Cancel' onclick='history.back();'>
</td>
</tr>
</table>
</form>
</body>
<?php

}  // end if/else

?>
</html>
