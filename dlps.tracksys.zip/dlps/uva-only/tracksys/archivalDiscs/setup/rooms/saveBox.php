<?php

/*
  saveBox.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-11-08
  Last modified: 2006-05-23

  Saves user-entered data to database, either by inserting a new
  record or updating an existing record, as appropriate.

  Receives data from: boxes.php
  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: rooms.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// validate user input

$location = 'Location: ../../../err/badInput.php?msg=';

// name
if (empty($boxName)) {
  header($location . urlencode('Box label is required'));
  exit;
}

// room ID to which this box corresponds
if (empty($roomId)) {
  header($location . urlencode('Room ID is required'));
  exit;
}

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}

// ID
if ($mode == 'update') {
  if (empty($boxId)) {
    header($location . urlencode('Box ID is required'));
    exit;
  }
}

// connect to db
$connection = connect();

// prep user input
$boxName = clean2($boxName, $connection, $boxNameMaxLength);
$boxDesc = clean2($boxDesc, $connection, $boxDescMaxLength);

// build SQL statement

if ($mode == 'update') {
  if ($chkDelete) {
    testPerm('discSetupDelete');
    $mode = 'delete';
    $sql = 'DELETE FROM boxes';
  } else {
    testPerm('discSetupUpdate');
    $sql = 'UPDATE boxes SET';
  }
  $where = " WHERE boxId = $boxId";
} else {
  testPerm('discSetupInsert');
  $sql = 'INSERT INTO boxes SET';
  $where = '';
}


if ($mode == 'delete') {
  $values = '';
} else {
  $values = " roomId = $roomId";

  if (empty($boxName)) { $value = "NULL"; } else { $value = "'$boxName'"; }
  $values .= ", boxName = $value";

  if (empty($boxDesc)) { $value = "NULL"; } else { $value = "'$boxDesc'"; }
  $values .= ", boxDesc = $value";
}

$sql .= $values . $where;

// execute SQL statement
if ( mysql_query($sql, $connection) ) {
  if ( $mode == 'insert' ) {
    $boxId = mysql_insert_id();
  }
  $affected = mysql_affected_rows();

  // redirect, indicating success
  header("Location: rooms.php?roomId=$roomId&boxId=$boxId&mode=$mode&affected=$affected");
} else {
  die($dbErrorPreface . "Unable to $mode box '$boxName': " . mysql_error($connection) . "<br><br>$sql");
}

?>