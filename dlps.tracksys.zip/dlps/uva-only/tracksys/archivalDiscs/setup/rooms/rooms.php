<?php

/*
  rooms.php - page for managing rooms where archival discs are stored
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-11-08
  Last modified: 2005-10-07

  If no 'roomId' parameter, lists rooms already defined.
  If ID is 'new', displays add-new form for defining a room.
  If ID is a number, displays edit form for editing an existing room.
*/

import_request_variables('PG');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Archival Discs - Setup';

if ( empty($roomId) ) {
  // list existing rooms
  $pageTitle = 'Rooms';

  // test permissions
  testPerm('discSetupSelect');
} else {
  if ($roomId == 'new') {
    // display enter-new form
    $pageTitle = 'Enter New Room';

    // test permissions
    testPerm('discSetupInsert');
  } else {
    // display edit form
    $pageTitle = 'Edit Room';

    // test permissions; need Select to view item details, Update to enable submit button
    testPerm('discSetupSelect');
    if (!getPerm('discSetupUpdate')) { $submitAppearance = ' disabled'; }
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
<script type="text/javascript" src="../../../inc/tracksys.js"></script>
</head>

<?php
// determine status message, if any
$status = '';
if (!empty($mode)) {
  if ( empty($boxId) ) {
    $sql = "SELECT * FROM rooms WHERE roomId = $roomId";
    $table = 'rooms'; $thing = 'room'; $thingId = $roomId;
  } else {
    $sql = "SELECT * FROM boxes WHERE boxId = $boxId";
    $table = 'boxes'; $thing = 'box'; $thingId = $boxId;
  }
  $result = query($sql, $connection);

  if ( mysql_num_rows($result) == 1 ) {
    if ($mode == 'delete') {
      $status = "<p class='error'>WARNING: The $thing was <b>not</b> deleted ($thing ID: $thingId).";
      $status .= " Contact the $appTitle administrator.</p>";
    }

    if ($affected == '0') {
      $status = "<p class='updated'>No changes were needed.</p>";
    } else {
      if ($mode == 'insert') {
        $status = "<p class='updated'>New $thing added successfully</p>";
      } else {
        $status = "<p class='updated'>" . ucfirst($thing) . " updated successfully</p>";
      }
    }
  } else {
    if ($mode == 'delete') {
      $status = "<p class='updated'>" . ucfirst($thing) . " deleted successfully.</p>\n";
      if ($thing == 'room') {
        // room deleted; undefine room ID variable, so we display list of rooms instead of room detail
        unset($roomId);
      }
    }
  }
}  // END if (!empty($mode))

if ( empty($roomId) ) {
  // list existing rooms

  if (getPerm('discSetupInsert')) {
    $addNewLink = '<a href="?roomId=new">Add new room</a>';
  } else {
    $addNewLink = '<span class="disabled">Add new room</span>';
  }
?>

<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<?=$status?>
<p><?=$addNewLink?></p>
<table cellpadding="6" cellspacing="0" class="list">
<tr class="head">
<td>Name</td>
<td>Description</td>
</tr>

<?php
  $sql = "SELECT * FROM rooms ORDER BY roomName";
  $result = query($sql, $connection);
  $num = mysql_num_rows($result);
  if ($num == 0) { echo "<tr><td cols='2'><b>0</b> items</td></tr>\n"; }
  while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);
      echo "<tr$class>
<td><a href='?roomId=$row[roomId]'>$row[roomName]</a></td>
<td>$row[roomDesc]</td>
</tr>\n";
  }
  echo "</table>\n";
}  // END if ( empty($roomId) )

else {
  if ($roomId == 'new') {
    // display enter-new form
    $mode = 'insert';
    $submitCaption = ' Add ';
  } else {
    // display edit form
    $mode = 'update';
    $submitCaption = 'Update';

    $sql = "SELECT * FROM rooms WHERE roomId = '$roomId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $roomId = $row['roomId'];
    }
  }

  if ($deleteEnabled and $mode == 'update' and getPerm('discSetupDelete')) {
    $onSubmit = " onsubmit='return confirmDelete(document.frm, \"room, and all its associated boxes,\");'";
  }
?>

<body onload="document.frm.roomName.focus();">
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<?=$status?>
<form name="frm" method="POST" action="saveRoom.php"<?=$onSubmit?>>
<input type="hidden" name="mode" value="<?=$mode?>">
<input type="hidden" name="roomId" value="<?=$roomId?>">
<table cellpadding="4">
<tr>
<td class="label">Name:</td>
<td><input type="text" name="roomName" value="<?=$row[roomName]?>" size="30" maxlength="<?=$roomNameMaxLength?>"></td>
</tr>
<tr>
<td class="label">Description:</td>
<td><input type="text" name="roomDesc" value="<?=$row[roomDesc]?>" size="60" maxlength="<?=$roomDescMaxLength?>"></td>
</tr>
<?php
  if ($deleteEnabled and $mode == 'update' and getPerm('discSetupDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>
<tr>
<td></td>
<td>
<input type="submit" name="go" value="<?=$submitCaption?>"<?=$submitAppearance?>>
<input type="button" value="Cancel" onclick="history.back();">
</td>
</tr>

<?php
  if ($mode == 'update') {

    if (getPerm('discSetupInsert')) {
      $addNewLink = "<a href='boxes.php?boxId=new&roomId=$roomId'>Add new box</a>";
    } else {
      $addNewLink = "<span class='disabled'>Add new box</span>";
    }
?>
<tr>
<td colspan="2"><hr></td>
</tr>
<tr>
<td colspan="2">

  <h3>Boxes</h3>
  <p><?=$addNewLink?></p>

  <table cellpadding="6" cellspacing="0" class="list">
  <tr class="head">
  <td>Label</td>
  <td>Description</td>
  <td>View all discs</td>
  </tr>

<?php
    $sql = "SELECT * FROM boxes WHERE roomId = $roomId ORDER BY boxName";
    $result = query($sql, $connection);
    $num = mysql_num_rows($result);
    if ($num == 0) { echo "<tr><td colspan='2'><b>0</b> items</td></tr>\n"; }
    while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);
      echo "<tr$class>
  <td><a href='boxes.php?boxId=$row[boxId]&roomId=$row[roomId]'>$row[boxName]</a></td>
  <td>$row[boxDesc]</td>
  <td><a href='../../searchArchivalDiscs.php?query=true&boxId1=$row[boxId]'>View all discs in this box</a></td>
  </tr>\n";
    }
?>

  </table>
</td>
</tr>

<?php
  } // END if ($mode == 'update')
?>

</table>
</form>

<?php
}  // END if ($roomId == 'new')
?>

</body>
</html>
