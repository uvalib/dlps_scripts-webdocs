<?php

/*
  boxes.php - page for managing boxes where archival discs are stored
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-11-08
  Last modified: 2005-10-07

  If no 'boxId' parameter, lists boxes already defined.
  If ID is 'new', displays add-new form for defining a box.
  If ID is a number, displays edit form for editing an existing box.
*/

import_request_variables('PG');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Archival Discs - Setup';

if ( empty($boxId) ) {
  // list existing boxes
  $pageTitle = 'Boxes';

  // test permissions
  testPerm('discSetupSelect');
} else {
  if ($boxId == 'new') {
    // display enter-new form
    $pageTitle = 'Enter New Box';

    // test permissions
    testPerm('discSetupInsert');
  } else {
    // display edit form
    $pageTitle = 'Edit Box';

    // test permissions; need Select to view item details, Update to enable submit button
    testPerm('discSetupSelect');
    if (!getPerm('discSetupUpdate')) { $submitAppearance = ' disabled'; }
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
<script type="text/javascript" src="../../../inc/tracksys.js"></script>
</head>

<?php
// determine status message, if any
$status = '';
if (!empty($mode)) {
  if ($affected == '0') {
    $status = "<p class='updated'>No changes were needed.</p>";
  } else {
    if ($mode == 'insert') {
      $status = "<p class='updated'>New box added successfully</p>";
    } else {
      $status = "<p class='updated'>Box updated successfully</p>";
    }
  }
}

if ( empty($boxId) ) {
  // list existing boxes

  if (getPerm('discSetupInsert')) {
    $addNewLink = '<a href="?boxId=new">Add new box</a>';
  } else {
    $addNewLink = '<span class="disabled">Add new box</span>';
  }
?>

<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<p><?=$addNewLink?></p>
<table cellpadding="6" cellspacing="0" class="list">
<tr class="head">
<td>Room</td>
<td>Label</td>
<td>View all discs</td>
</tr>

<?php
  $sql = "SELECT boxes.*, rooms.roomName FROM boxes, rooms ORDER BY roomName, boxName";
  $result = query($sql, $connection);
  $num = mysql_num_rows($result);
  if ($num == 0) { echo "<tr><td colspan='3'><b>0</b> items</td></tr>\n"; }
  while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);
      echo "<tr$class>
<td>$row[roomName]</td>
<td><a href='?boxId=$row[boxId]'>$row[boxName]</a></td>
<td><a href='../../../text/viewTextItems.php?query=true&boxId=$row[boxId]&orderBy=title'>View all discs</a></td>
</tr>\n";
  }
  echo "</table>\n";
}  // END if ( empty($boxId) )

else {
  // get room name
  if (!empty($roomId)) {
    $sql = "SELECT roomName FROM rooms WHERE roomId = '$roomId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $roomName = $row['roomName'];
    }
  }

  if ($boxId == 'new') {
    // display enter-new form
    $mode = 'insert';
    $submitCaption = ' Add ';
  } else {
    // display edit form
    $mode = 'update';
    $submitCaption = 'Update';

    $sql = "SELECT * FROM boxes WHERE boxId = '$boxId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $boxId = $row['boxId'];
    }
  }

  if ($deleteEnabled and $mode == 'update' and getPerm('discSetupDelete')) {
    $onSubmit = " onsubmit='return confirmDelete(document.frm, \"box\");'";
  }
?>

<body onload="document.frm.boxName.focus();">
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<?=$status?>
<form name="frm" method="POST" action="saveBox.php"<?=$onSubmit?>>
<input type="hidden" name="mode" value="<?=$mode?>">
<input type="hidden" name="boxId" value="<?=$boxId?>">
<input type="hidden" name="roomId" value="<?=$roomId?>">
<table cellpadding="4">
<tr>
<td class="label">Room:</td>
<td><?=$roomName?></td>
</tr>
<tr>
<td class="label">Box Label:</td>
<td><input type="text" name="boxName" value="<?=$row[boxName]?>" size="30" maxlength="<?=$boxNameMaxLength?>"></td>
</tr>
<tr>
<td class="label">Description:</td>
<td><input type="text" name="boxDesc" value="<?=$row[boxDesc]?>" size="60" maxlength="<?=$boxDescMaxLength?>"></td>
</tr>
<?php
  if ($deleteEnabled and $mode == 'update' and getPerm('discSetupDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>
<tr>
<td></td>
<td>
<input type="submit" name="go" value="<?=$submitCaption?>"<?=$submitAppearance?>>
<input type="button" value="Cancel" onclick="history.back();">
</td>
</tr>
</table>
</form>
<?php
}  // END if ( empty($boxId) ) { ... } else
?>
</body>
</html>
