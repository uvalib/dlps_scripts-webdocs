<?php

/*
  saveArchivalDisc.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-11-01
  Last modified: 2006-05-23

  Saves user-entered data to database table archivalDiscs.

  Receives data from: archivalDisc.php
  If data is not valid, redirects to: err/badInput.php
  If record is updated successfully, redirects to: archivalDisc.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

//--------------------
// validate user input
//--------------------

$location = 'Location: ../err/badInput.php?msg=';

// disc ID
if (empty($volumeId)) {
  header($location . urlencode('Disc ID is required'));
  exit;
}

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}

if ($mode == 'insert') {
  // media (DVD or CD)
  if (empty($media)) {
    header($location . urlencode('Media indicator is required'));
    exit;
  }
}

// make sure boxId1 and boxId2 are not the same (unless they're both empty)
if ($boxId1 == $boxId2) {
  if (! $boxId1 == '0') {
    header($location . urlencode('Location 1 and Location 2 must not be the same'));
    exit;
  }
}

// connect to db
$connection = connect();

// prep user input
if ($mode == 'insert') {
  $volumeId = clean2($volumeId, $connection, $volumeIdMaxLength);
  $fileList = clean2($fileList, $connection);
}
$projectLabel = clean2($projectLabel, $connection, $projectLabelMaxLength);

// test whether this volume ID already exists
$sql = "SELECT volumeId FROM archivalDiscs WHERE volumeId = '$volumeId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) >= 1 ) {
  if ($mode == 'insert') {
    // can't insert a disc ID that already exists
    header($location . urlencode('Disc ID "' . $volumeId . '" already exists, so it cannot be added'));
    exit;
  }
} else {
  if ($mode == 'update') {
    // can't update a record that doesn't exist
    header($location . urlencode('Disc ID "' . $volumeId . '" does not exist, so it cannot be updated'));
    exit;
  }
}

// if disc ID starts with a 6-digit date, convert it to a date for dateBurned
if ( preg_match('/^(\d{2})(\d{2})(\d{2})/', $volumeId, $matches) ) {
  $dateBurned = '20' . $matches[1] . '-' . $matches[2] . '-' . $matches[3];
  // add 5 years to get dateExpires
  $year = $matches[1];
  $year += 5;
  $dateExpires = '20' . str_pad($year, 2, '0', STR_PAD_LEFT) . '-' . $matches[2] . '-' . $matches[3];
}


//--------------------
// build SQL statement
//--------------------

if ($mode == 'update') {
  if ($chkDelete) {
    testPerm('discDelete');
    $mode = 'delete';
    $sql = "DELETE FROM archivalDiscs";
  } else {
    testPerm('discUpdate');
    $sql = "UPDATE archivalDiscs SET";
  }
  $where = " WHERE volumeId = '$volumeId'";
} else {
  testPerm('discInsert');
  $sql = "INSERT INTO archivalDiscs SET";
  $where = '';
}

if ($mode == 'delete') {
  $values = '';
} else {
  $values = '';
  if (!$isRimage) {
    if ($mode == 'insert') {
      if (empty($volumeId)) {
        // this should never occur due to prior tests; this is a last-ditch
        // check that will cause the insert or update to fail (since ID cannot be null)
        $value = "NULL";
      } else {
        $value = "'$volumeId'";
      }
      $values .= " volumeId = $value";
    }

    if (! empty($values)) {
      $values .= ',';
    }

    if (empty($media)) { $value = "NULL"; } else { $value = "'$media'"; }
    $values .= " media = $value";

    if (empty($copies)) {
      $value = '0';
    } else {
      if ( preg_match('/\d+/', $copies) ) {
        $value = $copies;
      } else {
        $value = '0';
      }
    }
    $values .= ", copies = $value";

    if (empty($fileCount)) {
      $value = '0';
    } else {
      if ( preg_match('/\d+/', $fileCount) ) {
        $value = $fileCount;
      } else {
        $value = '0';
      }
    }
    $values .= ", fileCount = $value";

    if (empty($fileList)) { $value = "NULL"; } else { $value = "'$fileList'"; }
    $values .= ", fileList = $value";
  }

  if ( ! empty($values) ) {
    $values .= ',';
  }

  if (empty($projectLabel)) { $value = "NULL"; } else { $value = "'$projectLabel'"; }
  $values .= " projectLabel = $value";

  if (!empty($dateBurned)) {
    $values .= ", dateBurned = '$dateBurned'";
  }

  if (!empty($dateExpires)) {
    $values .= ", dateExpires = '$dateExpires'";
  }

  if (empty($boxId1)) { $value = "0"; } else { $value = "$boxId1"; }
  $values .= ", boxId1 = $value";

  if (empty($boxId2)) { $value = "0"; } else { $value = "$boxId2"; }
  $values .= ", boxId2 = $value";
}

$sql .= $values . $where;

//----------------------
// execute SQL statement
//----------------------

if ( mysql_query($sql, $connection) ) {
  $affected = mysql_affected_rows();

  // redirect, indicating success
  if ($mode == 'insert') {
    // exclude disc ID when redirecting, so form appears as enter-new-item form
    $temp = '';
  } else {
    $temp = "volumeId=$volumeId&";
  }
  header("Location: archivalDisc.php?${temp}status=changed&mode=$mode&affected=$affected");
} else {
  die($dbErrorPreface . mysql_error($connection) . "<br><br>$sql");
}
?>