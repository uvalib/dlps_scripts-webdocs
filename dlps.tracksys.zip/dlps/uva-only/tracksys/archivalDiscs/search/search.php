<?php

/*
  search.php - queries database and displays search results
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-06-19
  Last modified: 2006-06-19
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to db
$connection = connect();

testPerm('discSelect');
$siteArea = 'Archival Discs';
$pageTitle = 'Search Results';

// get associative array representing table 'sets'
$sets = getHashSets($connection);

// get associative array representing table 'projects'
$projects = getHashProjects($connection);

// get associative array representing table 'selectors'
$selectors = getHashSelectors($connection);

// get associative array representing table 'requestors'
$requestors = getHashRequestors($connection);

// get associative array representing table 'pageImagesResps'
$pageImagesResps = getHashPageImagesResps($connection);

// get associative array representing table 'boxes'
$boxes = getHashBoxes($connection);


//--------------------------------------------------------------------
// query table textItems to get DLPS IDs associated with the specified
// set, project, etc. (if any)
//--------------------------------------------------------------------

$criteriaUsed = false;
$sql = 'SELECT DISTINCT dlpsId FROM textItems';
$where = '';

$where .= $_SESSION['searchArchivalDiscsSql']['setId'];
$where .= $_SESSION['searchArchivalDiscsSql']['projectId'];
$where .= $_SESSION['searchArchivalDiscsSql']['selectorId'];
$where .= $_SESSION['searchArchivalDiscsSql']['requestorId'];
$where .= $_SESSION['searchArchivalDiscsSql']['pageImagesRespId'];

$dlpsIds = array();
if (!empty($where)) {
  $where = preg_replace('/^ AND/', '', $where);  // remove the initial ' AND', if any
  $sql .= ' WHERE' . $where;
  $sql .= ' ORDER BY dlpsId';
  $subquery = $sql;

  // execute query
  $result = query($sql, $connection);
  while ( $row = mysql_fetch_array($result) ) {
    $dlpsIds[] = $row['dlpsId'];
  }
}


//-----------------------------------------------------------------------
// query table archiveDiscs to find disc IDs matching the search criteria
//-----------------------------------------------------------------------

$sql = 'SELECT * FROM archivalDiscs';
$where = '';

$where .= $_SESSION['searchArchivalDiscsSql']['volumeId'];
$where .= $_SESSION['searchArchivalDiscsSql']['fileList'];
$where .= $_SESSION['searchArchivalDiscsSql']['projectDir'];
$where .= $_SESSION['searchArchivalDiscsSql']['projectLabel'];
$where .= $_SESSION['searchArchivalDiscsSql']['boxId1'];
$where .= $_SESSION['searchArchivalDiscsSql']['boxId2'];
$where .= $_SESSION['searchArchivalDiscsSql']['isRimage'];

// include dlpsIds associated with set, project, etc.
if (empty($dlpsIds)) {
  if ($criteriaUsed) {
    // text criteria were used but returned no DLPS IDs; thus overall query must fail
    $where .= " AND 0";
  }
} else {
  $where .= " AND (";
  foreach ($dlpsIds as $id) {
    $idSql = clean2($id, $connection);
    $subWhere .= " OR fileList LIKE '%$idSql%'";
  }
  $subWhere = preg_replace('/^ OR /', '', $subWhere);  // remove the initial ' OR'
  $where .= "$subWhere)";
}

if (!empty($where)) {
  $where = preg_replace('/^ +AND +/', '', $where);  // remove the initial ' AND'
  $sql .= ' WHERE ' . $where;
}

// sort order
if ( $_GET['orderBy'] ) {
  $orderBy = $_GET['orderBy'];
} elseif ( $_SESSION['searchArchivalDiscsOutput']['orderBy'] ) {
  $orderBy = $_SESSION['searchArchivalDiscsOutput']['orderBy'];
} else {
  $orderBy = 'volumeId';
}
$_SESSION['searchArchivalDiscsOutput']['orderBy'] = $orderBy;
switch ($orderBy) {
  case 'volumeId':
    $_SESSION['searchArchivalDiscsSql']['orderBy'] = ' ORDER BY volumeId';
    break;
  default:
    //unset($_SESSION['searchArchivalDiscsOutput']['orderBy']);
    //unset($_SESSION['searchArchivalDiscsSql']['orderBy']);
    //$orderBy = '';
    $_SESSION['searchArchivalDiscsSql']['orderBy'] = " ORDER BY $orderBy, volumeId";
}
$sql .= $_SESSION['searchArchivalDiscsSql']['orderBy'];

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
if ($debugMode) {
  echo "<p>$sql</p>\n";
}

// execute query
$result = query($sql, $connection);

$num = mysql_num_rows($result);
if ($num == 1) { $plural = ''; } else { $plural = 's'; }
echo "<p>Found <b>$num</b> disc$plural</p>\n";

$newSearchLink = "<p><a href='search1.php'>Adjust this search</a><br>
<a href='search3.php'>Adjust output options</a><br>
<a href='search0.php'>Start a new search</a></p>\n";
echo $newSearchLink;

if ($num >= 1) {
  //echo "<form name='selectForm' method='POST'>\n";
  echo "<table cellpadding='6' cellspacing='0' class='list'>\n";
  echo "<tr class='head'>\n";
  //echo "<td>&nbsp;</td>\n";

  //-----------------------
  // set up column headings
  //-----------------------

  $colspan = 1;

  if ($_SESSION['searchArchivalDiscsOutput']['useSearchColumns']) {
    $useSearchColumns = 1;
  } else {
    $useSearchColumns = 0;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['volumeId']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['volumeId'])) ) {
    if ($orderBy == 'volumeId') {
      echo "<td><i>Disc ID</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=volumeId'>Disc ID</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['media']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['media'])) ) {
    if ($orderBy == 'media') {
      echo "<td><i>Media</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=media'>Media</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['format']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['format'])) ) {
    if ($orderBy == 'format') {
      echo "<td><i>Format</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=format'>Format</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['copies']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['copies'])) ) {
    if ($orderBy == 'copies') {
      echo "<td><i>Number of Copies</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=copies'>Number of Copies</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['projectDir']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['projectDir'])) ) {
    if ($orderBy == 'projectDir') {
      echo "<td><i>Project Directory</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=projectDir'>Project Directory</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['projectLabel']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['projectLabel'])) ) {
    if ($orderBy == 'projectLabel') {
      echo "<td><i>Project Label</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=projectLabel'>Project Label</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['dateBurned']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['dateBurned'])) ) {
    if ($orderBy == 'dateBurned') {
      echo "<td><i>Date Burned</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=dateBurned'>Date Burned</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['dateExpires']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['dateExpires'])) ) {
    if ($orderBy == 'dateExpires') {
      echo "<td><i>Date Expires</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=dateExpires'>Date Expires</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['fileCount']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['fileCount'])) ) {
    if ($orderBy == 'fileCount') {
      echo "<td><i>File Count</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=fileCount'>File Count</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['editlistFile']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['editlistFile'])) ) {
    if ($orderBy == 'editlistFile') {
      echo "<td><i>Editlist File</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=editlistFile'>Editlist File</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['boxId1']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['boxId1'])) ) {
    if ($orderBy == 'boxId1') {
      echo "<td><i>Location 1</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=boxId1'>Location 1</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['boxId2']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['boxId2'])) ) {
    if ($orderBy == 'boxId2') {
      echo "<td><i>Location 2</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=boxId2'>Location 2</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['isRimage']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['isRimage'])) ) {
    if ($orderBy == 'isRimage') {
      echo "<td><i>Created With</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=isRimage'>Created With</a></td>\n";
    }
    $colspan++;
  }

/*
  if ( $_SESSION['searchArchivalDiscsOutput']['setId']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['setId'])) ) {
    echo "<td>Set</td>\n";
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['projectId']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['projectId'])) ) {
    echo "<td>Project</td>\n";
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['selectorId']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['selectorId'])) ) {
    echo "<td>Selector</td>\n";
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['requestorId']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['requestorId'])) ) {
    echo "<td>Requestor</td>\n";
    $colspan++;
  }

  if ( $_SESSION['searchArchivalDiscsOutput']['pageImagesRespId']
       or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['pageImagesRespId'])) ) {
    echo "<td>Page-image Creator</td>\n";
    $colspan++;
  }
*/

  echo "</tr>\n";

  $c = 1;
  $class = getRowClass($c);
  $colspan--;
/*
  echo "<tr$class>
<td style='white-space: nowrap'>
<img name='checkAll' src='../../img/check.gif' hspace='0' onclick='setCheckboxes(true);' title='Check All'>
<img name='clearAll' border='0' src='../../img/square.gif' hspace='0' onclick='setCheckboxes(false);' title='Clear All'>
</td>
<td colspan='$colspan'>&nbsp;</td>
</tr>\n";
*/

  //----------------------
  // display query results
  //----------------------

  while ( $row = mysql_fetch_array($result) ) {
    $c++;
    $class = getRowClass($c);
    echo "<tr$class>\n";
    //echo "<td><input type='checkbox' name='volumeId_$row[volumeId]' checked></td>\n";

    if ( $_SESSION['searchArchivalDiscsOutput']['volumeId']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['volumeId'])) ) {
      echo "<td><a href='../archivalDisc.php?volumeId=$row[volumeId]'>$row[volumeId]</a></td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['media']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['media'])) ) {
      echo "<td>$row[media]</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['format']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['format'])) ) {
      echo "<td>$row[format]</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['copies']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['copies'])) ) {
      echo "<td>$row[copies]</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['projectDir']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['projectDir'])) ) {
      echo "<td>$row[projectDir]</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['projectLabel']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['projectLabel'])) ) {
      echo "<td>$row[projectLabel]</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['dateBurned']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['dateBurned'])) ) {
      echo "<td>" . formatDateUS($row['dateBurned']) . "</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['dateExpires']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['dateExpires'])) ) {
      echo "<td>" . formatDateUS($row['dateExpires']) . "</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['fileCount']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['fileCount'])) ) {
      if ($row['fileCount'] == 0) { $fileCount = ''; } else { $fileCount = $row['fileCount']; }
      echo "<td>$fileCount</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['editlistFile']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['editlistFile'])) ) {
      echo "<td>$row[editlistFile]</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['boxId1']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['boxId1'])) ) {
      $location1 = '';
      if (!empty($row['boxId1'])) {
        foreach ($boxes as $id => $name) {
          if ($id == $row['boxId1']) {
            $temp = explode('|', $boxes[$id]);
            $roomName = $temp[0];
            $boxName = $temp[1];
            $location1 = "$roomName, $boxName";
          }
        }
      }
      echo "<td>$location1</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['boxId2']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['boxId2'])) ) {
      $location2 = '';
      if (!empty($row['boxId2'])) {
        foreach ($boxes as $id => $name) {
          if ($id == $row['boxId2']) {
            $temp = explode('|', $boxes[$id]);
            $roomName = $temp[0];
            $boxName = $temp[1];
            $location2 = "$roomName, $boxName";
          }
        }
      }
      echo "<td>$location2</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['isRimage']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['isRimage'])) ) {
      if ($row['isRimage'] == 1) { $temp = 'Rimage'; } else { $temp = 'other'; }
      echo "<td>$temp</td>\n";
    }

/*
    if ( $_SESSION['searchArchivalDiscsOutput']['setId']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['setId'])) ) {
      if ( empty($row['setId']) ) {
        $name = '';
      } else {
        foreach ($sets as $id => $name) {
          if ($row['setId'] == $id) {
	    break;
          }
        }
      }
      echo "<td>$name</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['projectId']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['projectId'])) ) {
      if ( empty($row['projectId']) ) {
        $name = '';
      } else {
        foreach ($projects as $id => $name) {
          if ($row['projectId'] == $id) {
	    break;
          }
        }
      }
      echo "<td>$name</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['selectorId']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['selectorId'])) ) {
      if ( empty($row['selectorId']) ) {
        $name = '';
      } else {
        foreach ($selectors as $id => $name) {
          if ($row['selectorId'] == $id) {
	    break;
          }
        }
      }
      echo "<td>$name</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['requestorId']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['requestorId'])) ) {
      if ( empty($row['requestorId']) ) {
        $name = '';
      } else {
        foreach ($requestors as $id => $name) {
          if ($row['requestorId'] == $id) {
	    break;
          }
        }
      }
      echo "<td>$name</td>\n";
    }

    if ( $_SESSION['searchArchivalDiscsOutput']['pageImagesRespId']
	 or ($useSearchColumns and !empty($_SESSION['searchArchivalDiscsSql']['pageImagesRespId'])) ) {
      if ( empty($row['pageImagesRespId']) ) {
        $name = '';
      } else {
        foreach ($pageImagesResps as $id => $name) {
          if ($row['pageImagesRespId'] == $id) {
	    break;
          }
        }
      }
      echo "<td>$name</td>\n";
    }
*/

    echo "</tr>\n";
  }
  echo "</table>\n";

/*
  echo "<p> </p>
<table cellpadding='4' border='0'>
<tr>
<td class='tableSectionHeading' colspan='3'>Actions:</td>
</tr>

<tr>
<td align='right'>View checked items:</td>
<td><select name='workflow'>
<option value='bookScanning'>Book scanning workflow</option>
<option value='migration'>Migration images workflow</option>
<option value='teiHeader'>TEI header workflow</option>
<option value='postkb'>Post-keyboarding workflow</option>
<option value='markupQA'>Markup QA workflow</option>
<option value='finalization'>Finalization workflow</option>
</select>
</td>
<td valign='bottom'>
<input type='submit' value='View Workflow' onclick='return setFormAction(document.selectForm);'>
<input type='hidden' name='orderBy' value='$orderBy'>
</td>
</tr>
</table>\n;

  echo "</form>\n";
*/

  echo $newSearchLink;
}  // END if ($num >= 1)
?>
</body>
</html>
