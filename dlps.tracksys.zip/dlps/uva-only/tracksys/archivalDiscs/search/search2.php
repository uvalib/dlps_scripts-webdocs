<?php

/*
  search2.php - second search page - misc criteria
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-06-16
  Last modified: 2006-06-16

  Receives data from: search1.php
  Submits data to: search3.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Archival Discs';
$pageTitle = 'Search - Other Criteria';

// connect to db
$connection = connect();

// get associative array representing table 'sets'
$sets = getHashSets($connection);

// get associative array representing table 'projects'
$projects = getHashProjects($connection);

// get associative array representing table 'selectors'
$selectors = getHashSelectors($connection);

// get associative array representing table 'requestors'
$requestors = getHashRequestors($connection);

// get associative array representing table 'pageImagesResps'
$pageImagesResps = getHashPageImagesResps($connection);


//-------------------------------------
// process form data from previous page
//-------------------------------------

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// volume ID
if ( isset($volumeId) ) {
  if ( empty($volumeId) ) {
    unset($_SESSION['searchArchivalDiscs']['volumeId']);
    unset($_SESSION['searchArchivalDiscsSql']['volumeId']);
  } else {
    $_SESSION['searchArchivalDiscs']['volumeId'] = $volumeId;
    $volumeId = clean2($volumeId, $connection);

    // check for comma or semicolon indicating multiple IDs to search for
    if (ereg('[,;]', $volumeId)) {
      $volumeIds = preg_split('/[,;] ?/', $volumeId);
      $like = '';
      foreach($volumeIds as $id) {
	if (!empty($id)) {
	  $id = translateWildcards($id);
	  if (!ereg('%$', $id)) { $id .= '%'; }
	  $like .= "(archivalDiscs.volumeId LIKE '$id') OR ";
	}
      }
      $like = preg_replace('/ OR $/', '', $like);
      $_SESSION['searchArchivalDiscsSql']['volumeId'] = " AND $like";
    } else {
      $volumeIdSql = translateWildcards($volumeId);
      if (!ereg('%$', $volumeIdSql)) { $volumeIdSql .= '%'; }
      $_SESSION['searchArchivalDiscsSql']['volumeId'] = " AND archivalDiscs.volumeId LIKE '$volumeIdSql'";
    }
  }
}

// filename or DLPS ID
if ( isset($fileList) ) {
  if ( empty($fileList) ) {
    unset($_SESSION['searchArchivalDiscs']['fileList']);
    unset($_SESSION['searchArchivalDiscsSql']['fileList']);
  } else {
    $_SESSION['searchArchivalDiscs']['fileList'] = $fileList;
    $fileList = clean2($fileList, $connection);

    // check for comma or semicolon indicating multiple DLPS IDs to search for
    if (ereg('[,;]', $fileList)) {
      $fileLists = preg_split('/[,;] ?/', $fileList);
      $like = '';
      foreach($fileLists as $id) {
	if (!empty($id)) {
	  $id = translateWildcards($id);
	  if (!ereg('^%', $id)) { $id = '%' . $id; }
	  if (!ereg('%$', $id)) { $id .= '%'; }
	  $like .= "(fileList LIKE '$id') OR ";
	}
      }
      $like = preg_replace('/ OR $/', '', $like);
      $_SESSION['searchArchivalDiscsSql']['fileList'] = " AND $like";
    } else {
      $fileListSql = translateWildcards($fileList);
      if (!ereg('^%', $fileListSql)) { $fileListSql = '%' . $fileListSql; }
      if (!ereg('%$', $fileListSql)) { $fileListSql .= '%'; }
      $_SESSION['searchArchivalDiscsSql']['fileList'] = " AND fileList LIKE '$fileListSql'";
    }
  }
}

// project directory
if ( isset($projectDir) ) {
  if ( empty($projectDir) ) {
    unset($_SESSION['searchArchivalDiscs']['projectDir']);
    unset($_SESSION['searchArchivalDiscsSql']['projectDir']);
  } else {
    $_SESSION['searchArchivalDiscs']['projectDir'] = $projectDir;
    $projectDirSql = clean2(translateWildcards($projectDir), $connection);
    if (!ereg('^%', $projectDirSql)) { $projectDirSql = '%' . $projectDirSql; }
    if (!ereg('%$', $projectDirSql)) { $projectDirSql .= '%'; }
    $_SESSION['searchArchivalDiscsSql']['projectDir'] = " AND projectDir LIKE '$projectDirSql'";
  }
}

// project label
if ( isset($projectLabel) ) {
  if ( empty($projectLabel) ) {
    unset($_SESSION['searchArchivalDiscs']['projectLabel']);
    unset($_SESSION['searchArchivalDiscsSql']['projectLabel']);
  } else {
    $_SESSION['searchArchivalDiscs']['projectLabel'] = $projectLabel;
    $projectLabelSql = clean2(translateWildcards($projectLabel), $connection);
    if (!ereg('^%', $projectLabelSql)) { $projectLabelSql = '%' . $projectLabelSql; }
    if (!ereg('%$', $projectLabelSql)) { $projectLabelSql .= '%'; }
    $_SESSION['searchArchivalDiscsSql']['projectLabel'] = " AND projectLabel LIKE '$projectLabelSql'";
  }
}

// location 1
if ( isset($boxId1) ) {
  if ( empty($boxId1) ) {
    unset($_SESSION['searchArchivalDiscs']['boxId1']);
    unset($_SESSION['searchArchivalDiscsSql']['boxId1']);
  } else {
    $_SESSION['searchArchivalDiscs']['boxId1'] = $boxId1;
    $_SESSION['searchArchivalDiscsSql']['boxId1'] = " AND boxId1 = $boxId1";
  }
}

// location 2
if ( isset($boxId2) ) {
  if ( empty($boxId2) ) {
    unset($_SESSION['searchArchivalDiscs']['boxId2']);
    unset($_SESSION['searchArchivalDiscsSql']['boxId2']);
  } else {
    $_SESSION['searchArchivalDiscs']['boxId2'] = $boxId2;
    $_SESSION['searchArchivalDiscsSql']['boxId2'] = " AND boxId2 = $boxId2";
  }
}

// created with
if ( isset($isRimage) ) {
  if ($isRimage == '0' or $isRimage == '1') {
    $_SESSION['searchArchivalDiscs']['isRimage'] = $isRimage;
    $_SESSION['searchArchivalDiscsSql']['isRimage'] = " AND isRimage = $isRimage";
  } else {
    unset($_SESSION['searchArchivalDiscs']['isRimage']);
    unset($_SESSION['searchArchivalDiscsSql']['isRimage']);
  }
}

// redirect to search form, if immediate search was requested
if ($searchNow) {
  header('Location: search.php');
  exit;
}


//---------------------------
// display form for this page
//---------------------------
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="GET" action="search3.php">
<table cellpadding="4">

<tr>
<td class="label">Multi-volume set:</td>
<td><select name="setId">
<option value=''>All items</option>
<?php
$setId = $_SESSION['searchArchivalDiscs']['setId'];

$selected = '';
if ($setId == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items in any set</option>\n";

$selected = '';
if ($setId == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not in a set</option>\n";

$selected = '';
if ($setId == 'not9') { $selected = ' selected'; }
echo "<option value='not9'$selected>Items not in UVa Record</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($sets as $id => $name) {
  $selected = '';
  if ( $id == $setId ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>


<tr>
<td class="label">Project:</td>
<td><select name="projectId">
<option value=''>All items</option>
<?php
$projectId = $_SESSION['searchArchivalDiscs']['projectId'];

$selected = '';
if ($projectId == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items in any project</option>\n";

$selected = '';
if ($projectId == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not in a project</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($projects as $id => $name) {
  $selected = '';
  if ( $id == $projectId ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>


<tr>
<td class="label">Selector:</td>
<td><select name="selectorId">
<option value=''>All items</option>
<?php
$selectorId = $_SESSION['searchArchivalDiscs']['selectorId'];

$selected = '';
if ($selectorId == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items from any selector</option>\n";

$selected = '';
if ($selectorId == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not from a selector</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($selectors as $id => $name) {
  $selected = '';
  if ( $id == $selectorId ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>


<tr>
<td class="label">Requestor:</td>
<td><select name="requestorId">
<option value=''>All items</option>
<?php
$requestorId = $_SESSION['searchArchivalDiscs']['requestorId'];

$selected = '';
if ($requestorId == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items from any requestor</option>\n";

$selected = '';
if ($requestorId == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not from a requestor</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($requestors as $id => $name) {
  $selected = '';
  if ( $id == $requestorId ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>


<tr>
<td class="label">Page image creator:</td>
<td><select name="pageImagesRespId">
<option value=''>All items</option>
<?php
$pageImagesRespId = $_SESSION['searchArchivalDiscs']['pageImagesRespId'];

$selected = '';
if ($pageImagesRespId == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items from any page-image creator</option>\n";

$selected = '';
if ($pageImagesRespId == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not from a page-image creator</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($pageImagesResps as $id => $name) {
  $selected = '';
  if ( $id == $pageImagesRespId ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td></td>
<td>
<input type="button" value="&lt; Back" onclick="history.back();">
<input type="button" value="Clear" onclick="clearForm();">
<input type="button" value="Search Now" onclick="document.frm.searchNow.value='true'; document.frm.submit();">
<input type="submit" value="Next &gt;"  onclick="document.frm.searchNow.value='';">
<input type="hidden" name="searchNow">
</td>
</tr>

</table>
</form>
</body>
</html>
