<?php

/*
  search0.php - preliminary search page - clears saved search criteria
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-06-16
  Last modified: 2006-06-16

  Receives data from: Not applicable
  Redirects to: search1.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

unset($_SESSION['searchArchivalDiscs']);
unset($_SESSION['searchArchivalDiscsSql']);

// reset output options to defaults
unset($_SESSION['searchArchivalDiscsOutput']);
$_SESSION['searchArchivalDiscsOutput']['useSearchColumns'] = 1;
$_SESSION['searchArchivalDiscsOutput']['volumeId'] = 1;
//$_SESSION['searchArchivalDiscsOutput']['media'] = 1;
//$_SESSION['searchArchivalDiscsOutput']['projectDir'] = 1;
$_SESSION['searchArchivalDiscsOutput']['projectLabel'] = 1;
$_SESSION['searchArchivalDiscsOutput']['dateBurned'] = 1;
$_SESSION['searchArchivalDiscsOutput']['fileCount'] = 1;
$_SESSION['searchArchivalDiscsOutput']['boxId1'] = 1;
$_SESSION['searchArchivalDiscsOutput']['boxId2'] = 1;

// redirect to first page of search form
header('Location: search1.php');
?>