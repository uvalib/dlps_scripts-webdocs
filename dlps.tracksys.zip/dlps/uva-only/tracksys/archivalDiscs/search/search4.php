<?php

/*
  search4.php - final search page for archival discs - processes form data and redirects to search page
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-06-26
  Last modified: 2006-06-26

  Receives data from: search3.php
  Redirects to: search.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to db
//$connection = connect();

//-------------------------------------
// process form data from previous page
//-------------------------------------

unset($_SESSION['searchArchivalDiscsOutput']);

// display columns used in search criteria, in addition to those specified?
if ($useSearchColumns) {
  $_SESSION['searchArchivalDiscsOutput']['useSearchColumns'] = 1;
} else {
  $_SESSION['searchArchivalDiscsOutput']['useSearchColumns'] = 0;
}

// columns to display
foreach ($columns as $columnName) {
  $_SESSION['searchArchivalDiscsOutput'][$columnName] = 1;
}

// sort order
if (!empty($orderBy)) {
  $_SESSION['searchArchivalDiscsOutput']['orderBy'] = $orderBy;
}

// redirect to search form
header('Location: search.php');
?>