<?php

/*
  search1.php - first search page - basic criteria
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-06-16
  Last modified: 2006-06-16

  Submits data to: search2.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Archival Discs';
$pageTitle = 'Search - Basic Criteria';

// connect to db
$connection = connect();

// get associative array representing table 'boxes'
$boxes = getHashBoxes($connection);

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body onload="document.frm.volumeId.focus();">
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<form name="frm" method="GET" action="search2.php">
<table cellpadding="4">
<tr>
<td class="label">Disc ID:</td>
<td><input type="text" name="volumeId" value="<?=$_SESSION['searchArchivalDiscs']['volumeId']?>"></td>
</tr>

<tr>
<td class="label">Filename or DLPS ID:</td>
<td><input type="text" name="fileList" value="<?=$_SESSION['searchArchivalDiscs']['fileList']?>"></td>
</tr>

<tr>
<td class="label">Project directory:</td>
<td><input type="text" name="projectDir" value="<?=$_SESSION['searchArchivalDiscs']['projectDir']?>"></td>
</tr>

<tr>
<td class="label">Project label:</td>
<td><input type="text" name="projectLabel" value="<?=$_SESSION['searchArchivalDiscs']['projectLabel']?>"></td>
</tr>

<tr>
<td class='label'>Location 1:</td>
<td><select name="boxId1">
<option value=''>All items</option>
<option value=''>--------------------</option>
<?php
foreach ($boxes as $id => $name) {
  $selected = '';
  if ( ! empty($_SESSION['searchArchivalDiscs']['boxId1']) ) {
    if ( $id == $_SESSION['searchArchivalDiscs']['boxId1'] ) { $selected = ' selected'; }
  }
  $temp = explode('|', $name);
  $roomName = $temp[0];
  $boxName = $temp[1];
  echo "<option value='$id'$selected>$roomName, $boxName</option>\n";
}
?>
</select>
</td>
</tr>

<tr>
<td class='label'>Location 2:</td>
<td><select name="boxId2">
<option value=''>All items</option>
<option value=''>--------------------</option>
<?php
foreach ($boxes as $id => $name) {
  $selected = '';
  if ( ! empty($_SESSION['searchArchivalDiscs']['boxId2']) ) {
    if ( $id == $_SESSION['searchArchivalDiscs']['boxId2'] ) { $selected = ' selected'; }
  }
  $temp = explode('|', $name);
  $roomName = $temp[0];
  $boxName = $temp[1];
  echo "<option value='$id'$selected>$roomName, $boxName</option>\n";
}
?>
</select>
</td>
</tr>

<?php
if (isset($_SESSION['searchArchivalDiscs']['isRimage'])) {
  switch($_SESSION['searchArchivalDiscs']['isRimage']) {
    case '1':
      $isRimageSelectedRimage = ' selected';
      break;
    case '0':
      $isRimageSelectedOther = ' selected';
      break;
  }
}
?>
<tr>
<td class="label">Created with:</td>
<td><select name="isRimage">
<option value=''>All items</option>
<option value=''>--------------------</option>
<option value="1"<?=$isRimageSelectedRimage?>>Rimage system</option>
<option value="0"<?=$isRimageSelectedOther?>>other</option>
</tr>

<tr>
<td></td>
<td>
<input type="button" value="Clear" onclick="clearForm();">
<input type="button" value="Search Now" onclick="document.frm.searchNow.value='true'; document.frm.submit();">
<input type="submit" value="Next &gt;"  onclick="document.frm.searchNow.value='';">
<input type="hidden" name="searchNow">
</td>
</tr>

</table>

<br>
<p><strong>Wildcards:</strong> Use * for zero or more characters, ? for
exactly one character.</p>

<p><strong>Disc ID:</strong> To search for multiple disc IDs, enter
the IDs separated by commas or semicolons.</p>

<p><strong>Filename or DLPS ID:</strong> To search for multiple
filenames or DLPS IDs, enter the values separated by commas or
semicolons.</p>

</form>
</body>
</html>
