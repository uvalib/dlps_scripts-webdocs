<?php

/*
  search3.php - options for output/display of search results
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-06-26
  Last modified: 2006-06-26

  Receives data from: search2.php
  Submits data to: search4.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Archival Discs';
$pageTitle = 'Search - Output Options';

// connect to db
$connection = connect();

//-------------------------------------
// process form data from previous page
//-------------------------------------

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// set
if ( isset($setId) ) {
  if ( empty($setId) ) {
    unset($_SESSION['searchArchivalDiscs']['setId']);
    unset($_SESSION['searchArchivalDiscsSql']['setId']);
  } else {
    $_SESSION['searchArchivalDiscs']['setId'] = $setId;
    $_SESSION['searchArchivalDiscsSql']['setId'] = ' AND ';
    if ($setId == 'any') {
      // select items from any set
      $_SESSION['searchArchivalDiscsSql']['setId'] .= 'setId != 0';
    } elseif ($setId == 'none') {
      // select items not assigned to a set
      $_SESSION['searchArchivalDiscsSql']['setId'] .= 'setId = 0';
    } elseif ($setId == 'not9') {
      // select items not assigned set 9, UVa Record
      $_SESSION['searchArchivalDiscsSql']['setId'] .= 'setId != 9';
    } else {
      $_SESSION['searchArchivalDiscsSql']['setId'] .= "setId = $setId";
    }
  }
}

// project
if ( isset($projectId) ) {
  if ( empty($projectId) ) {
    unset($_SESSION['searchArchivalDiscs']['projectId']);
    unset($_SESSION['searchArchivalDiscsSql']['projectId']);
  } else {
    $_SESSION['searchArchivalDiscs']['projectId'] = $projectId;
    $_SESSION['searchArchivalDiscsSql']['projectId'] = ' AND ';
    if ($projectId == 'any') {
      $_SESSION['searchArchivalDiscsSql']['projectId'] .= 'projectId != 0';
    } elseif ($projectId == 'none') {
      $_SESSION['searchArchivalDiscsSql']['projectId'] .= 'projectId = 0';
    } else {
      $_SESSION['searchArchivalDiscsSql']['projectId'] .= "projectId = $projectId";
    }
  }
}

// selector
if ( isset($selectorId) ) {
  if ( empty($selectorId) ) {
    unset($_SESSION['searchArchivalDiscs']['selectorId']);
    unset($_SESSION['searchArchivalDiscsSql']['selectorId']);
  } else {
    $_SESSION['searchArchivalDiscs']['selectorId'] = $selectorId;
    $_SESSION['searchArchivalDiscsSql']['selectorId'] = ' AND ';
    if ($selectorId == 'any') {
      $_SESSION['searchArchivalDiscsSql']['selectorId'] .= 'selectorId != 0';
    } elseif ($selectorId == 'none') {
      $_SESSION['searchArchivalDiscsSql']['selectorId'] .= 'selectorId = 0';
    } else {
      $_SESSION['searchArchivalDiscsSql']['selectorId'] .= "selectorId = $selectorId";
    }
  }
}

// requestor
if ( isset($requestorId) ) {
  if ( empty($requestorId) ) {
    unset($_SESSION['searchArchivalDiscs']['requestorId']);
    unset($_SESSION['searchArchivalDiscsSql']['requestorId']);
  } else {
    $_SESSION['searchArchivalDiscs']['requestorId'] = $requestorId;
    $_SESSION['searchArchivalDiscsSql']['requestorId'] = ' AND ';
    if ($requestorId == 'any') {
      $_SESSION['searchArchivalDiscsSql']['requestorId'] .= 'requestorId != 0';
    } elseif ($requestorId == 'none') {
      $_SESSION['searchArchivalDiscsSql']['requestorId'] .= 'requestorId = 0';
    } else {
      $_SESSION['searchArchivalDiscsSql']['requestorId'] .= "requestorId = $requestorId";
    }
  }
}

// page image creator
if ( isset($pageImagesRespId) ) {
  if ( empty($pageImagesRespId) ) {
    unset($_SESSION['searchArchivalDiscs']['pageImagesRespId']);
    unset($_SESSION['searchArchivalDiscsSql']['pageImagesRespId']);
  } else {
    $_SESSION['searchArchivalDiscs']['pageImagesRespId'] = $pageImagesRespId;
    $_SESSION['searchArchivalDiscsSql']['pageImagesRespId'] = ' AND ';
    if ($pageImagesRespId == 'any') {
      $_SESSION['searchArchivalDiscsSql']['pageImagesRespId'] .= 'pageImagesRespId != 0';
    } elseif ($pageImagesRespId == 'none') {
      $_SESSION['searchArchivalDiscsSql']['pageImagesRespId'] .= 'pageImagesRespId = 0';
    } else {
      $_SESSION['searchArchivalDiscsSql']['pageImagesRespId'] .= "pageImagesRespId = $pageImagesRespId";
    }
  }
}

// redirect to search form, if immediate search was requested
if ($searchNow) {
  header('Location: search.php');
  exit;
}


//---------------------------
// display form for this page
//---------------------------
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="GET" action="search4.php">
<table cellpadding="4">

<tr>
<td colspan="4"><!--<strong>1</strong> -->Indicate which columns to display in the output.</td>
</tr>

<?php
if (isset($_SESSION['searchArchivalDiscsOutput']['useSearchColumns'])) {
  if ($_SESSION['searchArchivalDiscsOutput']['useSearchColumns']) {
    $checked = ' checked';  $checked2 = '';
  } else {
    $checked = '';  $checked2 = ' checked';
  }
} else {
  $checked = ' checked';  $checked2 = '';
}
?>
<tr>
<td width="15">&nbsp;</td>
<td class="label">Search-related columns:</td>
<td colspan="2">
<input type="radio" name="useSearchColumns" value="1"<?=$checked?>>
Display columns used in search criteria, in addition to those specified below <br>
<input type="radio" name="useSearchColumns" value=""<?=$checked2?>>
Only display the columns specified below
</td>
</tr>

<?php
if (isset($_SESSION['searchArchivalDiscsOutput'])) {
  if ($_SESSION['searchArchivalDiscsOutput']['volumeId']) { $volumeIdSelected = ' selected'; }
  if ($_SESSION['searchArchivalDiscsOutput']['media']) { $mediaSelected = ' selected'; }
  if ($_SESSION['searchArchivalDiscsOutput']['format']) { $formatSelected = ' selected'; }
  if ($_SESSION['searchArchivalDiscsOutput']['copies']) { $copiesSelected = ' selected'; }
  if ($_SESSION['searchArchivalDiscsOutput']['projectDir']) { $projectDirSelected = ' selected'; }
  if ($_SESSION['searchArchivalDiscsOutput']['projectLabel']) { $projectLabelSelected = ' selected'; }
  if ($_SESSION['searchArchivalDiscsOutput']['dateBurned']) { $dateBurnedSelected = ' selected'; }
  if ($_SESSION['searchArchivalDiscsOutput']['dateExpires']) { $dateExpiresSelected = ' selected'; }
  if ($_SESSION['searchArchivalDiscsOutput']['fileCount']) { $fileCountSelected = ' selected'; }
  if ($_SESSION['searchArchivalDiscsOutput']['editlistFile']) { $editlistFileSelected = ' selected'; }
  if ($_SESSION['searchArchivalDiscsOutput']['boxId1']) { $boxId1Selected = ' selected'; }
  if ($_SESSION['searchArchivalDiscsOutput']['boxId2']) { $boxId2Selected = ' selected'; }
  if ($_SESSION['searchArchivalDiscsOutput']['isRimage']) { $isRimageSelected = ' selected'; }
} else {
  // set defaults
  $volumeIdSelected = ' selected';
  //$mediaSelected = ' selected';
  //$projectDirSelected = ' selected';
  $projectLabelSelected = ' selected';
  $dateBurnedSelected = ' selected';
  $fileCountSelected = ' selected';
  $boxId1Selected = ' selected';
  $boxId2Selected = ' selected';
}

echo <<<EOD
<tr>
<td></td>
<td class="label">Other columns:</td>
<td colspan="2"><select name="columns[]" size="10" multiple>
<option value="volumeId"$volumeIdSelected>Disc ID</option>
<option value="media"$mediaSelected>Media</option>
<option value="format"$formatSelected>Format</option>
<option value="copies"$copiesSelected>Number of copies</option>
<option value="projectDir"$projectDirSelected>Project directory</option>
<option value="projectLabel"$projectLabelSelected>Project label</option>
<option value="dateBurned"$dateBurnedSelected>Date burned</option>
<option value="dateExpires"$dateExpiresSelected>Date expires</option>
<option value="fileCount"$fileCountSelected>Number of files</option>
<option value="editlistFile"$editlistFileSelected>Editlist file</option>
<option value="boxId1"$boxId1Selected>Location 1</option>
<option value="boxId2"$boxId2Selected>Location 2</option>
<option value="isRimage"$isRimageSelected>Created with</option>
</select></td>
</tr>
EOD;
?>

<?php
if (false) {  // HIDE THIS SECTION
?>

<tr>
<td colspan="4"><strong>2</strong> Select an initial sorting order.</td>
</tr>

<tr>
<td></td>
<td class="label">Sort by:</td>
<td colspan="2"><select name="orderBy">
<?php
$selected = '';
if ($_SESSION['searchArchivalDiscsOutput']['orderBy'] == 'dlpsId') {
  $selected = ' selected';
}
echo "<option value='dlpsId'$selected>DLPS ID</option>\n";

$selected = '';
if ($_SESSION['searchArchivalDiscsOutput']['orderBy'] == 'title') {
  $selected = ' selected';
}
echo "<option value='title'$selected>Title</option>\n";

$selected = '';
if ($_SESSION['searchArchivalDiscsOutput']['orderBy'] == 'dateReceived') {
  $selected = ' selected';
}
echo "<option value='dateReceived'$selected>Date received</option>\n";
?>
</select></td>
</tr>

<?php
}  // END if (false) {
?>

<tr>
<td></td>
<td></td>
<td colspan="2">
<input type="button" value="&lt; Back" onclick="history.back();">
<input type="reset" value="Reset">
<input type="submit" value="Search &gt;">
</td>
</tr>

</table>
</form>
</body>
</html>
