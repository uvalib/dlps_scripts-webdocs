<?php

/*
  importRimageLog.php - reads a Rimage log file and writes data to table archivalDiscs
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-09-14
  Last modified: 2006-05-23

  Receives data from: setupImportRimageLog.php
  If data is not valid, redirects to: err/badInput.php
  If uploaded file is imported successfully, redirects to: followImportRimageLog.php
*/

import_request_variables('P');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

$location = 'Location: ../err/badInput.php?msg=';

if (empty($importCount)) {
    header($location . urlencode('Number of files to import is required.'));
    exit;
}

for ($i = 1; $i <= $importCount; $i++) {
  $key = "logfile$i";

  //-------------------
  // test uploaded file
  //-------------------

  if ( is_uploaded_file($_FILES[$key]['tmp_name']) ) {
    $size = $_FILES[$key]['size'];
    if ($size > 0) {
      // proceed
    } else {
      $_SESSION['importBad'][$key] = "Log file $i is empty (0 bytes)";
      continue;
    }
  } else {
    $_SESSION['importBad'][$key] = "Log file $i is not accessible as an uploaded file";
    continue;
  }


  //-----------------------
  // determine project info
  //-----------------------

  // determine project label
  if ($_POST["useProjectInfo_$i"] == 'other') {
    if ($_POST["projectLabel_$i"]) {
      $projectLabel = $_POST["projectLabel_$i"];
    } else {
      $projectLabel = '';
    }
  } else {
    if ($projectLabelMain) {
      $projectLabel = $projectLabelMain;
    } else {
      $projectLabel = '';
    }
  }

  // determine location 1
  if ($_POST["useProjectInfo_$i"] == 'other') {
    if ($_POST["boxId1_$i"]) {
      $boxId1 = $_POST["boxId1_$i"];
    } else {
      $boxId1 = '0';
    }
  } else {
    if ($boxId1Main) {
      $boxId1 = $boxId1Main;
    } else {
      $boxId1 = '0';
    }
  }

  // determine location 2
  if ($_POST["useProjectInfo_$i"] == 'other') {
    if ($_POST["boxId2_$i"]) {
      $boxId2 = $_POST["boxId2_$i"];
    } else {
      $boxId2 = '0';
    }
  } else {
    if ($boxId2Main) {
      $boxId2 = $boxId2Main;
    } else {
      $boxId2 = '0';
    }
  }


  //-------------------
  // read uploaded file
  //-------------------

  // read file into an array
  $lines = file($_FILES[$key]['tmp_name']);

  if (!$lines) {
    $_SESSION['importBad'][$key] = "Cannot open log file $i";
    continue;
  }


  //--------------------
  // parse uploaded file
  //--------------------

  $fileList = '';
  foreach ($lines as $line) {
    $line = trim($line);
    if ( preg_match('/^Project\s?=\s?(.+)/', $line, $matches) ) {
      $projectDir = $matches[1];
    }

    if ( preg_match('/^Date\s?=\s?(.+)/', $line, $matches) ) {
      $dateBurned = formatDateISO($matches[1]);
    }

    if ( preg_match('/^Expires\s?=\s?(.+)/', $line, $matches) ) {
      $dateExpires = formatDateISO($matches[1]);
    }

    if ( preg_match('/^Format\s?=\s?(.+)/', $line, $matches) ) {
      $format = $matches[1];
    }

    if ( preg_match('/^NumberOfFiles\s?=\s?(.+)/', $line, $matches) ) {
      $fileCount = $matches[1];
    }

    if ( preg_match('/^copies\s?=\s?(.+)/', $line, $matches) ) {
      $copies = $matches[1];
    }

    if ( preg_match('/^file\s?=\s?(.+)/', $line, $matches) ) {
      $editlistFile = $matches[1];
    }

    if ( preg_match('/^media\s?=\s?(.+)/', $line, $matches) ) {
      $media = $matches[1];
    }

    if ( preg_match('/^volume\s?=\s?(.+)/', $line, $matches) ) {
      $volumeId = $matches[1];
    }

    if ( preg_match('/^\\\\/', $line, $matches) ) {
      $fileList .= mysql_escape_string($line) . "\n";
    }
  }


  //---------------------------------
  // validate data from uploaded file
  //---------------------------------

  if (empty($volumeId)) {
    $_SESSION['importBad'][$key] = "Cannot import log file $i: Volume ID is required";
    continue;
  }

  if (empty($fileList)) {
    $_SESSION['importBad'][$key] = "Cannot import log file $i: List of files is required";
    continue;
  }


  //----------------------------------
  // prep data for writing to database
  //----------------------------------

  $connection = connect();

  $volumeId = clean2($volumeId, $connection, $volumeIdMaxLength);
  $media = clean2($media, $connection, $mediaMaxLength);
  $format = clean2($format, $connection, $formatMaxLength);
  $projectDir = clean2($projectDir, $connection, $projectDirMaxLength);
  $projectLabel = clean2($projectLabel, $connection, $projectLabelMaxLength);
  $editlistFile = clean2($editlistFile, $connection, $editlistFileMaxLength);


  //-----------------------
  // write data to database
  //-----------------------

  // test whether this volume ID already exists

  /* Of course, since volumeId is the primary key, MySQL will not allow
  inserting a new record with an existing volumeId. But uploading a file
  more than once is the most likely reason an insert would fail, so we
  handle it specially and provide a friendlier status message. */

  $sql = "SELECT volumeId FROM archivalDiscs WHERE volumeId = '$volumeId'";
  $result = query($sql, $connection);
  if ( mysql_num_rows($result) >= 1 ) {
    $_SESSION['importBad'][$key] = "Cannot import log file $i: Volume ID '$volumeId' already exists";
    continue;
  }

  // test permissions
  testPerm('discInsert');

  $sql = "INSERT INTO archivalDiscs SET";

  if (empty($volumeId)) {
    // this should never occur due to prior tests; this is a last-ditch
    // check that will cause the insert to fail (since volumeId cannot be null)
    $value = "NULL";
  } else {
    $value = "'$volumeId'";
  }
  $sql .= " volumeId = $value";

  if (!empty($media)) { $sql .= ", media = '$media'"; }
  if (!empty($format)) { $sql .= ", format = '$format'"; }
  if (!empty($copies)) { $sql .= ", copies = $copies"; }
  if (!empty($projectDir)) { $sql .= ", projectDir = '$projectDir'"; }
  if (!empty($projectLabel)) { $sql .= ", projectLabel = '$projectLabel'"; }
  if (!empty($dateBurned)) { $sql .= ", dateBurned = '$dateBurned'"; }
  if (!empty($dateExpires)) { $sql .= ", dateExpires = '$dateExpires'"; }
  if (!empty($fileCount)) { $sql .= ", fileCount = $fileCount"; }
  if (!empty($editlistFile)) { $sql .= ", editlistFile = '$editlistFile'"; }
  if (!empty($fileList)) { $sql .= ", fileList = '$fileList'"; }
  $sql .= ", boxId1 = $boxId1";
  $sql .= ", boxId2 = $boxId2";
  $sql .= ", isRimage = 1";

  if ( mysql_query($sql, $connection) ) {
    $_SESSION['importGood'][$key] = $volumeId;
  } else {
    $_SESSION['importBad'][$key] = "Cannot import log file $i: " . mysql_error($connection);
  }
}  // end for

// redirect
header("Location: followImportRimageLog.php?importCount=$importCount");
?>