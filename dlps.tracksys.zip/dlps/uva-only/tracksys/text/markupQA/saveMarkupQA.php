<?php

/*
  saveMarkupQA.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-11-29
  Last modified: 2006-03-30

  Saves changes to database for markup QA workflow steps.

  Receives data from: confirmMarkupQA.php
  Redirects to: workflowMarkupQA.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to database
$connection = connect();

// test permissions
testPerm('textMarkupQAUpdate');

// get all DLPS IDs from the posted form
$ids = array();
foreach ($_POST as $name => $value) {
  if ( preg_match('/(fixUnknownChars|addRevDesc|fixDivStructures|updateNotes|runCommandLinePrograms|runWebPrograms|spellcheck|copyToDoneDir)_(.+)/', $name, $refs) ) {
    $ids[] = $refs[2];
  }
}

// for each ID, update values as needed
$updatedIds = array();
foreach ($ids as $id) {
  $sql = "UPDATE markupQA SET";

  $updates = '';
  for ($i = 1; $i <= 8; $i++) {
    switch ($i) {
      case 1:  $columnName = 'fixUnknownChars'; break;
      case 2:  $columnName = 'addRevDesc'; break;
      case 3:  $columnName = 'fixDivStructures'; break;
      case 4:  $columnName = 'updateNotes'; break;
      case 5:  $columnName = 'runCommandLinePrograms'; break;
      case 6:  $columnName = 'runWebPrograms'; break;
      case 7:  $columnName = 'spellcheck'; break;
      case 8: $columnName = 'copyToDoneDir'; break;
    }

    if (!empty($_POST[$columnName . '_' . $id])) {
      $value = $_POST[$columnName . '_' . $id];
      if ($value == 'true') {
        $updates .= " $columnName = 1,";
      } else {
        $updates .= " $columnName = 0,";
      }
    }
  }

  if (empty($updates)) {
    // no updates for this ID; continue with next ID
    continue;
  }

  $updates = preg_replace('/,$/', '', $updates);  // strip final comma

  $sql .= "$updates WHERE dlpsId = '$id'";

  if ( mysql_query($sql, $connection) ) {
    if (mysql_affected_rows() == 1) {
      $updatedIds[$id] = $id;
    }
  } else {
    die($dbErrorPreface . "Unable to update record '$id' in table markupQA: " . mysql_error($connection) . "<br><br>$sql");
  }
}

// redirect, indicating success
$ids = '';
foreach ($updatedIds as $id) {
  $ids .= $id . '|';
}
$ids = preg_replace('/\|$/', '', $ids);  // strip final |
header("Location: workflowMarkupQA.php?status=updated&ids=$ids");
?>