<?php

/*
  confirmMarkupQA.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-11-29
  Last modified: 2006-03-30

  Displays changes proposed for text items in the context of the
  markup QA workflow. Allows user to commit changes to database, or
  cancel.

  Receives data from: workflowMarkupQA.php
  Posts data to: saveMarkupQA.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'Markup QA Workflow - Confirm Changes';

// connect to database
$connection = connect();

// test permissions
testPerm('textMarkupQAUpdate');

// get all DLPS IDs from the posted form
$ids = array();
foreach ($_POST as $name => $value) {
  if ( ereg("dlpsId_(.+)", $name, $refs) ) {
    $ids[] = $refs[1];
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<p>Do you want to make the following changes?</p>
<form name="form" method="POST" action="saveMarkupQA.php">
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>DLPS&nbsp;ID</td>
<td>Title</td>
<td align='center'>Fix unknown characters</td>
<td align='center'>Add revision history</td>
<td align='center'>Fix div structure</td>
<td align='center'>Update notes</td>
<td align='center'>Run command-line programs</td>
<td align='center'>Run web-based programs</td>
<td align='center'>Check spelling</td>
<td align='center'>Copy to 69processed</td>
</tr>

<?php
$colspan = 10;  // total number of columns

// for each ID, query database to determine whether the record actually requires updating
$changes = array();
foreach ($ids as $id) {
  $sql = "SELECT textItems.title, textItems.volumeNumber, markupQA.*
          FROM textItems LEFT JOIN markupQA USING (dlpsId)
          WHERE markupQA.dlpsId = '$id'";
  $result = query($sql, $connection);
  if ( mysql_num_rows($result) == 1 ) {
    $row = mysql_fetch_array($result);

    for ($i = 1; $i <= 8; $i++) {
      switch ($i) {
        case 1:  $columnName = 'fixUnknownChars'; break;
        case 2:  $columnName = 'addRevDesc'; break;
        case 3:  $columnName = 'fixDivStructures'; break;
        case 4:  $columnName = 'updateNotes'; break;
        case 5:  $columnName = 'runCommandLinePrograms'; break;
        case 6:  $columnName = 'runWebPrograms'; break;
        case 7:  $columnName = 'spellcheck'; break;
        case 8:  $columnName = 'copyToDoneDir'; break;
      }

      if ( (!empty($_POST[$columnName . '_' . $id])) && ($row[$columnName] == 0) ) {
        // form = true, database = false
        $changes[$id] .= "$columnName=1|";
      }
      if ( (empty($_POST[$columnName . '_' . $id])) && ($row[$columnName] == 1) ) {
        // form = false, database = true
        $changes[$id] .= "$columnName=0|";
      }
    }

    if (!empty($changes[$id])) {
      $changes[$id] = preg_replace('/\|$/', '', $changes[$id]);
      $c++;
      $class = getRowClass($c);
      $title = formatTitle($row['title'], $row['volumeNumber']);
      echo "<tr$class><td>$id</td><td>$title</td>";
      for ($i = 1; $i <= 8; $i++) {
        switch ($i) {
          case 1:  $columnName = 'fixUnknownChars'; break;
          case 2:  $columnName = 'addRevDesc'; break;
          case 3:  $columnName = 'fixDivStructures'; break;
          case 4:  $columnName = 'updateNotes'; break;
          case 5:  $columnName = 'runCommandLinePrograms'; break;
          case 6:  $columnName = 'runWebPrograms'; break;
          case 7:  $columnName = 'spellcheck'; break;
          case 8:  $columnName = 'copyToDoneDir'; break;
        }

        if ( preg_match("/$columnName=(0|1)/", $changes[$id], $refs) ) {
          if ($refs[1] == '1') {
	    $checked = ' checked';
	    $tf = 'true';
	  } else {
	    $checked = '';
	    $tf = 'false';
	  }
	  // checkboxes are for display only; value is passed via hidden textbox
          echo "<td align='center'><input type='checkbox'$checked disabled>
                <input type='hidden' name='{$columnName}_$id' value='$tf'></td>";
        } else {
          echo "<td>&nbsp;</td>";
        }
      }
      echo "</tr>\n";
    }
  }
}

if (empty($changes)) {
  echo "<tr><td colspan='$colspan'>[No changes indicated]</td></tr>\n";
}

echo "</table>\n";

if (empty($changes)) {
  echo "<p><input type='button' value=' Back ' onclick='history.back();'></p>\n";
} else {
  echo "<p><input type='submit' name='update' value='Update'>
        <input type='button' name='cancel' value='Cancel' onclick='history.back();'></p>\n";
}
?>
</form>
</body>
</html>
