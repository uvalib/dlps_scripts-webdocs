<?php

/*
  search0.php - preliminary page of Search Assistant - clears saved search criteria
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-09-30
  Last modified: 2006-06-28

  Receives data from: Not applicable
  Redirects to: search1.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

unset($_SESSION['searchText']);
unset($_SESSION['searchTextSql']);

// reset output options to defaults
setSearchTextOutputDefaults();

// redirect to first page of search form
header('Location: search1.php');
?>