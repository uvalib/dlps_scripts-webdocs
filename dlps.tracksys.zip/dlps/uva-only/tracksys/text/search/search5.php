<?php

/*
  search5.php - fifth page of Search Assistant - misc criteria
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-09-13
  Last modified: 2006-09-01

  Receives data from: search4.php
  Submits data to: search6.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'Search - Other Criteria';
$location = 'Location: ../../err/badInput.php?msg=';

// connect to db
$connection = connect();

//-------------------------------------
// process form data from previous page
//-------------------------------------

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// priority
if ( isset($priority) ) {
  if ($priority == '1' or $priority == '0' or $priority == '-1') {
    $_SESSION['searchText']['priority'] = $priority;
    $_SESSION['searchTextSql']['priority'] = " AND priority = $priority";
  } else {
    unset($_SESSION['searchText']['priority']);
    unset($_SESSION['searchTextSql']['priority']);
  }
}

// date received
if ( isset($dateReceived) ) {
  if ($dateReceived == 'preset') {
    $_SESSION['searchText']['dateReceived'] = $dateReceived;

    // test drop-down selection
    if ( empty($dateReceivedPreset) ) {
      header($location
        . urlencode("For 'Date received', 'Preset range' was chosen, but no date option was selected."));
      exit;
    }
    $_SESSION['searchText']['dateReceivedPreset'] = $dateReceivedPreset;

    // test year
    if ( empty($dateReceivedPresetYear) ) {
      $dateReceivedPresetYear = getCurrentYear($dateReceivedPreset);
    } else {
      if ( preg_match('/^\d{4}$/', $dateReceivedPresetYear) ) {
	// 4-digit year
      } elseif ( preg_match('/^(\d\d)\s*$/', $dateReceivedPresetYear, $matches) ) {
	$dateReceivedPresetYear = '20' . $matches[1];
      } else {
	header($location . urlencode("For 'Date received', 'Preset range' was chosen"
	  . " but '$dateReceivedPresetYear' is not a 2-digit or 4-digit year."));
	exit;
      }
    }
    $_SESSION['searchText']['dateReceivedPresetYear'] = $dateReceivedPresetYear;

    switch($dateReceivedPreset) {
      case 'fiscal year':
        // for example, for fiscal year 2006: 2005-07-01 thru 2006-06-30
        $dateReceivedFrom = $dateReceivedPresetYear - 1 . '-07-01';
        $dateReceivedTo = $dateReceivedPresetYear . '-06-30';
        break;
      case 'fiscal Q1':
        // for example, for fiscal year 2006: 2005-07-01 thru 2005-09-30
        $dateReceivedFrom = $dateReceivedPresetYear - 1 . '-07-01';
        $dateReceivedTo = $dateReceivedPresetYear -1 . '-09-30';
        break;
      case 'fiscal Q2':
        // for example, for fiscal year 2006: 2005-10-01 thru 2005-12-31
        $dateReceivedFrom = $dateReceivedPresetYear - 1 . '-10-01';
        $dateReceivedTo = $dateReceivedPresetYear -1 . '-12-31';
        break;
      case 'fiscal Q3':
        // for example, for fiscal year 2006: 2006-01-01 thru 2006-03-31
        $dateReceivedFrom = $dateReceivedPresetYear . '-01-01';
        $dateReceivedTo = $dateReceivedPresetYear . '-03-31';
        break;
      case 'fiscal Q4':
        // for example, for fiscal year 2006: 2006-04-01 thru 2006-06-30
        $dateReceivedFrom = $dateReceivedPresetYear . '-04-01';
        $dateReceivedTo = $dateReceivedPresetYear . '-06-30';
        break;
      case 'calendar year':
        $dateReceivedFrom = $dateReceivedPresetYear . '-01-01';
        $dateReceivedTo = $dateReceivedPresetYear . '-12-31';
        break;
      case 'calendar Q1':
        $dateReceivedFrom = $dateReceivedPresetYear . '-01-01';
        $dateReceivedTo = $dateReceivedPresetYear . '-03-31';
        break;
      case 'calendar Q2':
        $dateReceivedFrom = $dateReceivedPresetYear . '-04-01';
        $dateReceivedTo = $dateReceivedPresetYear . '-06-30';
        break;
      case 'calendar Q3':
        $dateReceivedFrom = $dateReceivedPresetYear . '-07-01';
        $dateReceivedTo = $dateReceivedPresetYear . '-09-30';
        break;
      case 'calendar Q4':
        $dateReceivedFrom = $dateReceivedPresetYear . '-10-01';
        $dateReceivedTo = $dateReceivedPresetYear . '-12-31';
        break;
    }

    $_SESSION['searchText']['dateReceivedFrom'] = $dateReceivedFrom;
    $_SESSION['searchText']['dateReceivedTo'] = $dateReceivedTo;
    $_SESSION['searchTextSql']['dateReceived'] = " AND dateReceived >= '$dateReceivedFrom'"
      . " AND dateReceived <= '$dateReceivedTo'";
    
  } elseif ($dateReceived == 'custom') {

    $_SESSION['searchText']['dateReceived'] = $dateReceived;
    unset($_SESSION['searchText']['dateReceivedPreset']);
    unset($_SESSION['searchText']['dateReceivedPresetYear']);
    unset($_SESSION['searchTextSql']['dateReceived']);

    if (empty($dateReceivedFrom) and empty($dateReceivedTo)) {
      header($location . urlencode("For 'Date received', 'Custom range' was chosen,"
        . "but 'from' and 'to' are both empty."));
      exit;
    }

    if ( empty($dateReceivedFrom) ) {
      unset($_SESSION['searchText']['dateReceivedFrom']);
    } else {
      $dateReceivedFromISO = formatDateISO($dateReceivedFrom);
      if ( empty($dateReceivedFromISO) ) {
	header($location . urlencode("For 'Date received', value '$dateReceivedFrom' is not a valid date."));
	exit;
      } else {
	$dateReceivedFrom = $dateReceivedFromISO;
      }
    }

    if ( empty($dateReceivedTo) ) {
      unset($_SESSION['searchText']['dateReceivedTo']);
    } else {
      $dateReceivedToISO = formatDateISO($dateReceivedTo);
      if ( empty($dateReceivedToISO) ) {
	header($location . urlencode("For 'Date received', value '$dateReceivedTo' is not a valid date."));
	exit;
      } else {
	$dateReceivedTo = $dateReceivedToISO;
      }
    }

    if (!empty($dateReceivedFrom)) {
      $_SESSION['searchText']['dateReceivedFrom'] = $dateReceivedFrom;
      $_SESSION['searchTextSql']['dateReceived'] .= " AND dateReceived >= '$dateReceivedFrom'";
    }
    if (!empty($dateReceivedTo)) {
      $_SESSION['searchText']['dateReceivedTo'] = $dateReceivedTo;
      $_SESSION['searchTextSql']['dateReceived'] .= " AND dateReceived <= '$dateReceivedTo'";
    }
  } else {
    unset($_SESSION['searchText']['dateReceived']);
    unset($_SESSION['searchText']['dateReceivedPreset']);
    unset($_SESSION['searchText']['dateReceivedPresetYear']);
    unset($_SESSION['searchText']['dateReceivedFrom']);
    unset($_SESSION['searchText']['dateReceivedTo']);
    unset($_SESSION['searchTextSql']['dateReceived']);
  }
}

// date finished
if ( isset($dateFinished) ) {
  if ($dateFinished == 'preset') {
    $_SESSION['searchText']['dateFinished'] = $dateFinished;

    // test drop-down selection
    if ( empty($dateFinishedPreset) ) {
      header($location
	     . urlencode("For 'Date finished', 'Preset range' was chosen, but no date option was selected."));
      exit;
    }
    $_SESSION['searchText']['dateFinishedPreset'] = $dateFinishedPreset;

    // test year
    if ( empty($dateFinishedPresetYear) ) {
      $dateFinishedPresetYear = getCurrentYear($dateFinishedPreset);
    } else {
      if ( preg_match('/^\d{4}$/', $dateFinishedPresetYear) ) {
	// 4-digit year
      } elseif ( preg_match('/^(\d\d)\s*$/', $dateFinishedPresetYear, $matches) ) {
	$dateFinishedPresetYear = '20' . $matches[1];
      } else {
	header($location . urlencode("For 'Date finished', 'Preset range' was chosen"
          . "but '$dateFinishedPresetYear' is not a 2-digit or 4-digit year."));
	exit;
      }
    }
    $_SESSION['searchText']['dateFinishedPresetYear'] = $dateFinishedPresetYear;

    switch($dateFinishedPreset) {
      case 'fiscal year':
        // for example, for fiscal year 2006: 2005-07-01 thru 2006-06-30
        $dateFinishedFrom = $dateFinishedPresetYear - 1 . '-07-01';
        $dateFinishedTo = $dateFinishedPresetYear . '-06-30';
        break;
      case 'fiscal Q1':
        // for example, for fiscal year 2006: 2005-07-01 thru 2005-09-30
        $dateFinishedFrom = $dateFinishedPresetYear - 1 . '-07-01';
        $dateFinishedTo = $dateFinishedPresetYear -1 . '-09-30';
        break;
      case 'fiscal Q2':
        // for example, for fiscal year 2006: 2005-10-01 thru 2005-12-31
        $dateFinishedFrom = $dateFinishedPresetYear - 1 . '-10-01';
        $dateFinishedTo = $dateFinishedPresetYear -1 . '-12-31';
        break;
      case 'fiscal Q3':
        // for example, for fiscal year 2006: 2006-01-01 thru 2006-03-31
        $dateFinishedFrom = $dateFinishedPresetYear . '-01-01';
        $dateFinishedTo = $dateFinishedPresetYear . '-03-31';
        break;
      case 'fiscal Q4':
        // for example, for fiscal year 2006: 2006-04-01 thru 2006-06-30
        $dateFinishedFrom = $dateFinishedPresetYear . '-04-01';
        $dateFinishedTo = $dateFinishedPresetYear . '-06-30';
        break;
      case 'calendar year':
        $dateFinishedFrom = $dateFinishedPresetYear . '-01-01';
        $dateFinishedTo = $dateFinishedPresetYear . '-12-31';
        break;
      case 'calendar Q1':
        $dateFinishedFrom = $dateFinishedPresetYear . '-01-01';
        $dateFinishedTo = $dateFinishedPresetYear . '-03-31';
        break;
      case 'calendar Q2':
        $dateFinishedFrom = $dateFinishedPresetYear . '-04-01';
        $dateFinishedTo = $dateFinishedPresetYear . '-06-30';
        break;
      case 'calendar Q3':
        $dateFinishedFrom = $dateFinishedPresetYear . '-07-01';
        $dateFinishedTo = $dateFinishedPresetYear . '-09-30';
        break;
      case 'calendar Q4':
        $dateFinishedFrom = $dateFinishedPresetYear . '-10-01';
        $dateFinishedTo = $dateFinishedPresetYear . '-12-31';
        break;
    }

    $_SESSION['searchText']['dateFinishedFrom'] = $dateFinishedFrom;
    $_SESSION['searchText']['dateFinishedTo'] = $dateFinishedTo;
    $_SESSION['searchTextSql']['dateFinished'] = " AND dateFinished >= '$dateFinishedFrom'"
      . " AND dateFinished <= '$dateFinishedTo'";

  } elseif ($dateFinished == 'custom') {

    $_SESSION['searchText']['dateFinished'] = $dateFinished;
    unset($_SESSION['searchText']['dateFinishedPreset']);
    unset($_SESSION['searchText']['dateFinishedPresetYear']);
    unset($_SESSION['searchTextSql']['dateFinished']);

    if (empty($dateFinishedFrom) and empty($dateFinishedTo)) {
      header($location . urlencode("For 'Date finished', 'Custom range' was chosen,"
        . "but 'from' and 'to' are both empty."));
      exit;
    }

    if ( empty($dateFinishedFrom) ) {
      unset($_SESSION['searchText']['dateFinishedFrom']);
    } else {
      $dateFinishedFromISO = formatDateISO($dateFinishedFrom);
      if ( empty($dateFinishedFromISO) ) {
	header($location . urlencode("For 'Date finished', value '$dateFinishedFrom' is not a valid date."));
	exit;
      } else {
	$dateFinishedFrom = $dateFinishedFromISO;
      }
    }

    if ( empty($dateFinishedTo) ) {
      unset($_SESSION['searchText']['dateFinishedTo']);
    } else {
      $dateFinishedToISO = formatDateISO($dateFinishedTo);
      if ( empty($dateFinishedToISO) ) {
	header($location . urlencode("For 'Date finished', value '$dateFinishedTo' is not a valid date."));
	exit;
      } else {
	$dateFinishedTo = $dateFinishedToISO;
      }
    }

    if (!empty($dateFinishedFrom)) {
      $_SESSION['searchText']['dateFinishedFrom'] = $dateFinishedFrom;
      $_SESSION['searchTextSql']['dateFinished'] .= " AND dateFinished >= '$dateFinishedFrom'";
    }
    if (!empty($dateFinishedTo)) {
      $_SESSION['searchText']['dateFinishedTo'] = $dateFinishedTo;
      $_SESSION['searchTextSql']['dateFinished'] .= " AND dateFinished <= '$dateFinishedTo'";
    }
  } else {
    unset($_SESSION['searchText']['dateFinished']);
    unset($_SESSION['searchText']['dateFinishedPreset']);
    unset($_SESSION['searchText']['dateFinishedPresetYear']);
    unset($_SESSION['searchText']['dateFinishedFrom']);
    unset($_SESSION['searchText']['dateFinishedTo']);
    unset($_SESSION['searchTextSql']['dateFinished']);
  }
}

// redirect to search form, if immediate search was requested
if ($searchNow) {
  header('Location: search.php');
  exit;
}

// redirect to another search page, if requested
if ($jumpTo) {
  $url = getJumpToUrl($jumpTo);
  if ($url != 'search5.php') {
    header("Location: $url");
    exit;
  }
}


//---------------------------
// display form for this page
//---------------------------
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="GET" action="search6.php">
<table cellpadding="4">

<tr>
<td class="label">Item type:</td>
<td><select name="itemType">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['itemType'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>Production</option>\n";

$selected = '';
if ($_SESSION['searchText']['itemType'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Migration</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Genre:</td>
<td><select name="genre">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['genre'] == strval(GENRE_PROSE_NONFICTION)) { $selected = ' selected'; }
echo "<option value='" . GENRE_PROSE_NONFICTION . "'$selected>" . getGenre(GENRE_PROSE_NONFICTION) . "</option>\n";

$selected = '';
if ($_SESSION['searchText']['genre'] == strval(GENRE_PROSE_FICTION)) { $selected = ' selected'; }
echo "<option value='" . GENRE_PROSE_FICTION . "'$selected>" . getGenre(GENRE_PROSE_FICTION) . "</option>\n";

$selected = '';
if ($_SESSION['searchText']['genre'] == strval(GENRE_POETRY)) { $selected = ' selected'; }
echo "<option value='" . GENRE_POETRY . "'$selected>" . getGenre(GENRE_POETRY) . "</option>\n";

$selected = '';
if ($_SESSION['searchText']['genre'] == strval(GENRE_DRAMA)) { $selected = ' selected'; }
echo "<option value='" . GENRE_DRAMA . "'$selected>" . getGenre(GENRE_DRAMA) . "</option>\n";

$selected = '';
if ($_SESSION['searchText']['genre'] == strval(GENRE_DICTIONARY)) { $selected = ' selected'; }
echo "<option value='" . GENRE_DICTIONARY . "'$selected>" . getGenre(GENRE_DICTIONARY) . "</option>\n";

$selected = '';
if ($_SESSION['searchText']['genre'] == strval(GENRE_ENCYCLOPEDIA)) { $selected = ' selected'; }
echo "<option value='" . GENRE_ENCYCLOPEDIA . "'$selected>" . getGenre(GENRE_ENCYCLOPEDIA) . "</option>\n";

$selected = '';
if ($_SESSION['searchText']['genre'] == strval(GENRE_MANUSCRIPT)) { $selected = ' selected'; }
echo "<option value='" . GENRE_MANUSCRIPT . "'$selected>" . getGenre(GENRE_MANUSCRIPT) . "</option>\n";

$selected = '';
if ($_SESSION['searchText']['genre'] == strval(GENRE_NEWSPAPER)) { $selected = ' selected'; }
echo "<option value='" . GENRE_NEWSPAPER . "'$selected>" . getGenre(GENRE_NEWSPAPER) . "</option>\n";

$selected = '';
if ($_SESSION['searchText']['genre'] == strval(GENRE_SHEET_MUSIC)) { $selected = ' selected'; }
echo "<option value='" . GENRE_SHEET_MUSIC . "'$selected>" . getGenre(GENRE_SHEET_MUSIC) . "</option>\n";

$selected = '';
if ($_SESSION['searchText']['genre'] == strval(GENRE_MAP)) { $selected = ' selected'; }
echo "<option value='" . GENRE_MAP . "'$selected>" . getGenre(GENRE_MAP) . "</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Year of publication:</td>
<td><input type="text" name="publicationYearFrom" size="5" value="<?=$_SESSION['searchText']['publicationYearFrom']?>"> to 
<input type="text" name="publicationYearTo" size="5" value="<?=$_SESSION['searchText']['publicationYearTo']?>"></td>
</tr>

<tr>
<td class="label">Access:</td>
<td><select name="access">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['access'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>public</option>\n";

$selected = '';
if ($_SESSION['searchText']['access'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>VIVA only</option>\n";

$selected = '';
if ($_SESSION['searchText']['access'] == '2') { $selected = ' selected'; }
echo "<option value='2'$selected>UVA only</option>\n";

$selected = '';
if ($_SESSION['searchText']['access'] == '3') { $selected = ' selected'; }
echo "<option value='3'$selected>restricted</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Page images:</td>
<td><select name="pageImagesType">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['pageImagesType'] == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Page images of any type</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageImagesType'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>No page images</option>\n";

echo "<option value=''>--------------------</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageImagesType'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Bitonal</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageImagesType'] == '2') { $selected = ' selected'; }
echo "<option value='2'$selected>Color</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Figure images:</td>
<td><select name="hasFigureImages">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['hasFigureImages'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Has figure images</option>\n";

$selected = '';
if ($_SESSION['searchText']['hasFigureImages'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>No figure images</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Transcription:</td>
<td><select name="transcriptionType">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['transcriptionType'] == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Transcription of any type</option>\n";

$selected = '';
if ($_SESSION['searchText']['transcriptionType'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>No transcription</option>\n";

echo "<option value=''>--------------------</option>\n";

$selected = '';
if ($_SESSION['searchText']['transcriptionType'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Vendor</option>\n";

$selected = '';
if ($_SESSION['searchText']['transcriptionType'] == '2') { $selected = ' selected'; }
echo "<option value='2'$selected>OCR</option>\n";

$selected = '';
if ($_SESSION['searchText']['transcriptionType'] == '3') { $selected = ' selected'; }
echo "<option value='3'$selected>Other</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Independent header:</td>
<td><select name="hasIndependentHeader">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['hasIndependentHeader'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Has independent header</option>\n";

$selected = '';
if ($_SESSION['searchText']['hasIndependentHeader'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>No independent header</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">Destined for repository:</td>
<td><select name="forRepo">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['forRepo'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Yes</option>\n";

$selected = '';
if ($_SESSION['searchText']['forRepo'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>No</option>\n";
?>
</select></td>
</tr>

<tr>
<td class="label">For internal use only:</td>
<td><select name="forInternalUseOnly">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['forInternalUseOnly'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Yes</option>\n";

$selected = '';
if ($_SESSION['searchText']['forInternalUseOnly'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>No</option>\n";
?>
</select></td>
</tr>

<tr>
<td></td>
<td>
<input type="button" value="&lt; Back" onclick="history.back();">
<input type="button" value="Clear" onclick="clearForm();">
<input type="button" value="Search Now" onclick="document.frm.searchNow.value='true'; document.frm.submit();">
<input type="submit" value="Next &gt;"  onclick="document.frm.searchNow.value='';">
<input type="hidden" name="searchNow">
</td>
</tr>

<tr>
<td></td>
<td>
Go to: <select name="jumpTo">
<option value=""></option>
<option value="basic">Basic Criteria</option>
<option value="groupings">Groupings</option>
<option value="responsibility">Responsibility</option>
<option value="dates">Priority and Dates</option>
<option value="">----------</option>
<option value="status">Workflow Status</option>
<option value="output">Output Options</option>
</select>
<input type="button" value="Go" onclick="document.frm.submit();">
</td>
</tr>

</table>

<br>

<p><strong>Year of publication:</strong> To use a date range with no
starting point, leave the "from" date blank. To use a date range with
no ending point, leave the "to" date blank.</p>

<p><span class="attn">Note:</span> The "Year of publication" field is
empty for some items, especially unfinished items. When using "Year of
publication" as a search criterion, search results will <em>not</em>
include items for which the year of publication is empty.</p>

</form>
</body>
</html>
