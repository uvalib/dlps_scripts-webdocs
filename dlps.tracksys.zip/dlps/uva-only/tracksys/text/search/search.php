<?php

/*
  search.php - queries database and displays search results
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-06-21
  Last modified: 2007-04-11
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to db
$connection = connect();

// test permissions
testPerm('textSelect');
if (!getPerm('textExport')) { $exportAppearance = ' disabled'; }

$siteArea = 'Text Workflow';
$pageTitle = 'Search Results';

// set output defaults if necessary
if (!isset($_SESSION['searchTextOutput'])) {
  setSearchTextOutputDefaults();
}

// get associative array representing table 'sets'
$sets = getHashSets($connection);

// get associative array representing table 'projects'
$projects = getHashProjects($connection);

// get associative array representing table 'groups'
$groups = getHashGroups($connection);

// get associative array representing table 'batches'
$batches = getHashBatches($connection);

// get associative array representing table 'selectors'
$selectors = getHashSelectors($connection);

// get associative array representing table 'requestors'
$requestors = getHashRequestors($connection);

// get associative array representing table 'pageImagesResps'
$pageImagesResps = getHashPageImagesResps($connection);

// get associative array representing table 'transcriptionResps'
$transcriptionResps = getHashTranscriptionResps($connection);


//-------------------------
// prepare SQL query string
//-------------------------

$sql = 'SELECT textItems.* FROM textItems';

if (!empty($_SESSION['searchTextSql']['bookScanning'])) {
  $sql .= ' LEFT JOIN bookScanning USING (dlpsId)';
}

if (!empty($_SESSION['searchTextSql']['migration'])) {
  $sql .= ' LEFT JOIN migration USING (dlpsId)';
  $sql .= ' LEFT JOIN bookScanning USING (dlpsId)';
}

if (!empty($_SESSION['searchTextSql']['pageBook'])) {
  $sql .= ' LEFT JOIN pageBook USING (dlpsId)';
}

if (!empty($_SESSION['searchTextSql']['teiHeader'])) {
  $sql .= ' LEFT JOIN teiHeader USING (dlpsId)';
}

if (!empty($_SESSION['searchTextSql']['postkb'])) {
  $sql .= ' LEFT JOIN postkb USING (dlpsId)';
}

if (!empty($_SESSION['searchTextSql']['markupQA'])) {
  $sql .= ' LEFT JOIN markupQA USING (dlpsId)';
}

if (!empty($_SESSION['searchTextSql']['finalization'])) {
  $sql .= ' LEFT JOIN finalization USING (dlpsId)';
}

$where = '';

// basic criteria
$where .= $_SESSION['searchTextSql']['dlpsId'];
$where .= $_SESSION['searchTextSql']['virgoId'];
$where .= $_SESSION['searchTextSql']['titleControlNumber'];
$where .= $_SESSION['searchTextSql']['title'];
$where .= $_SESSION['searchTextSql']['authorNameLast'];
$where .= $_SESSION['searchTextSql']['notes'];

// groupings
$where .= $_SESSION['searchTextSql']['setId'];
$where .= $_SESSION['searchTextSql']['projectId'];
$where .= $_SESSION['searchTextSql']['groupId'];
$where .= $_SESSION['searchTextSql']['batchId'];

// responsibility
$where .= $_SESSION['searchTextSql']['selectorId'];
$where .= $_SESSION['searchTextSql']['requestorId'];
$where .= $_SESSION['searchTextSql']['pageImagesRespId'];
$where .= $_SESSION['searchTextSql']['transcriptionRespId'];

// priority and dates
$where .= $_SESSION['searchTextSql']['priority'];
$where .= $_SESSION['searchTextSql']['dateReceived'];
$where .= $_SESSION['searchTextSql']['dateFinished'];

// misc criteria
$where .= $_SESSION['searchTextSql']['itemType'];
$where .= $_SESSION['searchTextSql']['genre'];
$where .= $_SESSION['searchTextSql']['publicationYear'];
$where .= $_SESSION['searchTextSql']['access'];
$where .= $_SESSION['searchTextSql']['pageImagesType'];
$where .= $_SESSION['searchTextSql']['hasFigureImages'];
$where .= $_SESSION['searchTextSql']['transcriptionType'];
$where .= $_SESSION['searchTextSql']['hasIndependentHeader'];
$where .= $_SESSION['searchTextSql']['forRepo'];
$where .= $_SESSION['searchTextSql']['forInternalUseOnly'];

// workflow status
$where .= $_SESSION['searchTextSql']['bookScanning'];
$where .= $_SESSION['searchTextSql']['migration'];
$where .= $_SESSION['searchTextSql']['pageBook'];
$where .= $_SESSION['searchTextSql']['teiHeader'];
$where .= $_SESSION['searchTextSql']['postkb'];
$where .= $_SESSION['searchTextSql']['markupQA'];
$where .= $_SESSION['searchTextSql']['finalization'];
$where .= $_SESSION['searchTextSql']['isFinished'];

if (!empty($where)) {
  $where = preg_replace('/^ +AND +/', '', $where);  // remove the initial ' AND'
  $sql .= ' WHERE ' . $where;
}

// sort order
if ( $_GET['orderBy'] ) {
  $orderBy = $_GET['orderBy'];
} elseif ( $_SESSION['searchTextOutput']['orderBy'] ) {
  $orderBy = $_SESSION['searchTextOutput']['orderBy'];
} else {
  $orderBy = 'dlpsId';
}
$_SESSION['searchTextOutput']['orderBy'] = $orderBy;
switch ($orderBy) {
  case 'dlpsId':
    $_SESSION['searchTextSql']['orderBy'] = ' ORDER BY dlpsId';
    break;
  case 'title':
    $_SESSION['searchTextSql']['orderBy'] = ' ORDER BY title, volumeNumber';
    break;
  case 'author':
    $_SESSION['searchTextSql']['orderBy'] = ' ORDER BY authorNameLast, authorNameFirst, dlpsId';
    break;
  default:
    //unset($_SESSION['searchTextOutput']['orderBy']);
    //unset($_SESSION['searchTextSql']['orderBy']);
    //$orderBy = '';
    $_SESSION['searchTextSql']['orderBy'] = " ORDER BY $orderBy, dlpsId";
}
$sql .= $_SESSION['searchTextSql']['orderBy'];

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
<script type="text/javascript">
function exportData() {
  document.selectForm.action="../exportTextItems.php";
  document.selectForm.submit();
}

function setCheckboxes(onOrOff) {
  for (i = 0; i < document.selectForm.elements.length; i++) {
    if (document.selectForm.elements[i].type == "checkbox") {
      document.selectForm.elements[i].checked = onOrOff;
    }
  }
}
</script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
if ($debugMode) { echo "<p>$sql</p>\n"; }

// execute query
$result = query($sql, $connection);

$num = mysql_num_rows($result);
if ($num == 1) { $plural = ''; } else { $plural = 's'; }
echo "<p>Found <b>$num</b> item$plural</p>\n";

$newSearchLink = "<p><a href='search1.php'>Adjust this search</a><br>
<a href='search7.php'>Adjust output options</a><br>
<a href='search0.php'>Start a new search</a></p>\n";
echo $newSearchLink;

if ($num >= 1) {
  echo "<form name='selectForm' method='POST'>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>&nbsp;</td>\n";

  //-----------------------
  // set up column headings
  //-----------------------

  $colspan = 1;

  if ($_SESSION['searchTextOutput']['useSearchColumns']) {
    $useSearchColumns = 1;
  } else {
    $useSearchColumns = 0;
  }

  if ( $_SESSION['searchTextOutput']['dlpsId']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['dlpsId'])) ) {
    if ($orderBy == 'dlpsId') {
      echo "<td><i>DLPS ID</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=dlpsId'>DLPS ID</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['itemType']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['itemType'])) ) {
    if ($orderBy == 'itemType') {
      echo "<td><i>Item type</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=itemType'>Item type</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['virgoId']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['virgoId'])) ) {
    if ($orderBy == 'virgoId') {
      echo "<td><i>Virgo ID</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=virgoId'>Virgo ID</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['titleControlNumber']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['titleControlNumber'])) ) {
    if ($orderBy == 'titleControlNumber') {
      echo "<td><i>Title control number</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=titleControlNumber'>Title control number</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['callNumber']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['callNumber'])) ) {
    if ($orderBy == 'callNumber') {
      echo "<td><i>Call number</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=callNumber'>Call number</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['title']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['title'])) ) {
    if ($orderBy == 'title') {
      echo "<td><i>Title</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=title'>Title</a></td>\n";
    }
    echo "<td>Volume</td>\n";
    $colspan += 2;
  }

  if ( $_SESSION['searchTextOutput']['authorNameLast']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['authorNameLast'])) ) {
    if ($orderBy == 'author') {
      echo "<td><i>Author</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=author'>Author</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['pageImagesType']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['pageImagesType'])) ) {
    if ($orderBy == 'pageImagesType') {
      echo "<td><i>Page images</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=pageImagesType'>Page images</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['pageImagesRespId']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['pageImagesRespId'])) ) {
    if ($orderBy == 'pageImagesRespId') {
      echo "<td><i>Page image creator</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=pageImagesRespId'>Page image creator</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['pageCount']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['pageCount'])) ) {
    if ($orderBy == 'pageCount') {
      echo "<td><i>Page image count</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=pageCount'>Page image count</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['hasFigureImages']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['hasFigureImages'])) ) {
    if ($orderBy == 'hasFigureImages') {
      echo "<td><i>Has figure images?</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=hasFigureImages'>Has figure images?</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['transcriptionType']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['transcriptionType'])) ) {
    if ($orderBy == 'transcriptionType') {
      echo "<td><i>Transcription</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=transcriptionType'>Transcription</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['transcriptionRespId']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['transcriptionRespId'])) ) {
    if ($orderBy == 'transcriptionRespId') {
      echo "<td><i>Transcription creator</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=transcriptionRespId'>Transcription creator</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['setId']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['setId'])) ) {
    echo "<td>Set</td>\n";
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['projectId']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['projectId'])) ) {
    echo "<td>Project</td>\n";
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['groupId']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['groupId'])) ) {
    echo "<td>Group</td>\n";
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['batchId']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['batchId'])) ) {
    echo "<td>Batch</td>\n";
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['selectorId']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['selectorId'])) ) {
    echo "<td>Selector</td>\n";
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['requestorId']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['requestorId'])) ) {
    echo "<td>Requestor</td>\n";
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['priority']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['priority'])) ) {
    if ($orderBy == 'priority') {
      echo "<td><i>Priority</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=priority'>Priority</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['genre']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['genre'])) ) {
    if ($orderBy == 'genre') {
      echo "<td><i>Genre</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=genre'>Genre</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['publicationYear']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['publicationYear'])) ) {
    if ($orderBy == 'publicationYear') {
      echo "<td><i>Year of publication</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=publicationYear'>Year of publication</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['access']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['access'])) ) {
    if ($orderBy == 'access') {
      echo "<td><i>Access</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=access'>Access</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['dateReceived']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['dateReceived'])) ) {
    if ($orderBy == 'dateReceived') {
      echo "<td><i>Date received</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=dateReceived'>Date received</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['notes']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['notes'])) ) {
    if ($orderBy == 'notes') {
      echo "<td><i>Notes</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=notes'>Notes</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['hasIndependentHeader']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['hasIndependentHeader'])) ) {
    if ($orderBy == 'hasIndependentHeader') {
      echo "<td><i>Has independent header?</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=hasIndependentHeader'>Has independent header?</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['forRepo']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['forRepo'])) ) {
    if ($orderBy == 'forRepo') {
      echo "<td><i>Destined for repository?</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=forRepo'>Destined for repository?</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['forInternalUseOnly']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['forInternalUseOnly'])) ) {
    if ($orderBy == 'forInternalUseOnly') {
      echo "<td><i>For internal use only?</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=forInternalUseOnly'>For internal use only?</a></td>\n";
    }
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['isArchived']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['isArchived'])) ) {
    echo "<td>Archived</td>";
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['isFinished']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['isFinished'])) ) {
    echo "<td>Finished</td>";
    $colspan++;
  }

  if ( $_SESSION['searchTextOutput']['dateFinished']
       or ($useSearchColumns and !empty($_SESSION['searchTextSql']['dateFinished'])) ) {
    if ($orderBy == 'dateFinished') {
      echo "<td><i>Date finished</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=dateFinished'>Date finished</a></td>\n";
    }
    $colspan++;
  }

  echo "</tr>\n";

  $c = 1;
  $class = getRowClass($c);
  $colspan--;
  echo "<tr$class>
<td style='white-space: nowrap'>
<img name='checkAll' src='../../img/check.gif' hspace='0' onclick='setCheckboxes(true);' title='Check All'>
<img name='clearAll' border='0' src='../../img/square.gif' hspace='0' onclick='setCheckboxes(false);' title='Clear All'>
</td>
<td colspan='$colspan'>&nbsp;</td>
</tr>\n";

  //----------------------
  // display query results
  //----------------------

  while ( $row = mysql_fetch_array($result) ) {
    $dlpsId = $row['dlpsId'];

    $c++;
    $class = getRowClass($c);
    echo "<tr$class>\n";
    echo "<td><input type='checkbox' name='dlpsId_$dlpsId' checked></td>\n";

    if ( $_SESSION['searchTextOutput']['dlpsId']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['dlpsId'])) ) {
      echo "<td><a href='../textItem.php?dlpsId=$dlpsId'>$dlpsId</a></td>\n";
    }

    if ( $_SESSION['searchTextOutput']['itemType']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['itemType'])) ) {
      echo "<td>" . getItemType($row['itemType']) . "</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['virgoId']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['virgoId'])) ) {
      echo "<td style='white-space: nowrap'>$row[virgoId]</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['titleControlNumber']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['titleControlNumber'])) ) {
      echo "<td style='white-space: nowrap'>$row[titleControlNumber]</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['callNumber']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['callNumber'])) ) {
      if ( strlen($row['callNumber']) <= 30 ) {
        $style = " style='white-space: nowrap'";
      } else {
        $style = '';
      }
      echo "<td$style>$row[callNumber]</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['title']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['title'])) ) {
      echo "<td>$row[title]</td>\n";
      echo "<td style='white-space: nowrap'>$row[volumeNumber]</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['authorNameLast']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['authorNameLast'])) ) {
      echo "<td>" . formatName($row['authorNameLast'], $row['authorNameFirst']) . "</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['pageImagesType']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['pageImagesType'])) ) {
      echo "<td>" . getPageImagesType($row['pageImagesType']) . "</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['pageImagesRespId']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['pageImagesRespId'])) ) {
      if ( empty($row['pageImagesRespId']) ) {
        $name = '';
      } else {
        foreach ($pageImagesResps as $id => $name) {
          if ($row['pageImagesRespId'] == $id) {
	    break;
          }
        }
      }
      echo "<td>$name</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['pageCount']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['pageCount'])) ) {
      echo "<td>$row[pageCount]</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['hasFigureImages']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['hasFigureImages'])) ) {
      if ($row['hasFigureImages'] == 1) { $temp = 'yes'; } else { $temp = 'no'; }
      echo "<td>$temp</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['transcriptionType']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['transcriptionType'])) ) {
      echo "<td>" . getTranscriptionType($row['transcriptionType']) . "</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['transcriptionRespId']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['transcriptionRespId'])) ) {
      if ( empty($row['transcriptionRespId']) ) {
        $name = '';
      } else {
        foreach ($transcriptionResps as $id => $name) {
          if ($row['transcriptionRespId'] == $id) {
	    break;
          }
        }
      }
      echo "<td>$name</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['setId']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['setId'])) ) {
      //if (!empty($_SESSION['searchText']['setId'])) {
      if ( empty($row['setId']) ) {
        $name = '';
      } else {
        foreach ($sets as $id => $name) {
          if ($row['setId'] == $id) {
	    break;
          }
        }
      }
      echo "<td>$name</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['projectId']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['projectId'])) ) {
      //if (!empty($_SESSION['searchText']['projectId'])) {
      if ( empty($row['projectId']) ) {
        $name = '';
      } else {
        foreach ($projects as $id => $name) {
          if ($row['projectId'] == $id) {
	    break;
          }
        }
      }
      echo "<td>$name</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['groupId']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['groupId'])) ) {
      //if (!empty($_SESSION['searchText']['groupId'])) {
      if ( empty($row['groupId']) ) {
        $name = '';
      } else {
        foreach ($groups as $id => $name) {
          if ($row['groupId'] == $id) {
	    break;
          }
        }
      }
      echo "<td>$name</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['batchId']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['batchId'])) ) {
      //if (!empty($_SESSION['searchText']['batchId'])) {
      if ( empty($row['batchId']) ) {
        $name = '';
      } else {
        foreach ($batches as $id => $name) {
          if ($row['batchId'] == $id) {
	    break;
          }
        }
      }
      echo "<td>$name</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['selectorId']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['selectorId'])) ) {
      if ( empty($row['selectorId']) ) {
        $name = '';
      } else {
        foreach ($selectors as $id => $name) {
          if ($row['selectorId'] == $id) {
	    break;
          }
        }
      }
      echo "<td>$name</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['requestorId']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['requestorId'])) ) {
      if ( empty($row['requestorId']) ) {
        $name = '';
      } else {
        foreach ($requestors as $id => $name) {
          if ($row['requestorId'] == $id) {
	    break;
          }
        }
      }
      echo "<td>$name</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['priority']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['priority'])) ) {
      echo "<td>" . getPriority($row['priority']) . "</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['genre']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['genre'])) ) {
      echo "<td>" . getGenre($row['genre']) . "</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['publicationYear']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['publicationYear'])) ) {
      echo "<td>$row[publicationYear]</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['access']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['access'])) ) {
      echo "<td>" . getAccess($row['access']) . "</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['dateReceived']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['dateReceived'])) ) {
      echo "<td>" . formatDateUS($row['dateReceived']) . "</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['notes']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['notes'])) ) {
      echo "<td>" . truncate($row['notes'], 200) . "</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['hasIndependentHeader']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['hasIndependentHeader'])) ) {
      if ($row['hasIndependentHeader'] == 1) { $temp = 'yes'; } else { $temp = 'no'; }
      echo "<td>$temp</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['forRepo']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['forRepo'])) ) {
      if ($row['forRepo'] == 1) { $temp = 'yes'; } else { $temp = 'no'; }
      echo "<td>$temp</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['forInternalUseOnly']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['forInternalUseOnly'])) ) {
      if ($row['forInternalUseOnly'] == 1) { $temp = 'yes'; } else { $temp = 'no'; }
      echo "<td>$temp</td>\n";
    }

    // run a query to see if files named with this DLPS ID have been burned to DVD
    if ( $_SESSION['searchTextOutput']['isArchived']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['isArchived'])) ) {
      $sql2 = "SELECT volumeId FROM archivalDiscs WHERE fileList LIKE '%$dlpsId%' ORDER BY volumeId";
      $result2 = query($sql2, $connection);
      if (mysql_num_rows($result2) >= 1) {
	$temp = '';
	while ( $row2 = mysql_fetch_array($result2) ) {
	  $temp .= "<a href='../../archivalDiscs/archivalDisc.php?volumeId=$row2[volumeId]'>$row2[volumeId]</a>, ";
	}
	$temp = preg_replace('/, $/', '', $temp);  // remove the final delimiter characters
      } else {
	$temp = 'no';
      }
      echo "<td>$temp</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['isFinished']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['isFinished'])) ) {
      if ($row['isFinished'] == 1) { $temp = 'yes'; } else { $temp = 'no'; }
      echo "<td>$temp</td>\n";
    }

    if ( $_SESSION['searchTextOutput']['dateFinished']
	 or ($useSearchColumns and !empty($_SESSION['searchTextSql']['dateFinished'])) ) {
      echo "<td>" . formatDateUS($row['dateFinished']) . "</td>\n";
    }

    echo "</tr>\n";
  }
  echo "</table>

<p> </p>
<table cellpadding='4' border='0'>
<tr>
<td class='tableSectionHeading' colspan='3'>Actions:</td>
</tr>

<tr>
<td align='right'>View checked items:</td>
<td><select name='workflow'>
<option value='bookScanning'>Book scanning workflow</option>
<option value='migration'>Migration images workflow</option>
<option value='pageBook'>Page book workflow</option>
<option value='teiHeader'>TEI header workflow</option>
<option value='postkb'>Post-keyboarding workflow</option>
<option value='markupQA'>Markup QA workflow</option>
<option value='finalization'>Finalization workflow</option>
</select>
</td>
<td valign='bottom'>
<input type='submit' value='View Workflow' onclick='return setFormAction(document.selectForm);'>
<input type='hidden' name='orderBy' value='$orderBy'>
</td>
</tr>

<tr>
<td align='right' valign='top'>Export to tab-delimited text:</td>
<td>
<input type='radio' name='exportMode' value='all' checked> All items in database <br>
<input type='radio' name='exportMode' value='checked'> Items checked on this page
</td>
<td valign='top'>
<input type='button' value='Export Data...' onclick='exportData();'$exportAppearance>
</td>
</tr>
</table>
</form>\n";
echo $newSearchLink;
}  // END if ($num >= 1)
?>
</body>
</html>
