<?php

/*
  search6.php - sixth page of Search Assistant - workflow status
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-09-27
  Last modified: 2007-04-11

  Receives data from: search5.php
  Submits data to: search7.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'Search - Workflow Status';

// connect to db
$connection = connect();

//-------------------------------------
// process form data from previous page
//-------------------------------------

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// item type
if ( isset($itemType) ) {
  if (preg_match('/^[0-1]$/', $itemType)) {
    $_SESSION['searchText']['itemType'] = $itemType;
    $_SESSION['searchTextSql']['itemType'] = " AND itemType = $itemType";
  } else {
    unset($_SESSION['searchText']['itemType']);
    unset($_SESSION['searchTextSql']['itemType']);
  }
}

// genre
if ( isset($genre) ) {
  if (preg_match('/^\d$/', $genre)) {
    $_SESSION['searchText']['genre'] = $genre;
    $_SESSION['searchTextSql']['genre'] = " AND genre = $genre";
  } else {
    unset($_SESSION['searchText']['genre']);
    unset($_SESSION['searchTextSql']['genre']);
  }
}

// year of publication
if ( isset($publicationYearFrom) or isset($publicationYearTo) ) {
  unset($_SESSION['searchTextSql']['publicationYear']);
  if ( empty($publicationYearFrom) ) {
    unset($_SESSION['searchText']['publicationYearFrom']);
  } else {
    $_SESSION['searchText']['publicationYearFrom'] = $publicationYearFrom;
    $publicationYearFrom = clean2($publicationYearFrom, $connection);
    $_SESSION['searchTextSql']['publicationYear'] .= " AND publicationYear >= '$publicationYearFrom'";
  }
  if ( empty($publicationYearTo) ) {
    unset($_SESSION['searchText']['publicationYearTo']);
  } else {
    $_SESSION['searchText']['publicationYearTo'] = $publicationYearTo;
    $publicationYearTo = clean2($publicationYearTo, $connection);
    $_SESSION['searchTextSql']['publicationYear'] .= " AND publicationYear <= '$publicationYearTo'";
  }
}

// access
if ( isset($access) ) {
  if (preg_match('/^[0-3]$/', $access)) {
    $_SESSION['searchText']['access'] = $access;
    $_SESSION['searchTextSql']['access'] = " AND access = $access";
  } else {
    unset($_SESSION['searchText']['access']);
    unset($_SESSION['searchTextSql']['access']);
  }
}

// page images
if ( isset($pageImagesType) ) {
  if ($pageImagesType == 'any') {
    $_SESSION['searchText']['pageImagesType'] = $pageImagesType;
    $_SESSION['searchTextSql']['pageImagesType'] = ' AND pageImagesType != 0';
  } elseif ($pageImagesType == '0' or $pageImagesType == '1' or $pageImagesType == '2') {
    $_SESSION['searchText']['pageImagesType'] = $pageImagesType;
    $_SESSION['searchTextSql']['pageImagesType'] = " AND pageImagesType = $pageImagesType";
  } else {
    unset($_SESSION['searchText']['pageImagesType']);
    unset($_SESSION['searchTextSql']['pageImagesType']);
  }
}

// figure images
if ( isset($hasFigureImages) ) {
  if ($hasFigureImages == '0' or $hasFigureImages == '1') {
    $_SESSION['searchText']['hasFigureImages'] = $hasFigureImages;
    $_SESSION['searchTextSql']['hasFigureImages'] = " AND hasFigureImages = $hasFigureImages";
  } else {
    unset($_SESSION['searchText']['hasFigureImages']);
    unset($_SESSION['searchTextSql']['hasFigureImages']);
  }
}

// transcription
if ( isset($transcriptionType) ) {
  if ($transcriptionType == 'any') {
    $_SESSION['searchText']['transcriptionType'] = $transcriptionType;
    $_SESSION['searchTextSql']['transcriptionType'] = ' AND transcriptionType != 0';
  } elseif ($transcriptionType == '0' or $transcriptionType == '1' or $transcriptionType == '2' or $transcriptionType == '3') {
    $_SESSION['searchText']['transcriptionType'] = $transcriptionType;
    $_SESSION['searchTextSql']['transcriptionType'] = " AND transcriptionType = $transcriptionType";
  } else {
    unset($_SESSION['searchText']['transcriptionType']);
    unset($_SESSION['searchTextSql']['transcriptionType']);
  }
}

// independent header
if ( isset($hasIndependentHeader) ) {
  if ($hasIndependentHeader == '0' or $hasIndependentHeader == '1') {
    $_SESSION['searchText']['hasIndependentHeader'] = $hasIndependentHeader;
    $_SESSION['searchTextSql']['hasIndependentHeader'] = " AND hasIndependentHeader = $hasIndependentHeader";
  } else {
    unset($_SESSION['searchText']['hasIndependentHeader']);
    unset($_SESSION['searchTextSql']['hasIndependentHeader']);
  }
}

// destined for repository
if ( isset($forRepo) ) {
  if ($forRepo == '0' or $forRepo == '1') {
    $_SESSION['searchText']['forRepo'] = $forRepo;
    $_SESSION['searchTextSql']['forRepo'] = " AND forRepo = $forRepo";
  } else {
    unset($_SESSION['searchText']['forRepo']);
    unset($_SESSION['searchTextSql']['forRepo']);
  }
}

// for internal use only
if ( isset($forInternalUseOnly) ) {
  if ($forInternalUseOnly == '0' or $forInternalUseOnly == '1') {
    $_SESSION['searchText']['forInternalUseOnly'] = $forInternalUseOnly;
    $_SESSION['searchTextSql']['forInternalUseOnly'] = " AND forInternalUseOnly = $forInternalUseOnly";
  } else {
    unset($_SESSION['searchText']['forInternalUseOnly']);
    unset($_SESSION['searchTextSql']['forInternalUseOnly']);
  }
}

// redirect to search form, if immediate search was requested
if ($searchNow) {
  header('Location: search.php');
  exit;
}

// redirect to another search page, if requested
if ($jumpTo) {
  $url = getJumpToUrl($jumpTo);
  if ($url != 'search6.php') {
    header("Location: $url");
    exit;
  }
}


//---------------------------
// display form for this page
//---------------------------

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="GET" action="search7.php">
<table cellpadding="4">

<tr>
<td class="label">Book scanning:</td>
<td><select name="bookScanning">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['bookScanning'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>Book scanning finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['bookScanning'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>Book scanning not finished</option>\n";

echo "<option value=''>--------------------</option>\n";

$selected = '';
if ($_SESSION['searchText']['bookScanning'] == 'scanPages') { $selected = ' selected'; }
echo "<option value='scanPages'$selected>Scan pages</option>\n";

$selected = '';
if ($_SESSION['searchText']['bookScanning'] == 'scanFigures') { $selected = ' selected'; }
echo "<option value='scanFigures'$selected>Scan figures</option>\n";

$selected = '';
if ($_SESSION['searchText']['bookScanning'] == 'renameFigureScans') { $selected = ' selected'; }
echo "<option value='renameFigureScans'$selected>Rename figure scans</option>\n";

$selected = '';
if ($_SESSION['searchText']['bookScanning'] == 'fixPageScans') { $selected = ' selected'; }
echo "<option value='fixPageScans'$selected>Fix page scans</option>\n";

$selected = '';
if ($_SESSION['searchText']['bookScanning'] == 'makeRescans') { $selected = ' selected'; }
echo "<option value='makeRescans'$selected>Make rescans</option>\n";

$selected = '';
if ($_SESSION['searchText']['bookScanning'] == 'proof') { $selected = ' selected'; }
echo "<option value='proof'$selected>Perform QA</option>\n";

$selected = '';
if ($_SESSION['searchText']['bookScanning'] == 'makeWebImages') { $selected = ' selected'; }
echo "<option value='makeWebImages'$selected>Make web images</option>\n";

$selected = '';
if ($_SESSION['searchText']['bookScanning'] == 'zip') { $selected = ' selected'; }
echo "<option value='zip'$selected>Zip for vendor</option>\n";

$selected = '';
if ($_SESSION['searchText']['bookScanning'] == 'sendToVendor') { $selected = ' selected'; }
echo "<option value='sendToVendor'$selected>Send to vendor</option>\n";

echo <<<EOD
</select></td>
<td><select name='bookScanningMode'>
<option value=''></option>
EOD;

$selected = '';
if ($_SESSION['searchText']['bookScanningMode'] == 'next') { $selected = ' selected'; }
echo "<option value='next'$selected>is the next step</option>\n";

$selected = '';
if ($_SESSION['searchText']['bookScanningMode'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>is finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['bookScanningMode'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>is not finished</option>\n";

?>
</select></td>
</tr>

<tr>
<td class="label">Migration images:</td>
<td><select name="migration">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['migration'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>Migration finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['migration'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>Migration not finished</option>\n";

echo "<option value=''>--------------------</option>\n";

$selected = '';
if ($_SESSION['searchText']['migration'] == 'loadFiles') { $selected = ' selected'; }
echo "<option value='loadFiles'$selected>Load files</option>\n";

$selected = '';
if ($_SESSION['searchText']['migration'] == 'requestRescans') { $selected = ' selected'; }
echo "<option value='requestRescans'$selected>Request rescans</option>\n";

$selected = '';
if ($_SESSION['searchText']['migration'] == 'makeRescans') { $selected = ' selected'; }
echo "<option value='makeRescans'$selected>Make rescans</option>\n";

$selected = '';
if ($_SESSION['searchText']['migration'] == 'insertRescans') { $selected = ' selected'; }
echo "<option value='insertRescans'$selected>Insert rescans</option>\n";

$selected = '';
if ($_SESSION['searchText']['migration'] == 'renameImageFiles') { $selected = ' selected'; }
echo "<option value='renameImageFiles'$selected>Rename image files</option>\n";

$selected = '';
if ($_SESSION['searchText']['migration'] == 'photoshopScripts') { $selected = ' selected'; }
echo "<option value='photoshopScripts'$selected>Photoshop scripts</option>\n";

$selected = '';
if ($_SESSION['searchText']['migration'] == 'proof') { $selected = ' selected'; }
echo "<option value='proof'$selected>Perform QA</option>\n";

$selected = '';
if ($_SESSION['searchText']['migration'] == 'makeWebImages') { $selected = ' selected'; }
echo "<option value='makeWebImages'$selected>Make web images</option>\n";

echo <<<EOD
</select></td>
<td><select name='migrationMode'>
<option value=''></option>
EOD;

$selected = '';
if ($_SESSION['searchText']['migrationMode'] == 'next') { $selected = ' selected'; }
echo "<option value='next'$selected>is the next step</option>\n";

$selected = '';
if ($_SESSION['searchText']['migrationMode'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>is finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['migrationMode'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>is not finished</option>\n";

?>
</select></td>
</tr>

<tr>
<td class="label">Page book:</td>
<td><select name="pageBook">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['pageBook'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>Page book finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageBook'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>Page book not finished</option>\n";

echo "<option value=''>--------------------</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageBook'] == 'scanPages') { $selected = ' selected'; }
echo "<option value='scanPages'$selected>Scan pages</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageBook'] == 'runScripts') { $selected = ' selected'; }
echo "<option value='runScripts'$selected>Run scripts</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageBook'] == 'makeWebImages') { $selected = ' selected'; }
echo "<option value='makeWebImages'$selected>Make web images</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageBook'] == 'qaImages') { $selected = ' selected'; }
echo "<option value='qaImages'$selected>QA images</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageBook'] == 'makeDerivatives') { $selected = ' selected'; }
echo "<option value='makeDerivatives'$selected>Make derivatives</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageBook'] == 'makePDF') { $selected = ' selected'; }
echo "<option value='makePDF'$selected>Make PDF</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageBook'] == 'finalize') { $selected = ' selected'; }
echo "<option value='finalize'$selected>Finalize</option>\n";

echo <<<EOD
</select></td>
<td><select name='pageBookMode'>
<option value=''></option>
EOD;

$selected = '';
if ($_SESSION['searchText']['pageBookMode'] == 'next') { $selected = ' selected'; }
echo "<option value='next'$selected>is the next step</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageBookMode'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>is finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageBookMode'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>is not finished</option>\n";

?>
</select></td>
</tr>

<tr>
<td class="label">TEI header:</td>
<td><select name="teiHeader">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['teiHeader'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>TEI header finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['teiHeader'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>TEI header not finished</option>\n";

echo "<option value=''>--------------------</option>\n";

$selected = '';
if ($_SESSION['searchText']['teiHeader'] == 'reviewMarc') { $selected = ' selected'; }
echo "<option value='reviewMarc'$selected>Review Virgo record</option>\n";

$selected = '';
if ($_SESSION['searchText']['teiHeader'] == 'exportMarc') { $selected = ' selected'; }
echo "<option value='exportMarc'$selected>Export Virgo record</option>\n";

$selected = '';
if ($_SESSION['searchText']['teiHeader'] == 'makeTeiHeader') { $selected = ' selected'; }
echo "<option value='makeTeiHeader'$selected>Make TEI header</option>\n";

$selected = '';
if ($_SESSION['searchText']['teiHeader'] == 'reviewTeiHeader') { $selected = ' selected'; }
echo "<option value='reviewTeiHeader'$selected>Review TEI header</option>\n";

echo <<<EOD
</select></td>
<td><select name='teiHeaderMode'>
<option value=''></option>
EOD;

$selected = '';
if ($_SESSION['searchText']['teiHeaderMode'] == 'next') { $selected = ' selected'; }
echo "<option value='next'$selected>is the next step</option>\n";

$selected = '';
if ($_SESSION['searchText']['teiHeaderMode'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>is finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['teiHeaderMode'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>is not finished</option>\n";

?>
</select></td>
</tr>

<tr>
<td class="label">Post-keyboarding:</td>
<td><select name="postkb">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['postkb'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>Post-keyboarding finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>Post-keyboarding not finished</option>\n";

echo "<option value=''>--------------------</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'download') { $selected = ' selected'; }
echo "<option value='download'$selected>Download</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'validate') { $selected = ' selected'; }
echo "<option value='validate'$selected>Validate</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'fixVendorProblems') { $selected = ' selected'; }
echo "<option value='fixVendorProblems'$selected>Fix vendor problems</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'runScripts') { $selected = ' selected'; }
echo "<option value='runScripts'$selected>Run scripts</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'syncPages') { $selected = ' selected'; }
echo "<option value='syncPages'$selected>Sync pages</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'generateReports') { $selected = ' selected'; }
echo "<option value='generateReports'$selected>Generate reports</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'submitRehyphenateReport') { $selected = ' selected'; }
echo "<option value='submitRehyphenateReport'$selected>Submit rehyphenate report</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'commitRehyphenateChanges') { $selected = ' selected'; }
echo "<option value='commitRehyphenateChanges'$selected>Commit rehyphenate changes</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'submitUnclearsReport') { $selected = ' selected'; }
echo "<option value='submitUnclearsReport'$selected>Submit unclears report</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'commitUnclearsChanges') { $selected = ' selected'; }
echo "<option value='commitUnclearsChanges'$selected>Commit unclears changes</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'submitFiguresRendReport') { $selected = ' selected'; }
echo "<option value='submitFiguresRendReport'$selected>Submit figures-rend report</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'commitFiguresRendChanges') { $selected = ' selected'; }
echo "<option value='commitFiguresRendChanges'$selected>Commit figures-rend changes</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'generateFiguresFilenamesReport') { $selected = ' selected'; }
echo "<option value='generateFiguresFilenamesReport'$selected>Generate figures-filenames report</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'submitFiguresFilenamesReport') { $selected = ' selected'; }
echo "<option value='submitFiguresFilenamesReport'$selected>Submit figures-filenames report</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'commitFiguresFilenamesChanges') { $selected = ' selected'; }
echo "<option value='commitFiguresFilenamesChanges'$selected>Commit figures-filenames changes</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkb'] == 'copyToDoneDir') { $selected = ' selected'; }
echo "<option value='copyToDoneDir'$selected>Copy to 59processed</option>\n";

echo <<<EOD
</select></td>
<td><select name='postkbMode'>
<option value=''></option>
EOD;

$selected = '';
if ($_SESSION['searchText']['postkbMode'] == 'next') { $selected = ' selected'; }
echo "<option value='next'$selected>is the next step</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkbMode'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>is finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['postkbMode'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>is not finished</option>\n";

?>
</select></td>
</tr>

<tr>
<td class="label">Markup QA:</td>
<td><select name="markupQA">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['markupQA'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>Markup QA finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['markupQA'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>Markup QA not finished</option>\n";

echo "<option value=''>--------------------</option>\n";

$selected = '';
if ($_SESSION['searchText']['markupQA'] == 'findUnclosedUnclears') { $selected = ' selected'; }
echo "<option value='findUnclosedUnclears'$selected>Find unclosed unclears</option>\n";

$selected = '';
if ($_SESSION['searchText']['markupQA'] == 'fixUnknownChars') { $selected = ' selected'; }
echo "<option value='fixUnknownChars'$selected>Fix unknown characters</option>\n";

$selected = '';
if ($_SESSION['searchText']['markupQA'] == 'addPropertySheet') { $selected = ' selected'; }
echo "<option value='addPropertySheet'$selected>Add property sheet</option>\n";

$selected = '';
if ($_SESSION['searchText']['markupQA'] == 'updateTeiHeader') { $selected = ' selected'; }
echo "<option value='updateTeiHeader'$selected>Update TEI header</option>\n";

$selected = '';
if ($_SESSION['searchText']['markupQA'] == 'fixDivStructures') { $selected = ' selected'; }
echo "<option value='fixDivStructures'$selected>Fix div structure</option>\n";

$selected = '';
if ($_SESSION['searchText']['markupQA'] == 'updateNotes') { $selected = ' selected'; }
echo "<option value='updateNotes'$selected>Update notes</option>\n";

$selected = '';
if ($_SESSION['searchText']['markupQA'] == 'runCommandLinePrograms') { $selected = ' selected'; }
echo "<option value='runCommandLinePrograms'$selected>Run command-line programs</option>\n";

$selected = '';
if ($_SESSION['searchText']['markupQA'] == 'runWebPrograms') { $selected = ' selected'; }
echo "<option value='runWebPrograms'$selected>Run web-based programs</option>\n";

$selected = '';
if ($_SESSION['searchText']['markupQA'] == 'spellcheck') { $selected = ' selected'; }
echo "<option value='spellcheck'$selected>Check spelling</option>\n";

$selected = '';
if ($_SESSION['searchText']['markupQA'] == 'copyToDoneDir') { $selected = ' selected'; }
echo "<option value='copyToDoneDir'$selected>Copy to 69processed</option>\n";

echo <<<EOD
</select></td>
<td><select name='markupQAMode'>
<option value=''></option>
EOD;

$selected = '';
if ($_SESSION['searchText']['markupQAMode'] == 'next') { $selected = ' selected'; }
echo "<option value='next'$selected>is the next step</option>\n";

$selected = '';
if ($_SESSION['searchText']['markupQAMode'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>is finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['markupQAMode'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>is not finished</option>\n";

?>
</select></td>
</tr>

<tr>
<td class="label">Finalization:</td>
<td><select name="finalization">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['finalization'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>Finalization finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>Finalization not finished</option>\n";

echo "<option value=''>--------------------</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'replaceHeader') { $selected = ' selected'; }
echo "<option value='replaceHeader'$selected>Replace TEI header</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'updateIssueData') { $selected = ' selected'; }
echo "<option value='updateIssueData'$selected>Update issue data</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'refreshFileSize') { $selected = ' selected'; }
echo "<option value='refreshFileSize'$selected>Update access and file size</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'qaHeader') { $selected = ' selected'; }
echo "<option value='qaHeader'$selected>QA TEI header</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'runHeaderReport') { $selected = ' selected'; }
echo "<option value='runHeaderReport'$selected>Run TEI header report</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'to70fullheaders_added') { $selected = ' selected'; }
echo "<option value='to70fullheaders_added'$selected>Move to 70fullheaders_added</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'restoreChars') { $selected = ' selected'; }
echo "<option value='restoreChars'$selected>Restore characters</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'replacePaths') { $selected = ' selected'; }
echo "<option value='replacePaths'$selected>Replace paths</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'verifyImages') { $selected = ' selected'; }
echo "<option value='verifyImages'$selected>Verify image files</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'addPids') { $selected = ' selected'; }
echo "<option value='addPids'$selected>Add PIDs</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'qaProgram') { $selected = ' selected'; }
echo "<option value='qaProgram'$selected>Run QA program</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'validate') { $selected = ' selected'; }
echo "<option value='validate'$selected>Validate</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'to80final') { $selected = ' selected'; }
echo "<option value='to80final'$selected>Move to 80final</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'dlps2ReadyRepo') { $selected = ' selected'; }
echo "<option value='dlps2ReadyRepo'$selected>Run dlps2ReadyRepo</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'verifyImagesReadyRepo') { $selected = ' selected'; }
echo "<option value='verifyImagesReadyRepo'$selected>Verify image files</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'pogo2archive') { $selected = ' selected'; }
echo "<option value='pogo2archive'$selected>Archive to StorNext</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalization'] == 'runCleanupScript') { $selected = ' selected'; }
echo "<option value='runCleanupScript'$selected>Run cleanup script</option>\n";

echo <<<EOD
</select></td>
<td><select name='finalizationMode'>
<option value=''></option>
EOD;

$selected = '';
if ($_SESSION['searchText']['finalizationMode'] == 'next') { $selected = ' selected'; }
echo "<option value='next'$selected>is the next step</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalizationMode'] == 'finished') { $selected = ' selected'; }
echo "<option value='finished'$selected>is finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['finalizationMode'] == 'notFinished') { $selected = ' selected'; }
echo "<option value='notFinished'$selected>is not finished</option>\n";

?>
</select></td>
</tr>

<tr>
<td class="label">Finished status:</td>
<td><select name="isFinished">
<option value="all">All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['isFinished'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>Finished</option>\n";

$selected = '';
if ($_SESSION['searchText']['isFinished'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>Not finished</option>\n";
?>
</select></td>
<td></td>
</tr>

<tr>
<td></td>
<td colspan="2">
<input type="button" value="&lt; Back" onclick="history.back();">
<input type="button" value="Clear" onclick="clearForm();">
<input type="button" value="Search Now" onclick="document.frm.searchNow.value='true'; document.frm.submit();">
<input type="submit" value="Next &gt;"  onclick="document.frm.searchNow.value='';">
<input type="hidden" name="searchNow">
</td>
</tr>

<tr>
<td></td>
<td colspan="2">
Go to: <select name="jumpTo">
<option value=""></option>
<option value="basic">Basic Criteria</option>
<option value="groupings">Groupings</option>
<option value="responsibility">Responsibility</option>
<option value="dates">Priority and Dates</option>
<option value="misc">Other Criteria</option>
<option value="">----------</option>
<option value="output">Output Options</option>
</select>
<input type="button" value="Go" onclick="document.frm.submit();">
</td>
</tr>

</table>
</form>
</body>
</html>
