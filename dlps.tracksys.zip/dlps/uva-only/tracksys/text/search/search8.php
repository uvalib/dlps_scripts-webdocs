<?php

/*
  search8.php - final page of Search Assistant - processes form data and redirects to search page
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-12-14
  Last modified: 2005-12-15

  Receives data from: search7.php
  Redirects to: search.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to db
//$connection = connect();

//-------------------------------------
// process form data from previous page
//-------------------------------------

unset($_SESSION['searchTextOutput']);

// display columns used in search criteria, in addition to those specified?
if ($useSearchColumns) {
  $_SESSION['searchTextOutput']['useSearchColumns'] = 1;
} else {
  $_SESSION['searchTextOutput']['useSearchColumns'] = 0;
}

// columns to display
foreach ($columns as $columnName) {
  $_SESSION['searchTextOutput'][$columnName] = 1;
}

// sort order
if (!empty($orderBy)) {
  $_SESSION['searchTextOutput']['orderBy'] = $orderBy;
}

// redirect to another search page, if requested
if ($jumpTo) {
  $url = getJumpToUrl($jumpTo);
  if ($url != 'search8.php') {
    header("Location: $url");
    exit;
  }
}

// redirect to search form
header('Location: search.php');
?>