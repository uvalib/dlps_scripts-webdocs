<?php

/*
  search4.php - fourth page of Search Assistant - priority and dates
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-09-12
  Last modified: 2005-12-19

  Receives data from: search3.php
  Submits data to: search5.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'Search - Priority and Dates';

// connect to db
$connection = connect();

//-------------------------------------
// process form data from previous page
//-------------------------------------

if ($clear) {
  unset($_SESSION['searchText']);
  unset($_SESSION['searchTextSql']);
}

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// selector
if ( isset($selectorId) ) {
  if ( empty($selectorId) ) {
    unset($_SESSION['searchText']['selectorId']);
    unset($_SESSION['searchTextSql']['selectorId']);
  } else {
    $_SESSION['searchText']['selectorId'] = $selectorId;
    $_SESSION['searchTextSql']['selectorId'] = ' AND ';
    if ($selectorId == 'any') {
      // select items from any selector
      $_SESSION['searchTextSql']['selectorId'] .= 'selectorId != 0';
    } elseif ($selectorId == 'none') {
      // select items not assigned to a selector
      $_SESSION['searchTextSql']['selectorId'] .= 'selectorId = 0';
    } else {
      $_SESSION['searchTextSql']['selectorId'] .= "selectorId = $selectorId";
    }
  }
}

// requestor
if ( isset($requestorId) ) {
  if ( empty($requestorId) ) {
    unset($_SESSION['searchText']['requestorId']);
    unset($_SESSION['searchTextSql']['requestorId']);
  } else {
    $_SESSION['searchText']['requestorId'] = $requestorId;
    $_SESSION['searchTextSql']['requestorId'] = ' AND ';
    if ($requestorId == 'any') {
      // select items from any requestor
      $_SESSION['searchTextSql']['requestorId'] .= 'requestorId != 0';
    } elseif ($requestorId == 'none') {
      // select items not assigned to a requestor
      $_SESSION['searchTextSql']['requestorId'] .= 'requestorId = 0';
    } else {
      $_SESSION['searchTextSql']['requestorId'] .= "requestorId = $requestorId";
    }
  }
}

// page-image creator
if ( isset($pageImagesRespId) ) {
  if ( empty($pageImagesRespId) ) {
    unset($_SESSION['searchText']['pageImagesRespId']);
    unset($_SESSION['searchTextSql']['pageImagesRespId']);
  } else {
    $_SESSION['searchText']['pageImagesRespId'] = $pageImagesRespId;
    $_SESSION['searchTextSql']['pageImagesRespId'] = ' AND ';
    if ($pageImagesRespId == 'any') {
      // select items from any page-image creator
      $_SESSION['searchTextSql']['pageImagesRespId'] = 'pageImagesRespId != 0';
    } elseif ($pageImagesRespId == 'none') {
      // select items not assigned to a page-image creator
      $_SESSION['searchTextSql']['pageImagesRespId'] = 'pageImagesRespId = 0';
    } else {
      $_SESSION['searchTextSql']['pageImagesRespId'] = "pageImagesRespId = $pageImagesRespId";
    }
  }
}

// transcription creator
if ( isset($transcriptionRespId) ) {
  if ( empty($transcriptionRespId) ) {
    unset($_SESSION['searchText']['transcriptionRespId']);
    unset($_SESSION['searchTextSql']['transcriptionRespId']);
  } else {
    $_SESSION['searchText']['transcriptionRespId'] = $transcriptionRespId;
    $_SESSION['searchTextSql']['transcriptionRespId'] = ' AND ';
    if ($transcriptionRespId == 'any') {
      // select items from any transcription creator
      $_SESSION['searchTextSql']['transcriptionRespId'] = 'transcriptionRespId != 0';
    } elseif ($transcriptionRespId == 'none') {
      // select items not assigned to a transcription creator
      $_SESSION['searchTextSql']['transcriptionRespId'] = 'transcriptionRespId = 0';
    } else {
      $_SESSION['searchTextSql']['transcriptionRespId'] = "transcriptionRespId = $transcriptionRespId";
    }
  }
}

// redirect to search form, if immediate search was requested
if ($searchNow) {
  header('Location: search.php');
  exit;
}

// redirect to another search page, if requested
if ($jumpTo) {
  $url = getJumpToUrl($jumpTo);
  if ($url != 'search4.php') {
    header("Location: $url");
    exit;
  }
}


//---------------------------
// display form for this page
//---------------------------
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
<script type="text/javascript">
function clearSearchAsst4() {
  document.frm.dateReceived[0].checked = true;
  document.frm.dateFinished[0].checked = true;
  clearForm();
}
</script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="GET" action="search5.php">
<table cellpadding="4">

<tr>
<td class="label">Priority:</td>
<td><select name="priority">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['priority'] == '1') { $selected = ' selected'; }
echo "<option value='1'$selected>high</option>\n";

$selected = '';
if ($_SESSION['searchText']['priority'] == '0') { $selected = ' selected'; }
echo "<option value='0'$selected>normal</option>\n";

$selected = '';
if ($_SESSION['searchText']['priority'] == '-1') { $selected = ' selected'; }
echo "<option value='-1'$selected>low</option>\n";
?>
</select></td>
</tr>

<?php
if ( empty($_SESSION['searchText']['dateReceived']) ) {
  $allDatesSelected = ' checked'; $presetSelected = ''; $customSelected = '';
} else {
  if ( $_SESSION['searchText']['dateReceived'] == 'preset' ) {
    $allDatesSelected = ''; $presetSelected = ' checked'; $customSelected = '';
  } elseif ( $_SESSION['searchText']['dateReceived'] == 'custom' ) {
    $allDatesSelected = ''; $presetSelected = ''; $customSelected = ' checked';
  } else {
    $allDatesSelected = ' checked'; $presetSelected = ''; $customSelected = '';
  }
}

if ($presetSelected) {
  if ( empty($_SESSION['searchText']['dateReceivedPresetYear']) ) {
    //$year = getCurrentYear($_SESSION['searchText']['dateReceivedPreset']);
    $year = '';
  } else {
    $year = $_SESSION['searchText']['dateReceivedPresetYear'];
  }
} else {
  $year = '';
}
?>

<tr>
<td class="label">Date received:</td>
<td>
<input type="radio" name="dateReceived" value="allDates"<?=$allDatesSelected?>> All items
</td>
</tr>
<tr>
<td></td>
<td>
<input type="radio" name="dateReceived" value="preset"<?=$presetSelected?>> Preset range:
<select name="dateReceivedPreset">
<option value=''></option>
<?php

$selected = '';
if ($_SESSION['searchText']['dateReceivedPreset'] == 'fiscal year') { $selected = ' selected'; }
echo "<option value='fiscal year'$selected>Fiscal year (7/1 - 6/30)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateReceivedPreset'] == 'fiscal Q1') { $selected = ' selected'; }
echo "<option value='fiscal Q1'$selected>First fiscal quarter (7/1 - 9/30)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateReceivedPreset'] == 'fiscal Q2') { $selected = ' selected'; }
echo "<option value='fiscal Q2'$selected>Second fiscal quarter (10/1 - 12/31)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateReceivedPreset'] == 'fiscal Q3') { $selected = ' selected'; }
echo "<option value='fiscal Q3'$selected>Third fiscal quarter (1/1 - 3/31)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateReceivedPreset'] == 'fiscal Q4') { $selected = ' selected'; }
echo "<option value='fiscal Q4'$selected>Fourth fiscal quarter (4/1 - 6/30)</option>\n";

echo "<option value=''>--------------------</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateReceivedPreset'] == 'calendar year') { $selected = ' selected'; }
echo "<option value='calendar year'$selected>Calendar year (1/1 - 12/31)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateReceivedPreset'] == 'calendar Q1') { $selected = ' selected'; }
echo "<option value='calendar Q1'$selected>First calendar quarter (1/1 - 3/31)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateReceivedPreset'] == 'calendar Q2') { $selected = ' selected'; }
echo "<option value='calendar Q2'$selected>Second calendar quarter (4/1 - 6/30)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateReceivedPreset'] == 'calendar Q3') { $selected = ' selected'; }
echo "<option value='calendar Q3'$selected>Third calendar quarter (7/1 - 9/30)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateReceivedPreset'] == 'calendar Q4') { $selected = ' selected'; }
echo "<option value='calendar Q4'$selected>Fourth calendar quarter (10/1 - 12/31)</option>\n";
?>
</select>
Year: <input type="text" name="dateReceivedPresetYear" size="5" maxlength="4" value="<?=$year?>">
</td>
</tr>
<tr>
<td></td>
<td>
<input type='radio' name='dateReceived' value='custom'<?=$customSelected?>> Custom range:
<?php
echo "<input type='text' name='dateReceivedFrom'";
if ($customSelected and $_SESSION['searchText']['dateReceivedFrom']) {
  echo " value='" . formatDateUS($_SESSION['searchText']['dateReceivedFrom']) . "'";
}
echo " size='10' maxlength='10'>\n";
echo " to <input type='text' name='dateReceivedTo'";
if ($customSelected and $_SESSION['searchText']['dateReceivedTo']) {
  echo " value='" . formatDateUS($_SESSION['searchText']['dateReceivedTo']) . "'";
}
echo " size='10' maxlength='10'>\n";
?>
</td>
</tr>

<?php
if ( empty($_SESSION['searchText']['dateFinished']) ) {
  $allDatesSelected = ' checked'; $presetSelected = ''; $customSelected = '';
} else {
  if ( $_SESSION['searchText']['dateFinished'] == 'preset' ) {
    $allDatesSelected = ''; $presetSelected = ' checked'; $customSelected = '';
  } elseif ( $_SESSION['searchText']['dateFinished'] == 'custom' ) {
    $allDatesSelected = ''; $presetSelected = ''; $customSelected = ' checked';
  } else {
    $allDatesSelected = ' checked'; $presetSelected = ''; $customSelected = '';
  }
}

if ($presetSelected) {
  if ( empty($_SESSION['searchText']['dateFinishedPresetYear']) ) {
    //$year = getCurrentYear($_SESSION['searchText']['dateFinishedPreset']);
    $year = '';
  } else {
    $year = $_SESSION['searchText']['dateFinishedPresetYear'];
  }
} else {
  $year = '';
}
?>

<tr>
<td class="label">Date finished:</td>
<td>
<input type="radio" name="dateFinished" value="allDates"<?=$allDatesSelected?>> All items
</td>
</tr>
<tr>
<td></td>
<td>
<input type="radio" name="dateFinished" value="preset"<?=$presetSelected?>> Preset range:
<select name="dateFinishedPreset">
<option value=''></option>
<?php

$selected = '';
if ($_SESSION['searchText']['dateFinishedPreset'] == 'fiscal year') { $selected = ' selected'; }
echo "<option value='fiscal year'$selected>Fiscal year (7/1 - 6/30)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateFinishedPreset'] == 'fiscal Q1') { $selected = ' selected'; }
echo "<option value='fiscal Q1'$selected>First fiscal quarter (7/1 - 9/30)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateFinishedPreset'] == 'fiscal Q2') { $selected = ' selected'; }
echo "<option value='fiscal Q2'$selected>Second fiscal quarter (10/1 - 12/31)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateFinishedPreset'] == 'fiscal Q3') { $selected = ' selected'; }
echo "<option value='fiscal Q3'$selected>Third fiscal quarter (1/1 - 3/31)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateFinishedPreset'] == 'fiscal Q4') { $selected = ' selected'; }
echo "<option value='fiscal Q4'$selected>Fourth fiscal quarter (4/1 - 6/30)</option>\n";

echo "<option value=''>--------------------</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateFinishedPreset'] == 'calendar year') { $selected = ' selected'; }
echo "<option value='calendar year'$selected>Calendar year (1/1 - 12/31)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateFinishedPreset'] == 'calendar Q1') { $selected = ' selected'; }
echo "<option value='calendar Q1'$selected>First calendar quarter (1/1 - 3/31)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateFinishedPreset'] == 'calendar Q2') { $selected = ' selected'; }
echo "<option value='calendar Q2'$selected>Second calendar quarter (4/1 - 6/30)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateFinishedPreset'] == 'calendar Q3') { $selected = ' selected'; }
echo "<option value='calendar Q3'$selected>Third calendar quarter (7/1 - 9/30)</option>\n";

$selected = '';
if ($_SESSION['searchText']['dateFinishedPreset'] == 'calendar Q4') { $selected = ' selected'; }
echo "<option value='calendar Q4'$selected>Fourth calendar quarter (10/1 - 12/31)</option>\n";
?>
</select>
Year: <input type="text" name="dateFinishedPresetYear" size="5" maxlength="4" value="<?=$year?>">
</td>
</tr>
<tr>
<td></td>
<td>
<input type='radio' name='dateFinished' value='custom'<?=$customSelected?>> Custom range:
<?php
echo "<input type='text' name='dateFinishedFrom'";
if ($customSelected and $_SESSION['searchText']['dateFinishedFrom']) {
  echo " value='" . formatDateUS($_SESSION['searchText']['dateFinishedFrom']) . "'";
}
echo " size='10' maxlength='10'>\n";
echo " to <input type='text' name='dateFinishedTo'";
if ($customSelected and $_SESSION['searchText']['dateFinishedTo']) {
  echo " value='" . formatDateUS($_SESSION['searchText']['dateFinishedTo']) . "'";
}
echo " size='10' maxlength='10'>\n";
?>
</td>
</tr>

<tr>
<td></td>
<td>
<input type="button" value="&lt; Back" onclick="history.back();">
<input type="button" value="Clear" onclick="clearSearchAsst4();">
<input type="button" value="Search Now" onclick="document.frm.searchNow.value='true'; document.frm.submit();">
<input type="submit" value="Next &gt;"  onclick="document.frm.searchNow.value='';">
<input type="hidden" name="searchNow">
</td>
</tr>

<tr>
<td></td>
<td>
Go to: <select name="jumpTo">
<option value=""></option>
<option value="basic">Basic Criteria</option>
<option value="groupings">Groupings</option>
<option value="responsibility">Responsibility</option>
<option value="">----------</option>
<option value="misc">Other Criteria</option>
<option value="status">Workflow Status</option>
<option value="output">Output Options</option>
</select>
<input type="button" value="Go" onclick="document.frm.submit();">
</td>
</tr>

</table>

<br>
<p><strong>Custom range:</strong> To use a date range with no starting
point, leave the "from" date blank. To use a date range with no ending
point, leave the "to" date blank.</p>

</form>
</body>
</html>
