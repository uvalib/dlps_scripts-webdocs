<?php

/*
  search.php - queries database and displays search results
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-06-21
  Last modified: 2005-12-12

*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to db
$connection = connect();

testPerm('textSelect');
if (!getPerm('textExport')) { $exportAppearance = ' disabled'; }
$siteArea = 'Text Workflow';
$pageTitle = 'Search Results';

// get associative array representing table 'sets'
$sets = getHashSets($connection);

// get associative array representing table 'projects'
$projects = getHashProjects($connection);

// get associative array representing table 'groups'
$groups = getHashGroups($connection);

// get associative array representing table 'batches'
$batches = getHashBatches($connection);

// get associative array representing table 'selectors'
$selectors = getHashSelectors($connection);

// get associative array representing table 'requestors'
$requestors = getHashRequestors($connection);

// get associative array representing table 'pageImagesResps'
$pageImagesResps = getHashPageImagesResps($connection);

// get associative array representing table 'transcriptionResps'
$transcriptionResps = getHashTranscriptionResps($connection);


//-------------------------
// prepare SQL query string
//-------------------------

$sql = 'SELECT textItems.* FROM textItems';

if (!empty($_SESSION['searchTextSql']['bookScanning'])) {
  $sql .= ' LEFT JOIN bookScanning USING (dlpsId)';
}

if (!empty($_SESSION['searchTextSql']['migration'])) {
  $sql .= ' LEFT JOIN migration USING (dlpsId)';
  $sql .= ' LEFT JOIN bookScanning USING (dlpsId)';
}

if (!empty($_SESSION['searchTextSql']['teiHeader'])) {
  $sql .= ' LEFT JOIN teiHeader USING (dlpsId)';
}

if (!empty($_SESSION['searchTextSql']['postkb'])) {
  $sql .= ' LEFT JOIN postkb USING (dlpsId)';
}

if (!empty($_SESSION['searchTextSql']['markupQA'])) {
  $sql .= ' LEFT JOIN markupQA USING (dlpsId)';
}

if (!empty($_SESSION['searchTextSql']['finalization'])) {
  $sql .= ' LEFT JOIN finalization USING (dlpsId)';
}

$where = '';

// basic criteria
$where .= $_SESSION['searchTextSql']['dlpsId'];
$where .= $_SESSION['searchTextSql']['virgoId'];
$where .= $_SESSION['searchTextSql']['titleControlNumber'];
$where .= $_SESSION['searchTextSql']['title'];
$where .= $_SESSION['searchTextSql']['authorNameLast'];
$where .= $_SESSION['searchTextSql']['notes'];

// groupings
$where .= $_SESSION['searchTextSql']['setId'];
$where .= $_SESSION['searchTextSql']['projectId'];
$where .= $_SESSION['searchTextSql']['groupId'];
$where .= $_SESSION['searchTextSql']['batchId'];

// responsibility
$where .= $_SESSION['searchTextSql']['selectorId'];
$where .= $_SESSION['searchTextSql']['requestorId'];
$where .= $_SESSION['searchTextSql']['pageImagesRespId'];
$where .= $_SESSION['searchTextSql']['transcriptionRespId'];

// priority and dates
$where .= $_SESSION['searchTextSql']['priority'];
$where .= $_SESSION['searchTextSql']['dateReceived'];
$where .= $_SESSION['searchTextSql']['dateFinished'];

// misc criteria
$where .= $_SESSION['searchTextSql']['genre'];
$where .= $_SESSION['searchTextSql']['publicationYear'];
$where .= $_SESSION['searchTextSql']['access'];
$where .= $_SESSION['searchTextSql']['pageImagesType'];
$where .= $_SESSION['searchTextSql']['hasFigureImages'];
$where .= $_SESSION['searchTextSql']['hasTranscription'];
$where .= $_SESSION['searchTextSql']['forRepo'];
$where .= $_SESSION['searchTextSql']['forInternalUseOnly'];

// workflow status
$where .= $_SESSION['searchTextSql']['bookScanning'];
$where .= $_SESSION['searchTextSql']['migration'];
$where .= $_SESSION['searchTextSql']['teiHeader'];
$where .= $_SESSION['searchTextSql']['postkb'];
$where .= $_SESSION['searchTextSql']['markupQA'];
$where .= $_SESSION['searchTextSql']['finalization'];
$where .= $_SESSION['searchTextSql']['isFinished'];

if (!empty($where)) {
  $where = preg_replace('/^ +AND +/', '', $where);  // remove the initial ' AND'
  $sql .= ' WHERE ' . $where;
}

// sort order
if ( $_GET['orderBy'] ) {
  $orderBy = $_GET['orderBy'];
} elseif ( $_SESSION['searchText']['orderBy'] ) {
  $orderBy = $_SESSION['searchText']['orderBy'];
} else {
  $orderBy = 'dlpsId';
}
$_SESSION['searchText']['orderBy'] = $orderBy;
switch ($orderBy) {
  case 'dlpsId':
    $_SESSION['searchTextSql']['orderBy'] = ' ORDER BY dlpsId';
    break;
  case 'title':
    $_SESSION['searchTextSql']['orderBy'] = ' ORDER BY title, volumeNumber';
    break;
  case 'author':
    $_SESSION['searchTextSql']['orderBy'] = ' ORDER BY authorNameLast, authorNameFirst, dlpsId';
    break;
  case 'dateReceived':
    $_SESSION['searchTextSql']['orderBy'] = ' ORDER BY dateReceived, dlpsId';
    break;
  case 'dateFinished':
    $_SESSION['searchTextSql']['orderBy'] = ' ORDER BY dateFinished, dlpsId';
    break;
  case 'publicationYear':
    $_SESSION['searchTextSql']['orderBy'] = ' ORDER BY publicationYear, dlpsId';
    break;
  default:
    unset($_SESSION['searchText']['orderBy']);
    unset($_SESSION['searchTextSql']['orderBy']);
    $orderBy = '';
}
$sql .= $_SESSION['searchTextSql']['orderBy'];

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
<script type="text/javascript">
function exportData() {
  document.selectForm.action="../exportTextItems.php";
  document.selectForm.submit();
}

function setCheckboxes(onOrOff) {
  for (i = 0; i < document.selectForm.elements.length; i++) {
    if (document.selectForm.elements[i].type == "checkbox") {
      document.selectForm.elements[i].checked = onOrOff;
    }
  }
}
</script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
if ($debugMode) {
  echo "<p>$sql</p>\n";
}

// execute query
$result = query($sql, $connection)
  or die("Unable to select from table 'textItems': " . mysql_error($connection));

$num = mysql_num_rows($result);
if ($num == 1) { $plural = ''; } else { $plural = 's'; }
echo "<p>Found <b>$num</b> item$plural</p>\n";

$newSearchLink = "<p><a href='search1.php'>Adjust this search</a><br>
<a href='search0.php'>Start a new search</a></p>\n";
echo $newSearchLink;

if ($num >= 1) {
  echo "<form name='selectForm' method='POST'>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>&nbsp;</td>\n";

  if ($orderBy == 'dlpsId') {
    echo "<td><i>DLPS ID</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=dlpsId'>DLPS ID</a></td>\n";
  }

  if ($orderBy == 'title') {
    echo "<td><i>Title</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=title'>Title</a></td>\n";
  }

  echo "<td>Volume</td>\n";

  if ($orderBy == 'author') {
    echo "<td><i>Author</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=author'>Author</a></td>\n";
  }

  if ($orderBy == 'dateReceived') {
    echo "<td><i>Date received</i></td>\n";
  } else {
    echo "<td><a class='head' href='search.php?orderBy=dateReceived'>Date received</a></td>\n";
  }

  $colspan = 6;

  if (!empty($_SESSION['searchTextSql']['dateFinished'])) {
    if ($orderBy == 'dateFinished') {
      echo "<td><i>Date finished</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=dateFinished'>Date finished</a></td>\n";
    }
    $colspan++;
  }

  if (!empty($_SESSION['searchTextSql']['setId'])) {
    echo "<td>Set</td>";
    $colspan++;
  }

  if (!empty($_SESSION['searchTextSql']['projectId'])) {
    echo "<td>Project</td>";
    $colspan++;
  }

  if (!empty($_SESSION['searchTextSql']['groupId'])) {
    echo "<td>Group</td>";
    $colspan++;
  }

  if (!empty($_SESSION['searchTextSql']['batchId'])) {
    echo "<td>Batch</td>";
    $colspan++;
  }

  if ( (!empty($_SESSION['searchTextSql']['selectorId']))
    || (!empty($_SESSION['searchTextSql']['requestorId'])) ) {
    echo "<td>Selector</td>";
    echo "<td>Requestor</td>";
    $colspan += 2;
  }

  if (!empty($_SESSION['searchTextSql']['publicationYear'])) {
    if ($orderBy == 'publicationYear') {
      echo "<td><i>Year of publication</i></td>\n";
    } else {
      echo "<td><a class='head' href='search.php?orderBy=publicationYear'>Year of publication</a></td>\n";
    }
    $colspan++;
  }

  if ($_SESSION['searchText']['isFinished'] == 'all' or $_SESSION['searchText']['isFinished'] == '') {
    echo "<td>Finished</td>";
    $colspan++;
  }

  echo "</tr>\n";

  $c = 1;
  $class = getRowClass($c);
  $colspan--;
  echo "<tr$class>
<td style='white-space: nowrap'>
<img name='checkAll' src='../../img/check.gif' hspace='0' onclick='setCheckboxes(true);' title='Check All'>
<img name='clearAll' border='0' src='../../img/square.gif' hspace='0' onclick='setCheckboxes(false);' title='Clear All'>
</td>
<td colspan='$colspan'>&nbsp;</td>
</tr>\n";

  // display query results
  while ( $row = mysql_fetch_array($result) ) {
    $c++;
    $class = getRowClass($c);
    $author = formatName($row['authorNameLast'], $row['authorNameFirst']);
    $dateReceived = formatDateUS($row['dateReceived']);
    echo "<tr$class>
<td><input type='checkbox' name='dlpsId_$row[dlpsId]' checked></td>
<td><a href='../textItem.php?dlpsId=$row[dlpsId]'>$row[dlpsId]</a></td>
<td>$row[title]</td>
<td style='white-space: nowrap'>$row[volumeNumber]</td>
<td>$author</td>
<td>$dateReceived</td>\n";

    if (!empty($_SESSION['searchText']['dateFinished'])) {
      echo "<td>" . formatDateUS($row['dateFinished']) . "</td>\n";
    }

    if (!empty($_SESSION['searchText']['setId'])) {
      if ( empty($row['setId']) ) {
        $setName = '';
      } else {
        foreach ($sets as $setId => $name) {
          if ($row['setId'] == $setId) {
            $setName = $name;
          }
        }
      }
      echo "<td>$setName</td>\n";
    }

    if (!empty($_SESSION['searchText']['projectId'])) {
      if ( empty($row['projectId']) ) {
        $projectName = '';
      } else {
        foreach ($projects as $projectId => $name) {
          if ($row['projectId'] == $projectId) {
            $projectName = $name;
          }
        }
      }
      echo "<td>$projectName</td>\n";
    }

    if (!empty($_SESSION['searchText']['groupId'])) {
      if ( empty($row['groupId']) ) {
        $groupName = '';
      } else {
        foreach ($groups as $groupId => $name) {
          if ($row['groupId'] == $groupId) {
            $groupName = $name;
          }
        }
      }
      echo "<td>$groupName</td>\n";
    }

    if (!empty($_SESSION['searchText']['batchId'])) {
      if ( empty($row['batchId']) ) {
        $batchName = '';
      } else {
        foreach ($batches as $batchId => $name) {
          if ($row['batchId'] == $batchId) {
            $batchName = $name;
          }
        }
      }
      echo "<td>$batchName</td>\n";
    }

    if ( (!empty($_SESSION['searchText']['selectorId']))
      || (!empty($_SESSION['searchText']['requestorId'])) ) {
      if ( empty($row['selectorId']) ) {
        $selectorName = '';
      } else {
        foreach ($selectors as $selectorId => $name) {
          if ($row['selectorId'] == $selectorId) {
            $selectorName = $name;
          }
        }
      }
      echo "<td style='white-space: nowrap'>$selectorName</td>\n";

      if ( empty($row['requestorId']) ) {
        $requestorName = '';
      } else {
        foreach ($requestors as $requestorId => $name) {
          if ($row['requestorId'] == $requestorId) {
            $requestorName = $name;
          }
        }
      }
      echo "<td style='white-space: nowrap'>$requestorName</td>\n";
    }

    if (!empty($_SESSION['searchTextSql']['publicationYear'])) {
      echo "<td>$row[publicationYear]</td>\n";
    }

    if ($_SESSION['searchText']['isFinished'] == 'all' or $_SESSION['searchText']['isFinished'] == '') {
      echo "<td>";
      if ($row['isFinished'] == 1) {
        echo "Yes";
      } else {
        echo "No";
      }
      echo "</td>\n";
    }

    echo "</tr>\n";
  }
  echo "</table>

<p> </p>
<table cellpadding='4' border='0'>
<tr>
<td class='tableSectionHeading' colspan='3'>Actions:</td>
</tr>

<tr>
<td align='right'>View checked items:</td>
<td><select name='workflow'>
<option value='bookScanning'>Book scanning workflow</option>
<option value='migration'>Migration images workflow</option>
<option value='teiHeader'>TEI header workflow</option>
<option value='postkb'>Post-keyboarding workflow</option>
<option value='markupQA'>Markup QA workflow</option>
<option value='finalization'>Finalization workflow</option>
</select>
</td>
<td valign='bottom'>
<input type='submit' value='View Workflow' onclick='return setFormAction(document.selectForm);'>
<input type='hidden' name='orderBy' value='$orderBy'>
</td>
</tr>

<tr>
<td align='right' valign='top'>Export to tab-delimited text:</td>
<td>
<input type='radio' name='exportMode' value='all' checked> All items in database <br>
<input type='radio' name='exportMode' value='checked'> Items checked on this page
</td>
<td valign='top'>
<input type='button' value='Export Data...' onclick='exportData();'$exportAppearance>
</td>
</tr>
</table>
</form>\n";
echo $newSearchLink;
}  // END if ($num >= 1)
?>
</body>
</html>
