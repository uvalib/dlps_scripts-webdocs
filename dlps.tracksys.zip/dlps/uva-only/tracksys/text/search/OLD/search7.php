<?php

/*
  search7.php - final page of Search Assistant - processes form data and redirects to search page
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-09-29
  Last modified: 2005-12-02

  Receives data from: search6.php
  Redirects to: search.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to db
$connection = connect();

//-------------------------------------
// process form data from previous page
//-------------------------------------

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// book scanning status
if (empty($bookScanning)) {
  unset($_SESSION['searchText']['bookScanning']);
  unset($_SESSION['searchTextSql']['bookScanning']);
} else {
  $_SESSION['searchText']['bookScanning'] = $bookScanning;
  switch ($bookScanning) {
    case 'scanPages':
      $_SESSION['searchTextSql']['bookScanning'] = " AND (scanPages = 0 AND sendToVendor = 0)";
      break;
    case 'scanFigures':
      $_SESSION['searchTextSql']['bookScanning'] = 
        " AND (scanPages = 1 AND scanFigures = 0 AND sendToVendor = 0)";
      break;
    case 'renameFigureScans':
      $_SESSION['searchTextSql']['bookScanning'] = 
        " AND (scanFigures = 1 AND renameFigureScans = 0 AND sendToVendor = 0)";
      break;
    case 'fixPageScans':
      $_SESSION['searchTextSql']['bookScanning'] = 
        " AND (scanPages = 1 AND fixPageScans = 0 AND sendToVendor = 0)";
      break;
    case 'makeRescans':
      $_SESSION['searchTextSql']['bookScanning'] = 
        " AND (fixPageScans = 1 AND makeRescans = 0 AND sendToVendor = 0)";
      break;
    case 'proof':
      // 'makeRescans' is optional, so use 'fixPageScans' as preceding finished step
      $_SESSION['searchTextSql']['bookScanning'] = 
        " AND (fixPageScans = 1 AND proof = 0 AND sendToVendor = 0)";
      break;
    case 'makeWebImages':
      $_SESSION['searchTextSql']['bookScanning'] = 
        " AND (proof = 1 AND makeWebImages = 0 AND sendToVendor = 0)";
      break;
    case 'zip':
      $_SESSION['searchTextSql']['bookScanning'] = " AND (makeWebImages = 1 AND zip = 0 AND sendToVendor = 0)";
      break;
    case 'sendToVendor':
      $_SESSION['searchTextSql']['bookScanning'] = " AND (zip = 1 AND sendToVendor = 0)";
      break;
    case 'finished':
      $_SESSION['searchTextSql']['bookScanning'] = " AND sendToVendor = 1";
      break;
    case 'notFinished':
      $_SESSION['searchTextSql']['bookScanning'] = " AND sendToVendor = 0";
      break;
    default:
      unset($_SESSION['searchText']['bookScanning']);
      unset($_SESSION['searchTextSql']['bookScanning']);
  }
}

// migration status
if (empty($migration)) {
  unset($_SESSION['searchText']['migration']);
  unset($_SESSION['searchTextSql']['migration']);
} else {
  $_SESSION['searchText']['migration'] = $migration;
  switch ($migration) {
    case 'loadFiles':
      $_SESSION['searchTextSql']['migration'] = " AND (migration.loadFiles = 0 AND bookScanning.makeWebImages = 0)";
      break;
    case 'requestRescans':
      $_SESSION['searchTextSql']['migration'] = 
        " AND (migration.loadFiles = 1 AND migration.requestRescans = 0 AND bookScanning.makeWebImages = 0)";
      break;
    case 'makeRescans':
      $_SESSION['searchTextSql']['migration'] = 
        " AND (migration.requestRescans = 1 AND migration.makeRescans = 0 AND bookScanning.makeWebImages = 0)";
      break;
    case 'insertRescans':
      $_SESSION['searchTextSql']['migration'] = 
        " AND (migration.makeRescans = 1 AND migration.insertRescans = 0 AND bookScanning.makeWebImages = 0)";
      break;
    case 'renameImageFiles':
      // rescanning steps are optional, so use 'loadFiles' as preceding finished step
      $_SESSION['searchTextSql']['migration'] = 
        " AND (migration.loadFiles = 1 AND migration.renameImageFiles = 0 AND bookScanning.makeWebImages = 0)";
      break;
    case 'photoshopScripts':
      $_SESSION['searchTextSql']['migration'] = 
        " AND (migration.renameImageFiles = 1 AND migration.photoshopScripts = 0 AND bookScanning.makeWebImages = 0)";
      break;
    case 'proof':
      $_SESSION['searchTextSql']['migration'] = 
        " AND (migration.photoshopScripts = 1 AND migration.proof = 0 AND bookScanning.makeWebImages = 0)";
      break;
    case 'makeWebImages':
      $_SESSION['searchTextSql']['migration'] = 
        " AND (migration.proof = 1 AND bookScanning.makeWebImages = 0)";
      break;
    case 'finished':
      $_SESSION['searchTextSql']['migration'] = " AND bookScanning.makeWebImages = 1";
      break;
    case 'notFinished':
      $_SESSION['searchTextSql']['migration'] = " AND bookScanning.makeWebImages = 0";
      break;
    default:
      unset($_SESSION['searchText']['migration']);
      unset($_SESSION['searchTextSql']['migration']);
  }
}

// TEI header status
if (empty($teiHeader)) {
  unset($_SESSION['searchText']['teiHeader']);
  unset($_SESSION['searchTextSql']['teiHeader']);
} else {
  $_SESSION['searchText']['teiHeader'] = $teiHeader;
  switch ($teiHeader) {
    case 'reviewMarc':
      $_SESSION['searchTextSql']['teiHeader'] = " AND (reviewMarc = 0 AND reviewTeiHeader = 0)";
      break;
    case 'exportMarc':
      $_SESSION['searchTextSql']['teiHeader'] = 
        " AND (reviewMarc = 1 AND exportMarc = 0 AND reviewTeiHeader = 0)";
      break;
    case 'makeTeiHeader':
      $_SESSION['searchTextSql']['teiHeader'] = 
        " AND (exportMarc = 1 AND makeTeiHeader = 0 AND reviewTeiHeader = 0)";
      break;
    case 'reviewTeiHeader':
      $_SESSION['searchTextSql']['teiHeader'] = " AND (makeTeiHeader = 1 AND reviewTeiHeader = 0)";
      break;
    case 'finished':
      $_SESSION['searchTextSql']['teiHeader'] = " AND reviewTeiHeader = 1";
      break;
    case 'notFinished':
      $_SESSION['searchTextSql']['teiHeader'] = " AND reviewTeiHeader = 0";
      break;
    default:
      unset($_SESSION['searchText']['teiHeader']);
      unset($_SESSION['searchTextSql']['teiHeader']);
  }
}

// post-keyboarding status
if (empty($postkb)) {
  unset($_SESSION['searchText']['postkb']);
  unset($_SESSION['searchTextSql']['postkb']);
} else {
  $_SESSION['searchText']['postkb'] = $postkb;
  switch ($postkb) {
    case 'download':
      $_SESSION['searchTextSql']['postkb'] = " AND (download = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'validate':
      $_SESSION['searchTextSql']['postkb'] = 
        " AND (download = 1 AND validate = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'fixVendorProblems':
      $_SESSION['searchTextSql']['postkb'] = 
        " AND (validate = 1 AND fixVendorProblems = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'runScripts':
      // 'fixVendorProblems' is optional, so use 'validate' as preceding finished step
      $_SESSION['searchTextSql']['postkb'] = 
        " AND (validate = 1 AND runScripts = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'syncPages':
      $_SESSION['searchTextSql']['postkb'] = 
        " AND (runScripts = 1 AND syncPages = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'generateReports':
      $_SESSION['searchTextSql']['postkb'] = 
        " AND (syncPages = 1 AND generateReports = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'submitRehyphenateReport':
      $_SESSION['searchTextSql']['postkb'] = 
        " AND (generateReports = 1 AND submitRehyphenateReport = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'commitRehyphenateChanges':
      $_SESSION['searchTextSql']['postkb'] = " AND (submitRehyphenateReport = 1"
        . " AND commitRehyphenateChanges = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'submitUnclearsReport':
      $_SESSION['searchTextSql']['postkb'] = 
        " AND (generateReports = 1 AND submitUnclearsReport = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'commitUnclearsChanges':
      $_SESSION['searchTextSql']['postkb'] = 
        " AND (submitUnclearsReport = 1 AND commitUnclearsChanges = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'submitFiguresRendReport':
      $_SESSION['searchTextSql']['postkb'] = 
        " AND (generateReports = 1 AND submitFiguresRendReport = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'commitFiguresRendChanges':
      $_SESSION['searchTextSql']['postkb'] = 
        " AND (submitFiguresRendReport = 1 AND commitFiguresRendChanges = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'generateFiguresFilenamesReport':
      $_SESSION['searchTextSql']['postkb'] = " AND (commitFiguresRendChanges = 1"
        . " AND generateFiguresFilenamesReport = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'submitFiguresFilenamesReport':
      $_SESSION['searchTextSql']['postkb'] = " AND (generateFiguresFilenamesReport = 1"
        . " AND submitFiguresFilenamesReport = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'commitFiguresFilenamesChanges':
      $_SESSION['searchTextSql']['postkb'] = " AND (submitFiguresFilenamesReport = 1"
        . " AND commitFiguresFilenamesChanges = 0 AND postkb.copyToDoneDir = 0)";
      break;
    case 'copyToDoneDir':
      // preceding non-optional step is 'commitRehyphenateChanges'
      $_SESSION['searchTextSql']['postkb'] = 
        " AND (commitRehyphenateChanges = 1 AND postkb.copyToDoneDir = 0)";
      break;
    case 'finished':
      $_SESSION['searchTextSql']['postkb'] = " AND postkb.copyToDoneDir = 1";
      break;
    case 'notFinished':
      $_SESSION['searchTextSql']['postkb'] = " AND postkb.copyToDoneDir = 0";
      break;
    default:
      unset($_SESSION['searchText']['postkb']);
      unset($_SESSION['searchTextSql']['postkb']);
  }
}

// markup QA status
if (empty($markupQA)) {
  unset($_SESSION['searchText']['markupQA']);
  unset($_SESSION['searchTextSql']['markupQA']);
} else {
  $_SESSION['searchText']['markupQA'] = $markupQA;
  switch ($markupQA) {
    case 'findUnclosedUnclears':
      $_SESSION['searchTextSql']['markupQA'] = 
        " AND (findUnclosedUnclears = 0 AND markupQA.copyToDoneDir = 0)";
      break;
    case 'fixUnknownChars':
      $_SESSION['searchTextSql']['markupQA'] = 
        " AND (findUnclosedUnclears = 1 AND fixUnknownChars = 0 AND markupQA.copyToDoneDir = 0)";
      break;
    case 'addPropertySheet':
      $_SESSION['searchTextSql']['markupQA'] = 
        " AND (fixUnknownChars = 1 AND addPropertySheet = 0 AND markupQA.copyToDoneDir = 0)";
      break;
    case 'updateTeiHeader':
      $_SESSION['searchTextSql']['markupQA'] = 
        " AND (addPropertySheet = 1 AND updateTeiHeader = 0 AND markupQA.copyToDoneDir = 0)";
      break;
    case 'fixDivStructures':
      $_SESSION['searchTextSql']['markupQA'] = 
        " AND (updateTeiHeader = 1 AND fixDivStructures = 0 AND markupQA.copyToDoneDir = 0)";
      break;
    case 'updateNotes':
      $_SESSION['searchTextSql']['markupQA'] = 
        " AND (fixDivStructures = 1 AND updateNotes = 0 AND markupQA.copyToDoneDir = 0)";
      break;
    case 'runCommandLinePrograms':
      $_SESSION['searchTextSql']['markupQA'] = 
        " AND (updateNotes = 1 AND runCommandLinePrograms = 0 AND markupQA.copyToDoneDir = 0)";
      break;
    case 'runWebPrograms':
      $_SESSION['searchTextSql']['markupQA'] = 
        " AND (runCommandLinePrograms = 1 AND runWebPrograms = 0 AND markupQA.copyToDoneDir = 0)";
      break;
    case 'spellcheck':
      $_SESSION['searchTextSql']['markupQA'] = 
        " AND (runWebPrograms = 1 AND spellcheck = 0 AND markupQA.copyToDoneDir = 0)";
      break;
    case 'copyToDoneDir':
      // preceding non-optional step is 'runWebPrograms'
      $_SESSION['searchTextSql']['markupQA'] = " AND (runWebPrograms = 1 AND markupQA.copyToDoneDir = 0)";
      break;
    case 'finished':
      $_SESSION['searchTextSql']['markupQA'] = " AND markupQA.copyToDoneDir = 1";
      break;
    case 'notFinished':
      $_SESSION['searchTextSql']['markupQA'] = " AND markupQA.copyToDoneDir = 0";
      break;
    default:
      unset($_SESSION['searchText']['markupQA']);
      unset($_SESSION['searchTextSql']['markupQA']);
  }
}

// finalization status
if (empty($finalization)) {
  unset($_SESSION['searchText']['finalization']);
  unset($_SESSION['searchTextSql']['finalization']);
} else {
  $_SESSION['searchText']['finalization'] = $finalization;
  switch ($finalization) {
    case 'replaceHeader':
      $_SESSION['searchTextSql']['finalization'] = " AND (replaceHeader = 0 AND runCleanupScript = 0)";
      break;
    case 'updateIssueData':
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (replaceHeader = 1 AND updateIssueData = 0 AND runCleanupScript = 0)";
      break;
    case 'refreshFileSize':
      // 'updateIssueData' is optional, so use 'replaceHeader' as preceding finished step
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (replaceHeader = 1 AND refreshFileSize = 0 AND runCleanupScript = 0)";
      break;
    case 'qaHeader':
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (refreshFileSize = 1 AND qaHeader = 0 AND runCleanupScript = 0)";
      break;
    case 'runHeaderReport':
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (qaHeader = 1 AND runHeaderReport = 0 AND runCleanupScript = 0)";
      break;
    case 'to70fullheaders_added':
      // 'runHeaderReport' is optional, so use 'qaHeader' as preceding finished step
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (qaHeader = 1 AND to70fullheaders_added = 0 AND runCleanupScript = 0)";
      break;
    case 'restoreChars':
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (to70fullheaders_added = 1 AND restoreChars = 0 AND runCleanupScript = 0)";
      break;
    case 'replacePaths':
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (restoreChars = 1 AND replacePaths = 0 AND runCleanupScript = 0)";
      break;
    case 'verifyImages':
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (replacePaths = 1 AND verifyImages = 0 AND runCleanupScript = 0)";
      break;
    case 'addPids':
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (verifyImages = 1 AND addPids = 0 AND runCleanupScript = 0)";
      break;
    case 'qaProgram':
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (addPids = 1 AND qaProgram = 0 AND runCleanupScript = 0)";
      break;
    case 'validate':
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (qaProgram = 1 AND validate = 0 AND runCleanupScript = 0)";
      break;
    case 'to80final':
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (validate = 1 AND to80final = 0 AND runCleanupScript = 0)";
      break;
    case 'dlps2ReadyRepo':
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (to80final = 1 AND dlps2ReadyRepo = 0 AND runCleanupScript = 0)";
      break;
    case 'verifyImagesReadyRepo':
      $_SESSION['searchTextSql']['finalization'] = 
        " AND (dlps2ReadyRepo = 1 AND verifyImagesReadyRepo = 0 AND runCleanupScript = 0)";
      break;
    case 'runCleanupScript':
      $_SESSION['searchTextSql']['finalization'] = " AND (verifyImagesReadyRepo = 1 AND runCleanupScript = 0)";
      break;
    case 'finished':
      $_SESSION['searchTextSql']['finalization'] = " AND runCleanupScript = 1";
      break;
    case 'notFinished':
      $_SESSION['searchTextSql']['finalization'] = " AND runCleanupScript = 0";
      break;
    default:
      unset($_SESSION['searchText']['finalization']);
      unset($_SESSION['searchTextSql']['finalization']);
  }
}

// finished status
if ($isFinished == '0' or $isFinished == '1') {
  $_SESSION['searchText']['isFinished'] = $isFinished;
  $_SESSION['searchTextSql']['isFinished'] = " AND isFinished = $isFinished";
} elseif ($isFinished == 'all') {
  $_SESSION['searchText']['isFinished'] = $isFinished;
} else {
  unset($_SESSION['searchText']['isFinished']);
  unset($_SESSION['searchTextSql']['isFinished']);
}

// redirect to search form
header('Location: search.php');
?>