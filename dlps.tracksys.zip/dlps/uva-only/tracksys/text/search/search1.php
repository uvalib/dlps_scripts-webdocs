<?php

/*
  search1.php - first page of Search Assistant - basic criteria
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-08-31
  Last modified: 2005-12-19

  Submits data to: search2.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'Search - Basic Criteria';

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body onload="document.frm.dlpsId.focus();">
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<form name="frm" method="GET" action="search2.php">
<table cellpadding="4">
<tr>
<td class="label">DLPS ID:</td>
<td><input type="text" name="dlpsId" value="<?=$_SESSION['searchText']['dlpsId']?>"></td>
</tr>

<tr>
<td class="label">Virgo ID:</td>
<td><input type="text" name="virgoId" value="<?=$_SESSION['searchText']['virgoId']?>"></td>
</tr>

<tr>
<td class="label">Title control number:</td>
<td><input type="text" name="titleControlNumber" value="<?=$_SESSION['searchText']['titleControlNumber']?>"></td>
</tr>

<tr>
<td class="label">Title:</td>
<td><input type="text" name="title" value="<?=$_SESSION['searchText']['title']?>"></td>
</tr>

<tr>
<td class="label">Author last name:</td>
<td><input type="text" name="authorNameLast" value="<?=$_SESSION['searchText']['authorNameLast']?>"></td>
</tr>

<tr>
<td class="label">Notes:</td>
<td><input type="text" name="notes" value="<?=$_SESSION['searchText']['notes']?>"></td>
</tr>

<tr>
<td></td>
<td>
<input type="button" value="Clear" onclick="clearForm();">
<input type="button" value="Search Now" onclick="document.frm.searchNow.value='true'; document.frm.submit();">
<input type="submit" value="Next &gt;"  onclick="document.frm.searchNow.value='';">
<input type="hidden" name="searchNow">
</td>
</tr>

<tr>
<td></td>
<td>
Go to: <select name="jumpTo">
<option value=""></option>
<option value="groupings">Groupings</option>
<option value="responsibility">Responsibility</option>
<option value="dates">Priority and Dates</option>
<option value="misc">Other Criteria</option>
<option value="status">Workflow Status</option>
<option value="output">Output Options</option>
</select>
<input type="button" value="Go" onclick="document.frm.submit();">
</td>
</tr>

</table>

<br>
<p><strong>Wildcards:</strong> Use * for zero or more characters, ? for
exactly one character.</p>

<p><strong>DLPS ID:</strong> To search for multiple DLPS IDs, enter
the IDs separated by commas or semicolons.</p>

</form>
</body>
</html>
