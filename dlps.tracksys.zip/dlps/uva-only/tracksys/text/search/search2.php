<?php

/*
  search2.php - second page of Search Assistant - groupings
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-08-31
  Last modified: 2006-05-24

  Receives data from: search1.php
  Submits data to: search3.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'Search - Groupings';

$setId = $_SESSION['searchText']['setId'];
$projectId = $_SESSION['searchText']['projectId'];
$groupId = $_SESSION['searchText']['groupId'];
$batchId = $_SESSION['searchText']['batchId'];

// connect to db
$connection = connect();

// get associative array representing table 'sets'
$sets = getHashSets($connection);

// get associative array representing table 'projects'
$projects = getHashProjects($connection);

// get associative array representing table 'groups'
$groups = getHashGroups($connection);

// get associative array representing table 'batches'
$batches = getHashBatches($connection);

//-------------------------------------
// process form data from previous page
//-------------------------------------

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// DLPS ID
if ( isset($dlpsId) ) {
  if ( empty($dlpsId) ) {
    unset($_SESSION['searchText']['dlpsId']);
    unset($_SESSION['searchTextSql']['dlpsId']);
  } else {
    $_SESSION['searchText']['dlpsId'] = $dlpsId;
    //$dlpsId = normalizeDlpsId($dlpsId);
    $dlpsId = clean2($dlpsId, $connection);

    // check for comma or semicolon indicating multiple DLPS IDs to search for
    if (ereg('[,;]', $dlpsId)) {
      $dlpsIds = preg_split('/[,;] ?/', $dlpsId);
      $like = '';
      foreach($dlpsIds as $id) {
	if (!empty($id)) {
	  $id = translateWildcards($id);
	  if (!ereg('%$', $id)) { $id .= '%'; }
	  $like .= "(textItems.dlpsId LIKE '$id') OR ";
	}
      }
      $like = preg_replace('/ OR $/', '', $like);
      $_SESSION['searchTextSql']['dlpsId'] = " AND $like";
    } else {
      $dlpsIdSql = translateWildcards($dlpsId);
      if (!ereg('%$', $dlpsIdSql)) { $dlpsIdSql .= '%'; }
      $_SESSION['searchTextSql']['dlpsId'] = " AND textItems.dlpsId LIKE '$dlpsIdSql'";
    }
  }
}

// Virgo ID
if ( isset($virgoId) ) {
  if ( empty($virgoId) ) {
    unset($_SESSION['searchText']['virgoId']);
    unset($_SESSION['searchTextSql']['virgoId']);
  } else {
    $_SESSION['searchText']['virgoId'] = $virgoId;
    $virgoIdSql = clean2(translateWildcards($virgoId), $connection);
    if (!ereg('%$', $virgoIdSql)) { $virgoIdSql .= '%'; }
    $_SESSION['searchTextSql']['virgoId'] = " AND virgoId LIKE '$virgoIdSql'";
  }
}

// title control number
if ( isset($titleControlNumber) ) {
  if ( empty($titleControlNumber) ) {
    unset($_SESSION['searchText']['titleControlNumber']);
    unset($_SESSION['searchTextSql']['titleControlNumber']);
  } else {
    $_SESSION['searchText']['titleControlNumber'] = $titleControlNumber;
    $titleControlNumberSql = clean2(translateWildcards($titleControlNumber), $connection);
    if (!ereg('%$', $titleControlNumberSql)) { $titleControlNumberSql .= '%'; }
    $_SESSION['searchTextSql']['titleControlNumber'] = " AND titleControlNumber LIKE '$titleControlNumberSql'";
  }
}

// title
if ( isset($title) ) {
  if ( empty($title) ) {
    unset($_SESSION['searchText']['title']);
    unset($_SESSION['searchTextSql']['title']);
  } else {
    $_SESSION['searchText']['title'] = $title;
    $titleSql = clean2(translateWildcards($title), $connection);
    if (!ereg('%$', $titleSql)) { $titleSql .= '%'; }
    $_SESSION['searchTextSql']['title'] = " AND title LIKE '$titleSql'";
  }
}

// author
if ( isset($authorNameLast) ) {
  if ( empty($authorNameLast) ) {
    unset( $_SESSION['searchText']['authorNameLast']);
    unset( $_SESSION['searchTextSql']['authorNameLast']);
  } else {
    $_SESSION['searchText']['authorNameLast'] = $authorNameLast;
    $authorNameLastSql = clean2(translateWildcards($authorNameLast), $connection);
    if (!ereg('%$', $authorNameLastSql)) { $authorNameLastSql .= '%'; }
    $_SESSION['searchTextSql']['authorNameLast'] = " AND authorNameLast LIKE '$authorNameLastSql'";
  }
}

// notes
if ( isset($notes) ) {
  if ( empty($notes) ) {
    unset($_SESSION['searchText']['notes']);
    unset($_SESSION['searchTextSql']['notes']);
  } else {
    $_SESSION['searchText']['notes'] = $notes;
    $notesSql = clean2(translateWildcards($notes), $connection);
    if (!ereg('^%', $notesSql)) { $notesSql = '%' .  $notesSql; }
    if (!ereg('%$', $notesSql)) { $notesSql .= '%'; }
    $_SESSION['searchTextSql']['notes'] = " AND notes LIKE '$notesSql'";
  }
}

// redirect to search form, if immediate search was requested
if ($searchNow) {
  header('Location: search.php');
  exit;
}

// redirect to another search page, if requested
if ($jumpTo) {
  $url = getJumpToUrl($jumpTo);
  if ($url != 'search2.php') {
    header("Location: $url");
    exit;
  }
}


//---------------------------
// display form for this page
//---------------------------
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="GET" action="search3.php">
<table cellpadding="4">

<tr>
<td class="label">Multi-volume set:</td>
<td><select name="setId">
<option value=''>All items</option>
<?php
$selected = '';
if ($setId == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items in any set</option>\n";

$selected = '';
if ($setId == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not in a set</option>\n";

$selected = '';
if ($setId == 'not9') { $selected = ' selected'; }
echo "<option value='not9'$selected>Items not in UVa Record</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($sets as $id => $name) {
  $selected = '';
  if ( $id == $setId ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td class="label">Project:</td>
<td><select name="projectId">
<option value=''>All items</option>
<?php
$selected = '';
if ($projectId == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items in any project</option>\n";

$selected = '';
if ($projectId == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not in a project</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($projects as $id => $name) {
  $selected = '';
  if ( $id == $projectId ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td class="label">Group:</td>
<td><select name="groupId">
<option value=''>All items</option>
<?php
$selected = '';
if ($groupId == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items in any group</option>\n";

$selected = '';
if ($groupId == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not in a group</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($groups as $id => $name) {
  $selected = '';
  if ( $id == $groupId ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td class="label">Vendor batch:</td>
<td><select name="batchId">
<option value=''>All items</option>
<?php
$selected = '';
if ($batchId == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items in any batch</option>\n";

$selected = '';
if ($batchId == 'none') { $selected = ' selected'; }
echo "<option value='none'>Items not in a batch</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($batches as $id => $name) {
  $selected = '';
  if ( $id == $batchId ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td></td>
<td>
<input type="button" value="&lt; Back" onclick="history.back();">
<input type="button" value="Clear" onclick="clearForm();">
<input type="button" value="Search Now" onclick="document.frm.searchNow.value='true'; document.frm.submit();">
<input type="submit" value="Next &gt;"  onclick="document.frm.searchNow.value='';">
<input type="hidden" name="searchNow">
</td>
</tr>

<tr>
<td></td>
<td>
Go to: <select name="jumpTo">
<option value=""></option>
<option value="basic">Basic Criteria</option>
<option value="">----------</option>
<option value="responsibility">Responsibility</option>
<option value="dates">Priority and Dates</option>
<option value="misc">Other Criteria</option>
<option value="status">Workflow Status</option>
<option value="output">Output Options</option>
</select>
<input type="button" value="Go" onclick="document.frm.submit();">
</td>
</tr>

</table>
</form>
</body>
</html>
