<?php

/*
  search7.php - options for output/display of search results
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-12-12
  Last modified: 2007-04-11

  Receives data from: search6.php
  Submits data to: search8.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'Search - Output Options';

// connect to db
$connection = connect();

//-------------------------------------
// process form data from previous page
//-------------------------------------

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// book scanning status
if ( isset($bookScanning) ) {
  if ( empty($bookScanning) ) {
    unset($_SESSION['searchText']['bookScanning']);
    unset($_SESSION['searchText']['bookScanningMode']);
    unset($_SESSION['searchTextSql']['bookScanning']);
  } else {
    $_SESSION['searchText']['bookScanning'] = $bookScanning;
    $_SESSION['searchText']['bookScanningMode'] = $bookScanningMode;
    switch ($bookScanning) {
      case 'scanPages':
	if ($bookScanningMode == 'finished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND scanPages = 1";
	} elseif ($bookScanningMode == 'notFinished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND scanPages = 0";
	} else {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND (scanPages = 0 AND sendToVendor = 0)";
	}
	break;
      case 'scanFigures':
	if ($bookScanningMode == 'finished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND scanFigures = 1";
	} elseif ($bookScanningMode == 'notFinished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND scanFigures = 0";
	} else {
	  $_SESSION['searchTextSql']['bookScanning'] = 
	    " AND (scanPages = 1 AND scanFigures = 0 AND sendToVendor = 0)";
	}
	break;
      case 'renameFigureScans':
	if ($bookScanningMode == 'finished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND renameFigureScans = 1";
	} elseif ($bookScanningMode == 'notFinished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND renameFigureScans = 0";
	} else {
	  $_SESSION['searchTextSql']['bookScanning'] = 
	    " AND (scanFigures = 1 AND renameFigureScans = 0 AND sendToVendor = 0)";
	}
	break;
      case 'fixPageScans':
	if ($bookScanningMode == 'finished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND fixPageScans = 1";
	} elseif ($bookScanningMode == 'notFinished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND fixPageScans = 0";
	} else {
	  $_SESSION['searchTextSql']['bookScanning'] = 
	    " AND (scanPages = 1 AND fixPageScans = 0 AND sendToVendor = 0)";
	}
	break;
      case 'makeRescans':
        if ($bookScanningMode == 'finished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND makeRescans = 1";
        } elseif ($bookScanningMode == 'notFinished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND makeRescans = 0";
        } else {
	  $_SESSION['searchTextSql']['bookScanning'] = 
	    " AND (fixPageScans = 1 AND makeRescans = 0 AND sendToVendor = 0)";
	}
	break;
      case 'proof':
        if ($bookScanningMode == 'finished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND proof = 1";
        } elseif ($bookScanningMode == 'notFinished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND proof = 0";
        } else {
	  // 'makeRescans' is optional, so use 'fixPageScans' as preceding finished step
	  $_SESSION['searchTextSql']['bookScanning'] = 
	    " AND (fixPageScans = 1 AND proof = 0 AND sendToVendor = 0)";
	}
	break;
      case 'makeWebImages':
        if ($bookScanningMode == 'finished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND makeWebImages = 1";
        } elseif ($bookScanningMode == 'notFinished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND makeWebImages = 0";
        } else {
	  $_SESSION['searchTextSql']['bookScanning'] = 
	    " AND (proof = 1 AND makeWebImages = 0 AND sendToVendor = 0)";
	}
	break;
      case 'zip':
        if ($bookScanningMode == 'finished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND zip = 1";
        } elseif ($bookScanningMode == 'notFinished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND zip = 0";
        } else {
	  $_SESSION['searchTextSql']['bookScanning'] =
	    " AND (makeWebImages = 1 AND zip = 0 AND sendToVendor = 0)";
	}
	break;
      case 'sendToVendor':
        if ($bookScanningMode == 'finished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND sendToVendor = 1";
        } elseif ($bookScanningMode == 'notFinished') {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND sendToVendor = 0";
        } else {
	  $_SESSION['searchTextSql']['bookScanning'] = " AND (zip = 1 AND sendToVendor = 0)";
	}
	break;
      case 'finished':
	$_SESSION['searchTextSql']['bookScanning'] = " AND sendToVendor = 1";
	break;
      case 'notFinished':
	$_SESSION['searchTextSql']['bookScanning'] = " AND sendToVendor = 0";
	break;
      default:
	unset($_SESSION['searchText']['bookScanning']);
	unset($_SESSION['searchTextSql']['bookScanning']);
    }
  }
}

// migration status
if ( isset($migration) ) {
  if (empty($migration)) {
    unset($_SESSION['searchText']['migration']);
    unset($_SESSION['searchText']['migrationMode']);
    unset($_SESSION['searchTextSql']['migration']);
  } else {
    $_SESSION['searchText']['migration'] = $migration;
    $_SESSION['searchText']['migrationMode'] = $migrationMode;
    switch ($migration) {
      case 'loadFiles':
        if ($migrationMode == 'finished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.loadFiles = 1";
        } elseif ($migrationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.loadFiles = 0";
        } else {
	  $_SESSION['searchTextSql']['migration'] =
	    " AND (migration.loadFiles = 0 AND bookScanning.makeWebImages = 0)";
	}
	break;
      case 'requestRescans':
        if ($migrationMode == 'finished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.requestRescans = 1";
        } elseif ($migrationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.requestRescans = 0";
        } else {
	  $_SESSION['searchTextSql']['migration'] = 
	  " AND (migration.loadFiles = 1 AND migration.requestRescans = 0 AND bookScanning.makeWebImages = 0)";
	}
	break;
      case 'makeRescans':
        if ($migrationMode == 'finished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.makeRescans = 1";
        } elseif ($migrationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.makeRescans = 0";
        } else {
	  $_SESSION['searchTextSql']['migration'] = 
	    " AND (migration.requestRescans = 1 AND migration.makeRescans = 0 AND"
	    . " bookScanning.makeWebImages = 0)";
	}
	break;
      case 'insertRescans':
        if ($migrationMode == 'finished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.insertRescans = 1";
        } elseif ($migrationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.insertRescans = 0";
        } else {
	  $_SESSION['searchTextSql']['migration'] = 
	    " AND (migration.makeRescans = 1 AND migration.insertRescans = 0 AND"
	    . " bookScanning.makeWebImages = 0)";
	}
	break;
      case 'renameImageFiles':
        if ($migrationMode == 'finished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.renameImageFiles = 1";
        } elseif ($migrationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.renameImageFiles = 0";
        } else {
	  // rescanning steps are optional, so use 'loadFiles' as preceding finished step
	  $_SESSION['searchTextSql']['migration'] = 
	    " AND (migration.loadFiles = 1 AND migration.renameImageFiles = 0 AND"
	    . " bookScanning.makeWebImages = 0)";
	}
	break;
      case 'photoshopScripts':
        if ($migrationMode == 'finished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.photoshopScripts = 1";
        } elseif ($migrationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.photoshopScripts = 0";
        } else {
	  $_SESSION['searchTextSql']['migration'] = 
	    " AND (migration.renameImageFiles = 1 AND migration.photoshopScripts = 0 AND"
	    . " bookScanning.makeWebImages = 0)";
	}
	break;
      case 'proof':
        if ($migrationMode == 'finished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.proof = 1";
        } elseif ($migrationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['migration'] = " AND migration.proof = 0";
        } else {
	  $_SESSION['searchTextSql']['migration'] = 
	    " AND (migration.photoshopScripts = 1 AND migration.proof = 0 AND bookScanning.makeWebImages = 0)";
	}
	break;
      case 'makeWebImages':
        if ($migrationMode == 'finished') {
	  $_SESSION['searchTextSql']['migration'] = " AND bookScanning.makeWebImages = 1";
        } elseif ($migrationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['migration'] = " AND bookScanning.makeWebImages = 0";
        } else {
	  $_SESSION['searchTextSql']['migration'] = 
	    " AND (migration.proof = 1 AND bookScanning.makeWebImages = 0)";
	}
	break;
      case 'finished':
	$_SESSION['searchTextSql']['migration'] = " AND bookScanning.makeWebImages = 1";
	break;
      case 'notFinished':
	$_SESSION['searchTextSql']['migration'] = " AND bookScanning.makeWebImages = 0";
	break;
      default:
	unset($_SESSION['searchText']['migration']);
	unset($_SESSION['searchTextSql']['migration']);
    }
  }
}

// page book status
if ( isset($pageBook) ) {
  if (empty($pageBook)) {
    unset($_SESSION['searchText']['pageBook']);
    unset($_SESSION['searchText']['pageBookMode']);
    unset($_SESSION['searchTextSql']['pageBook']);
  } else {
    $_SESSION['searchText']['pageBook'] = $pageBook;
    $_SESSION['searchText']['pageBookMode'] = $pageBookMode;
    switch ($pageBook) {
      case 'scanPages':
        if ($pageBookMode == 'finished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.scanPages = 1";
        } elseif ($pageBookMode == 'notFinished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.scanPages = 0";
        } else {
	  $_SESSION['searchTextSql']['pageBook'] =
	    " AND (pageBook.scanPages = 0 AND pageBook.finalize = 0)";
	}
	break;
      case 'runScripts':
        if ($pageBookMode == 'finished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.runScripts = 1";
        } elseif ($pageBookMode == 'notFinished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.runScripts = 0";
        } else {
	  $_SESSION['searchTextSql']['pageBook'] = 
	  " AND (pageBook.scanPages = 1 AND pageBook.runScripts = 0 AND pageBook.finalize = 0)";
	}
	break;
      case 'makeWebImages':
        if ($pageBookMode == 'finished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.makeWebImages = 1";
        } elseif ($pageBookMode == 'notFinished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.makeWebImages = 0";
        } else {
	  $_SESSION['searchTextSql']['pageBook'] = 
	    " AND (pageBook.runScripts = 1 AND pageBook.makeWebImages = 0 AND pageBook.finalize = 0)";
	}
	break;
      case 'qaImages':
        if ($pageBookMode == 'finished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.qaImages = 1";
        } elseif ($pageBookMode == 'notFinished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.qaImages = 0";
        } else {
	  $_SESSION['searchTextSql']['pageBook'] = 
	    " AND (pageBook.makeWebImages = 1 AND pageBook.qaImages = 0 AND pageBook.finalize = 0)";
	}
	break;
      case 'makeDerivatives':
        if ($pageBookMode == 'finished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.makeDerivatives = 1";
        } elseif ($pageBookMode == 'notFinished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.makeDerivatives = 0";
        } else {
	  // rescanning steps are optional, so use 'loadFiles' as preceding finished step
	  $_SESSION['searchTextSql']['pageBook'] = 
	    " AND (pageBook.qaImages = 1 AND pageBook.makeDerivatives = 0 AND pageBook.finalize = 0)";
	}
	break;
      case 'makePDF':
        if ($pageBookMode == 'finished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.makePDF = 1";
        } elseif ($pageBookMode == 'notFinished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.makePDF = 0";
        } else {
	  $_SESSION['searchTextSql']['pageBook'] = 
	    " AND (pageBook.makeDerivatives = 1 AND pageBook.makePDF = 0 AND pageBook.finalize = 0)";
	}
	break;
      case 'finalize':
        if ($pageBookMode == 'finished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.finalize = 1";
        } elseif ($pageBookMode == 'notFinished') {
	  $_SESSION['searchTextSql']['pageBook'] = " AND pageBook.finalize = 0";
        } else {
	  $_SESSION['searchTextSql']['pageBook'] = 
	    " AND (pageBook.makePDF = 1 AND pageBook.finalize = 0)";
	}
	break;
      case 'finished':
	$_SESSION['searchTextSql']['pageBook'] = " AND pageBook.finalize = 1";
	break;
      case 'notFinished':
	$_SESSION['searchTextSql']['pageBook'] = " AND pageBook.finalize = 0";
	break;
      default:
	unset($_SESSION['searchText']['pageBook']);
	unset($_SESSION['searchTextSql']['pageBook']);
    }
  }
}

// TEI header status
if ( isset($teiHeader) ) {
  if ( empty($teiHeader) ) {
    unset($_SESSION['searchText']['teiHeader']);
    unset($_SESSION['searchText']['teiHeaderMode']);
    unset($_SESSION['searchTextSql']['teiHeader']);
  } else {
    $_SESSION['searchText']['teiHeader'] = $teiHeader;
    $_SESSION['searchText']['teiHeaderMode'] = $teiHeaderMode;
    switch ($teiHeader) {
      case 'reviewMarc':
        if ($teiHeaderMode == 'finished') {
	  $_SESSION['searchTextSql']['teiHeader'] = " AND reviewMarc = 1";
        } elseif ($teiHeaderMode == 'notFinished') {
	  $_SESSION['searchTextSql']['teiHeader'] = " AND reviewMarc = 0";
        } else {
	  $_SESSION['searchTextSql']['teiHeader'] = " AND (reviewMarc = 0 AND reviewTeiHeader = 0)";
	}
	break;
      case 'exportMarc':
        if ($teiHeaderMode == 'finished') {
	  $_SESSION['searchTextSql']['teiHeader'] = " AND exportMarc = 1";
        } elseif ($teiHeaderMode == 'notFinished') {
	  $_SESSION['searchTextSql']['teiHeader'] = " AND exportMarc = 0";
        } else {
	  $_SESSION['searchTextSql']['teiHeader'] = 
	    " AND (reviewMarc = 1 AND exportMarc = 0 AND reviewTeiHeader = 0)";
	}
	break;
      case 'makeTeiHeader':
        if ($teiHeaderMode == 'finished') {
	  $_SESSION['searchTextSql']['teiHeader'] = " AND makeTeiHeader = 1";
        } elseif ($teiHeaderMode == 'notFinished') {
	  $_SESSION['searchTextSql']['teiHeader'] = " AND makeTeiHeader = 0";
        } else {
	  $_SESSION['searchTextSql']['teiHeader'] = 
	    " AND (exportMarc = 1 AND makeTeiHeader = 0 AND reviewTeiHeader = 0)";
	}
	break;
      case 'reviewTeiHeader':
        if ($teiHeaderMode == 'finished') {
	  $_SESSION['searchTextSql']['teiHeader'] = " AND reviewTeiHeader = 1";
        } elseif ($teiHeaderMode == 'notFinished') {
	  $_SESSION['searchTextSql']['teiHeader'] = " AND reviewTeiHeader = 0";
        } else {
	  $_SESSION['searchTextSql']['teiHeader'] = " AND (makeTeiHeader = 1 AND reviewTeiHeader = 0)";
	}
	break;
      case 'finished':
	$_SESSION['searchTextSql']['teiHeader'] = " AND reviewTeiHeader = 1";
	break;
      case 'notFinished':
	$_SESSION['searchTextSql']['teiHeader'] = " AND reviewTeiHeader = 0";
	break;
      default:
	unset($_SESSION['searchText']['teiHeader']);
	unset($_SESSION['searchTextSql']['teiHeader']);
    }
  }
}

// post-keyboarding status
if ( isset($postkb) ) {
  if ( empty($postkb) ) {
    unset($_SESSION['searchText']['postkb']);
    unset($_SESSION['searchText']['postkbMode']);
    unset($_SESSION['searchTextSql']['postkb']);
  } else {
    $_SESSION['searchText']['postkb'] = $postkb;
    $_SESSION['searchText']['postkbMode'] = $postkbMode;
    switch ($postkb) {
      case 'download':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND download = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND download = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = " AND (download = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'validate':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND validate = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND validate = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = 
	    " AND (download = 1 AND validate = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'fixVendorProblems':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND fixVendorProblems = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND fixVendorProblems = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = 
	    " AND (validate = 1 AND fixVendorProblems = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'runScripts':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND runScripts = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND runScripts = 0";
        } else {
	  // 'fixVendorProblems' is optional, so use 'validate' as preceding finished step
	  $_SESSION['searchTextSql']['postkb'] = 
	    " AND (validate = 1 AND runScripts = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'syncPages':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND syncPages = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND syncPages = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = 
	    " AND (runScripts = 1 AND syncPages = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'generateReports':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND generateReports = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND generateReports = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = 
	    " AND (syncPages = 1 AND generateReports = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'submitRehyphenateReport':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND submitRehyphenateReport = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND submitRehyphenateReport = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = 
	    " AND (generateReports = 1 AND submitRehyphenateReport = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'commitRehyphenateChanges':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND commitRehyphenateChanges = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND commitRehyphenateChanges = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = " AND (submitRehyphenateReport = 1"
	    . " AND commitRehyphenateChanges = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'submitUnclearsReport':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND submitUnclearsReport = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND submitUnclearsReport = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = 
	    " AND (generateReports = 1 AND submitUnclearsReport = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'commitUnclearsChanges':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND commitUnclearsChanges = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND commitUnclearsChanges = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = 
	    " AND (submitUnclearsReport = 1 AND commitUnclearsChanges = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'submitFiguresRendReport':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND submitFiguresRendReport = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND submitFiguresRendReport = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = 
	    " AND (generateReports = 1 AND submitFiguresRendReport = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'commitFiguresRendChanges':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND commitFiguresRendChanges = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND commitFiguresRendChanges = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = 
	    " AND (submitFiguresRendReport = 1 AND commitFiguresRendChanges = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'generateFiguresFilenamesReport':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND generateFiguresFilenamesReport = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND generateFiguresFilenamesReport = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = " AND (commitFiguresRendChanges = 1"
	    . " AND generateFiguresFilenamesReport = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'submitFiguresFilenamesReport':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND submitFiguresFilenamesReport = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND submitFiguresFilenamesReport = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = " AND (generateFiguresFilenamesReport = 1"
	    . " AND submitFiguresFilenamesReport = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'commitFiguresFilenamesChanges':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND commitFiguresFilenamesChanges = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND commitFiguresFilenamesChanges = 0";
        } else {
	  $_SESSION['searchTextSql']['postkb'] = " AND (submitFiguresFilenamesReport = 1"
	    . " AND commitFiguresFilenamesChanges = 0 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'copyToDoneDir':
        if ($postkbMode == 'finished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND postkb.copyToDoneDir = 1";
        } elseif ($postkbMode == 'notFinished') {
	  $_SESSION['searchTextSql']['postkb'] = " AND postkb.copyToDoneDir = 0";
        } else {
	  // preceding non-optional step is 'commitRehyphenateChanges'
	  $_SESSION['searchTextSql']['postkb'] = 
	    " AND (commitRehyphenateChanges = 1 AND postkb.copyToDoneDir = 0)";
	}
	break;
      case 'finished':
	$_SESSION['searchTextSql']['postkb'] = " AND postkb.copyToDoneDir = 1";
	break;
      case 'notFinished':
	$_SESSION['searchTextSql']['postkb'] = " AND postkb.copyToDoneDir = 0";
	break;
      default:
	unset($_SESSION['searchText']['postkb']);
	unset($_SESSION['searchTextSql']['postkb']);
    }
  }
}

// markup QA status
if ( isset($markupQA) ) {
  if ( empty($markupQA) ) {
    unset($_SESSION['searchText']['markupQA']);
    unset($_SESSION['searchText']['markupQAMode']);
    unset($_SESSION['searchTextSql']['markupQA']);
  } else {
    $_SESSION['searchText']['markupQA'] = $markupQA;
    $_SESSION['searchText']['markupQAMode'] = $markupQAMode;
    switch ($markupQA) {
      case 'findUnclosedUnclears':
        if ($markupQAMode == 'finished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND findUnclosedUnclears = 1";
        } elseif ($markupQAMode == 'notFinished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND findUnclosedUnclears = 0";
        } else {
	  $_SESSION['searchTextSql']['markupQA'] = 
	    " AND (findUnclosedUnclears = 0 AND markupQA.copyToDoneDir = 0)";
	}
	break;
      case 'fixUnknownChars':
        if ($markupQAMode == 'finished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND fixUnknownChars = 1";
        } elseif ($markupQAMode == 'notFinished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND fixUnknownChars = 0";
        } else {
	  $_SESSION['searchTextSql']['markupQA'] = 
	    " AND (findUnclosedUnclears = 1 AND fixUnknownChars = 0 AND markupQA.copyToDoneDir = 0)";
	}
	break;
      case 'addPropertySheet':
        if ($markupQAMode == 'finished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND addPropertySheet = 1";
        } elseif ($markupQAMode == 'notFinished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND addPropertySheet = 0";
        } else {
	  $_SESSION['searchTextSql']['markupQA'] = 
	    " AND (fixUnknownChars = 1 AND addPropertySheet = 0 AND markupQA.copyToDoneDir = 0)";
	}
	break;
      case 'updateTeiHeader':
        if ($markupQAMode == 'finished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND updateTeiHeader = 1";
        } elseif ($markupQAMode == 'notFinished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND updateTeiHeader = 0";
        } else {
	  $_SESSION['searchTextSql']['markupQA'] = 
	    " AND (addPropertySheet = 1 AND updateTeiHeader = 0 AND markupQA.copyToDoneDir = 0)";
	}
	break;
      case 'fixDivStructures':
        if ($markupQAMode == 'finished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND fixDivStructures = 1";
        } elseif ($markupQAMode == 'notFinished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND fixDivStructures = 0";
        } else {
	  $_SESSION['searchTextSql']['markupQA'] = 
	    " AND (updateTeiHeader = 1 AND fixDivStructures = 0 AND markupQA.copyToDoneDir = 0)";
	}
	break;
      case 'updateNotes':
        if ($markupQAMode == 'finished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND updateNotes = 1";
        } elseif ($markupQAMode == 'notFinished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND updateNotes = 0";
        } else {
	  $_SESSION['searchTextSql']['markupQA'] = 
	    " AND (fixDivStructures = 1 AND updateNotes = 0 AND markupQA.copyToDoneDir = 0)";
	}
	break;
      case 'runCommandLinePrograms':
        if ($markupQAMode == 'finished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND runCommandLinePrograms = 1";
        } elseif ($markupQAMode == 'notFinished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND runCommandLinePrograms = 0";
        } else {
	  $_SESSION['searchTextSql']['markupQA'] = 
	    " AND (updateNotes = 1 AND runCommandLinePrograms = 0 AND markupQA.copyToDoneDir = 0)";
	}
	break;
      case 'runWebPrograms':
        if ($markupQAMode == 'finished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND runWebPrograms = 1";
        } elseif ($markupQAMode == 'notFinished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND runWebPrograms = 0";
        } else {
	  $_SESSION['searchTextSql']['markupQA'] = 
	    " AND (runCommandLinePrograms = 1 AND runWebPrograms = 0 AND markupQA.copyToDoneDir = 0)";
	}
	break;
      case 'spellcheck':
        if ($markupQAMode == 'finished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND spellcheck = 1";
        } elseif ($markupQAMode == 'notFinished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND spellcheck = 0";
        } else {
	  $_SESSION['searchTextSql']['markupQA'] = 
	    " AND (runWebPrograms = 1 AND spellcheck = 0 AND markupQA.copyToDoneDir = 0)";
	}
	break;
      case 'copyToDoneDir':
        if ($markupQAMode == 'finished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND markupQA.copyToDoneDir = 1";
        } elseif ($markupQAMode == 'notFinished') {
	  $_SESSION['searchTextSql']['markupQA'] = " AND markupQA.copyToDoneDir = 0";
        } else {
	  // preceding non-optional step is 'runWebPrograms'
	  $_SESSION['searchTextSql']['markupQA'] = " AND (runWebPrograms = 1 AND markupQA.copyToDoneDir = 0)";
	}
	break;
      case 'finished':
	$_SESSION['searchTextSql']['markupQA'] = " AND markupQA.copyToDoneDir = 1";
	break;
      case 'notFinished':
	$_SESSION['searchTextSql']['markupQA'] = " AND markupQA.copyToDoneDir = 0";
	break;
      default:
	unset($_SESSION['searchText']['markupQA']);
	unset($_SESSION['searchTextSql']['markupQA']);
    }
  }
}

// finalization status
if ( isset($finalization) ) {
  if ( empty($finalization) ) {
    unset($_SESSION['searchText']['finalization']);
    unset($_SESSION['searchText']['finalizationMode']);
    unset($_SESSION['searchTextSql']['finalization']);
  } else {
    $_SESSION['searchText']['finalization'] = $finalization;
    $_SESSION['searchText']['finalizationMode'] = $finalizationMode;
    switch ($finalization) {
      case 'replaceHeader':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND replaceHeader = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND replaceHeader = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = " AND (replaceHeader = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'updateIssueData':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND updateIssueData = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND updateIssueData = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (replaceHeader = 1 AND updateIssueData = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'refreshFileSize':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND refreshFileSize = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND refreshFileSize = 0";
        } else {
	  // 'updateIssueData' is optional, so use 'replaceHeader' as preceding finished step
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (replaceHeader = 1 AND refreshFileSize = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'qaHeader':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND qaHeader = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND qaHeader = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (refreshFileSize = 1 AND qaHeader = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'runHeaderReport':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND runHeaderReport = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND runHeaderReport = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (qaHeader = 1 AND runHeaderReport = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'to70fullheaders_added':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND to70fullheaders_added = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND to70fullheaders_added = 0";
        } else {
	  // 'runHeaderReport' is optional, so use 'qaHeader' as preceding finished step
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (qaHeader = 1 AND to70fullheaders_added = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'restoreChars':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND restoreChars = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND restoreChars = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (to70fullheaders_added = 1 AND restoreChars = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'replacePaths':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND replacePaths = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND replacePaths = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (restoreChars = 1 AND replacePaths = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'verifyImages':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND verifyImages = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND verifyImages = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (replacePaths = 1 AND verifyImages = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'addPids':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND addPids = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND addPids = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (verifyImages = 1 AND addPids = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'qaProgram':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND qaProgram = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND qaProgram = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (addPids = 1 AND qaProgram = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'validate':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND validate = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND validate = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (qaProgram = 1 AND validate = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'to80final':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND to80final = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND to80final = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (validate = 1 AND to80final = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'dlps2ReadyRepo':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND dlps2ReadyRepo = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND dlps2ReadyRepo = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (to80final = 1 AND dlps2ReadyRepo = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'verifyImagesReadyRepo':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND verifyImagesReadyRepo = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND verifyImagesReadyRepo = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (dlps2ReadyRepo = 1 AND verifyImagesReadyRepo = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'pogo2archive':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND pogo2archive = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND pogo2archive = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] = 
	    " AND (verifyImagesReadyRepo = 1 AND pogo2archive = 0 AND runCleanupScript = 0)";
	}
	break;
      case 'runCleanupScript':
        if ($finalizationMode == 'finished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND runCleanupScript = 1";
        } elseif ($finalizationMode == 'notFinished') {
	  $_SESSION['searchTextSql']['finalization'] = " AND runCleanupScript = 0";
        } else {
	  $_SESSION['searchTextSql']['finalization'] =
	    " AND (pogo2archive = 1 AND runCleanupScript = 0)";
	}
	break;
      case 'finished':
        $_SESSION['searchTextSql']['finalization'] = " AND runCleanupScript = 1";
	break;
      case 'notFinished':
	$_SESSION['searchTextSql']['finalization'] = " AND runCleanupScript = 0";
	break;
      default:
	unset($_SESSION['searchText']['finalization']);
	unset($_SESSION['searchTextSql']['finalization']);
    }
  }
}

// finished status
if ( isset($isFinished) ) {
  if ($isFinished == '0' or $isFinished == '1') {
    $_SESSION['searchText']['isFinished'] = $isFinished;
    $_SESSION['searchTextSql']['isFinished'] = " AND isFinished = $isFinished";
  } else {
    unset($_SESSION['searchText']['isFinished']);
    unset($_SESSION['searchTextSql']['isFinished']);
  }
}

// redirect to search form, if immediate search was requested
if ($searchNow) {
  header('Location: search.php');
  exit;
}

// redirect to another search page, if requested
if ($jumpTo) {
  $url = getJumpToUrl($jumpTo);
  if ($url != 'search7.php') {
    header("Location: $url");
    exit;
  }
}


//---------------------------
// display form for this page
//---------------------------
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="GET" action="search8.php">
<table cellpadding="4">

<tr>
<td colspan="4"><!--<strong>1</strong> -->Indicate which columns to display in the output.</td>
</tr>

<?php
// set output defaults if necessary
if (!isset($_SESSION['searchTextOutput'])) {
  setSearchTextOutputDefaults();
}

if (isset($_SESSION['searchTextOutput']['useSearchColumns'])) {
  if ($_SESSION['searchTextOutput']['useSearchColumns']) {
    $checked = ' checked';  $checked2 = '';
  } else {
    $checked = '';  $checked2 = ' checked';
  }
} else {
  $checked = ' checked';  $checked2 = '';
}
?>
<tr>
<td width="15">&nbsp;</td>
<td class="label">Search-related columns:</td>
<td colspan="2">
<input type="radio" name="useSearchColumns" value="1"<?=$checked?>>
Display columns used in search criteria, in addition to those specified below <br>
<input type="radio" name="useSearchColumns" value=""<?=$checked2?>>
Only display the columns specified below
</td>
</tr>

<?php
if ($_SESSION['searchTextOutput']['dlpsId']) { $dlpsIdSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['title']) { $titleSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['authorNameLast']) { $authorNameLastSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['virgoId']) { $virgoIdSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['titleControlNumber']) { $titleControlNumberSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['callNumber']) { $callNumberSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['pageImagesType']) { $pageImagesTypeSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['pageImagesRespId']) { $pageImagesRespIdSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['pageCount']) { $pageCountSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['hasFigureImages']) { $hasFigureImagesSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['transcriptionType']) { $transcriptionTypeSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['hasIndependentHeader']) { $hasIndependentHeaderSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['transcriptionRespId']) { $transcriptionRespIdSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['setId']) { $setIdSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['projectId']) { $projectIdSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['groupId']) { $groupIdSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['batchId']) { $batchIdSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['selectorId']) { $selectorIdSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['requestorId']) { $requestorIdSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['priority']) { $prioritySelected = ' selected'; }
if ($_SESSION['searchTextOutput']['itemType']) { $itemTypeSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['genre']) { $genreSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['publicationYear']) { $publicationYearSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['access']) { $accessSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['dateReceived']) { $dateReceivedSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['notes']) { $notesSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['forRepo']) { $forRepoSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['forInternalUseOnly']) { $forInternalUseOnlySelected = ' selected'; }
if ($_SESSION['searchTextOutput']['isArchived']) { $isArchivedSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['isFinished']) { $isFinishedSelected = ' selected'; }
if ($_SESSION['searchTextOutput']['dateFinished']) { $dateFinishedSelected = ' selected'; }

echo <<<EOD
<tr>
<td></td>
<td class="label">Other columns:</td>
<td colspan="2"><select name="columns[]" size="10" multiple>
<option value="dlpsId"$dlpsIdSelected>DLPS ID</option>
<option value="itemType"$itemTypeSelected>Item type</option>
<option value="virgoId"$virgoIdSelected>Virgo ID</option>
<option value="titleControlNumber"$titleControlNumberSelected>Title control number</option>
<option value="callNumber"$callNumberSelected>Call number</option>
<option value="title"$titleSelected>Title</option>
<option value="authorNameLast"$authorNameLastSelected>Author</option>
<option value="">----------</option>
<option value="pageImagesType"$pageImagesTypeSelected>Page image type</option>
<option value="pageImagesRespId"$pageImagesRespIdSelected>Page image creator</option>
<option value="pageCount"$pageCountSelected>Page image count</option>
<option value="hasFigureImages"$hasFigureImagesSelected>Has figure images?</option>
<option value="transcriptionType"$transcriptionTypeSelected>Transcription type</option>
<option value="transcriptionRespId"$transcriptionRespIdSelected>Transcription creator</option>
<option value="">----------</option>
<option value="setId"$setIdSelected>Multi-volume set</option>
<option value="projectId"$projectIdSelected>Project</option>
<option value="groupId"$groupIdSelected>Group</option>
<option value="batchId"$batchIdSelected>Vendor batch</option>
<option value="selectorId"$selectorIdSelected>Selector</option>
<option value="requestorId"$requestorIdSelected>Requestor</option>
<option value="">----------</option>
<option value="priority"$prioritySelected>Priority</option>
<option value="genre"$genreSelected>Genre</option>
<option value="publicationYear"$publicationYearSelected>Year of publication</option>
<option value="access"$accessSelected>Access</option>
<option value="dateReceived"$dateReceivedSelected>Date received</option>
<option value="notes"$notesSelected>Notes</option>
<option value="hasIndependentHeader"$hasIndependentHeaderSelected>Has independent header?</option>
<option value="forRepo"$forRepoSelected>Destined for repository?</option>
<option value="forInternalUseOnly"$forInternalUseOnlySelected>For internal use only?</option>
<option value="isArchived"$isArchivedSelected>Archived?</option>
<option value="isFinished"$isFinishedSelected>Finished?</option>
<option value="dateFinished"$dateFinishedSelected>Date finished</option>
</select></td>
</tr>
EOD;
?>

<?php
if (false) {  // HIDE THIS SECTION
?>

<tr>
<td colspan="4"><strong>2</strong> Select an initial sorting order.</td>
</tr>

<tr>
<td></td>
<td class="label">Sort by:</td>
<td colspan="2"><select name="orderBy">
<?php
$selected = '';
if ($_SESSION['searchTextOutput']['orderBy'] == 'dlpsId') {
  $selected = ' selected';
}
echo "<option value='dlpsId'$selected>DLPS ID</option>\n";

$selected = '';
if ($_SESSION['searchTextOutput']['orderBy'] == 'title') {
  $selected = ' selected';
}
echo "<option value='title'$selected>Title</option>\n";

$selected = '';
if ($_SESSION['searchTextOutput']['orderBy'] == 'dateReceived') {
  $selected = ' selected';
}
echo "<option value='dateReceived'$selected>Date received</option>\n";
?>
</select></td>
</tr>

<?php
}  // END if (false) {
?>

<tr>
<td></td>
<td></td>
<td colspan="2">
<input type="button" value="&lt; Back" onclick="history.back();">
<input type="reset" value="Reset">
<input type="submit" value="Search &gt;">
</td>
</tr>

<tr>
<td></td>
<td></td>
<td colspan="2">
Go to: <select name="jumpTo">
<option value=""></option>
<option value="basic">Basic Criteria</option>
<option value="groupings">Groupings</option>
<option value="responsibility">Responsibility</option>
<option value="dates">Priority and Dates</option>
<option value="misc">Other Criteria</option>
<option value="status">Workflow Status</option>
</select>
<input type="button" value="Go" onclick="document.frm.submit();">
</td>
</tr>

</table>
</form>
</body>
</html>
