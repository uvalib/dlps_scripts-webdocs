<?php

/*
  search3.php - third page of Search Assistant - responsibility
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-09-12
  Last modified: 2005-12-19

  Receives data from: search2.php
  Submits data to: search4.php
*/

import_request_variables('G');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'Search - Responsibility';

// connect to db
$connection = connect();

// get associative array representing table 'selectors'
$selectors = getHashSelectors($connection);

// get associative array representing table 'requestors'
$requestors = getHashRequestors($connection);

// get associative array representing table 'pageImagesResps'
$pageImagesResps = getHashPageImagesResps($connection);

// get associative array representing table 'transcriptionResps'
$transcriptionResps = getHashTranscriptionResps($connection);

//-------------------------------------
// process form data from previous page
//-------------------------------------

if ($clear) {
  unset($_SESSION['searchText']);
  unset($_SESSION['searchTextSql']);
}

// note: it's ok to put AND directly in each search phrase; later the initial ' AND', if any, will be removed

// set
if ( isset($setId) ) {
  if ( empty($setId) ) {
    unset($_SESSION['searchText']['setId']);
    unset($_SESSION['searchTextSql']['setId']);
  } else {
    $_SESSION['searchText']['setId'] = $setId;
    $_SESSION['searchTextSql']['setId'] = ' AND ';
    if ($setId == 'any') {
      // select items from any set
      $_SESSION['searchTextSql']['setId'] .= 'setId != 0';
    } elseif ($setId == 'none') {
      // select items not assigned to a set
      $_SESSION['searchTextSql']['setId'] .= 'setId = 0';
    } elseif ($setId == 'not9') {
      // select items not assigned set 9, UVa Record
      $_SESSION['searchTextSql']['setId'] .= 'setId != 9';
    } else {
      $_SESSION['searchTextSql']['setId'] .= "setId = $setId";
    }
  }
}

// project
if ( isset($projectId) ) {
  if ( empty($projectId) ) {
    unset($_SESSION['searchText']['projectId']);
    unset($_SESSION['searchTextSql']['projectId']);
  } else {
    $_SESSION['searchText']['projectId'] = $projectId;
    $_SESSION['searchTextSql']['projectId'] = ' AND ';
    if ($projectId == 'any') {
      $_SESSION['searchTextSql']['projectId'] .= 'projectId != 0';
    } elseif ($projectId == 'none') {
      $_SESSION['searchTextSql']['projectId'] .= 'projectId = 0';
    } else {
      $_SESSION['searchTextSql']['projectId'] .= "projectId = $projectId";
    }
  }
}

// group
if ( isset($groupId) ) {
  if ( empty($groupId) ) {
    unset($_SESSION['searchText']['groupId']);
    unset($_SESSION['searchTextSql']['groupId']);
  } else {
    $_SESSION['searchText']['groupId'] = $groupId;
    $_SESSION['searchTextSql']['groupId'] = ' AND ';
    if ($groupId == 'any') {
      $_SESSION['searchTextSql']['groupId'] .= 'groupId != 0';
    } elseif ($groupId == 'none') {
      $_SESSION['searchTextSql']['groupId'] .= 'groupId = 0';
    } else {
      $_SESSION['searchTextSql']['groupId'] .= "groupId = $groupId";
    }
  }
}

// batch
if ( isset($batchId) ) {
  if ( empty($batchId) ) {
    unset($_SESSION['searchText']['batchId']);
    unset($_SESSION['searchTextSql']['batchId']);
  } else {
    $_SESSION['searchText']['batchId'] = $batchId;
    $_SESSION['searchTextSql']['batchId'] = ' AND ';
    if ($batchId == 'any') {
      $_SESSION['searchTextSql']['batchId'] .= 'batchId != 0';
    } elseif ($batchId == 'none') {
      $_SESSION['searchTextSql']['batchId'] .= 'batchId = 0';
    } else {
      $_SESSION['searchTextSql']['batchId'] .= "batchId = $batchId";
    }
  }
}

// redirect to search form, if immediate search was requested
if ($searchNow) {
  header('Location: search.php');
  exit;
}

// redirect to another search page, if requested
if ($jumpTo) {
  $url = getJumpToUrl($jumpTo);
  if ($url != 'search3.php') {
    header("Location: $url");
    exit;
  }
}


//---------------------------
// display form for this page
//---------------------------
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="GET" action="search4.php">
<table cellpadding="4">

<tr>
<td class="label">Selector:</td>
<td><select name="selectorId">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['selectorId'] == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items from any selector</option>\n";

$selected = '';
if ($_SESSION['searchText']['selectorId'] == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not from a selector</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($selectors as $id => $name) {
  $selected = '';
  if ( $id == $_SESSION['searchText']['selectorId'] ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td class="label">Requestor:</td>
<td><select name="requestorId">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['requestorId'] == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items from any requestor</option>\n";

$selected = '';
if ($_SESSION['searchText']['requestorId'] == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not from a requestor</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($requestors as $id => $name) {
  $selected = '';
  if ( $id == $_SESSION['searchText']['requestorId'] ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td class="label">Page image creator:</td>
<td><select name="pageImagesRespId">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['pageImagesRespId'] == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items from any page-image creator</option>\n";

$selected = '';
if ($_SESSION['searchText']['pageImagesRespId'] == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not from a page-image creator</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($pageImagesResps as $id => $name) {
  $selected = '';
  if ( $id == $_SESSION['searchText']['pageImagesRespId'] ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td class="label">Text creator:</td>
<td><select name="transcriptionRespId">
<option value=''>All items</option>
<?php
$selected = '';
if ($_SESSION['searchText']['transcriptionRespId'] == 'any') { $selected = ' selected'; }
echo "<option value='any'$selected>Items from any text creator</option>\n";

$selected = '';
if ($_SESSION['searchText']['transcriptionRespId'] == 'none') { $selected = ' selected'; }
echo "<option value='none'$selected>Items not from a text creator</option>\n";

echo "<option value=''>--------------------</option>\n";

foreach ($transcriptionResps as $id => $name) {
  $selected = '';
  if ( $id == $_SESSION['searchText']['transcriptionRespId'] ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td></td>
<td>
<input type="button" value="&lt; Back" onclick="history.back();">
<input type="button" value="Clear" onclick="clearForm();">
<input type="button" value="Search Now" onclick="document.frm.searchNow.value='true'; document.frm.submit();">
<input type="submit" value="Next &gt;"  onclick="document.frm.searchNow.value='';">
<input type="hidden" name="searchNow">
</td>
</tr>

<tr>
<td></td>
<td>
Go to: <select name="jumpTo">
<option value=""></option>
<option value="basic">Basic Criteria</option>
<option value="groupings">Groupings</option>
<option value="">----------</option>
<option value="dates">Priority and Dates</option>
<option value="misc">Other Criteria</option>
<option value="status">Workflow Status</option>
<option value="output">Output Options</option>
</select>
<input type="button" value="Go" onclick="document.frm.submit();">
</td>
</tr>

</table>
</form>
</body>
</html>
