<?php

/*
  saveFinalization.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-01-14
  Last modified: 2006-08-17

  Saves changes to database for TEI Header workflow steps.

  Receives data from: confirmFinalization.php
  Redirects to: workflowFinalization.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to database
$connection = connect();

// test permissions
testPerm('textFinalizationUpdate');

// get all DLPS IDs from the posted form
$ids = array();
foreach ($_POST as $name => $value) {
  if ( ereg("(replaceHeader|updateIssueData|updateAccess|qaHeader|runHeaderReport|to70fullheaders_added|verifyImages|addPids|qaProgram|to80final|dlps2ReadyRepo|verifyImagesReadyRepo|pogo2archive|runCleanupScript|isFinished)_(.+)", $name, $refs) ) {
    $ids[] = $refs[2];
  }
}

// for each ID, update values as needed
$updatedIds = array();
$to80finalIds = array();
foreach ($ids as $id) {
  // update table 'finalization' as needed
  $updates = '';
  for ($i = 1; $i <= 14; $i++) {
    switch ($i) {
      case 1:  $columnName = 'replaceHeader'; break;
      case 2:  $columnName = 'updateIssueData'; break;
      case 3:  $columnName = 'updateAccess'; break;
      case 4:  $columnName = 'qaHeader'; break;
      case 5:  $columnName = 'runHeaderReport'; break;
      case 6:  $columnName = 'to70fullheaders_added'; break;
      case 7:  $columnName = 'verifyImages'; break;
      case 8:  $columnName = 'addPids'; break;
      case 9:  $columnName = 'qaProgram'; break;
      case 10: $columnName = 'to80final'; break;
      case 11: $columnName = 'dlps2ReadyRepo'; break;
      case 12: $columnName = 'verifyImagesReadyRepo'; break;
      case 13: $columnName = 'pogo2archive'; break;
      case 14: $columnName = 'runCleanupScript'; break;
    }

    if (!empty($_POST[$columnName . '_' . $id])) {
      $value = $_POST[$columnName . '_' . $id];
      if ($value == 'true') {
        $updates .= " $columnName = 1,";
      } else {
        $updates .= " $columnName = 0,";
      }
    }
  }

  if (!empty($updates)) {
    $updates = ereg_replace(',$', '', $updates);  // strip final comma

    // determine which IDs to include in email notification
    if ( preg_match('/to80final = 1/', $updates) ) {
      $sql =  "SELECT finalization.dlpsId, textItems.title ";
      $sql .= "FROM finalization LEFT JOIN textItems USING (dlpsId) ";
      $sql .= "WHERE finalization.dlpsId = '$id' AND finalization.to80final = 0";
      $result = query($sql, $connection);
      if ( mysql_num_rows($result) == 1 ) {
        $row = mysql_fetch_array($result);
        $to80finalIds[$id] = $row['title'];
      }
    }

    $sql = "UPDATE finalization SET $updates WHERE dlpsId = '$id'";

    if ( mysql_query($sql, $connection) ) {
      if (mysql_affected_rows() == 1) {
        $updatedIds[$id] = $id;
      }
    } else {
      die($dbErrorPreface . "Unable to update record '$id' in table 'finalization': " . mysql_error($connection) . "<br><br>$sql");
    }
  }


  // update table 'textItems' if needed
  $sql = "UPDATE textItems SET";
  $updates = '';

  if (!empty($_POST['isFinished_' . $id])) {
    $value = $_POST['isFinished_' . $id];
    if ($value == 'true') {
      // set isFinished to true, dateFinished to today's date ("n/j/Y" means m/d/yyyy)
      $updates .= " isFinished = 1, dateFinished = '" . formatDateISO( date("n/j/Y") )  . "'";
    } else {
      // set isFinished to false, dateFinished to NULL
      $updates .= " isFinished = 0, dateFinished = NULL";
    }
  }

  if (!empty($updates)) {
    $sql .= "$updates WHERE dlpsId = '$id'";

    if ( mysql_query($sql, $connection) ) {
      if (mysql_affected_rows() == 1) {
        $updatedIds[$id] = $id;
      }
    } else {
      die($dbErrorPreface . "Unable to update record '$id' in table 'textItems': " . mysql_error($connection) . "<br><br>$sql");
    }
  }
}

// send email notification for items moved to '80final' directory
if ($to80finalIds) {
  $to = $to80FinalEmailRecipients;
  $headers = "From: $emailFrom";
  $subject = "$appTitle - Items moved to 80final";

  $body = "User " . getUserDesc() . " has updated the $appTitle to indicate that the following items have been moved to the '80final' directory:\n\n";

  foreach ($to80finalIds as $id => $title) {
    $body .= "$id   $title\n";
  }

  $body = wordwrap($body, 70);
  mail($to, $subject, $body, $headers);
}

// redirect, indicating success
$ids = '';
foreach ($updatedIds as $id) {
  $ids .= $id . '|';
}
$ids = ereg_replace('\|$', '', $ids);  // strip final |
header("Location: workflowFinalization.php?status=updated&ids=$ids");
?>