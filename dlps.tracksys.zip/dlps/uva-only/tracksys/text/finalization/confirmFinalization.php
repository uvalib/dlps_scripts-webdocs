<?php

/*
  confirmFinalization.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-01-14
  Last modified: 2006-08-17

  Displays changes proposed for text items in the context of the
  finalization workflow. Allows user to commit changes to database, or
  cancel.

  Receives data from: workflowFinalization.php
  Posts data to: saveFinalization.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'Finalization Workflow - Confirm Changes';

// connect to database
$connection = connect();

// test permissions
testPerm('textFinalizationUpdate');

// get all DLPS IDs from the posted form
$ids = array();
foreach ($_POST as $name => $value) {
  if ( ereg("dlpsId_(.+)", $name, $refs) ) {
    $ids[] = $refs[1];
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?$pageTitle?></h2>
<p>Do you want to make the following changes?</p>
<form name="form" method="POST" action="saveFinalization.php">
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>DLPS&nbsp;ID</td>
<td>Title</td>
<td align='center'>Replace TEI header</td>
<td align='center'>Update issue data (newspapers)</td>
<td align='center'>Update access level</td>
<td align='center'>QA TEI header</td>
<td align='center'>Run &amp; send TEI header report (newspapers)</td>
<td align='center'>Move to 70fullheaders_added</td>
<td align='center'>Verify image files</td>
<td align='center'>Add PIDs</td>
<td align='center'>Run QA program</td>
<td align='center'>Move to 80final</td>
<td align='center'>Run dlps2ReadyRepo</td>
<td align='center'>Verify image files</td>
<td align='center'>Archive to StorNext</td>
<td align='center'>Run cleanup script</td>
<td align='center'>FINISHED</td>
</tr>

<?php
// for each ID, query database to determine whether the record actually requires updating
$changes = array();
foreach ($ids as $id) {
  $sql = "SELECT textItems.title, textItems.volumeNumber, textItems.isFinished, finalization.*
          FROM textItems LEFT JOIN finalization USING (dlpsId)
          WHERE finalization.dlpsId = '$id'";
  $result = query($sql, $connection);
  if ( mysql_num_rows($result) == 1 ) {
    $row = mysql_fetch_array($result);

    for ($i = 1; $i <= 15; $i++) {
      switch ($i) {
        case 1:  $columnName = 'replaceHeader'; break;
        case 2:  $columnName = 'updateIssueData'; break;
        case 3:  $columnName = 'updateAccess'; break;
        case 4:  $columnName = 'qaHeader'; break;
        case 5:  $columnName = 'runHeaderReport'; break;
        case 6:  $columnName = 'to70fullheaders_added'; break;
        case 7:  $columnName = 'verifyImages'; break;
        case 8:  $columnName = 'addPids'; break;
        case 9:  $columnName = 'qaProgram'; break;
        case 10: $columnName = 'to80final'; break;
        case 11: $columnName = 'dlps2ReadyRepo'; break;
        case 12: $columnName = 'verifyImagesReadyRepo'; break;
        case 13: $columnName = 'pogo2archive'; break;
        case 14: $columnName = 'runCleanupScript'; break;
        case 15: $columnName = 'isFinished'; break;
      }

      if ( (!empty($_POST[$columnName . '_' . $id])) && ($row[$columnName] == 0) ) {
        // form = true, database = false
        $changes[$id] .= "$columnName=1|";
      }
      if ( (empty($_POST[$columnName . '_' . $id])) && ($row[$columnName] == 1) ) {
        // form = false, database = true
        $changes[$id] .= "$columnName=0|";
      }
    }

    if (!empty($changes[$id])) {
      $changes[$id] = preg_replace('/\|$/', '', $changes[$id]);
      $c++;
      $class = getRowClass($c);
      $title = formatTitle($row['title'], $row['volumeNumber']);
      echo "<tr$class><td>$id</td><td>$title</td>";

      for ($i = 1; $i <= 15; $i++) {
        switch ($i) {
          case 1:  $columnName = 'replaceHeader'; break;
          case 2:  $columnName = 'updateIssueData'; break;
          case 3:  $columnName = 'updateAccess'; break;
          case 4:  $columnName = 'qaHeader'; break;
          case 5:  $columnName = 'runHeaderReport'; break;
          case 6:  $columnName = 'to70fullheaders_added'; break;
          case 7:  $columnName = 'verifyImages'; break;
          case 8:  $columnName = 'addPids'; break;
          case 9:  $columnName = 'qaProgram'; break;
          case 10: $columnName = 'to80final'; break;
          case 11: $columnName = 'dlps2ReadyRepo'; break;
          case 12: $columnName = 'verifyImagesReadyRepo'; break;
          case 13: $columnName = 'pogo2archive'; break;
          case 14: $columnName = 'runCleanupScript'; break;
          case 15: $columnName = 'isFinished'; break;
        }

        if ( preg_match("/$columnName=(0|1)/", $changes[$id], $refs) ) {
          if ($refs[1] == '1') {
	    $checked = ' checked';
	    $tf = 'true';
	  } else {
	    $checked = '';
	    $tf = 'false';
	  }
	  // checkboxes are for display only; value is passed via hidden textbox
          echo "<td align='center'><input type='checkbox'$checked disabled>
                <input type='hidden' name='{$columnName}_$id' value='$tf'></td>";
        } else {
          echo "<td>&nbsp;</td>";
        }
      }
      echo "</tr>\n";
    }
  }
}

if (empty($changes)) {
  echo "<tr><td colspan='7'>[No changes indicated]</td></tr>\n";
}

echo "</tr>\n</table>\n";

if (empty($changes)) {
  echo "<p><input type='button' value=' Back ' onclick='history.back();'></p>\n";
} else {
  echo "<p><input type='submit' name='update' value='Update'>
        <input type='button' name='cancel' value='Cancel' onclick='history.back();'></p>\n";
}
?>
</form>
</body>
</html>
