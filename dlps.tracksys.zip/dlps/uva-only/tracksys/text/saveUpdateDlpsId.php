<?php

/*
  saveUpdateDlpsId.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-06-24
  Last modified: 2006-05-24

  Updates DLPS ID in table textItems and in the corresponding record
  of each workflow table.

  Receives data from: updateDlpsId.php
  If data is not valid, redirects to: err/badInput.php
  If record is updated successfully, redirects to: followSaveItem.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

//--------------------
// validate user input
//--------------------

$location = 'Location: ../err/badInput.php?msg=';

// old DLPS ID
if (empty($oldDlpsId)) {
  header($location . urlencode('Current DLPS ID is required'));
  exit;
}

// new DLPS ID
if (empty($newDlpsId)) {
  header($location . urlencode('New DLPS ID is required'));
  exit;
}

if (! preg_match('/^[A-Za-z0-9\_\-\.]+$/', $newDlpsId) ) {
  header($location . urlencode('New DLPS ID is invalid. DLPS ID must contain only letters, numbers, underscore, hyphen, or period.'));
  exit;
}

// connect to db
$connection = connect();

// prep user input
$oldDlpsId = clean2($oldDlpsId, $connection, $dlpsIdMaxLength);
$newDlpsId = clean2($newDlpsId, $connection, $dlpsIdMaxLength);

// test whether this DLPS ID already exists

/* Of course, since dlpsId is the primary key, MySQL will not allow
inserting a new record with an existing dlpsId. But this is the most
common reason an insert would fail, so we handle it specially and
provide a friendlier status message. */

$sql = "SELECT dlpsId FROM textItems WHERE dlpsId = '$dlpsId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) >= 1 ) {
  // can't use a DLPS ID that already exists
  header($location . urlencode('DLPS ID "' . $dlpsId . '" already exists, so it cannot be used'));
  exit;
}

// test permissions
testPerm('textUpdateDlpsId');


//--------------------
// build SQL statement
//--------------------

$sql = "UPDATE textItems SET";
$sql .= " formerDlpsId = '$oldDlpsId', dlpsId = '$newDlpsId'";
$sql .= " WHERE dlpsId = '$oldDlpsId' LIMIT 1";


//----------------------
// execute SQL statement
//----------------------

if ( mysql_query($sql, $connection) ) {
  $affected = mysql_affected_rows();

  // update corresponding DLPS ID in each workflow table

  // update bookScanning table
  $sql = "UPDATE bookScanning SET dlpsId = '$newDlpsId' WHERE dlpsId = '$oldDlpsId'";
  query($sql, $connection);

  // update migration table
  $sql = "UPDATE migration SET dlpsId = '$newDlpsId' WHERE dlpsId = '$oldDlpsId'";
  query($sql, $connection);

  // update teiHeader table
  $sql = "UPDATE teiHeader SET dlpsId = '$newDlpsId' WHERE dlpsId = '$oldDlpsId'";
  query($sql, $connection);

  // update postkb table
  $sql = "UPDATE postkb SET dlpsId = '$newDlpsId' WHERE dlpsId = '$oldDlpsId'";
  query($sql, $connection);

  // update markupQA table
  $sql = "UPDATE markupQA SET dlpsId = '$newDlpsId' WHERE dlpsId = '$oldDlpsId'";
  query($sql, $connection);

  // update finalization table
  $sql = "UPDATE finalization SET dlpsId = '$newDlpsId' WHERE dlpsId = '$oldDlpsId'";
  query($sql, $connection);

  // redirect, indicating success
  header("Location: followSaveTextItem.php?mode=update&dlpsId=$newDlpsId&affected=$affected");
} else {
  die($dbErrorPreface . 'Unable to update table textItems: ' . mysql_error($connection) . "<br><br>$sql");
}
?>