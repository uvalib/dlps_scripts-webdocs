<?php

/*
  saveTextItem.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-06-21
  Last modified: 2007-04-10

  Saves user-entered data to database, either by inserting a new
  record or updating an existing record, as appropriate.

  Receives data from: textItem.php
  This page can also be reached from confirmSaveTextItem.php, in which
  case data is stored in session variables (not posted).

  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: followSaveItem.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

//----------------------------------------------------------------------
// get data not received via POST method
//----------------------------------------------------------------------

if ($_GET['confirmed']) {

  // we are returning here after confirming that a proposed new item
  // is unique/not a duplicate (confirmSaveTextItem.php); restore
  // session variables to normal variables for later use

  $mode = 'insert';

  $dlpsId = $_SESSION['saveTextItem']['dlpsId'];
  $itemType = $_SESSION['saveTextItem']['itemType'];
  $virgoId = $_SESSION['saveTextItem']['virgoId'];
  $titleControlNumber = $_SESSION['saveTextItem']['titleControlNumber'];
  $callNumber = $_SESSION['saveTextItem']['callNumber'];
  $title = $_SESSION['saveTextItem']['title'];
  $volumeNumber = $_SESSION['saveTextItem']['volumeNumber'];
  $authorNameLast = $_SESSION['saveTextItem']['authorNameLast'];
  $authorNameFirst = $_SESSION['saveTextItem']['authorNameFirst'];
  $hasPageImages = $_SESSION['saveTextItem']['hasPageImages'];
  $pageImagesType = $_SESSION['saveTextItem']['pageImagesType'];
  $pageImagesRespId = $_SESSION['saveTextItem']['pageImagesRespId'];
  $pageImagesRespName = $_SESSION['saveTextItem']['pageImagesRespName'];
  $pageCount = $_SESSION['saveTextItem']['pageCount'];
  $hasFigureImages = $_SESSION['saveTextItem']['hasFigureImages'];
  $hasTranscription = $_SESSION['saveTextItem']['hasTranscription'];
  $transcriptionType = $_SESSION['saveTextItem']['transcriptionType'];
  $transcriptionRespId = $_SESSION['saveTextItem']['transcriptionRespId'];
  $transcriptionRespName = $_SESSION['saveTextItem']['transcriptionRespName'];
  $setId = $_SESSION['saveTextItem']['setId'];
  $setName = $_SESSION['saveTextItem']['setName'];
  $projectId = $_SESSION['saveTextItem']['projectId'];
  $projectName = $_SESSION['saveTextItem']['projectName'];
  $groupId = $_SESSION['saveTextItem']['groupId'];
  $groupName = $_SESSION['saveTextItem']['groupName'];
  $batchId = $_SESSION['saveTextItem']['batchId'];
  $selectorId = $_SESSION['saveTextItem']['selectorId'];
  $selectorNameLast = $_SESSION['saveTextItem']['selectorNameLast'];
  $selectorNameFirst = $_SESSION['saveTextItem']['selectorNameFirst'];
  $requestorId = $_SESSION['saveTextItem']['requestorId'];
  $requestorNameLast = $_SESSION['saveTextItem']['requestorNameLast'];
  $requestorNameFirst = $_SESSION['saveTextItem']['requestorNameFirst'];
  $priority = $_SESSION['saveTextItem']['priority'];
  $genre = $_SESSION['saveTextItem']['genre'];
  $publicationYear = $_SESSION['saveTextItem']['publicationYear'];
  $access = $_SESSION['saveTextItem']['access'];
  $dateReceived = $_SESSION['saveTextItem']['dateReceived'];
  $forRepo = $_SESSION['saveTextItem']['forRepo'];
  $forInternalUseOnly = $_SESSION['saveTextItem']['forInternalUseOnly'];
  $notes = $_SESSION['saveTextItem']['notes'];

  unset($_SESSION['saveTextItem']);
} else {
  if ($mode == 'insert') {
    // store posted form data to session variable for possible later use
    unset($_SESSION['saveTextItem']);
    $_SESSION['saveTextItem']['dlpsId'] = $dlpsId;
    $_SESSION['saveTextItem']['itemType'] = $itemType;
    $_SESSION['saveTextItem']['virgoId'] = $virgoId;
    $_SESSION['saveTextItem']['titleControlNumber'] = $titleControlNumber;
    $_SESSION['saveTextItem']['callNumber'] = $callNumber;
    $_SESSION['saveTextItem']['title'] = $title;
    $_SESSION['saveTextItem']['volumeNumber'] = $volumeNumber;
    $_SESSION['saveTextItem']['authorNameLast'] = $authorNameLast;
    $_SESSION['saveTextItem']['authorNameFirst'] = $authorNameFirst;
    $_SESSION['saveTextItem']['hasPageImages'] = $hasPageImages;
    $_SESSION['saveTextItem']['pageImagesType'] = $pageImagesType;
    $_SESSION['saveTextItem']['pageImagesRespId'] = $pageImagesRespId;
    $_SESSION['saveTextItem']['pageImagesRespName'] = $pageImagesRespName;
    $_SESSION['saveTextItem']['pageCount'] = $pageCount;
    $_SESSION['saveTextItem']['hasFigureImages'] = $hasFigureImages;
    $_SESSION['saveTextItem']['hasTranscription'] = $hasTranscription;
    $_SESSION['saveTextItem']['transcriptionType'] = $transcriptionType;
    $_SESSION['saveTextItem']['transcriptionRespId'] = $transcriptionRespId;
    $_SESSION['saveTextItem']['transcriptionRespName'] = $transcriptionRespName;
    $_SESSION['saveTextItem']['setId'] = $setId;
    $_SESSION['saveTextItem']['setName'] = $setName;
    $_SESSION['saveTextItem']['projectId'] = $projectId;
    $_SESSION['saveTextItem']['projectName'] = $projectName;
    $_SESSION['saveTextItem']['groupId'] = $groupId;
    $_SESSION['saveTextItem']['groupName'] = $groupName;
    $_SESSION['saveTextItem']['batchId'] = $batchId;
    $_SESSION['saveTextItem']['selectorId'] = $selectorId;
    $_SESSION['saveTextItem']['selectorNameLast'] = $selectorNameLast;
    $_SESSION['saveTextItem']['selectorNameFirst'] = $selectorNameFirst;
    $_SESSION['saveTextItem']['requestorId'] = $requestorId;
    $_SESSION['saveTextItem']['requestorNameLast'] = $requestorNameLast;
    $_SESSION['saveTextItem']['requestorNameFirst'] = $requestorNameFirst;
    $_SESSION['saveTextItem']['priority'] = $priority;
    $_SESSION['saveTextItem']['genre'] = $genre;
    $_SESSION['saveTextItem']['publicationYear'] = $publicationYear;
    $_SESSION['saveTextItem']['access'] = $access;
    $_SESSION['saveTextItem']['dateReceived'] = $dateReceived;
    $_SESSION['saveTextItem']['forRepo'] = $forRepo;
    $_SESSION['saveTextItem']['forInternalUseOnly'] = $forInternalUseOnly;
    $_SESSION['saveTextItem']['notes'] = $notes;
  }
}


//----------------------------------------------------------------------
// validate user input
//----------------------------------------------------------------------

$location = 'Location: ../err/badInput.php?msg=';

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}

// DLPS ID
if (empty($dlpsId)) {
  header($location . urlencode('DLPS ID is required'));
  exit;
}

if ($mode != 'delete') {
  // title
  if (empty($title)) {
    header($location . urlencode('Title is required'));
    exit;
  }

  // genre
  if ($genre == '') {
    header($location . urlencode('Genre is required'));
    exit;
  }

  // year of publication
  if ($mode == 'insert' and empty($publicationYear) and $genre != GENRE_MANUSCRIPT) {
    header($location . urlencode('Year of publication is required, unless Genre is "Manuscript"'));
    exit;
  }
  if (!empty($publicationYear)) {
    if (! preg_match('/^\d{4}$/', $publicationYear) ) {
      header($location . urlencode('Year of publication must be a 4-digit year'));
      exit;
    }
  }

  // DLPS ID format
  if (! preg_match('/^[A-Za-z0-9\_\-\.]+$/', $dlpsId) ) {
    header($location . urlencode('DLPS ID is invalid: it must contain only letters, numbers, underscore, hyphen, or period.'));
    exit;
  }

  // page images
  if (empty($hasPageImages)) {
    if (!empty($pageImagesType)) {
      header($location . urlencode('When "Has page images?" is false, "Page image type" must be blank'));
      exit;
    }
    if (!empty($pageImagesRespId)) {
      header($location . urlencode('When "Has page images?" is false, "Page images created by" must be blank'));
      exit;
    }
  } else {
    if (empty($pageImagesType)) {
      header($location . urlencode('When "Has page images?" is true, "Page image type" cannot be blank'));
      exit;
    }
    if (empty($pageImagesRespId)) {
      header($location . urlencode('When "Has page images?" is true, "Page images created by" cannot be blank'));
      exit;
    }
  }

  if (!empty($pageImagesRespId)) {
    if ( $pageImagesRespId == 'new' && empty($pageImagesRespName) ) {
      header($location . urlencode('Name of new page-image creator is required when adding a new page-image creator'));
      exit;
    }
  }

  $pageCount = trim($pageCount);
  if (!preg_match('/^\d*$/', $pageCount)) {
    header($location . urlencode('If provided, the page image count must be a number'));
    exit;
  }

  // electronic transcription
  if (empty($hasTranscription)) {
    if (!empty($transcriptionType)) {
      header($location . urlencode('When "Has electronic transcription?" is false, "Transcription type" must be blank'));
      exit;
    }
    if (!empty($transcriptionRespId)) {
      header($location . urlencode('When "Has electronic transcription?" is false, "Transcription created by" must be blank'));
      exit;
    }
  } else {
    if (empty($transcriptionType)) {
      header($location . urlencode('When "Has electronic transcription?" is true, "Transcription type" cannot be blank'));
      exit;
    }
    if (empty($transcriptionRespId)) {
      header($location . urlencode('When "Has electronic transcription?" is true, "Transcription created by" cannot be blank'));
      exit;
    }
  }

  if ($transcriptionType == 2 && $transcriptionRespId != 3) {
    header($location . urlencode('When "Transcription type" is "OCR", "Transcription created by" must be "DLPS"'));
    exit;
  }
  if ($transcriptionType == 1 && $transcriptionRespId == 3) {
    header($location . urlencode('When "Transcription type" is "vendor", "Transcription created by" cannot be "DLPS"'));
    exit;
  }

  if (!empty($transcriptionRespId)) {
    if ( $transcriptionRespId == 'new' && empty($transcriptionRespName) ) {
      header($location . urlencode('Name of new transcription creator is required when adding a new transcription creator'));
      exit;
    }
  }

  // set
  if (!empty($setId)) {
    if ( $setId == 'new' && empty($setName) ) {
      header($location . urlencode('New set name is required when adding a new set'));
      exit;
    }
  }

  // project
  if (!empty($projectId)) {
    if ( $projectId == 'new' && empty($projectName) ) {
      header($location . urlencode('New project name is required when adding a new project'));
      exit;
    }
  }

  // group
  if (!empty($groupId)) {
    if ( $groupId == 'new' && empty($groupName) ) {
      header($location . urlencode('New group name is required when adding a new group'));
      exit;
    }
  }

  // selector
  if (!empty($selectorId)) {
    if ( $selectorId == 'new' && empty($selectorNameLast) ) {
      header($location . urlencode('Last name of new selector is required when adding a new selector'));
      exit;
    }
  }

  // requestor
  if (!empty($requestorId)) {
    if ( $requestorId == 'new' && empty($requestorNameLast) ) {
      header($location . urlencode('Last name of new requestor is required when adding a new requestor'));
      exit;
    }
  }

  // date received
  if (!empty($dateReceived)) {
    $test = formatDateISO($dateReceived);
    if ( empty($test) ) {
      header($location . urlencode("Value '$dateReceived' for date received is not a valid date"));
      exit;
    } else {
      $dateReceived = $test;
    }
  }
}  // END if ($mode != 'delete')

// connect to db
$connection = connect();

// test whether this DLPS ID already exists

/* Of course, since dlpsId is the primary key, MySQL will not allow
inserting a new record with an existing dlpsId. But this is probably
the most common reason an insert would fail, so we handle it specially
and provide a friendlier status message. */

$dlpsId = clean2($dlpsId, $connection);
$sql = "SELECT dlpsId FROM textItems WHERE dlpsId = '$dlpsId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) >= 1 ) {
  if ($mode == 'insert') {
    // can't insert a DLPS ID that already exists
    header($location . urlencode('DLPS ID "' . $dlpsId . '" already exists, so it cannot be added'));
    exit;
  }
} else {
  if ($mode == 'update') {
    // can't update a record that doesn't exist
    header($location . urlencode('DLPS ID "' . $dlpsId . '" does not exist, so it cannot be updated'));
    exit;
  }
}


//----------------------------------------------------------------------
// prevent duplicates: if adding a new item, check for similar items
//----------------------------------------------------------------------

if ($mode == 'insert' && ! $_GET['confirmed']) {
  $dupes = array();

  // test for identical Virgo IDs
  if ($virgoId) {
    $testVirgoId = clean2($virgoId, $connection);
    $sql = "SELECT dlpsId FROM textItems WHERE virgoId = '$testVirgoId'";
    $result = query($sql, $connection);
    if ( mysql_num_rows($result) >= 1 ) {
      while ( $row = mysql_fetch_array($result) ) {
	if (! array_key_exists($row['dlpsId'], $dupes) ) {
	  $dupes[$row['dlpsId']] = 'virgoId';
	}
      }
    }
  }

  // test for identical title control numbers
  if ($titleControlNumber) {
    $testTitleControlNumber = clean2($titleControlNumber, $connection);
    $sql = "SELECT dlpsId FROM textItems WHERE titleControlNumber = '$testTitleControlNumber'";
    $result = query($sql, $connection);
    if ( mysql_num_rows($result) >= 1 ) {
      while ( $row = mysql_fetch_array($result) ) {
	if (! array_key_exists($row['dlpsId'], $dupes) ) {
	  $dupes[$row['dlpsId']] = 'titleControlNumber';
	}
      }
    }
  }

  // test for similar call numbers
  if ($callNumber) {
    $testCallNumber = clean2($callNumber, $connection);
    $testCallNumber = preg_replace('/\. /', '%', $testCallNumber);
    $testCallNumber = preg_replace('/ \./', '%', $testCallNumber);
    $testCallNumber = preg_replace('/ /', '%', $testCallNumber);
    $testCallNumber = preg_replace('/\./', '%', $testCallNumber);
    $sql = "SELECT dlpsId FROM textItems WHERE callNumber LIKE '$testCallNumber%'";
    $result = query($sql, $connection);
    if ( mysql_num_rows($result) >= 1 ) {
      while ( $row = mysql_fetch_array($result) ) {
	if (! array_key_exists($row['dlpsId'], $dupes) ) {
	  $dupes[$row['dlpsId']] = 'callNumber';
	}
      }
    }
  }

  // test for similar titles
  if ($title) {
    $testTitle = clean2($title, $connection);
    $testTitle = preg_replace('/^(a|an|the) /i', '', $testTitle);  // remove initial A, An or The from title
    $testTitle = substr($testTitle, 0, 15);                        // truncate title to first 15 characters
    $sql = "SELECT dlpsId FROM textItems WHERE title LIKE '$testTitle%'";
    $result = query($sql, $connection);
    if ( mysql_num_rows($result) >= 1 ) {
      while ( $row = mysql_fetch_array($result) ) {
	if (! array_key_exists($row['dlpsId'], $dupes) ) {
	  $dupes[$row['dlpsId']] = 'title';
	}
      }
    }
  }

  if ($dupes) {
    // store needed values in session variable
    unset($_SESSION['confirmSaveTextItem']);
    $_SESSION['confirmSaveTextItem']['dupes'] = $dupes;
    $_SESSION['confirmSaveTextItem']['testCallNumberLength'] = strlen( trim($callNumber) );
    $_SESSION['confirmSaveTextItem']['testTitleLength'] = strlen($testTitle);

    // redirect to the confirmation page
    header('Location: confirmSaveTextItem.php');
    exit;
  }
}


//----------------------------------------------------------------------
// prep user input for use in SQL statement
//----------------------------------------------------------------------

$dlpsId = clean2($dlpsId, $connection, $dlpsIdMaxLength);
$virgoId = clean2($virgoId, $connection, $virgoIdMaxLength);
$virgoId = preg_replace('/^x/', 'X', $virgoId);  // replace x with X in Virgo ID
$titleControlNumber = clean2($titleControlNumber, $connection, $titleControlNumberMaxLength);
$callNumber = clean2($callNumber, $connection, $callNumberMaxLength);
$title = clean2($title, $connection, $titleMaxLength);
$volumeNumber = clean2($volumeNumber, $connection, $volumeNumberMaxLength);
$authorNameLast = clean2($authorNameLast, $connection, $authorNameLastMaxLength);
$authorNameFirst = clean2($authorNameFirst, $connection, $authorNameFirstMaxLength);
$pageImagesResp = clean2($pageImagesResp, $connection, 10);
$transcriptionResp = clean2($transcriptionResp, $connection, 10);
$setName = clean2($setName, $connection, $setNameMaxLength);
$projectName = clean2($projectName, $connection, $projectNameMaxLength);
$groupName = clean2($groupName, $connection, $groupNameMaxLength);
$selectorNameFirst = clean2($selectorNameFirst, $connection, $selectorNameFirstMaxLength);
$selectorNameLast = clean2($selectorNameLast, $connection, $selectorNameLastMaxLength);
$requestorNameFirst = clean2($requestorNameFirst, $connection, $requestorNameFirstMaxLength);
$requestorNameLast = clean2($requestorNameLast, $connection, $requestorNameLastMaxLength);
$publicationYear = clean2($publicationYear, $connection, 10);
$notes = clean2($notes, $connection);


//----------------------------------------------------------------------
// add new setup data if needed
//----------------------------------------------------------------------

// add new page-image creator if needed
if (!empty($pageImagesRespId)) {
  if ( $pageImagesRespId == 'new' ) {
    // add new page-image creator; just insert name, because ID is an auto-increment column
    if (empty($pageImagesRespName)) { $value = "NULL"; } else { $value = "'$pageImagesRespName'"; }
    $sql = "INSERT INTO pageImagesResps SET pageImagesRespName = $value";
    if ( mysql_query($sql, $connection) ) {
      // get new ID
      $pageImagesRespId = mysql_insert_id();
    } else {
      die($dbErrorPreface . "Unable to add new page-image creator '$pageImagesRespName': " . mysql_error($connection) . "<br><br>$sql");
    }
  }
}

// add new transcription creator if needed
if (!empty($transcriptionRespId)) {
  if ( $transcriptionRespId == 'new' ) {
    // add new transcription creator; just insert name, because ID is an auto-increment column
    if (empty($transcriptionRespName)) { $value = "NULL"; } else { $value = "'$transcriptionRespName'"; }
    $sql = "INSERT INTO transcriptionResps SET transcriptionRespName = $value";
    if ( mysql_query($sql, $connection) ) {
      // get new ID
      $transcriptionRespId = mysql_insert_id();
    } else {
      die($dbErrorPreface . "Unable to add new transcription creator '$transcriptionRespName': " . mysql_error($connection) . "<br><br>$sql");
    }
  }
}

// add new set if needed
if (!empty($setId)) {
  if ( $setId == 'new' ) {
    // add new set; just insert name, because ID is an auto-increment column
    $sql = "INSERT INTO sets SET setName = '$setName'";
    if ( mysql_query($sql, $connection) ) {
      // get new ID
      $setId = mysql_insert_id();
    } else {
      die($dbErrorPreface . "Unable to add new set '$setName': " . mysql_error($connection) . "<br><br>$sql");
    }
  }
}

// add new project if needed
if (!empty($projectId)) {
  if ( $projectId == 'new' ) {
    // add new project; just insert name, because ID is an auto-increment column
    $sql = "INSERT INTO projects SET projectName = '$projectName'";
    if ( mysql_query($sql, $connection) ) {
      // get new ID
      $projectId = mysql_insert_id();
    } else {
      die($dbErrorPreface . "Unable to add new project '$projectName': " . mysql_error($connection) . "<br><br>$sql");
    }
  }
}

// add new group if needed
if (!empty($groupId)) {
  if ( $groupId == 'new' ) {
    // add new group; just insert name, because ID is an auto-increment column
    $sql = "INSERT INTO groups SET groupName = '$groupName'";
    if ( mysql_query($sql, $connection) ) {
      // get new ID
      $groupId = mysql_insert_id();
    } else {
      die($dbErrorPreface . "Unable to add new group '$groupName': " . mysql_error($connection) . "<br><br>$sql");
    }
  }
}

// add new selector if needed
if (!empty($selectorId)) {
  if ( $selectorId == 'new' ) {
    // add new selector; just insert name, because ID is an auto-increment column
    $sql = "INSERT INTO selectors SET";
    if (!empty($selectorNameFirst)) { $sql .= " selectorNameFirst = '$selectorNameFirst'"; }
    if (!empty($selectorNameFirst) && !empty($selectorNameLast)) { $sql .= ','; }
    if (!empty($selectorNameLast)) { $sql .= " selectorNameLast = '$selectorNameLast'"; }
    if ( mysql_query($sql, $connection) ) {
      // get new ID
      $selectorId = mysql_insert_id();
    } else {
      die($dbErrorPreface . "Unable to add new selector '$selectorNameLast, $selectorNameFirst': " . mysql_error($connection) . "<br><br>$sql");
    }
  }
}

// add new requestor if needed
if (!empty($requestorId)) {
  if ( $requestorId == 'new' ) {
    // add new requestor; just insert name, because ID is an auto-increment column
    $sql = "INSERT INTO requestors SET";
    if (!empty($requestorNameFirst)) { $sql .= " requestorNameFirst = '$requestorNameFirst'"; }
    if (!empty($requestorNameFirst) && !empty($requestorNameLast)) { $sql .= ','; }
    if (!empty($requestorNameLast)) { $sql .= " requestorNameLast = '$requestorNameLast'"; }
    if ( mysql_query($sql, $connection) ) {
      // get new ID
      $requestorId = mysql_insert_id();
    } else {
      die($dbErrorPreface . "Unable to add new requestor '$requesorNameLast, $requestorNameFirst': " . mysql_error($connection) . "<br><br>$sql");
    }
  }
}


//----------------------------------------------------------------------
// build SQL statement
//----------------------------------------------------------------------

if ($mode == 'delete') {
  testPerm('textDelete');
  $sql = "DELETE FROM textItems";
  $where = " WHERE dlpsId = '$dlpsId' LIMIT 1";
} elseif ($mode == 'update') {
  testPerm('textUpdate');
  $sql = "UPDATE textItems SET";
  $where = " WHERE dlpsId = '$dlpsId' LIMIT 1";
} else {
  testPerm('textInsert');
  $sql = "INSERT INTO textItems SET";
}

if ($mode == 'delete') {
  $values = '';
} else {
  if (empty($dlpsId)) {
    // this should never occur due to prior tests; this is a last-ditch
    // check that will cause the insert or update to fail (since dlpsId cannot be null)
    $value = "NULL";
  } else {
    $value = "'$dlpsId'";
  }
  $values = " dlpsId = $value";

  if (empty($itemType)) { $value = "0"; } else { $value = "$itemType"; }
  $values .= ", itemType = $value";

  if (empty($virgoId)) { $value = "NULL"; } else { $value = "'$virgoId'"; }
  $values .= ", virgoId = $value";

  if (empty($titleControlNumber)) { $value = "NULL"; } else { $value = "'$titleControlNumber'"; }
  $values .= ", titleControlNumber = $value";

  if (empty($callNumber)) { $value = "NULL"; } else { $value = "'$callNumber'"; }
  $values .= ", callNumber = $value";

  if (empty($title)) { $value = "NULL"; } else { $value = "'$title'"; }
  $values .= ", title = $value";

  if (empty($volumeNumber)) { $value = "NULL"; } else { $value = "'$volumeNumber'"; }
  $values .= ", volumeNumber = $value";

  if (empty($authorNameLast)) { $value = "NULL"; } else { $value = "'$authorNameLast'"; }
  $values .= ", authorNameLast = $value";

  if (empty($authorNameFirst)) { $value = "NULL"; } else { $value = "'$authorNameFirst'"; }
  $values .= ", authorNameFirst = $value";

  if (empty($pageCount)) { $value = "0"; } else { $value = "$pageCount"; }
  $values .= ", pageCount = $value";

  if (empty($hasPageImages)) {
    $values .= ", pageImagesType = 0";
  } else {
    if (empty($pageImagesType)) {
      $value = "0";  // this should never occur; should be caught by user input validation above
    } else {
      $value = $pageImagesType;
    }
    $values .= ", pageImagesType = $value";
  }

  if (empty($pageImagesRespId)) { $value = "0"; } else { $value = $pageImagesRespId; }
  $values .= ", pageImagesRespId = $value";

  if (empty($hasFigureImages)) { $value = "0"; } else { $value = "1"; }
  $values .= ", hasFigureImages = $value";

  if (empty($hasTranscription)) {
    $values .= ", transcriptionType = 0";
  } else {
    if (empty($transcriptionType)) {
      $value = "0";  // this should never occur; should be caught by user input validation above
    } else {
      $value = $transcriptionType;
    }
    $values .= ", transcriptionType = $value";
  }

  if (empty($transcriptionRespId)) { $value = "0"; } else { $value = $transcriptionRespId; }
  $values .= ", transcriptionRespId = $value";

  if (empty($setId)) { $value = "0"; } else { $value = $setId; }
  $values .= ", setId = $value";

  if (empty($projectId)) { $value = "0"; } else { $value = $projectId; }
  $values .= ", projectId = $value";

  if (empty($groupId)) { $value = "0"; } else { $value = $groupId; }
  $values .= ", groupId = $value";

  if (empty($batchId)) { $value = "0"; } else { $value = $batchId; }
  $values .= ", batchId = $value";

  if (empty($selectorId)) { $value = "0"; } else { $value = $selectorId; }
  $values .= ", selectorId = $value";

  if (empty($requestorId)) { $value = "0"; } else { $value = $requestorId; }
  $values .= ", requestorId = $value";

  // can't use empty() for priority, because string "0" evaluates to true (is empty);
  // instead, test explicitly for appropriate values
  if ( ($priority == '-1') || ($priority == '0') || ($priority == '1') ) {
    $values .= ", priority = $priority";
  }

  if ($genre != '') {
    $values .= ", genre = $genre";
  }

  if (empty($publicationYear)) { $value = "NULL"; } else { $value = "'$publicationYear'"; }
  $values .= ", publicationYear = $value";

  if ($access != '') {
    $values .= ", access = $access";
  }

  if (empty($dateReceived)) { $value = "NULL"; } else { $value = "'$dateReceived'"; }
  $values .= ", dateReceived = $value";

  if (empty($forRepo)) { $value = "0"; } else { $value = "1"; }
  $values .= ", forRepo = $value";

  if (empty($forInternalUseOnly)) { $value = "0"; } else { $value = "1"; }
  $values .= ", forInternalUseOnly = $value";

  if (empty($notes)) { $value = "NULL"; } else { $value = "'$notes'"; }
  $values .= ", notes = $value";
}

$sql .= $values . $where;


//----------------------------------------------------------------------
// execute SQL statement
//----------------------------------------------------------------------

if ( mysql_query($sql, $connection) ) {
  $affected = mysql_affected_rows();

  if ($mode == 'insert') {

    // add corresponding new record to each workflow table

    $sql = "INSERT INTO bookScanning SET dlpsId = '$dlpsId'";
    query($sql, $connection);

    $sql = "INSERT INTO migration SET dlpsId = '$dlpsId'";
    query($sql, $connection);

    $sql = "INSERT INTO pageBook SET dlpsId = '$dlpsId'";
    query($sql, $connection);

    $sql = "INSERT INTO teiHeader SET dlpsId = '$dlpsId'";
    query($sql, $connection);

    $sql = "INSERT INTO postkb SET dlpsId = '$dlpsId'";
    query($sql, $connection);

    $sql = "INSERT INTO markupQA SET dlpsId = '$dlpsId'";
    query($sql, $connection);

    $sql = "INSERT INTO finalization SET dlpsId = '$dlpsId'";
    query($sql, $connection);

  } elseif ($mode == 'delete') {

    // delete corresponding record from each workflow table

    $sql = "DELETE FROM bookScanning WHERE dlpsId = '$dlpsId' LIMIT 1";
    query($sql, $connection);

    $sql = "DELETE FROM migration WHERE dlpsId = '$dlpsId' LIMIT 1";
    query($sql, $connection);

    $sql = "DELETE FROM pageBook WHERE dlpsId = '$dlpsId' LIMIT 1";
    query($sql, $connection);

    $sql = "DELETE FROM teiHeader WHERE dlpsId = '$dlpsId' LIMIT 1";
    query($sql, $connection);

    $sql = "DELETE FROM postkb WHERE dlpsId = '$dlpsId' LIMIT 1";
    query($sql, $connection);

    $sql = "DELETE FROM markupQA WHERE dlpsId = '$dlpsId' LIMIT 1";
    query($sql, $connection);

    $sql = "DELETE FROM finalization WHERE dlpsId = '$dlpsId' LIMIT 1";
    query($sql, $connection);
  }

  // redirect, indicating success
  header("Location: followSaveTextItem.php?mode=$mode&dlpsId=$dlpsId&affected=$affected");
} else {
  die($dbErrorPreface . mysql_error($connection) . "<br><br>$sql");
}
?>