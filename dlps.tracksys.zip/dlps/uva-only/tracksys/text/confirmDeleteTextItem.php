<?php

/*
  confirmDeleteTextItem.php - asks for user confirmation before deleting a text item

  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-03-28
  Last modified: 2006-03-28

  Posts to: saveTextItem.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Text Workflow';
$pageTitle = 'Delete Item';

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<p><span class="attn">WARNING:</span> This action cannot be undone, and
the data cannot be recovered. Are you sure you want to delete item
<b><?=$dlpsId?></b>?</p>

<?php

$sql = "SELECT dlpsId, title, volumeNumber, authorNameLast, authorNameFirst ";
$sql .= "FROM textItems WHERE dlpsId = '$dlpsId'";
$result = query($sql, $connection);
$row = mysql_fetch_array($result);

$author = formatName($row['authorNameLast'], $row['authorNameFirst']);

echo <<<EOD
<table cellpadding='6' cellspacing='0' class='list' width='100%'>
<tr class='head'>
<td>DLPS ID</td>
<td>Title</td>
<td>Volume</td>
<td>Author</td>
</tr>
<tr>
<td>$row[dlpsId]</td>
<td>$row[title]</td>
<td>$row[volumeNumber]</td>
<td>$author</td>
</tr>
</table>
EOD;
?>

<form name="frm" method="POST" action="saveTextItem.php">
<input type="hidden" name="dlpsId" value="<?=$dlpsId?>">
<input type="hidden" name="mode" value="delete">
<p>
<input type="submit" value="Delete">
<input type="button" value="Cancel" onclick="history.back();">
</p>
</form>

</body>
</html>
