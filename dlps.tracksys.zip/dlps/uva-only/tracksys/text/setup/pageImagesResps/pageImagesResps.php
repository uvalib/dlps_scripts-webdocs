<?php

/*
  pageImagesResps.php - page for managing page-image creators
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-09
  Last modified: 2005-10-07

  If no 'pageImagesRespId' parameter, lists page-image creators already defined.
  If ID is 'new', displays add-new form for defining a page-image creator.
  If ID is a number, displays edit form for editing an existing page-image creator.
*/

import_request_variables('PG');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Text Workflow - Setup';

if ( empty($pageImagesRespId) ) {
  // list existing page-image creators
  $pageTitle = 'Page-Image Creators';
  testPerm('textPageImagesRespsSelect');
} else {
  if ($pageImagesRespId == 'new') {
    // display enter-new form
    $mode = 'insert';
    $pageTitle = 'Enter New Page-Image Creator';
    $submitCaption = ' Add ';
    testPerm('textPageImagesRespsInsert');
  } else {
    // display edit form
    $mode = 'update';
    $pageTitle = 'Edit Page-Image Creator';
    $submitCaption = 'Update';

    testPerm('textPageImagesRespsSelect');
    if (!getPerm('textPageImagesRespsUpdate')) { $submitAppearance = ' disabled'; }
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
<script type="text/javascript" src="../../../inc/tracksys.js"></script>
</head>

<?php
if ( empty($pageImagesRespId) ) {
  // list existing page-image creators

  if (getPerm('textPageImagesRespsInsert')) {
    $addNewLink = "<p><a href='?pageImagesRespId=new'>Enter new page-image creator</a></p>";
  } else {
    $addNewLink = "<p><span class='disabled'>Enter new page-image creator</span></p>";
  }
?>

<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<?=$addNewLink?>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>Name</td>
<td>Description</td>
<td>View all items</td>
</tr>

<?php
  $sql = "SELECT * FROM pageImagesResps ORDER BY pageImagesRespName";
  $result = query($sql, $connection);
  $num = mysql_num_rows($result);
  if ($num == 0) { echo "<tr><td cols='2'><b>0</b> items</td></tr>\n"; }
  while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);
      echo "<tr$class>
<td><a href='?pageImagesRespId=$row[pageImagesRespId]'>$row[pageImagesRespName]</a></td>
<td>$row[pageImagesRespDesc]</td>
<td style='white-space: nowrap'><a href='../../../text/search/search4.php?pageImagesRespId=$row[pageImagesRespId]&clear=true&searchNow=true'>View all items</a></td>
</tr>\n";
  }
  echo "</table>\n";
}  // END if ( empty($pageImagesRespId) )

else {
  if ($pageImagesRespId != 'new') {
    $sql = "SELECT * FROM pageImagesResps WHERE pageImagesRespId = '$pageImagesRespId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $pageImagesRespId = $row['pageImagesRespId'];
    }
  }

  if ($deleteEnabled and $mode == 'update' and getPerm('textPageImagesRespsDelete')) {
    $onSubmit = " onsubmit='return confirmDelete(document.frm, \"page-image creator\");'";
  }
?>

<body onload='document.frm.pageImagesRespName.focus();'>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name='frm' method='POST' action='savePageImagesResp.php'<?=$onSubmit?>>
<input type='hidden' name='mode' value='<?=$mode?>'>
<input type='hidden' name='pageImagesRespId' value='<?=$pageImagesRespId?>'>
<table cellpadding='4'>
<tr>
<td class='label'>Name:</td>
<td><input type='text' name='pageImagesRespName' value='<?=$row[pageImagesRespName]?>' maxlength='<?=$pageImagesRespNameMaxLength?>'></td>
</tr>
<tr>
<td class='label'>Description:</td>
<td><input type='text' name='pageImagesRespDesc' value='<?=$row[pageImagesRespDesc]?>' size='60' maxlength='<?=$pageImagesRespDescMaxLength?>'></td>
</tr>
<?php
  if ($deleteEnabled and $mode == 'update' and getPerm('textPageImagesRespsDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>
<tr>
<td></td>
<td>
<input type='submit' name='go' value='<?=$submitCaption?>'<?=$submitAppearance?>>
<input type='button' value='Cancel' onclick='history.back();'>
</td>
</tr>
</table>
</form>
<?php
}  // END if ( empty($pageImagesRespId) ) { ... } else
?>
</body>
</html>
