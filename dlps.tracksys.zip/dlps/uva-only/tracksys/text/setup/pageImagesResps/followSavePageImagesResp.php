<?php

/*
  followSavePageImagesResp.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-08
  Last modified: 2005-10-07

  This page is displayed upon successful insert/update of a
  page-image creator. It simply displays non-editable values for
  the record.

  Receives data from: savePageImagesResp.php
*/

import_request_variables('G');
include '../../../inc/tracksys.php';
include '../../../inc/auth.php';

$siteArea = 'Text Workflow - Setup';
$pageTitle = 'Page-Image Creator - Update Status';

// connect to db
$connection = connect();

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
// get data from database and display for confirmation
$sql = "SELECT * FROM pageImagesResps WHERE pageImagesRespId = '$pageImagesRespId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) == 1 ) {
  if ($mode == 'delete') {
    echo "<p class='error'>WARNING: The page-image creator was <b>not</b> deleted (ID: $pageImagesRespId).
      Contact the $appTitle administrator.</p>
      </body></html>";
    exit;
  }

  if ($affected == '0') {
    echo "<p class='updated'>No changes were needed.</p>";
  } else {
    if ($mode == 'insert') {
      echo "<p class='updated'>New page-image creator added successfully</p>\n";
    } else {
      echo "<p class='updated'>Page-image creator updated successfully</p>\n";
    }
  }
  $row = mysql_fetch_array($result);
?>

<table cellpadding='6' cellspacing='0'>
<tr>
<td class='label'>Name:</td>
<td><?=$row['pageImagesRespName']?></td>
</tr><tr>
<td class='label'>Description:</td>
<td><?=$row['pageImagesRespDesc']?></td>
</tr>
</table>

<?php
} else {
  if ($mode == 'delete') {
    echo "<p class='updated'>Page-image creator deleted successfully.</p>\n";
  } else {
    echo "<p>Page-image creator ID '$pageImagesRespId' not found in database. 
      Contact the $appTitle administrator.</p>\n";
  }
}  // END if ( mysql_num_rows($result) == 1 ) ... else ...

if (getPerm('textPageImagesRespsInsert')) {
  echo "<p><a href='pageImagesResps.php?pageImagesRespId=new'>Enter new page-image creator</a></p>\n";
} else {
  echo "<p><span class='disabled'>Enter new page-image creator</span></p>\n";
}
?>
<p><a href='pageImagesResps.php'>View list of page-image creators</a></p>

</body>
</html>
