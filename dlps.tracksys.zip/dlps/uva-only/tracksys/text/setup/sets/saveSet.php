<?php

/*
  saveSet.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-08
  Last modified: 2006-05-24

  Saves user-entered data to database, either by inserting a new
  record or updating an existing record, as appropriate.

  Receives data from: sets.php
  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: followSaveSet.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// validate user input

$location = 'Location: ../../../err/badInput.php?msg=';

// name
if (empty($setName)) {
  header($location . urlencode('Name of multi-volume set is required'));
  exit;
}

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}

// ID
if ($mode == 'update') {
  if (empty($setId)) {
    header($location . urlencode('Multi-volume set ID is required'));
    exit;
  }
}

// connect to db
$connection = connect();

// prep user input
$setName = clean2($setName, $connection, $setNameMaxLength);
$setDesc = clean2($setDesc, $connection, $setDescMaxLength);


// build SQL statement

if ($mode == 'update') {
  if ($chkDelete) {
    testPerm('textSetsDelete');
    $mode = 'delete';
    $sql = 'DELETE FROM sets';
  } else {
    testPerm('textSetsUpdate');
    $sql = 'UPDATE sets SET';
  }
  $where = " WHERE setId = $setId";
} else {
  testPerm('textSetsInsert');
  $sql = 'INSERT INTO sets SET';
  $where = '';
}

if ($mode == 'delete') {
  $values = '';
} else {
  if (empty($setName)) { $value = "NULL"; } else { $value = "'$setName'"; }
  $values = " setName = $value";

  if (empty($setDesc)) { $value = "NULL"; } else { $value = "'$setDesc'"; }
  $values .= ", setDesc = $value";
}

$sql .= $values . $where;

// execute SQL statement
if ( mysql_query($sql, $connection) ) {
  if ( $mode == 'insert' ) {
    $setId = mysql_insert_id();
  }
  $affected = mysql_affected_rows();

  // redirect, indicating success
  header("Location: followSaveSet.php?mode=$mode&setId=$setId&affected=$affected");
} else {
  die($dbErrorPreface . "Unable to $mode multi-volume set '$setName': " . mysql_error($connection) . "<br><br>$sql");
}

?>