<?php

/*
  saveProject.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-08
  Last modified: 2006-05-24

  Saves user-entered data to database, either by inserting a new
  record or updating an existing record, as appropriate.

  Receives data from: projects.php
  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: followSaveProject.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// validate user input

$location = 'Location: ../../../err/badInput.php?msg=';

// name
if (empty($projectName)) {
  header($location . urlencode('Name of project is required'));
  exit;
}

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}

// ID
if ($mode == 'update') {
  if (empty($projectId)) {
    header($location . urlencode('Project ID is required'));
    exit;
  }
}

// connect to db
$connection = connect();

// prep user input
$projectName = clean2($projectName, $connection, $projectNameMaxLength);
$projectDesc = clean2($projectDesc, $connection, $projectDescMaxLength);


// build SQL statement

if ($mode == 'update') {
  if ($chkDelete) {
    testPerm('textProjectsDelete');
    $mode = 'delete';
    $sql = "DELETE FROM projects";
  } else {
    testPerm('textProjectsUpdate');
    $sql = "UPDATE projects SET";
  }
  $where = " WHERE projectId = $projectId";
} else {
  testPerm('textProjectsInsert');
  $sql = "INSERT INTO projects SET";
  $where = '';
}

if ($mode == 'delete') {
  $values = '';
} else {
  if (empty($projectName)) { $value = "NULL"; } else { $value = "'$projectName'"; }
  $values = " projectName = $value";

  if (empty($projectDesc)) { $value = "NULL"; } else { $value = "'$projectDesc'"; }
  $values .= ", projectDesc = $value";
}

$sql .= $values . $where;

// execute SQL statement
if ( mysql_query($sql, $connection) ) {
  if ( $mode == 'insert' ) {
    $projectId = mysql_insert_id();
  }
  $affected = mysql_affected_rows();

  // redirect, indicating success
  header("Location: followSaveProject.php?mode=$mode&projectId=$projectId&affected=$affected");
} else {
  die($dbErrorPreface . "Unable to $mode project '$projectName': " . mysql_error($connection) . "<br><br>$sql");
}

?>