<?php

/*
  followSaveProject.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-08
  Last modified: 2005-10-07

  This page is displayed upon successful insert/update of a project. It
  simply displays non-editable values for the record.

  Receives data from: saveProject.php
*/

import_request_variables('G');
include '../../../inc/tracksys.php';
include '../../../inc/auth.php';

$siteArea = 'Text Workflow - Setup';
$pageTitle = 'Project - Update Status';

// connect to db
$connection = connect();

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
// get data from database and display for confirmation
$sql = "SELECT * FROM projects WHERE projectId = '$projectId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) == 1 ) {
  if ($mode == 'delete') {
    echo "<p class='error'>WARNING: The project was <b>not</b> deleted (project ID: $projectId).
      Contact the $appTitle administrator.</p>
      </body></html>";
    exit;
  }

  if ($affected == '0') {
    echo "<p class='updated'>No changes were needed.</p>";
  } else {
    if ($mode == 'insert') {
      echo "<p class='updated'>New project added successfully</p>\n";
    } else {
      echo "<p class='updated'>Project updated successfully</p>\n";
    }
  }
  $row = mysql_fetch_array($result);
?>

<table cellpadding='6' cellspacing='0'>
<tr>
<td class='label'>Name:</td>
<td><?=$row['projectName']?></td>
</tr><tr>
<td class='label'>Description:</td>
<td><?=$row['projectDesc']?></td>
</tr>
</table>

<?php
} else {
  if ($mode == 'delete') {
    echo "<p class='updated'>Project deleted successfully.</p>\n";
  } else {
    echo "<p>Project ID '$projectId' not found in database. Contact the $appTitle administrator.</p>\n";
  }
}  // END if ( mysql_num_rows($result) == 1 ) ... else ...

if (getPerm('textProjectsInsert')) {
  echo "<p><a href='projects.php?projectId=new'>Enter new project</a></p>\n";
} else {
  echo "<p><span class='disabled'>Enter new project</span></p>\n";
}
?>
<p><a href='projects.php'>View list of projects</a></p>

</body>
</html>
