<?php

/*
  projects.php - page for managing projects
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-13
  Last modified: 2005-10-07

  If no 'projectId' parameter, lists projects already defined.
  If ID is 'new', displays add-new form for defining a project.
  If ID is a number, displays edit form for editing an existing project.
*/

import_request_variables('PG');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Text Workflow - Setup';

if ( empty($projectId) ) {
  // list existing projects
  $pageTitle = 'Projects';
  testPerm('textProjectsSelect');
} else {
  if ($projectId == 'new') {
    // display enter-new form
    $mode = 'insert';
    $pageTitle = 'Enter New Project';
    $submitCaption = ' Add ';
    testPerm('textProjectsInsert');
  } else {
    // display edit form
    $mode = 'update';
    $pageTitle = 'Edit Project';
    $submitCaption = 'Update';

    // test permissions; need Select to view item details, Update to enable submit button
    testPerm('textProjectsSelect');
    if (!getPerm('textProjectsUpdate')) { $submitAppearance = ' disabled'; }
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
<script type="text/javascript" src="../../../inc/tracksys.js"></script>
</head>

<?php
if ( empty($projectId) ) {
  // list existing projects

  if (getPerm('textProjectsInsert')) {
    $addNewLink = "<p><a href='?projectId=new'>Enter new project</a></p>";
  } else {
    $addNewLink = "<p><span class='disabled'>Enter new project</span></p>";
  }
?>

<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<?=$addNewLink?>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>Name</td>
<td>Description</td>
<td>View all members</td>
</tr>

<?php
  $sql = "SELECT * FROM projects ORDER BY projectName";
  $result = query($sql, $connection);
  $num = mysql_num_rows($result);
  if ($num == 0) { echo "<tr><td cols='2'><b>0</b> items</td></tr>\n"; }
  while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);
      echo "<tr$class>
<td><a href='?projectId=$row[projectId]'>$row[projectName]</a></td>
<td>$row[projectDesc]</td>
<td style='white-space: nowrap'><a href='../../../text/search/search3.php?projectId=$row[projectId]&clear=true&searchNow=true'>View all members</a></td>
</tr>\n";
  }
  echo "</table>\n";
}  // END if ( empty($projectId) )

else {
  if ($projectId != 'new') {
    $sql = "SELECT * FROM projects WHERE projectId = '$projectId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $projectId = $row['projectId'];
    }
  }

  if ($deleteEnabled and $mode == 'update' and getPerm('textProjectsDelete')) {
    $onSubmit = " onsubmit='return confirmDelete(document.frm, \"project\");'";
  }
?>

<body onload='document.frm.projectName.focus();'>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name='frm' method='POST' action='saveProject.php'<?=$onSubmit?>>
<input type='hidden' name='mode' value='<?=$mode?>'>
<input type='hidden' name='projectId' value='<?=$projectId?>'>
<table cellpadding='4'>
<tr>
<td class='label'>Name:</td>
<td><input type='text' name='projectName' value="<?=$row[projectName]?>" maxlength='<?=$projectNameMaxLength?>'></td>
</tr>
<tr>
<td class='label'>Description:</td>
<td><input type='text' name='projectDesc' value="<?=$row[projectDesc]?>" size='60' maxlength='<?=$projectDescMaxLength?>'></td>
</tr>
<?php
  if ($deleteEnabled and $mode == 'update' and getPerm('textProjectsDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>
<tr>
<td></td>
<td>
<input type='submit' name='go' value='<?=$submitCaption?>'<?=$submitAppearance?>>
<input type='button' value='Cancel' onclick='history.back();'>
</td>
</tr>
</table>
</form>
<?php
}  // END if ( empty($projectId) ) { ... } else
?>
</body>
</html>
