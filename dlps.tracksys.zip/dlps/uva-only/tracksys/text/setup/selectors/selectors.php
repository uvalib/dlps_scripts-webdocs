<?php

/*
  selectors.php - page for managing selectors
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-09
  Last modified: 2005-10-07

  If no 'selectorId' parameter, lists selectors already defined.
  If ID is 'new', displays add-new form for defining a selector.
  If ID is a number, displays edit form for editing an existing selector.
*/

import_request_variables('PG');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Text Workflow - Setup';

if ( empty($selectorId) ) {
  // list existing selectors
  $pageTitle = 'Selectors';
  testPerm('textSelectorsSelect');
} else {
  if ($selectorId == 'new') {
    // display enter-new form
    $mode = 'insert';
    $pageTitle = 'Enter New Selector';
    $submitCaption = ' Add ';
    testPerm('textSelectorsInsert');
  } else {
    // display edit form
    $mode = 'update';
    $pageTitle = 'Edit Selector';
    $submitCaption = 'Update';

    // test permissions; need Select to view item details, Update to enable submit button
    testPerm('textSelectorsSelect');
    if (!getPerm('textSelectorsUpdate')) { $submitAppearance = ' disabled'; }
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
<script type="text/javascript" src="../../../inc/tracksys.js"></script>
</head>

<?php
if ( empty($selectorId) ) {
  // list existing selectors

  if (getPerm('textSelectorsInsert')) {
    $addNewLink = "<p><a href='?selectorId=new'>Enter new selector</a></p>";
  } else {
    $addNewLink = "<p><span class='disabled'>Enter new selector</span></p>";
  }
?>

<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<?=$addNewLink?>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>Name</td>
<td>Comments</td>
<td>View all items</td>
</tr>

<?php
  $sql = "SELECT * FROM selectors ORDER BY selectorNameLast, selectorNameFirst";
  $result = query($sql, $connection);
  $num = mysql_num_rows($result);
  if ($num == 0) { echo "<tr><td cols='2'><b>0</b> items</td></tr>\n"; }
  while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);
      $name = formatName($row['selectorNameLast'], $row['selectorNameFirst']);
      echo "<tr$class>
<td><a href='?selectorId=$row[selectorId]'>$name</a></td>
<td>$row[selectorDesc]</td>
<td class='nowrap'><a href='../../../text/search/search4.php?selectorId=$row[selectorId]&clear=true&searchNow=true'>View all items from this selector</a></td>
</tr>\n";
  }
  echo "</table>\n";
}  // END if ( empty($selectorId) )

else {
  if ($selectorId != 'new') {
    $sql = "SELECT * FROM selectors WHERE selectorId = '$selectorId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $selectorId = $row['selectorId'];
    }
  }

  if ($deleteEnabled and $mode == 'update' and getPerm('textSelectorsDelete')) {
    $onSubmit = " onsubmit='return confirmDelete(document.frm, \"selector\");'";
  }
?>

<body onload='document.frm.selectorNameFirst.focus();'>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name='frm' method='POST' action='saveSelector.php'<?=$onSubmit?>>
<input type='hidden' name='mode' value='<?=$mode?>'>
<input type='hidden' name='selectorId' value='<?=$selectorId?>'>
<table cellpadding='4'>
<tr>
<td class='label'>First name:</td>
<td><input type='text' name='selectorNameFirst' value='<?=$row[selectorNameFirst]?>' maxlength='<?=$selectorNameFirstMaxLength?>'></td>
</tr>
<tr>
<td class='label'>Last name:</td>
<td><input type='text' name='selectorNameLast' value='<?=$row[selectorNameLast]?>' maxlength='<?=$selectorNameLastMaxLength?>'></td>
</tr>
<tr>
<td class='label'>Comments:</td>
<td><input type='text' name='selectorDesc' value='<?=$row[selectorDesc]?>' size='60' maxlength='<?=$selectorDescMaxLength?>'></td>
</tr>
<?php
  if ($deleteEnabled and $mode == 'update' and getPerm('textSelectorsDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>
<tr>
<td></td>
<td>
<input type='submit' name='go' value='<?=$submitCaption?>'<?=$submitAppearance?>>
<input type='button' value='Cancel' onclick='history.back();'>
</td>
</tr>
</table>
</form>
<?php
}  // END if ( empty($selectorId) ) { ... } else
?>
</body>
</html>
