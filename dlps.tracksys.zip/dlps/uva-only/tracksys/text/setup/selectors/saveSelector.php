<?php

/*
  saveSelector.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-09
  Last modified: 2006-05-24

  Saves user-entered data to database, either by inserting a new
  record or updating an existing record, as appropriate.

  Receives data from: selectors.php
  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: followSaveSelector.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// validate user input

$location = 'Location: ../../../err/badInput.php?msg=';

// name
if (empty($selectorNameLast)) {
  header($location . urlencode('Last name of selector is required'));
  exit;
}

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}

// ID
if ($mode == 'update') {
  if (empty($selectorId)) {
    header($location . urlencode('Selector ID is required'));
    exit;
  }
}

// connect to db
$connection = connect();

// prep user input
$selectorNameFirst = clean2($selectorNameFirst, $connection, $selectorNameFirstMaxLength);
$selectorNameLast = clean2($selectorNameLast, $connection, $selectorNameLastMaxLength);
$selectorDesc = clean2($selectorDesc, $connection, $selectorDescMaxLength);


// build SQL statement

if ($mode == 'update') {
  if ($chkDelete) {
    testPerm('textSelectorsDelete');
    $mode = 'delete';
    $sql = "DELETE FROM selectors";
  } else {
    testPerm('textSelectorsUpdate');
    $sql = "UPDATE selectors SET";
  }
  $where = " WHERE selectorId = $selectorId";
} else {
  testPerm('textSelectorsInsert');
  $sql = "INSERT INTO selectors SET";
  $where = '';
}

if ($mode == 'delete') {
  $values = '';
} else {
  if (empty($selectorNameLast)) { $value = "NULL"; } else { $value = "'$selectorNameLast'"; }
  $values = " selectorNameLast = $value";

  if (empty($selectorNameFirst)) { $value = "NULL"; } else { $value = "'$selectorNameFirst'"; }
  $values .= ", selectorNameFirst = $value";

  if (empty($selectorDesc)) { $value = "NULL"; } else { $value = "'$selectorDesc'"; }
  $values .= ", selectorDesc = $value";
}

$sql .= $values . $where;

// execute SQL statement
if ( mysql_query($sql, $connection) ) {
  if ( $mode == 'insert' ) {
    $selectorId = mysql_insert_id();
  }
  $affected = mysql_affected_rows();

  // redirect, indicating success
  header("Location: followSaveSelector.php?mode=$mode&selectorId=$selectorId&affected=$affected");
} else {
  die($dbErrorPreface . "Unable to $mode selector '$selectorName': " . mysql_error($connection) . "<br><br>$sql");
}

?>