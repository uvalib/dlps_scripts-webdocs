<?php

/*
  batches.php - page for managing vendor batches
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-15
  Last modified: 2005-10-07

  If no 'batchId' parameter, lists batches already defined.
  If ID is 'new', displays add-new form for defining a batch.
  If ID is a number, displays edit form for editing an existing batch.
*/

import_request_variables('PG');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Text Workflow - Setup';

if ( empty($batchId) ) {
  // list existing batches
  $pageTitle = 'Vendor Batches';

  // test permissions
  testPerm('textBatchesSelect');
} else {
  if ($batchId == 'new') {
    // display enter-new form
    $mode = 'insert';
    $pageTitle = 'Enter New Vendor Batch';
    $submitCaption = ' Add ';

    // test permissions
    testPerm('textBatchesInsert');
  } else {
    // display edit form
    $mode = 'update';
    $pageTitle = 'Edit Vendor Batch';
    $submitCaption = 'Update';

    // test permissions; need Select to view item details, Update to enable submit button
    testPerm('textBatchesSelect');
    if (!getPerm('textBatchesUpdate')) { $submitAppearance = ' disabled'; }
  }
}

// get associative array representing table 'batches'
$batches = getHashBatches($connection);

// get associative array representing table 'pageImagesResps'
$pageImagesResps = getHashPageImagesResps($connection);

// get associative array representing table 'transcriptionResps'
$transcriptionResps = getHashTranscriptionResps($connection);

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
<script type="text/javascript" src="../../../inc/tracksys.js"></script>
</head>

<?php
if ( empty($batchId) ) {
  // list existing batches

  if (getPerm('textBatchesInsert')) {
    $addNewLink = "<p><a href='?batchId=new'>Enter new vendor batch</a></p>";
  } else {
    $addNewLink = "<p><span class='disabled'>Enter new vendor batch</span></p>";
  }
?>

<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<?=$addNewLink?>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>Name</td>
<td>Type</td>
<td>Text creator</td>
<td>Page-image creator</td>
<td>Description</td>
<td>View all items</td>
</tr>

<?php
  $sql = "SELECT * FROM batches ORDER BY batchName";
  $result = query($sql, $connection);
  $num = mysql_num_rows($result);
  if ($num == 0) { echo "<tr><td cols='2'><b>0</b> items</td></tr>\n"; }
  while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);

      switch($row['batchType']) {
        case BATCH_TYPE_TEXTS:
          $batchType = 'XML texts';
          break;
        case BATCH_TYPE_IMAGES:
          $batchType = 'Page images';
          break;
        case BATCH_TYPE_BOTH:
          $batchType = 'Both texts and images';
          break;
        default:
          $batchType = '';
      }

      if ( empty($row['transcriptionRespId']) ) {
        $transcriptionRespName = '';
      } else {
        foreach ($transcriptionResps as $id => $name) {
          if ( $id == $row['transcriptionRespId'] ) {
            $transcriptionRespName = $name;
            break;
          }
        }
      }

      if ( empty($row['pageImagesRespId']) ) {
        $pageImagesRespName = '';
      } else {
        foreach ($pageImagesResps as $id => $name) {
          if ( $id == $row['pageImagesRespId'] ) {
            $pageImagesRespName = $name;
            break;
          }
        }
      }

      echo "<tr$class>
<td><a href='?batchId=$row[batchId]'>$row[batchName]</a></td>
<td>$batchType</td>
<td>$transcriptionRespName</td>
<td>$pageImagesRespName</td>
<td>$row[batchDesc]</td>
<td style='white-space: nowrap'><a href='../../../text/search/search3.php?batchId=$row[batchId]&clear=true&searchNow=true'>View all items</a></td>
</tr>\n";
  }
  echo "</table>\n";
}  // END if ( empty($batchId) )

else {
  if ($batchId != 'new') {
    $sql = "SELECT * FROM batches WHERE batchId = '$batchId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $batchId = $row['batchId'];

      switch($row['batchType']) {
        case BATCH_TYPE_TEXTS:
          $batchType = 'XML texts';
          $batchTypeSelectedTexts = ' selected';
          break;
        case BATCH_TYPE_IMAGES:
          $batchType = 'Page images';
          $batchTypeSelectedImages = ' selected';
          break;
        case BATCH_TYPE_BOTH:
          $batchType = 'Both texts and images';
          $batchTypeSelectedBoth = ' selected';
          break;
        default:
          $batchType = '';
      }

      if ( empty($row['transcriptionRespId']) ) {
        $transcriptionRespName = '';
      } else {
        foreach ($transcriptionResps as $id => $name) {
          if ( $id == $row['transcriptionRespId'] ) {
            $transcriptionRespName = $name;
            break;
          }
        }
      }

      if ( empty($row['pageImagesRespId']) ) {
        $pageImagesRespName = '';
      } else {
        foreach ($pageImagesResps as $id => $name) {
          if ( $id == $row['pageImagesRespId'] ) {
            $pageImagesRespName = $name;
            break;
          }
        }
      }
    }  // END if (mysql_num_rows($result) == 1)
  }  // END if ($batchId != 'new')

  if ($deleteEnabled and $mode == 'update' and getPerm('textBatchesDelete')) {
    $onSubmit = " onsubmit='return confirmDelete(document.frm, \"batch\");'";
  }
?>

<body onload='document.frm.batchName.focus();'>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name='frm' method='POST' action='saveBatch.php'<?=$onSubmit?>>
<input type='hidden' name='mode' value='<?=$mode?>'>
<input type='hidden' name='batchId' value='<?=$batchId?>'>
<table cellpadding='4'>
<tr>
<td class='label'>Name:</td>
<td><input type='text' name='batchName' value='<?=$row[batchName]?>' maxlength='<?=$batchNameMaxLength?>'></td>
</tr>

<tr>
<td class='label'>Description:</td>
<td><input type='text' name='batchDesc' value='<?=$row[batchDesc]?>' size='60' maxlength='<?=$batchDescMaxLength?>'></td>
</tr>

<tr>
<td class='label'>Type:</td>
<td><select name='batchType'>
<option value='<?=BATCH_TYPE_TEXTS?>'<?=$batchTypeSelectedTexts?>>XML texts</option>
<option value='<?=BATCH_TYPE_IMAGES?>'<?=$batchTypeSelectedImages?>>Page images</option>
<option value='<?=BATCH_TYPE_BOTH?>'<?=$batchTypeSelectedBoth?>>Both texts and images</option>
</select></td>
</tr>

<tr>
<td class="label">Text creator:</td>
<td><select name="transcriptionRespId">
<option value='0'></option>
<?php
foreach ($transcriptionResps as $id => $name) {
  $selected = '';
  if ( $id == $row['transcriptionRespId'] ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td class="label">Page-image creator:</td>
<td><select name="pageImagesRespId">
<option value='0'></option>
<?php
foreach ($pageImagesResps as $id => $name) {
  $selected = '';
  if ( $id == $row['pageImagesRespId'] ) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<?php
  if ($deleteEnabled and $mode == 'update' and getPerm('textBatchesDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>
<tr>
<td></td>
<td>
<input type='submit' name='go' value='<?=$submitCaption?>'<?=$submitAppearance?>>
<input type='button' value='Cancel' onclick='history.back();'>
</td>
</tr>
</table>
</form>
<?php
}  // END if ( empty($batchId) ) { ... } else
?>
</body>
</html>
