<?php

/*
  followSaveBatch.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-15
  Last modified: 2005-10-07

  This page is displayed upon successful insert/update of a batch. It
  simply displays non-editable values for the record.

  Receives data from: saveBatch.php
*/

import_request_variables('G');
include '../../../inc/tracksys.php';
include '../../../inc/auth.php';

$siteArea = 'Text Workflow - Setup';
$pageTitle = 'Vendor Batch - Update Status';

// connect to db
$connection = connect();

// get associative array representing table 'pageImagesResps'
$pageImagesResps = getHashPageImagesResps($connection);

// get associative array representing table 'transcriptionResps'
$transcriptionResps = getHashTranscriptionResps($connection);
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
// get data from database and display for confirmation
$sql = "SELECT * FROM batches WHERE batchId = '$batchId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) == 1 ) {
  if ($mode == 'delete') {
    echo "<p class='error'>WARNING: The vendor batch set was <b>not</b> deleted (batch ID: $batchId).
      Contact the $appTitle administrator.</p>
      </body></html>";
    exit;
  }

  if ($affected == '0') {
    echo "<p class='updated'>No changes were needed.</p>";
  } else {
    if ($mode == 'insert') {
      echo "<p class='updated'>New vendor batch added successfully</p>\n";
    } else {
      echo "<p class='updated'>Vendor batch updated successfully</p>\n";
    }
  }
  $row = mysql_fetch_array($result);

  switch($row['batchType']) {
    case BATCH_TYPE_TEXTS:
      $batchType = 'XML texts';
    case BATCH_TYPE_IMAGES:
      $batchType = 'Page images';
    case BATCH_TYPE_BOTH:
      $batchType = 'Both texts and images';
    default:
      $batchType = '';
  }

  if ( empty($row['pageImagesRespId']) ) {
    $pageImagesRespName = '';
  } else {
    foreach ($pageImagesResps as $id => $name) {
      if ( $id == $row['pageImagesRespId'] ) {
        $pageImagesRespName = $name;
        break;
      }
    }
  }

  if ( empty($row['transcriptionRespId']) ) {
    $transcriptionRespName = '';
  } else {
    foreach ($transcriptionResps as $id => $name) {
      if ( $id == $row['transcriptionRespId'] ) {
        $transcriptionRespName = $name;
        break;
      }
    }
  }
?>

<table cellpadding='6' cellspacing='0'>
<tr>
<td class='label'>Name:</td>
<td><?=$row['batchName']?></td>
</tr>

<tr>
<td class='label'>Description:</td>
<td><?=$row['batchDesc']?></td>
</tr>

<tr>
<td class='label'>Type:</td>
<td><?=$batchType?></td>
</tr>

<tr>
<td class='label'>Text creator:</td>
<td><?=$transcriptionRespName?></td>
</tr>

<tr>
<td class='label'>Page-image creator:</td>
<td><?=$pageImagesRespName?></td>
</tr>
</table>

<?php
} else {
  if ($mode == 'delete') {
    echo "<p class='updated'>Vendor batch deleted successfully.</p>\n";
  } else {
    echo "<p class='error'>Vendor batch ID '$batchId' not found in database. 
      Contact the $appTitle administrator.</p>\n";
  }
}  // END if ( mysql_num_rows($result) == 1 )

if (getPerm('textBatchesInsert')) {
  echo "<p><a href='batches.php?batchId=new'>Enter new vendor batch</a></p>\n";
} else {
  echo "<p><span class='disabled'>Enter new vendor batch</span></p>\n";
}
?>
<p><a href='batches.php'>View list of vendor batches</a></p>

</body>
</html>
