<?php

/*
  saveBatch.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-15
  Last modified: 2006-05-24

  Saves user-entered data to database, either by inserting a new
  record or updating an existing record, as appropriate.

  Receives data from: batches.php
  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: followSaveBatch.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// validate user input

$location = 'Location: ../../../err/badInput.php?msg=';

// name
if (empty($batchName)) {
  header($location . urlencode('Name of vendor batch is required'));
  exit;
}

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}

// ID
if ($mode == 'update') {
  if (empty($batchId)) {
    header($location . urlencode('Vendor batch ID is required'));
    exit;
  }
}

// batch type
if (empty($batchType)) {
  header($location . urlencode('Batch type is required'));
  exit;
}

// either page-image creator or text creator is required, depending on batch type
switch($batchType) {
  case BATCH_TYPE_TEXTS:
    if ( empty($transcriptionRespId) ) {
      header($location . urlencode('When batch type is "XML texts," text creator is required'));
      exit;
    }
    if ( ! empty($pageImagesRespId) ) {
      header($location . urlencode('When batch type is "XML texts," page-image creator must be empty'));
      exit;
    }
    break;
  case BATCH_TYPE_IMAGES:
    if ( empty($pageImagesRespId) ) {
      header($location . urlencode('When batch type is "Page images," page-images creator is required'));
      exit;
    }
    if ( ! empty($transcriptionRespId) ) {
      header($location . urlencode('When batch type is "Page images," text creator must be empty'));
      exit;
    }
    break;
  case BATCH_TYPE_BOTH:
    if ( empty($transcriptionRespId) || empty($pageImagesRespId) ) {
      header($location . urlencode('When batch type is "Both texts and images," text creator and page-images creator are both required'));
      exit;
    }
    break;
}

// connect to db
$connection = connect();

// prep user input
$batchName = clean2($batchName, $connection, $batchNameMaxLength);
$batchDesc = clean2($batchDesc, $connection, $batchDescMaxLength);


// build SQL statement

if ($mode == 'update') {
  if ($chkDelete) {
    testPerm('textBatchesDelete');
    $mode = 'delete';
    $sql = "DELETE FROM batches";
  } else {
    testPerm('textBatchesUpdate');
    $sql = "UPDATE batches SET";
  }
  $where = " WHERE batchId = $batchId";
} else {
  testPerm('textBatchesInsert');
  $sql = "INSERT INTO batches SET";
  $where = '';
}

if ($mode == 'delete') {
  $values = '';
} else {
  if (empty($batchName)) { $value = "NULL"; } else { $value = "'$batchName'"; }
  $values = " batchName = $value";

  if (empty($batchDesc)) { $value = "NULL"; } else { $value = "'$batchDesc'"; }
  $values .= ", batchDesc = $value";

  if (empty($batchType)) { $value = "0"; } else { $value = "$batchType"; }
  $values .= ", batchType = $value";

  if (empty($transcriptionRespId)) { $value = "0"; } else { $value = "$transcriptionRespId"; }
  $values .= ", transcriptionRespId = $value";

  if (empty($pageImagesRespId)) { $value = "0"; } else { $value = "$pageImagesRespId"; }
  $values .= ", pageImagesRespId = $value";
}

$sql .= $values . $where;

// execute SQL statement
if ( mysql_query($sql, $connection) ) {
  if ( $mode == 'insert' ) {
    $batchId = mysql_insert_id();
  }
  $affected = mysql_affected_rows();

  // redirect, indicating success
  header("Location: followSaveBatch.php?mode=$mode&batchId=$batchId&affected=$affected");
} else {
  die($dbErrorPreface . "Unable to $mode vendor batch '$batchName': " . mysql_error($connection) . "<br><br>$sql");
}

?>