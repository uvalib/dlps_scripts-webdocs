<?php

/*
  followSaveTranscriptionResp.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-08
  Last modified: 2005-10-07

  This page is displayed upon successful insert/update of a
  transcription creator. It simply displays non-editable values for
  the record.

  Receives data from: saveTranscriptionResp.php
*/

import_request_variables('G');
include '../../../inc/tracksys.php';
include '../../../inc/auth.php';

$siteArea = 'Text Workflow - Setup';
$pageTitle = 'Text Creator - Update Status';

// connect to db
$connection = connect();

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
// get data from database and display for confirmation
$sql = "SELECT * FROM transcriptionResps WHERE transcriptionRespId = '$transcriptionRespId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) == 1 ) {
  if ($mode == 'delete') {
    echo "<p class='error'>WARNING: The text creator was <b>not</b> deleted
      (text creator ID: $transcriptionRespId). Contact the $appTitle administrator.</p>
      </body></html>";
    exit;
  }

  if ($affected == '0') {
    echo "<p class='updated'>No changes were needed.</p>";
  } else {
    if ($mode == 'insert') {
      echo "<p class='updated'>New text creator added successfully</p>\n";
    } else {
      echo "<p class='updated'>Text creator updated successfully</p>\n";
    }
  }
  $row = mysql_fetch_array($result);
?>

<table cellpadding='6' cellspacing='0'>
<tr>
<td class='label'>Name:</td>
<td><?=$row['transcriptionRespName']?></td>
</tr><tr>
<td class='label'>Description:</td>
<td><?=$row['transcriptionRespDesc']?></td>
</tr>
</table>

<?php
} else {
  if ($mode == 'delete') {
    echo "<p class='updated'>Text creator deleted successfully.</p>\n";
  } else {
    echo "<p class='error'>Text creator ID '$transcriptionRespId' not found in database. 
      Contact the $appTitle administrator.</p>\n";
  }
}  // END if ( mysql_num_rows($result) == 1 ) ... else ...

if (getPerm('textTranscriptionRespsInsert')) {
  echo "<p><a href='transcriptionResps.php?transcriptionRespId=new'>Enter new text creator</a></p>\n";
} else {
  echo "<p><span class='disabled'>Enter new text creator</span></p>\n";
}
?>
<p><a href='transcriptionResps.php'>View list of text creators</a></p>

</body>
</html>
