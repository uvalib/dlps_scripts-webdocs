<?php

/*
  transcriptionResps.php - page for managing electronic transcription creators
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-06
  Last modified: 2005-10-07

  If no 'transcriptionRespId' parameter, lists transcription creators already defined.
  If ID is 'new', displays add-new form for defining a transcription creator.
  If ID is a number, displays edit form for editing an existing transcription creator.
*/

import_request_variables('PG');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Text Workflow - Setup';

if ( empty($transcriptionRespId) ) {
  // list existing transcription creators
  $pageTitle = 'Text Creators';
  testPerm('textTranscriptionRespsSelect');
} else {
  if ($transcriptionRespId == 'new') {
    // display enter-new form
    $mode = 'insert';
    $pageTitle = 'Enter New Text Creator';
    $submitCaption = ' Add ';
    testPerm('textTranscriptionRespsInsert');
  } else {
    // display edit form
    $mode = 'update';
    $pageTitle = 'Edit Text Creator';
    $submitCaption = 'Update';

    // test permissions; need Select to view item details, Update to enable submit button
    testPerm('textTranscriptionRespsSelect');
    if (!getPerm('textTranscriptionRespsUpdate')) { $submitAppearance = ' disabled'; }
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
<script type="text/javascript" src="../../../inc/tracksys.js"></script>
</head>

<?php
if ( empty($transcriptionRespId) ) {
  // list existing transcription creators

  if (getPerm('textTranscriptionRespsInsert')) {
    $addNewLink = "<p><a href='?transcriptionRespId=new'>Enter new text creator</a></p>";
  } else {
    $addNewLink = "<p><span class='disabled'>Enter new text creator</span></p>";
  }
?>

<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<?=$addNewLink?>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>Name</td>
<td>Description</td>
<td>View all items</td>
</tr>

<?php
  $sql = "SELECT * FROM transcriptionResps ORDER BY transcriptionRespName";
  $result = query($sql, $connection);
  $num = mysql_num_rows($result);
  if ($num == 0) { echo "<tr><td cols='2'><b>0</b> items</td></tr>\n"; }
  while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);
      echo "<tr$class>
<td><a href='?transcriptionRespId=$row[transcriptionRespId]'>$row[transcriptionRespName]</a></td>
<td>$row[transcriptionRespDesc]</td>
<td style='white-space: nowrap'><a href='../../../text/search/search4.php?transcriptionRespId=$row[transcriptionRespId]&clear=true&searchNow=true'>View all items</a></td>
</tr>\n";
  }
  echo "</table>\n";
}  // END if ( empty($transcriptionRespId) )

else {
  if ($transcriptionRespId != 'new') {
    $sql = "SELECT * FROM transcriptionResps WHERE transcriptionRespId = '$transcriptionRespId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $transcriptionRespId = $row['transcriptionRespId'];
    }
  }

  if ($deleteEnabled and $mode == 'update' and getPerm('textTranscriptionRespsDelete')) {
    $onSubmit = " onsubmit='return confirmDelete(document.frm, \"text creator\");'";
  }
?>

<body onload='document.frm.transcriptionRespName.focus();'>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name='frm' method='POST' action='saveTranscriptionResp.php'<?=$onSubmit?>>
<input type='hidden' name='mode' value='<?=$mode?>'>
<input type='hidden' name='transcriptionRespId' value='<?=$transcriptionRespId?>'>
<table cellpadding='4'>
<tr>
<td class='label'>Name:</td>
<td><input type='text' name='transcriptionRespName' value='<?=$row[transcriptionRespName]?>' maxlength='<?=$transcriptionRespNameMaxLength?>'></td>
</tr>
<tr>
<td class='label'>Description:</td>
<td><input type='text' name='transcriptionRespDesc' value='<?=$row[transcriptionRespDesc]?>' size='60' maxlength='<?=$transcriptionRespDescMaxLength?>'></td>
</tr>
<?php
  if ($deleteEnabled and $mode == 'update' and getPerm('textTranscriptionRespsDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>
<tr>
<td></td>
<td>
<input type='submit' name='go' value='<?=$submitCaption?>'<?=$submitAppearance?>>
<input type='button' value='Cancel' onclick='history.back();'>
</td>
</tr>
</table>
</form>
<?php
}  // END if ( empty($transcriptionRespId) ) { ... } else
?>
</body>
</html>
