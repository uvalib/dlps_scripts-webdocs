<?php

/*
  saveTranscriptionResp.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-08
  Last modified: 2006-05-24

  Saves user-entered data to database, either by inserting a new
  record or updating an existing record, as appropriate.

  Receives data from: transcriptionResps.php
  If data is not valid, redirects to: err/badInput.php
  If record is inserted or updated successfully, redirects to: followSaveTranscriptionResp.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// validate user input

$location = 'Location: ../../../err/badInput.php?msg=';

// name
if (empty($transcriptionRespName)) {
  header($location . urlencode('Name of transcription creator is required'));
  exit;
}

// mode
if (empty($mode)) {
  header($location . urlencode('Mode indicator is required'));
  exit;
}

// ID
if ($mode == 'update') {
  if (empty($transcriptionRespId)) {
    header($location . urlencode('Transcription creator ID is required'));
    exit;
  }
}

// connect to db
$connection = connect();

// prep user input
$transcriptionRespName = clean2($transcriptionRespName, $connection, $transcriptionRespNameMaxLength);
$transcriptionRespDesc = clean2($transcriptionRespDesc, $connection, $transcriptionRespDescMaxLength);


// build SQL statement

if ($mode == 'update') {
  if ($chkDelete) {
    testPerm('textTranscriptionRespsDelete');
    $mode = 'delete';
    $sql = 'DELETE FROM transcriptionResps';
  } else {
    testPerm('textTranscriptionRespsUpdate');
    $sql = 'UPDATE transcriptionResps SET';
  }
  $where = " WHERE transcriptionRespId = $transcriptionRespId";
} else {
  testPerm('textTranscriptionRespsInsert');
  $sql = 'INSERT INTO transcriptionResps SET';
  $where = '';
}

if ($mode == 'delete') {
  $values = '';
} else {
  if (empty($transcriptionRespName)) { $value = "NULL"; } else { $value = "'$transcriptionRespName'"; }
  $values = " transcriptionRespName = $value";

  if (empty($transcriptionRespDesc)) { $value = "NULL"; } else { $value = "'$transcriptionRespDesc'"; }
  $values .= ", transcriptionRespDesc = $value";
}

$sql .= $values . $where;

// execute SQL statement
if ( mysql_query($sql, $connection) ) {
  if ( $mode == 'insert' ) {
    $transcriptionRespId = mysql_insert_id();
  }
  $affected = mysql_affected_rows();

  // redirect, indicating success
  header("Location: followSaveTranscriptionResp.php?mode=$mode&transcriptionRespId=$transcriptionRespId&affected=$affected");
} else {
  die($dbErrorPreface . "Unable to $mode transcription creator '$transcriptionRespName': " . mysql_error($connection) . "<br><br>$sql");
}

?>