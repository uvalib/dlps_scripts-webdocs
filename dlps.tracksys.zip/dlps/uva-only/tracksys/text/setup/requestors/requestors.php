<?php

/*
  requestors.php - page for managing requestors
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-07-09
  Last modified: 2005-10-07

  If no 'requestorId' parameter, lists requestors already defined.
  If ID is 'new', displays add-new form for defining a requestor.
  If ID is a number, displays edit form for editing an existing requestor.
*/

import_request_variables('PG');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Text Workflow - Setup';

if ( empty($requestorId) ) {
  // list existing requestors
  $pageTitle = 'Requestors';
  testPerm('textRequestorsSelect');
} else {
  if ($requestorId == 'new') {
    // display enter-new form
    $mode = 'insert';
    $pageTitle = 'Enter New Requestor';
    $submitCaption = ' Add ';
    testPerm('textRequestorsInsert');
  } else {
    // display edit form
    $mode = 'update';
    $pageTitle = 'Edit Requestor';
    $submitCaption = 'Update';

    // test permissions; need Select to view item details, Update to enable submit button
    testPerm('textRequestorsSelect');
    if (!getPerm('textRequestorsUpdate')) { $submitAppearance = ' disabled'; }
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
<script type="text/javascript" src="../../../inc/tracksys.js"></script>
</head>

<?php
if ( empty($requestorId) ) {
  // list existing requestors

  if (getPerm('textRequestorsInsert')) {
    $addNewLink = "<p><a href='?requestorId=new'>Enter new requestor</a></p>";
  } else {
    $addNewLink = "<p><span class='disabled'>Enter new requestor</span></p>";
  }
?>

<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<?=$addNewLink?>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>Name</td>
<td>Comments</td>
<td>View all items</td>
</tr>

<?php
  $sql = "SELECT * FROM requestors ORDER BY requestorNameLast, requestorNameFirst";
  $result = query($sql, $connection);
  $num = mysql_num_rows($result);
  if ($num == 0) { echo "<tr><td cols='2'><b>0</b> items</td></tr>\n"; }
  while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);
      $name = formatName($row['requestorNameLast'], $row['requestorNameFirst']);
      echo "<tr$class>
<td><a href='?requestorId=$row[requestorId]'>$name</a></td>
<td>$row[requestorDesc]</td>
<td class='nowrap'><a href='../../../text/search/search4.php?requestorId=$row[requestorId]&clear=true&searchNow=true'>View all items from this requestor</a></td>
</tr>\n";
  }
  echo "</table>\n";
}  // END if ( empty($requestorId) )

else {
  if ($requestorId != 'new') {
    $sql = "SELECT * FROM requestors WHERE requestorId = '$requestorId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $requestorId = $row['requestorId'];
    }
  }

  if ($deleteEnabled and $mode == 'update' and getPerm('textRequestorsDelete')) {
    $onSubmit = " onsubmit='return confirmDelete(document.frm, \"requestor\");'";
  }
?>

<body onload='document.frm.requestorNameFirst.focus();'>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name='frm' method='POST' action='saveRequestor.php'<?=$onSubmit?>>
<input type='hidden' name='mode' value='<?=$mode?>'>
<input type='hidden' name='requestorId' value='<?=$requestorId?>'>
<table cellpadding='4'>
<tr>
<td class='label'>First name:</td>
<td><input type='text' name='requestorNameFirst' value='<?=$row[requestorNameFirst]?>' maxlength='<?=$requestorNameFirstMaxLength?>'></td>
</tr>
<tr>
<td class='label'>Last name:</td>
<td><input type='text' name='requestorNameLast' value='<?=$row[requestorNameLast]?>' maxlength='<?=$requestorNameLastMaxLength?>'></td>
</tr>
<tr>
<td class='label'>Comments:</td>
<td><input type='text' name='requestorDesc' value='<?=$row[requestorDesc]?>' size='60' maxlength='<?=$requestorDescMaxLength?>'></td>
</tr>
<?php
  if ($deleteEnabled and $mode == 'update' and getPerm('textRequestorsDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>
<tr>
<td></td>
<td>
<input type='submit' name='go' value='<?=$submitCaption?>'<?=$submitAppearance?>>
<input type='button' value='Cancel' onclick='history.back();'>
</td>
</tr>
</table>
</form>
<?php
}  // END if ( empty($requestorId) ) { ... } else
?>
</body>
</html>
