<?php

/*
  groups.php - page for managing groups (arbitrary groupings of text-digitization items)
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-12-01
  Last modified: 2005-10-07

  If no 'groupId' parameter, lists groups already defined.
  If ID is 'new', displays add-new form for defining a group.
  If ID is a number, displays edit form for editing an existing group.
*/

import_request_variables('PG');
include '../../../inc/tracksys.php';
include '../../../inc/maxlengths.php';
include '../../../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Text Workflow - Setup';

if ( empty($groupId) ) {
  // list existing groups
  $pageTitle = 'Groups';

  // test permissions
  testPerm('textGroupsSelect');
} else {
  if ($groupId == 'new') {
    // display enter-new form
    $mode = 'insert';
    $pageTitle = 'Enter New Group';
    $submitCaption = ' Add ';

    // test permissions
    testPerm('textGroupsInsert');
  } else {
    // display edit form
    $mode = 'update';
    $pageTitle = 'Edit Group';
    $submitCaption = 'Update';

    // test permissions; need Select to view item details, Update to enable submit button
    testPerm('textGroupsSelect');
    if (!getPerm('textGroupsUpdate')) { $submitAppearance = ' disabled'; }
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../../inc/tracksys.css">
<script type="text/javascript" src="../../../inc/tracksys.js"></script>
</head>

<?php
if ( empty($groupId) ) {
  // list existing groups

  if (getPerm('textGroupsInsert')) {
    $addNewLink = "<p><a href='?groupId=new'>Enter new group</a></p>";
  } else {
    $addNewLink = "<p><span class='disabled'>Enter new group</span></p>";
  }
?>

<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<?=$addNewLink?>
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>Name</td>
<td>Description</td>
<td>View all members</td>
</tr>

<?php
  $sql = "SELECT * FROM groups ORDER BY groupName";
  $result = query($sql, $connection);
  $num = mysql_num_rows($result);
  if ($num == 0) { echo "<tr><td cols='2'><b>0</b> items</td></tr>\n"; }
  while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);
      echo "<tr$class>
<td><a href='?groupId=$row[groupId]'>$row[groupName]</a></td>
<td>$row[groupDesc]</td>
<td style='white-space: nowrap'><a href='../../../text/search/search3.php?groupId=$row[groupId]&clear=true&searchNow=true'>View all members</a></td>
</tr>\n";
  }
  echo "</table>\n";
}  // END if ( empty($groupId) )

else {
  if ($groupId != 'new') {
    $sql = "SELECT * FROM groups WHERE groupId = '$groupId'";
    $result = query($sql, $connection);
    if (mysql_num_rows($result) == 1) {
      $row = mysql_fetch_array($result);
      $groupId = $row['groupId'];
    }
  }

  if ($deleteEnabled and $mode == 'update' and getPerm('textGroupsDelete')) {
    $onSubmit = " onsubmit='return confirmDelete(document.frm, \"group\");'";
  }
?>

<body onload='document.frm.groupName.focus();'>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name='frm' method='POST' action='saveGroup.php'<?=$onSubmit?>>
<input type='hidden' name='mode' value='<?=$mode?>'>
<input type='hidden' name='groupId' value='<?=$groupId?>'>
<table cellpadding='4'>
<tr>
<td class='label'>Name:</td>
<td><input type='text' name='groupName' value='<?=$row[groupName]?>' maxlength='<?=$groupNameMaxLength?>'></td>
</tr>
<tr>
<td class='label'>Description:</td>
<td><input type='text' name='groupDesc' value='<?=$row[groupDesc]?>' size='60' maxlength='<?=$groupDescMaxLength?>'></td>
</tr>
<?php
  if ($deleteEnabled and $mode == 'update' and getPerm('textGroupsDelete')) {
    echo "<tr>
<td></td>
<td><input type='checkbox' name='chkDelete' onclick='chkDelete_onClick(document.frm);'> Delete</td>
</tr>\n";
  }
?>
<tr>
<td></td>
<td>
<input type='submit' name='go' value='<?=$submitCaption?>'<?=$submitAppearance?>>
<input type='button' value='Cancel' onclick='history.back();'>
</td>
</tr>
</table>
</form>
<?php
}  // END if ( empty($groupId) ) { ... } else
?>
</body>
</html>
