<?php

/*
  saveTeiHeader.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-06-29
  Last modified: 2006-02-23

  Saves changes to database for TEI Header workflow steps.

  Receives data from: confirmTeiHeader.php (or from cataloging.php)
  Redirects to: workflowTeiHeader.php (or cataloging.php)

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to database
$connection = connect();

// test permissions
testPerm('textTeiHeaderUpdate');

// get all DLPS IDs from the posted form
$ids = array();
foreach ($_POST as $name => $value) {
  if ( ereg("(reviewMarc|exportMarc|makeTeiHeader|reviewTeiHeader|hasIndependentHeader)_(.+)", $name, $refs) ) {
    $ids[] = $refs[2];
  }
}

// for each ID, update values as needed
$updatedIds = array();
$teiHeaderDoneIds = array();
foreach ($ids as $id) {
  $updates = '';
  $updatesTextItems = '';
  for ($i = 1; $i <= 5; $i++) {
    switch ($i) {
      case 1: $columnName = 'reviewMarc'; break;
      case 2: $columnName = 'exportMarc'; break;
      case 3: $columnName = 'makeTeiHeader'; break;
      case 4: $columnName = 'reviewTeiHeader'; break;
      case 5: $columnName = 'hasIndependentHeader'; break;
    }

    if (!empty($_POST[$columnName . '_' . $id])) {
      $value = $_POST[$columnName . '_' . $id];
      if ($value == 'true') {
	if ($columnName == 'hasIndependentHeader') {
	  $updatesTextItems .= " $columnName = 1";
	} else {
	  $updates .= " $columnName = 1,";
	}
      } else {
	if ($columnName == 'hasIndependentHeader') {
	  $updatesTextItems .= " $columnName = 0";
	} else {
	  $updates .= " $columnName = 0,";
	}
      }
    }
  }

  $updates = ereg_replace(',$', '', $updates);  // strip final comma

  if (empty($updates) and empty($updatesTextItems)) {
    // no updates for this ID; continue with next ID
    continue;
  }

  // determine which IDs to include in email notification
  if ( preg_match('/reviewTeiHeader = 1/', $updates) ) {
    $sql =  "SELECT teiHeader.dlpsId, textItems.title ";
    $sql .= "FROM teiHeader LEFT JOIN textItems USING (dlpsId) ";
    $sql .= "WHERE teiHeader.dlpsId = '$id' AND teiHeader.reviewTeiHeader = 0";
    $result = query($sql, $connection);
    if ( mysql_num_rows($result) == 1 ) {
      $row = mysql_fetch_array($result);
      $teiHeaderDoneIds[$id] = $row['title'];
    }
  }

  if (!empty($updates)) {
    $sql = "UPDATE teiHeader SET $updates WHERE dlpsId = '$id' LIMIT 1";
    if ( mysql_query($sql, $connection) ) {
      if (mysql_affected_rows() == 1) {
	$updatedIds[$id] = $id;
      }
    } else {
      die($dbErrorPreface . "Unable to update record '$id' in table teiHeader: " . mysql_error($connection) . "<br><br>$sql");
    }
  }

  if (!empty($updatesTextItems)) {
    // get title control number for this DLPS ID
    $titleControlNumber = '';
    $sql =  "SELECT titleControlNumber FROM textItems WHERE dlpsId = '$id'";
    $result = query($sql, $connection);
    if ( mysql_num_rows($result) == 1 ) {
      $row = mysql_fetch_array($result);
      $titleControlNumber = $row['titleControlNumber'];
    }

    if ($titleControlNumber) {
      // update all items with this title control number
      $sql = "UPDATE textItems SET $updatesTextItems WHERE titleControlNumber = '$titleControlNumber'";
    } else {
      $sql = "UPDATE textItems SET $updatesTextItems WHERE dlpsId = '$id' LIMIT 1";
    }

    if ( mysql_query($sql, $connection) ) {
      if (! array_key_exists($id, $updatedIds)) {
	$updatedIds[$id] = $id;
      }
    } else {
      die($dbErrorPreface . "Unable to update record '$id' in table textItems: " . mysql_error($connection) . "<br><br>$sql");
    }
  }
}

// send email notification for items updated to indicate TEI header completed
if ($teiHeaderDoneIds) {
  $to = $teiHeaderDoneEmailRecipients;
  $headers = "From: $emailFrom";
  $subject = "$appTitle - TEI headers finished";

  $body = "User " . getUserDesc() . " has updated the $appTitle to indicate that the TEI header is finished for the following items:\n\n";

  foreach ($teiHeaderDoneIds as $id => $title) {
    $body .= "$id   $title\n";
  }

  $body = wordwrap($body, 70);
  mail($to, $subject, $body, $headers);
}

// redirect, indicating success
$ids = '';
foreach ($updatedIds as $id) {
  $ids .= $id . '|';
}
$ids = ereg_replace('\|$', '', $ids);  // strip final |
header("Location: workflowTeiHeader.php?status=updated&ids=$ids");
?>