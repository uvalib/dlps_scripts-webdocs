<?php

/*
  confirmTeiHeader.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-06-29
  Last modified: 2006-02-23

  Displays changes proposed for text items in the context of the TEI
  Header workflow. Allows user to commit changes to database, or cancel.

  Receives data from: workflowTeiHeader.php
  Posts data to: saveTeiHeader.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'TEI Header Workflow - Confirm Changes';

// connect to database
$connection = connect();

// test permissions
testPerm('textTeiHeaderUpdate');

// get all DLPS IDs from the posted form
$ids = array();
foreach ($_POST as $name => $value) {
  if ( ereg("dlpsId_(.+)", $name, $refs) ) {
    $ids[] = $refs[1];
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<p>Do you want to make the following changes?</p>
<form name="form" method="POST" action="saveTeiHeader.php">
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>DLPS&nbsp;ID</td>
<td>Title</td>
<td align='center'>Review Virgo record</td>
<td align='center'>Export Virgo record</td>
<td align='center'>Make TEI header</td>
<td align='center'>Review TEI header</td>
<td align='center'>Make independent header (serials only)</td>
</tr>

<?php
// for each ID, query database to determine whether the record actually requires updating
$changes = array();
foreach ($ids as $id) {
  $sql = "SELECT textItems.title, textItems.volumeNumber, textItems.hasIndependentHeader, teiHeader.*
          FROM textItems LEFT JOIN teiHeader USING (dlpsId)
          WHERE teiHeader.dlpsId = '$id'";
  $result = query($sql, $connection);
  if ( mysql_num_rows($result) == 1 ) {
    $row = mysql_fetch_array($result);

    for ($i = 1; $i <= 5; $i++) {
      switch ($i) {
        case 1: $columnName = 'reviewMarc'; break;
        case 2: $columnName = 'exportMarc'; break;
        case 3: $columnName = 'makeTeiHeader'; break;
        case 4: $columnName = 'reviewTeiHeader'; break;
        case 5: $columnName = 'hasIndependentHeader'; break;
      }

      if ( (!empty($_POST[$columnName . '_' . $id])) && ($row[$columnName] == 0) ) {
        // form = true, database = false
        $changes[$id] .= "$columnName=1|";
      }
      if ( (empty($_POST[$columnName . '_' . $id])) && ($row[$columnName] == 1) ) {
        // form = false, database = true
        $changes[$id] .= "$columnName=0|";
      }
    }

    if (!empty($changes[$id])) {
      $changes[$id] = preg_replace('/\|$/', '', $changes[$id]);
      $c++;
      $class = getRowClass($c);
      $title = formatTitle($row['title'], $row['volumeNumber']);
      echo "<tr$class><td>$id</td><td>$title</td>";

      for ($i = 1; $i <= 5; $i++) {
        switch ($i) {
          case 1: $columnName = 'reviewMarc'; break;
          case 2: $columnName = 'exportMarc'; break;
          case 3: $columnName = 'makeTeiHeader'; break;
          case 4: $columnName = 'reviewTeiHeader'; break;
          case 5: $columnName = 'hasIndependentHeader'; break;
        }

        if ( preg_match("/$columnName=(0|1)/", $changes[$id], $refs) ) {
          if ($refs[1] == '1') {
	    $checked = ' checked';
	    $tf = 'true';
	  } else {
	    $checked = '';
	    $tf = 'false';
	  }
	  // checkboxes are for display only; value is passed via hidden textbox
          echo "<td align='center'><input type='checkbox'$checked disabled>
                <input type='hidden' name='{$columnName}_$id' value='$tf'></td>";
        } else {
          echo "<td>&nbsp;</td>";
        }
      }
      echo "</tr>\n";
    }
  }
}

if (empty($changes)) {
  echo "<tr><td colspan='7'>[No changes indicated]</td></tr>\n";
}

echo "</tr>\n</table>\n";

if (empty($changes)) {
  echo "<p><input type='button' value=' Back ' onclick='history.back();'></p>\n";
} else {
  echo "<p><input type='submit' name='update' value='Update'>
        <input type='button' name='cancel' value='Cancel' onclick='history.back();'></p>\n";
}
?>
</form>
</body>
</html>
