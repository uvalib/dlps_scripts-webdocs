<?php

/*
  workflowPostkb.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-11-17
  Last modified: 2006-01-06

  Displays text items in the context of the post-keyboarding
  workflow. Allows user to check or uncheck the various steps in the
  workflow, to indicate completion or incompletion of the steps.

  Receives data from: search/search.php
  Posts data to: confirmPostkb.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'Post-keyboarding Workflow';

// connect to db
$connection = connect();

// test permissions
testPerm('textSelect');

// get DLPS IDs to be displayed
if ($_GET['status'] == 'updated') {
  // we are returning here after an update; get IDs from query string
  $ids = explode('|', $_GET['ids']);
} else {
  // get IDs from posted form
  $ids = array();
  foreach ($_POST as $name => $value) {
    if ( substr($name, 0, 7) == 'dlpsId_' ) {
      $ids[] = substr($name, 7);
    }
  }
}

// build SQL statement
if (!empty($ids)) {
  $sql = "SELECT textItems.title, textItems.volumeNumber, textItems.isFinished,
    bookScanning.makeWebImages, postkb.*
    FROM textItems LEFT JOIN bookScanning USING (dlpsId) LEFT JOIN postkb USING (dlpsId)
    WHERE postkb.dlpsId IN (";
  $c = 0;
  foreach ($ids as $id) {
    if ($c == 0) {
      $sql .= "'$id'";
    } else {
      $sql .= ", '$id'";
    }
    $c++;
  }
  $sql .= ")";

  switch ($_POST['orderBy']) {
    case 'title':
      $sql .= ' ORDER BY title, volumeNumber';
      break;
    default:
      $sql .= ' ORDER BY postkb.dlpsId';
  }
}
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="POST" action="confirmPostkb.php">
<?php

//if ($debugMode) { echo "<p>$sql</p>\n"; }

if ($_GET['status'] == 'updated') {
  echo "<p class='updated'>Updated</p>\n";
}

echo $workflowNewSearchLink;

echo "<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>DLPS&nbsp;ID</td>
<td>Title</td>
<td>View images</td>
<td align='center'>Download</td>
<td align='center'>Validate</td>
<td align='center'>Fix vendor problems</td>
<td align='center'>Run scripts</td>
<td align='center'>Sync pages</td>
<td align='center'>Generate reports</td>
<td align='center'>Submit rehyphenate report</td>
<td align='center'>Commit rehyphenate changes</td>
<td align='center'>Submit unclears report</td>
<td align='center'>Commit unclears changes</td>
<td align='center'>Submit figures-rend report</td>
<td align='center'>Commit figures-rend changes</td>
<td align='center'>Generate figures-filenames report</td>
<td align='center'>Submit figures-filenames report</td>
<td align='center'>Commit figures-filenames changes</td>
<td align='center'>Copy to 59processed</td>
<td>&nbsp;</td>
</tr>\n";

$colspan = 20;        // total number of columns
$colspanLeading = 3;  // number of leading (non-checkbox) columns preceding the first checkbox column
$colspanDiff = 17;

// submit query and display results
if ( empty($ids) ) {
  echo "<tr><td colspan='$colspan'>[No items selected]</td></tr>
        </table>
        <p><input type='button' value=' Back ' onclick='history.back();'></p>\n";
} else {
  // include 'Check all' and 'Clear all' controls
  $c = 1;
  $class = getRowClass($c);
  echo "<tr$class><td colspan='$colspanLeading'>&nbsp;</td>\n";

  echoCheckAllClearAll('download');
  echoCheckAllClearAll('validate');
  echoCheckAllClearAll('fixVendorProblems');
  echoCheckAllClearAll('runScripts');
  echoCheckAllClearAll('syncPages');
  echoCheckAllClearAll('generateReports');
  echoCheckAllClearAll('submitRehyphenateReport');
  echoCheckAllClearAll('commitRehyphenateChanges');
  echoCheckAllClearAll('submitUnclearsReport');
  echoCheckAllClearAll('commitUnclearsChanges');
  echoCheckAllClearAll('submitFiguresRendReport');
  echoCheckAllClearAll('commitFiguresRendChanges');
  echoCheckAllClearAll('generateFiguresFilenamesReport');
  echoCheckAllClearAll('submitFiguresFilenamesReport');
  echoCheckAllClearAll('commitFiguresFilenamesChanges');
  echoCheckAllClearAll('copyToDoneDir');

  echo "<td>&nbsp;</td>\n</tr>\n";

  $result = query($sql, $connection);
  if ( ! mysql_num_rows($result) >= 1 ) {
    echo "<tr><td colspan='$colspan'>[No matching items]</td></tr>
          </table>
          <p><input type='button' value=' Back ' onclick='history.back();'></p>\n";
  } else {
    while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);

      if ($row['download'] == 0)        { $downloadChecked = ''; }         else { $downloadChecked = 'checked'; }
      if ($row['validate'] == 0)        { $validateChecked = ''; }         else { $validateChecked = 'checked'; }
      if ($row['fixVendorProblems']==0) { $fixVendorProblemsChecked = '';} else { $fixVendorProblemsChecked = 'checked';}
      if ($row['runScripts'] == 0)      { $runScriptsChecked = ''; }       else { $runScriptsChecked = 'checked'; }
      if ($row['syncPages'] == 0)       { $syncPagesChecked = ''; }        else { $syncPagesChecked = 'checked'; }
      if ($row['generateReports'] == 0) { $generateReportsChecked = ''; }  else { $generateReportsChecked = 'checked'; }

      if ($row['submitRehyphenateReport'] == 0) {
        $submitRehyphenateReportChecked = '';
      } else {
        $submitRehyphenateReportChecked = 'checked';
      }

      if ($row['commitRehyphenateChanges'] == 0) {
        $commitRehyphenateChangesChecked = '';
      } else {
        $commitRehyphenateChangesChecked = 'checked';
      }

      if ($row['submitUnclearsReport'] == 0) {
        $submitUnclearsReportChecked = '';
      } else {
        $submitUnclearsReportChecked = 'checked';
      }

      if ($row['commitUnclearsChanges'] == 0) {
        $commitUnclearsChangesChecked = '';
      } else {
        $commitUnclearsChangesChecked = 'checked';
      }

      if ($row['submitFiguresRendReport'] == 0) {
        $submitFiguresRendReportChecked = '';
      } else {
        $submitFiguresRendReportChecked = 'checked';
      }

      if ($row['commitFiguresRendChanges'] == 0) {
        $commitFiguresRendChangesChecked = '';
      } else {
        $commitFiguresRendChangesChecked = 'checked';
      }

      if ($row['generateFiguresFilenamesReport'] == 0) {
        $generateFiguresFilenamesReportChecked = '';
      } else {
        $generateFiguresFilenamesReportChecked = 'checked';
      }

      if ($row['submitFiguresFilenamesReport'] == 0) {
        $submitFiguresFilenamesReportChecked = '';
      }  else {
        $submitFiguresFilenamesReportChecked = 'checked';
      }

      if ($row['commitFiguresFilenamesChanges'] == 0) {
        $commitFiguresFilenamesChangesChecked = '';
      } else {
        $commitFiguresFilenamesChangesChecked = 'checked';
      }

      if ($row['copyToDoneDir'] == 0) { $copyToDoneDirChecked = ''; } else { $copyToDoneDirChecked = 'checked'; }

      if ($row['makeWebImages'] == 0 or $row['isFinished'] == 1) {
        $viewPageImages = '';
      } else {
        $viewPageImages = "<a target='proofreader' href='$imageViewerUrl?id=$row[dlpsId]'>View images</a>";
      }

      $id = $row['dlpsId'];
      $idArg = '"' . $row['dlpsId'] . '"';
      $title = formatTitle($row['title'], $row['volumeNumber']);

      $cellStart = "<td align='center'><input type='checkbox'";

      echo "<tr$class>
<td><a href='../textItem.php?dlpsId=$id'>$id</a> <input type='hidden' name='dlpsId_$id' value='$id'></td>
<td>$title</td>
<td>$viewPageImages</td>

$cellStart name='download_$id'                 title='$id: Download'                    $downloadChecked></td>
$cellStart name='validate_$id'                 title='$id: Validate'                    $validateChecked></td>
$cellStart name='fixVendorProblems_$id'        title='$id: Fix vendor problems'         $fixVendorProblemsChecked></td>
$cellStart name='runScripts_$id'               title='$id: Run scripts'                 $runScriptsChecked></td>
$cellStart name='syncPages_$id'                title='$id: Sync pages'                  $syncPagesChecked></td>
$cellStart name='generateReports_$id'          title='$id: Generate reports'            $generateReportsChecked></td>
$cellStart name='submitRehyphenateReport_$id'  title='$id: Submit rehyphenate report'   $submitRehyphenateReportChecked></td>
$cellStart name='commitRehyphenateChanges_$id' title='$id: Commit rehyphenate changes'  $commitRehyphenateChangesChecked></td>
$cellStart name='submitUnclearsReport_$id'     title='$id: Submit unclears report'      $submitUnclearsReportChecked></td>
$cellStart name='commitUnclearsChanges_$id'    title='$id: Commit unclears changes'     $commitUnclearsChangesChecked></td>
$cellStart name='submitFiguresRendReport_$id'  title='$id: Submit figures-rend report'  $submitFiguresRendReportChecked></td>
$cellStart name='commitFiguresRendChanges_$id' title='$id: Commit figures-rend changes' $commitFiguresRendChangesChecked></td>
$cellStart name='generateFiguresFilenamesReport_$id' title='$id: Generate figures-filenames report' $generateFiguresFilenamesReportChecked></td>
$cellStart name='submitFiguresFilenamesReport_$id' title='$id: Submit figures-filenames report' $submitFiguresFilenamesReportChecked></td>
$cellStart name='commitFiguresFilenamesChanges_$id' title='$id: Commit figure filenames changes' $commitFiguresFilenamesChangesChecked></td>
$cellStart name='copyToDoneDir_$id'            title='$id: Copy to 59processed'         $copyToDoneDirChecked></td>

<td class='controls' nowrap>
  <img src='../../img/check.gif' onclick='setCheckboxesRow(true, $idArg);' title='Check all for this row ($id)'>
  <img src='../../img/square.gif' onclick='setCheckboxesRow(false, $idArg);' title='Clear all for this row ($id)'>
</td>
</tr>\n";
    }

    $c++;
    $class = getRowClass($c);

    if (!getPerm('textPostkbUpdate')) { $submitAppearance = ' disabled'; }
    $temp = "<input type='submit' value='Update'$submitAppearance> <input type='reset' value='Reset'>";
    if ($_GET['status'] != 'updated') {
      $temp .= " <input type='button' value='Cancel' onclick='history.back();'>";
    }
    echo "<tr$class>
<td colspan='$colspanLeading' style='white-space: nowrap;'>$temp</td>
<td align='right' colspan='$colspanDiff' style='white-space: nowrap;'>$temp</td>
</tr>
</table>\n";
  }

  echo "<p></p><hr>
<table cellpadding='4'>
<tr>
<td align='right'>Change view:
<select name='workflow'>
<option value='bookScanning'>Book scanning workflow</option>
<option value='migration'>Migration images workflow</option>
<option value='pageBook'>Page book workflow</option>
<option value='teiHeader'>TEI header workflow</option>
<option value='markupQA' selected>Markup QA workflow</option>
<option value='finalization'>Finalization workflow</option>
</select>
</td>
<td valign='bottom'>
<input type='button' value='View Workflow' onclick='if ( setFormAction(document.frm) ) { document.frm.submit(); }'>
<input type='hidden' name='orderBy' value='$_POST[orderBy]'>
</td>
</tr>
</table>\n";

  echo $workflowNewSearchLink;
}
?>
</form>
</body>
</html>
