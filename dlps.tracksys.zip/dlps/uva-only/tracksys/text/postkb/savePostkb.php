<?php

/*
  savePostkb.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-11-18
  Last modified: 2005-06-17

  Saves changes to database for post-keyboarding workflow steps.

  Receives data from: confirmPostkb.php
  Redirects to: workflowPostkb.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to database
$connection = connect();

// test permissions
testPerm('textPostkbUpdate');

// get all DLPS IDs from the posted form
$ids = array();
foreach ($_POST as $name => $value) {
  if ( preg_match('/(download|validate|fixVendorProblems|runScripts|syncPages|generateReports|submitRehyphenateReport|commitRehyphenateChanges|submitUnclearsReport|commitUnclearsChanges|submitFiguresRendReport|commitFiguresRendChanges|generateFiguresFilenamesReport|submitFiguresFilenamesReport|commitFiguresFilenamesChanges|copyToDoneDir)_(.+)/', $name, $refs) ) {
    $ids[] = $refs[2];
  }
}

// for each ID, update values as needed
$updatedIds = array();
foreach ($ids as $id) {
  $sql = "UPDATE postkb SET";

  $updates = '';
  for ($i = 1; $i <= 16; $i++) {
    switch ($i) {
      case 1:  $columnName = 'download'; break;
      case 2:  $columnName = 'validate'; break;
      case 3:  $columnName = 'fixVendorProblems'; break;
      case 4:  $columnName = 'runScripts'; break;
      case 5:  $columnName = 'syncPages'; break;
      case 6:  $columnName = 'generateReports'; break;
      case 7:  $columnName = 'submitRehyphenateReport'; break;
      case 8:  $columnName = 'commitRehyphenateChanges'; break;
      case 9:  $columnName = 'submitUnclearsReport'; break;
      case 10: $columnName = 'commitUnclearsChanges'; break;
      case 11: $columnName = 'submitFiguresRendReport'; break;
      case 12: $columnName = 'commitFiguresRendChanges'; break;
      case 13: $columnName = 'generateFiguresFilenamesReport'; break;
      case 14: $columnName = 'submitFiguresFilenamesReport'; break;
      case 15: $columnName = 'commitFiguresFilenamesChanges'; break;
      case 16: $columnName = 'copyToDoneDir'; break;
    }

    if (!empty($_POST[$columnName . '_' . $id])) {
      $value = $_POST[$columnName . '_' . $id];
      if ($value == 'true') {
        $updates .= " $columnName = 1,";
      } else {
        $updates .= " $columnName = 0,";
      }
    }
  }

  if (empty($updates)) {
    // no updates for this ID; continue with next ID
    continue;
  }

  $updates = preg_replace('/,$/', '', $updates);  // strip final comma

  $sql .= "$updates WHERE dlpsId = '$id'";

  if ( mysql_query($sql, $connection) ) {
    if (mysql_affected_rows() == 1) {
      $updatedIds[$id] = $id;
    }
  } else {
    die($dbErrorPreface . "Unable to update record '$id' in table postkb: " . mysql_error($connection) . "<br><br>$sql");
  }
}

// redirect, indicating success
$ids = '';
foreach ($updatedIds as $id) {
  $ids .= $id . '|';
}
$ids = preg_replace('/\|$/', '', $ids);  // strip final |
header("Location: workflowPostkb.php?status=updated&ids=$ids");
?>