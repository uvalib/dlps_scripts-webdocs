<?php

/*
  confirmPostkb.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-11-17
  Last modified: 2005-10-07

  Displays changes proposed for text items in the context of the
  post-keyboarding workflow. Allows user to commit changes to
  database, or cancel.

  Receives data from: workflowPostkb.php
  Posts data to: savePostkb.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'Post-keyboarding Workflow - Confirm Changes';

// connect to database
$connection = connect();

// test permissions
testPerm('textPostkbUpdate');

// get all DLPS IDs from the posted form
$ids = array();
foreach ($_POST as $name => $value) {
  if ( ereg("dlpsId_(.+)", $name, $refs) ) {
    $ids[] = $refs[1];
  }
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<p>Do you want to make the following changes?</p>
<form name="form" method="POST" action="savePostkb.php">
<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>DLPS&nbsp;ID</td>
<td>Title</td>
<td align='center'>Download</td>
<td align='center'>Validate</td>
<td align='center'>Fix vendor problems</td>
<td align='center'>Run scripts</td>
<td align='center'>Sync pages</td>
<td align='center'>Generate reports</td>
<td align='center'>Submit rehyphenate report</td>
<td align='center'>Commit rehyphenate changes</td>
<td align='center'>Submit unclears report</td>
<td align='center'>Commit unclears changes</td>
<td align='center'>Submit figures-rend report</td>
<td align='center'>Commit figures-rend changes</td>
<td align='center'>Generate figures-filenames report</td>
<td align='center'>Submit figures-filenames report</td>
<td align='center'>Commit figures-filenames changes</td>
<td align='center'>Copy to 59processed</td>
</tr>

<?php
$colspan = 18;  // total number of columns

// for each ID, query database to determine whether the record actually requires updating
$changes = array();
foreach ($ids as $id) {
  $sql = "SELECT textItems.title, textItems.volumeNumber, postkb.*
          FROM textItems LEFT JOIN postkb USING (dlpsId)
          WHERE postkb.dlpsId = '$id'";
  $result = query($sql, $connection);
  if ( mysql_num_rows($result) == 1 ) {
    $row = mysql_fetch_array($result);

    for ($i = 1; $i <= 16; $i++) {
      switch ($i) {
        case 1:  $columnName = 'download'; break;
        case 2:  $columnName = 'validate'; break;
        case 3:  $columnName = 'fixVendorProblems'; break;
        case 4:  $columnName = 'runScripts'; break;
        case 5:  $columnName = 'syncPages'; break;
        case 6:  $columnName = 'generateReports'; break;
        case 7:  $columnName = 'submitRehyphenateReport'; break;
        case 8:  $columnName = 'commitRehyphenateChanges'; break;
        case 9:  $columnName = 'submitUnclearsReport'; break;
        case 10: $columnName = 'commitUnclearsChanges'; break;
        case 11: $columnName = 'submitFiguresRendReport'; break;
        case 12: $columnName = 'commitFiguresRendChanges'; break;
        case 13: $columnName = 'generateFiguresFilenamesReport'; break;
        case 14: $columnName = 'submitFiguresFilenamesReport'; break;
        case 15: $columnName = 'commitFiguresFilenamesChanges'; break;
        case 16: $columnName = 'copyToDoneDir'; break;
      }

      if ( (!empty($_POST[$columnName . '_' . $id])) && ($row[$columnName] == 0) ) {
        // form = true, database = false
        $changes[$id] .= "$columnName=1|";
      }
      if ( (empty($_POST[$columnName . '_' . $id])) && ($row[$columnName] == 1) ) {
        // form = false, database = true
        $changes[$id] .= "$columnName=0|";
      }
    }

    if (!empty($changes[$id])) {
      $changes[$id] = preg_replace('/\|$/', '', $changes[$id]);
      $c++;
      $class = getRowClass($c);
      $title = formatTitle($row['title'], $row['volumeNumber']);
      echo "<tr$class><td>$id</td><td>$title</td>";
      for ($i = 1; $i <= 16; $i++) {
        switch ($i) {
          case 1:  $columnName = 'download'; break;
          case 2:  $columnName = 'validate'; break;
          case 3:  $columnName = 'fixVendorProblems'; break;
          case 4:  $columnName = 'runScripts'; break;
          case 5:  $columnName = 'syncPages'; break;
          case 6:  $columnName = 'generateReports'; break;
          case 7:  $columnName = 'submitRehyphenateReport'; break;
          case 8:  $columnName = 'commitRehyphenateChanges'; break;
          case 9:  $columnName = 'submitUnclearsReport'; break;
          case 10: $columnName = 'commitUnclearsChanges'; break;
          case 11: $columnName = 'submitFiguresRendReport'; break;
          case 12: $columnName = 'commitFiguresRendChanges'; break;
          case 13: $columnName = 'generateFiguresFilenamesReport'; break;
          case 14: $columnName = 'submitFiguresFilenamesReport'; break;
          case 15: $columnName = 'commitFiguresFilenamesChanges'; break;
          case 16: $columnName = 'copyToDoneDir'; break;
        }

        if ( preg_match("/$columnName=(0|1)/", $changes[$id], $refs) ) {
          if ($refs[1] == '1') {
	    $checked = ' checked';
	    $tf = 'true';
	  } else {
	    $checked = '';
	    $tf = 'false';
	  }
	  // checkboxes are for display only; value is passed via hidden textbox
          echo "<td align='center'><input type='checkbox'$checked disabled>
                <input type='hidden' name='{$columnName}_$id' value='$tf'></td>";
        } else {
          echo "<td>&nbsp;</td>";
        }
      }
      echo "</tr>\n";
    }
  }
}

if (empty($changes)) {
  echo "<tr><td colspan='$colspan'>[No changes indicated]</td></tr>\n";
}

echo "</table>\n";

if (empty($changes)) {
  echo "<p><input type='button' value=' Back ' onclick='history.back();'></p>\n";
} else {
  echo "<p><input type='submit' name='update' value='Update'>
        <input type='button' name='cancel' value='Cancel' onclick='history.back();'></p>\n";
}
?>
</form>
</body>
</html>
