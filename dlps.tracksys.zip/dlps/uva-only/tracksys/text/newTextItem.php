<?php

/*
  newTextItem.php - clears data saved when entering a new text item
  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-03-03
  Last modified: 2006-03-03

  Receives data from: Not applicable
  Redirects to: textItem.php
*/

include '../inc/tracksys.php';
include '../inc/auth.php';

unset($_SESSION['saveTextItem']);

header('Location: textItem.php');
?>