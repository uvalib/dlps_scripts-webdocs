<?php

/*
  exportTextItems.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-02-04
  Last modified: 2006-03-23

  Exports certain data fields from text items to tab-delimited records
  in the format required by the upload facility at

    http://hatbox.lib.virginia.edu/bin/cgi-dl/dlps/upload/uploadcompletedtext.php

  Displays the tab-delimited data in a <textarea> for copying and
  pasting into a file.

  Receives data from: searchTextItems.php
*/

include '../inc/tracksys.php';
include '../inc/auth.php';

$exportMode = $_POST['exportMode'];

// connect to db
$connection = connect();

// test permissions
testPerm('textExport');

$siteArea = 'Text Workflow';
$pageTitle = "Export Text Items";

$sql = "SELECT textItems.*, selectors.selectorNameFirst, selectors.selectorNameLast
        FROM textItems LEFT JOIN selectors USING (selectorId)
        WHERE textItems.forInternalUseOnly = 0";

if ($exportMode == 'checked') {
  $modeDesc = 'Checked items from search results (excluding those flagged as "For internal use only")';

  // get DLPS IDs to be exported
  $ids = array();
  foreach ($_POST as $name => $value) {
    if ( substr($name, 0, 7) == 'dlpsId_' ) {
      $ids[] = substr($name, 7);
    }
  }

  // build SQL statement
  if (!empty($ids)) {
    $sql .= " AND textItems.dlpsId IN (";
    $c = 0;
    foreach ($ids as $id) {
      if ($c == 0) {
	$sql .= "'$id'";
      } else {
	$sql .= ", '$id'";
      }
      $c++;
    }
    $sql .= ")";
  }
} else {
  // export all items in database not flagged as internal-use-only
  $modeDesc = 'All items (excluding those flagged as "For internal use only")';
}
$sql .= " ORDER BY dlpsId";
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
<script type="text/javascript" src="../inc/javascript.js"></script>
</head>
<body onload="document.frm.output.select();">
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<p><b>Export mode:</b> <?=$modeDesc?></p>
<form name="frm">
<?php

if ($debugMode) { echo "<p>$sql</p>\n"; }

// submit query and display results
if ( $exportMode == 'checked' and empty($ids) ) {
  echo "<p>[No items selected for export]</p>
        <p><input type='button' value=' Back ' onclick='history.back();'></p>\n";
} else {
  $result = query($sql, $connection);
  if ( ! mysql_num_rows($result) >= 1 ) {
    echo "<p>[No matching items]</p>
          <p><input type='button' value=' Back ' onclick='history.back();'></p>\n";
  } else {
    while ( $row = mysql_fetch_array($result) ) {
      if ($row['isFinished']) {
	if ($row['forRepo']) {
	  $line = "2Repo\t";  // in repository
	} else {
	  $line = "1Done\t";  // finished but not destined for repository
	}
      } else {
	$line = "0Processing\t";
      }

      $temp = preg_replace("/\t/", '', $row['callNumber']);
      $line .= $temp . "\t";

      $temp = preg_replace("/\t/", '', $row['virgoID']);
      $line .= $temp . "\t";

      $temp = preg_replace("/\t/", '', $row['volumeNumber']);
      $line .= $temp . "\t";

      $name = formatName($row[selectorNameLast], $row[selectorNameFirst]);
      $temp = preg_replace("/\t/", '', $name);
      $line .= $temp . "\t";

      $temp = preg_replace("/\t/", '', $row['dlpsId']);
      $line .= $temp . "\t";

      $name = formatName($row[authorNameLast], $row[authorNameFirst]);
      $temp = preg_replace("/\t/", '', $name);
      $line .= $temp . "\t";

      $temp = preg_replace("/\t/", '', $row['title']);
      $line .= $temp . "\t";

      $line .= $row['pageCount'];

      $line = preg_replace("/\r/", '', $line);
      $line = preg_replace("/\n/", '', $line);

      $output .= $line . "\n";
    }

    echo "<p>Copy the entire content below and paste it into a new
text file, then save the file with Mac line endings and upload it using the
<a href='http://pogo.lib.virginia.edu/dlps/dlps-only/upload/uploadcompletedtext.php' target='_blank'>Upload Replacement File page</a>.</p>\n";

    echo "<textarea name='output' cols='100' rows='20' wrap='off'>$output</textarea>\n";
    echo "<p><input type='button' value='Back' onclick='history.back();'></p>";
  }
}
?>
</form>
</body>
</html>
