<?php

/*
  followSaveTextItem.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-06-21
  Last modified: 2006-04-14

  This page is displayed upon successful insert/update of a
  text-workflow item. It simply displays non-editable values for the
  record.

  Receives data from: saveTextItem.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = "Text Item - Update Status";

// connect to db
$connection = connect();

// get associative array representing table 'transcriptionResps'
$transcriptionResps = getHashTranscriptionResps($connection);

// get associative array representing table 'pageImagesResps'
$pageImagesResps = getHashPageImagesResps($connection);

// get associative array representing table 'sets'
$sets = getHashSets($connection);

// get associative array representing table 'projects'
$projects = getHashProjects($connection);

// get associative array representing table 'groups'
$groups = getHashGroups($connection);

// get associative array representing table 'batches'
$batches = getHashBatches($connection);

// get associative array representing table 'selectors'
$selectors = getHashSelectors($connection);

// get associative array representing table 'requestors'
$requestors = getHashRequestors($connection);

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<?php
// set up navigation links for top and bottom of page
$links = "<p>";
if (getPerm('textInsert')) {
  $links .= "<a href='newTextItem.php'>Add new item</a>";
} else {
  $links .= "<span class='disabled'>Add new item</span>";
}
if ($mode == 'update') { $again = ' again'; } else { $again = ''; }
if ($mode != 'delete') {
  $links .= "\n<br><a href='textItem.php?dlpsId=$dlpsId'>Edit this item$again</a>";
}
$links .= "\n<br><a href='search/search.php'>Return to search results</a></p>\n";

// get data from database and display for confirmation
$sql = "SELECT * FROM textItems WHERE dlpsId = '$dlpsId'";
$result = query($sql, $connection);
if ( mysql_num_rows($result) == 1 ) {
  if ($mode == 'delete') {
    echo "<p class='error'>WARNING: The text item was <b>not</b> deleted (DLPS ID: $dlpsId).
      Contact the $appTitle administrator.</p>
      </body></html>";
    exit;
  }

  if ($affected == '0') {
    echo "<p class='updated'>No changes were needed.</p>";
  } else {
    if ($mode == 'insert') {
      echo "<p class='updated'>New item added successfully</p>\n";
    } else {
      echo "<p class='updated'>Item updated successfully</p>\n";
    }
  }
  $row = mysql_fetch_array($result);

  echo $links;
?>

<table cellpadding='6' cellspacing='0'>
<tr>
<td class='label'>DLPS ID:</td>
<td><?=$row['dlpsId']?></td>
</tr>

<?php
  if ($row['itemType'] == 1) {
    $itemTypeMigrationChecked = ' checked';
  } else {
    $itemTypeProductionChecked = ' checked';
  }
  echo <<<EOD
<tr>
<td class='label'>Item type:</td>
<td><input type='radio' disabled$itemTypeProductionChecked> Production &nbsp;
<input type='radio' disabled$itemTypeMigrationChecked> Migration</td>
</tr>
EOD;
?>

<tr>
<td class='label'>Virgo ID:</td>
<td><?=$row['virgoId']?></td>
</tr>

<tr>
<td class='label'>Title control number:</td>
<td><?=$row['titleControlNumber']?></td>
</tr>

<tr>
<td class='label'>Call number:</td>
<td><?=$row['callNumber']?></td>
</tr>

<tr>
<td class='label'>Title:</td>
<td><?=$row['title']?></td>
</tr>

<tr>
<td class='label'>Volume or issue number:</td>
<td><?=$row['volumeNumber']?></td>
</tr>

<tr>
<td class='label'>Author:</td>
<td><?=formatName($row['authorNameLast'], $row['authorNameFirst'])?></td>
</tr>

<tr>
<td></td>
<td><hr></td>
</tr>

<?php
  $pageImagesRespName = '';
  if ($row['pageImagesType'] != 0) {
    $hasPageImagesChecked = ' checked';
    $pageImagesType = getPageImagesType($row['pageImagesType']);

    foreach ($pageImagesResps as $id => $name) {
      if ($row['pageImagesRespId'] == $id) {
        $pageImagesRespName = $name;
      }
    }
  }

  if ($row['hasFigureImages'] == 1) {
    $hasFigureImagesChecked = ' checked';
  }

  $transcriptionRespName = '';
  if ($row['transcriptionType'] != 0) {
    $hasTranscriptionChecked = ' checked';
    $transcriptionType = getTranscriptionType($row['transcriptionType']);

    foreach ($transcriptionResps as $id => $name) {
      if ($row['transcriptionRespId'] == $id) {
        $transcriptionRespName = $name;
      }
    }
  }

  $setName = '';
  foreach ($sets as $id => $name) {
    if ($row['setId'] == $id) {
      $setName = $name;
    }
  }

  $projectName = '';
  foreach ($projects as $id => $name) {
    if ($row['projectId'] == $id) {
      $projectName = $name;
    }
  }

  $groupName = '';
  foreach ($groups as $id => $name) {
    if ($row['groupId'] == $id) {
      $groupName = $name;
    }
  }

  $batchName = '';
  foreach ($batches as $id => $name) {
    if ($row['batchId'] == $id) {
      $batchName = $name;
    }
  }

  $selectorName = '';
  foreach ($selectors as $id => $name) {
    if ($row['selectorId'] == $id) {
      $selectorName = $name;
    }
  }

  $requestorName = '';
  foreach ($requestors as $id => $name) {
    if ($row['requestorId'] == $id) {
      $requestorName = $name;
    }
  }

  if ($row['forRepo'] == 1) {
    $forRepoChecked = ' checked';
  }

  if ($row['forInternalUseOnly'] == 1) {
    $forInternalUseOnlyChecked = ' checked';
  }

?>
<tr>
<td class='label'>Page images:</td>
<td><input type='checkbox'<?=$hasPageImagesChecked?> disabled> Has page images?</td>
</tr>

<tr>
<td></td>
<td>Page image type: <?=$pageImagesType?></td>
</tr>

<tr>
<td></td>
<td>Page images created by: <?=$pageImagesRespName?></td>
</tr>

<tr>
<td class='label'>Page image count:</td>
<td><?=$row['pageCount']?></td>
</tr>

<tr>
<td class='label'>Figure images:</td>
<td><input type='checkbox'<?=$hasFigureImagesChecked?> disabled> Has figure images?</td>
</tr>

<tr>
<td class='label'>Transcription:</td>
<td><input type='checkbox'<?=$hasTranscriptionChecked?> disabled> Has transcription?</td>
</tr>

<tr>
<td></td>
<td>Transcription type: <?=$transcriptionType?></td>
</tr>

<tr>
<td></td>
<td>Text created by: <?=$transcriptionRespName?></td>
</tr>

<tr>
<td></td>
<td><hr></td>
</tr>

<tr>
<td class='label'>Multi-volume set:</td>
<td><?=$setName?></td>
</tr>

<tr>
<td class='label'>Project:</td>
<td><?=$projectName?></td>
</tr>

<tr>
<td class='label'>Group:</td>
<td><?=$groupName?></td>
</tr>

<tr>
<td class='label'>Vendor batch:</td>
<td><?=$batchName?></td>
</tr>

<tr>
<td class='label'>Selector:</td>
<td><?=$selectorName?></td>
</tr>

<tr>
<td class='label'>Requestor:</td>
<td><?=$requestorName?></td>
</tr>

<?php
   $priority = getPriority($row['priority']);
?>
<tr>
<td class='label'>Priority:</td>
<td><?=$priority?></td>
</tr>

<?php
  $genre = getGenre($row['genre']);
?>
<tr>
<td class='label'>Genre:</td>
<td><?=$genre?></td>
</tr>

<tr>
<td class='label'>Year of publication:</td>
<td><?=$row['publicationYear']?></td>
</tr>

<?php
  $access = getAccess($row['access']);
?>
<tr>
<td class='label'>Access:</td>
<td><?=$access?></td>
</tr>

<tr>
<td class='label'>Date received:</td>
<td><?=formatDateUS($row['dateReceived'])?></td>
</tr>

<tr>
<td class='label'>Destined for repository:</td>
<td><input type='checkbox'<?=$forRepoChecked?> disabled> </td>
</tr>

<tr>
<td class='label'>For internal use only:</td>
<td><input type='checkbox'<?=$forInternalUseOnlyChecked?> disabled> </td>
</tr>

<tr>
<td class='label' valign='top'>Notes:</td>
<td><pre><?=formatNotes($row['notes'])?></pre></td>
</tr>
</table>

<?php
} else {
  if ($mode == 'delete') {
    echo "<p class='updated'>Text item $dlpsId deleted successfully.</p>\n";
  } else {
    echo "<p>DLPS ID '$dlpsId' not found in database. Contact the $appTitle administrator.</p>\n";
  }
}  // END if ( mysql_num_rows($result) == 1 ) ... else ...

echo $links;
?>
</body>
</html>
