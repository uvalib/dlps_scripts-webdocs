<?php

/*
  minHeader.php - shows the minimal (vendor) TEI header for a particular text-digitization item
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-11-17
  Last modified: 2005-10-07

  Receives data from: textItem.php
  If data is not valid, redirects to: err/badInput.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = "Minimal TEI Header";
$location = 'Location: ../err/badInput.php?msg=';

// check for DLPS ID
if (empty($dlpsId)) {
  header($location . urlencode('DLPS ID is required'));
  exit;
}

// connect to db
$connection = connect();

// test permissions
testPerm('textSelect');

// get associative array representing table 'pageImagesResps'
$pageImagesResps = getHashPageImagesResps($connection);

// get data for item specified
$sql = "SELECT * FROM textItems WHERE dlpsId = '$dlpsId'";
$result = query($sql, $connection);
if (mysql_num_rows($result) == 1) {
  $row = mysql_fetch_array($result);

  switch ( $row['pageImagesType'] ) {
    case 0:
      $pageImages = 'no';
      break;
    case 1:
      $pageImages = 'bitonal';
      break;
    case 2:
      $pageImages = 'color';
      break;
  }

  foreach ($pageImagesResps as $id => $name) {
    if ( $id == $row['pageImagesRespId'] ) {
      $pageImagesResp = $name;
    }
  }

  $author = formatName($row['authorNameLast'], $row['authorNameFirst']);

  $minHeader = <<<END
<teiHeader>
<?dlps page-images="$pageImages" images-resp="$pageImagesResp"?>
<fileDesc>
<titleStmt>
<title>$row[title]</title>
<author>$author</author>
</titleStmt>
<publicationStmt>
<publisher>University of Virginia Library</publisher>
<idno type="DLPS ID">$row[dlpsId]</idno>
<idno type="Virgo ID">$row[virgoId]</idno>
<idno type="title control number">$row[titleControlNumber]</idno>
</publicationStmt>
<sourceDesc><bibl/></sourceDesc>
</fileDesc>
<profileDesc>
<langUsage>
<language id="eng">English</language>
</langUsage>
</profileDesc>
</teiHeader>

END;
}
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<body onload="document.frm.minHeader.select();">
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<h3><?=$row['dlpsId']?></h3>
<form name="frm">
<textarea name="minHeader" cols="80" rows="25"><?=$minHeader?></textarea>
<p>
<input type="button" value=" Back " onclick="history.back();">
</p>
</form>
</body>
</html>
