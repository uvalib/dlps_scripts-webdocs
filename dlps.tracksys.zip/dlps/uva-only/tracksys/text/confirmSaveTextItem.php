<?php

/*
  confirmSaveTextItem.php - shows existing text items similar to the
    one the user is attempting to add, to get user confirmation

  Greg Murray <gpm2a@virginia.edu>
  Written: 2006-02-28
  Last modified: 2006-03-03

  Posts to: saveTextItem.php
*/

include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Text Workflow';
$pageTitle = 'Confirm New Item';

// start HTML page
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>

<p><span class="attn">IMPORTANT:</span> Items already in the database
are similar to the item you are adding. Only add the item if you are
certain it is <b>unique</b>.</p>

<?php

//-------------------------------------
// show details for possible duplicates
//-------------------------------------

// build SQL statement to get possible duplicates
$sql = "SELECT dlpsId, virgoId, titleControlNumber, callNumber, title, volumeNumber ";
$sql .= "FROM textItems WHERE dlpsId IN (";
foreach ($_SESSION['confirmSaveTextItem']['dupes'] as $dlpsId => $type) {
  $sql .= "'$dlpsId', ";
}
$sql = preg_replace('/, $/', '', $sql);  // strip final comma
$sql .= ") ORDER BY title, volumeNumber, titleControlNumber, dlpsId";

if ($debugMode) {
  //echo "<p>$sql</p>\n";
}

// execute query and show results
echo <<<EOD
<table cellpadding='6' cellspacing='0' class='list' width='100%'>
<tr class='head'>
<td>DLPS ID</td>
<td>Virgo ID</td>
<td>Title control number</td>
<td>Call number</td>
<td>Title</td>
<td>Volume</td>
</tr>
EOD;

if ($_SESSION['confirmSaveTextItem']['testCallNumberLength']) {
  $testCallNumberLength = $_SESSION['confirmSaveTextItem']['testCallNumberLength'];
} else {
  $testCallNumberLength = 0;
}
if ($_SESSION['confirmSaveTextItem']['testTitleLength']) {
  $testTitleLength = $_SESSION['confirmSaveTextItem']['testTitleLength'];
} else {
  $testTitleLength = 15;
}

$c = 0;
$result = query($sql, $connection);
while ( $row = mysql_fetch_array($result) ) {
  $c++;
  $class = getRowClass($c);
  echo <<<EOD
<tr$class>
<td><a href='textItem.php?dlpsId=$row[dlpsId]'>$row[dlpsId]</a></td>
EOD;

  if ($_SESSION['confirmSaveTextItem']['dupes'][$row['dlpsId']] == 'virgoId') {
    $hitVirgoId = true;
    $value = "<b>$row[virgoId]</b>";
  } else {
    $value = $row['virgoId'];
  }
  echo "<td>$value</td>\n";

  if ($_SESSION['confirmSaveTextItem']['dupes'][$row['dlpsId']] == 'titleControlNumber') {
    $hitTitleControlNumber = true;
    $value = "<b>$row[titleControlNumber]</b>";
  } else {
    $value = $row['titleControlNumber'];
  }
  echo "<td>$value</td>\n";

  if ($_SESSION['confirmSaveTextItem']['dupes'][$row['dlpsId']] == 'callNumber') {
    $hitCallNumber = true;
    $value = '<b>' . substr($row['callNumber'], 0, $testCallNumberLength)
      . '</b>' . substr($row['callNumber'], $testCallNumberLength);
  } else {
    $value = $row['callNumber'];
  }
  echo "<td>$value</td>\n";

  if ($_SESSION['confirmSaveTextItem']['dupes'][$row['dlpsId']] == 'title') {
    $hitTitle = true;
    $value = '<b>' . substr($row['title'], 0, $testTitleLength)
      . '</b>' . substr($row['title'], $testTitleLength);
  } else {
    $value = $row['title'];
  }
  echo "<td>$value</td>\n";

  echo "<td>$row[volumeNumber]</td>\n";
  echo "</tr>\n";

}

//--------------------------------------------------------
// show details for the item the user is attempting to add
//--------------------------------------------------------

echo <<<EOD
<tr class='head'>
<td colspan='6'>Item you are adding:</td>
</tr>
EOD;

$c++;
$class = getRowClass($c);
echo "<tr>\n";
echo "<td>" . $_SESSION['saveTextItem']['dlpsId'] . "</td>\n";

$temp = $_SESSION['saveTextItem']['virgoId'];
if ($hitVirgoId) {
  $value = "<b>$temp</b>";
} else {
  $value = $temp;
}
echo "<td>$value</td>\n";

$temp = $_SESSION['saveTextItem']['titleControlNumber'];
if ($hitTitleControlNumber) {
  $value = "<b>$temp</b>";
} else {
  $value = $temp;
}
echo "<td>$value</td>\n";

$temp = $_SESSION['saveTextItem']['callNumber'];
if ($hitCallNumber) {
  $value = '<b>' . substr($temp, 0, $testCallNumberLength) . '</b>' . substr($temp, $testCallNumberLength);
} else {
  $value = $temp;
}
echo "<td>$value</td>\n";

$temp = $_SESSION['saveTextItem']['title'];
if ($hitTitle) {
  $value = '<b>' . substr($temp, 0, $testTitleLength) . '</b>' . substr($temp, $testTitleLength);
} else {
  $value = $temp;
}
echo "<td>$value</td>\n";

echo "<td>" . $_SESSION['saveTextItem']['volumeNumber'] . "</td>\n";
?>
</tr>
</table>

<form name="frm" method="GET">
<input type="hidden" name="confirmed">
<p>
<input type="button" value="Add <?=$_SESSION['saveTextItem']['dlpsId']?>" onclick="document.frm.confirmed.value='true'; document.frm.action='saveTextItem.php'; document.frm.submit();">
<input type="button" value="Cancel" onclick="document.frm.action='textItem.php'; document.frm.submit();">
</p>
</form>

</body>
</html>
