<?php

/*
  workflowMigration.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-09-26
  Last modified: 2006-01-06

  Displays text items in the context of the migration-images
  workflow (analogous to book-scanning, but for migrating items not
  new items). Allows user to check or uncheck the various steps in the
  workflow, to indicate completion or incompletion of the steps.

  Receives data from: search/search.php
  Posts data to: confirmMigration.php
*/

include '../../inc/tracksys.php';
include '../../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'Migration Images Workflow';

// connect to db
$connection = connect();

// test permissions
testPerm('textSelect');

// get DLPS IDs to be displayed
if ($_GET['status'] == 'updated') {
  // we are returning here after an update; get IDs from query string
  $ids = explode('|', $_GET['ids']);
} else {
  // get IDs from posted form
  $ids = array();
  foreach ($_POST as $name => $value) {
    if ( substr($name, 0, 7) == 'dlpsId_' ) {
      $ids[] = substr($name, 7);
    }
  }
}

// build SQL statement
if (!empty($ids)) {
  $sql = "SELECT textItems.title, textItems.volumeNumber, textItems.isFinished,
    bookScanning.makeWebImages, migration.*
    FROM textItems LEFT JOIN migration USING (dlpsId) LEFT JOIN bookScanning USING (dlpsId)
    WHERE migration.dlpsId IN (";
  $c = 0;
  foreach ($ids as $id) {
    if ($c == 0) {
      $sql .= "'$id'";
    } else {
      $sql .= ", '$id'";
    }
    $c++;
  }
  $sql .= ")";

  switch ($_POST['orderBy']) {
    case 'title':
      $sql .= ' ORDER BY title, volumeNumber';
      break;
    default:
      $sql .= ' ORDER BY migration.dlpsId';
  }
}
?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../../inc/tracksys.css">
<script type="text/javascript" src="../../inc/tracksys.js"></script>
</head>
<body>
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="POST" action="confirmMigration.php">
<?php

//if ($debugMode) { echo "<p>$sql</p>\n"; }

if ($_GET['status'] == 'updated') {
  echo "<p class='updated'>Updated</p>\n";
}

echo $workflowNewSearchLink;

echo "<table cellpadding='6' cellspacing='0' class='list'>
<tr class='head'>
<td>DLPS&nbsp;ID</td>
<td>Title</td>
<td>View images</td>
<td align='center'>Load files</td>
<td align='center'>Request rescans</td>
<td align='center'>Make rescans</td>
<td align='center'>Insert rescans</td>
<td align='center'>Rename image files</td>
<td align='center'>Image scripts</td>
<td align='center'>Perform QA</td>
<td align='center'>Make web images</td>
<td>&nbsp;</td>
</tr>\n";

$colspan = 12;        // total number of columns
$colspanLeading = 3;  // number of leading (non-checkbox) columns preceding the first checkbox column
$colspanDiff = 9;

// submit query and display results
if ( empty($ids) ) {
  echo "<tr><td colspan='$colspan'>[No items selected]</td></tr>
        </table>
        <p><input type='button' value=' Back ' onclick='history.back();'></p>\n";
} else {
  // include 'Check all' and 'Clear all' controls
  $c = 1;
  $class = getRowClass($c);
  echo "<tr$class><td colspan='$colspanLeading'>&nbsp;</td>\n";

  echoCheckAllClearAll('loadFiles');
  echoCheckAllClearAll('requestRescans');
  echoCheckAllClearAll('makeRescans');
  echoCheckAllClearAll('insertRescans');
  echoCheckAllClearAll('renameImageFiles');
  echoCheckAllClearAll('imageScripts');
  echoCheckAllClearAll('proof');
  echoCheckAllClearAll('makeWebImages');

  echo "<td>&nbsp;</td>\n</tr>\n";

  $result = query($sql, $connection);
  if ( ! mysql_num_rows($result) >= 1 ) {
    echo "<tr><td colspan='$colspan'>[No matching items]</td></tr>
          </table>
          <p><input type='button' value=' Back ' onclick='history.back();'></p>\n";
  } else {
    while ( $row = mysql_fetch_array($result) ) {
      $c++;
      $class = getRowClass($c);

      if ($row['loadFiles'] == 0) { $loadFilesChecked = ''; } else { $loadFilesChecked = 'checked'; }
      if ($row['requestRescans'] == 0) { $requestRescansChecked = ''; } else { $requestRescansChecked = 'checked'; }
      if ($row['makeRescans'] == 0) { $makeRescansChecked = ''; } else { $makeRescansChecked = 'checked'; }
      if ($row['insertRescans'] == 0) { $insertRescansChecked = ''; } else { $insertRescansChecked = 'checked'; }
      if ($row['proof'] == 0) { $proofChecked = ''; } else { $proofChecked = 'checked'; }
      if ($row['renameImageFiles'] == 0) { $renameImageFilesChecked = ''; } else { $renameImageFilesChecked = 'checked'; }
      if ($row['imageScripts'] == 0) { $imageScriptsChecked = ''; } else { $imageScriptsChecked = 'checked'; }
      if ($row['makeWebImages'] == 0) { $makeWebImagesChecked = '';} else { $makeWebImagesChecked = 'checked';}

      if ($row['makeWebImages'] == 0 or $row['isFinished'] == 1) {
        $viewPageImages = '';
      } else {
        $viewPageImages = "<a target='proofreader' href='$imageViewerUrl?id=$row[dlpsId]'>View images</a>";
      }

      $id = $row['dlpsId'];
      $idArg = '"' . $row['dlpsId'] . '"';
      $title = formatTitle($row['title'], $row['volumeNumber']);

      $cellStart = "<td align='center'><input type='checkbox'";

      echo "<tr$class>
<td><a href='../textItem.php?dlpsId=$id'>$id</a> <input type='hidden' name='dlpsId_$id' value='$id'></td>
<td>$title</td>
<td>$viewPageImages</td>

$cellStart name='loadFiles_$id'        title='$id: Load files'         $loadFilesChecked></td>
$cellStart name='requestRescans_$id'   title='$id: Request rescans'    $requestRescansChecked></td>
$cellStart name='makeRescans_$id'      title='$id: Make rescans'       $makeRescansChecked></td>
$cellStart name='insertRescans_$id'    title='$id: Insert rescans'     $insertRescansChecked></td>
$cellStart name='renameImageFiles_$id' title='$id: Rename image files' $renameImageFilesChecked></td>
$cellStart name='imageScripts_$id'     title='$id: Image scripts'      $imageScriptsChecked></td>
$cellStart name='proof_$id'            title='$id: Perform QA'         $proofChecked></td>
$cellStart name='makeWebImages_$id'    title='$id: Make web images'    $makeWebImagesChecked></td>

<td class='controls' nowrap>
  <img src='../../img/check.gif' onclick='setCheckboxesRow(true, $idArg);' title='Check all for this row ($id)'>
  <img src='../../img/square.gif' onclick='setCheckboxesRow(false, $idArg);' title='Clear all for this row ($id)'>
</td>
</tr>\n";
    }

    $c++;
    $class = getRowClass($c);

    if (!getPerm('textMigrationUpdate')) { $submitAppearance = ' disabled'; }
    $temp = "<input type='submit' value='Update'$submitAppearance> <input type='reset' value='Reset'> ";
    if ($_GET['status'] != 'updated') {
      $temp .= "<input type='button' value='Cancel' onclick='history.back();'>";
    }
    echo "<tr$class>
<td colspan='$colspanLeading' style='white-space: nowrap;'>$temp</td>
<td align='right' colspan='$colspanDiff' style='white-space: nowrap;'>$temp</td>
</tr>
</table>\n";
  }

  echo "<p></p><hr>
<table cellpadding='4'>
<tr>
<td align='right'>Change view:
<select name='workflow'>
<option value='teiHeader'>TEI header workflow</option>
<option value='postkb'>Post-keyboarding workflow</option>
<option value='markupQA'>Markup QA workflow</option>
<option value='finalization'>Finalization workflow</option>
</select>
</td>
<td valign='bottom'>
<input type='button' value='View Workflow' onclick='if ( setFormAction(document.frm) ) { document.frm.submit(); }'>
<input type='hidden' name='orderBy' value='$_POST[orderBy]'>
</td>
</tr>
</table>\n";

  echo $workflowNewSearchLink;
}
?>
</form>
</body>
</html>
