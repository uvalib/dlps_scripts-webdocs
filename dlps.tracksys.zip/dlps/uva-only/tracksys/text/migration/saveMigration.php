<?php

/*
  saveMigration.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-09-26
  Last modified: 2006-08-31

  Saves changes to database for migration workflow steps.

  Receives data from: confirmMigration.php
  Redirects to: workflowMigration.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to database
$connection = connect();

// test permissions
testPerm('textMigrationUpdate');

// get all DLPS IDs from the posted form
$ids = array();
foreach ($_POST as $name => $value) {
  if ( preg_match('/(loadFiles|requestRescans|makeRescans|insertRescans|renameImageFiles|imageScripts|proof|makeWebImages)_(.+)/', $name, $refs) ) {
    $ids[] = $refs[2];
  }
}

// for each ID, update values as needed
$updatedIds = array();
//$makeWebImagesDoneIds = array();
$requestRescansDoneIds = array();
foreach ($ids as $id) {
  $updates = '';
  $updates2 = '';
  for ($i = 1; $i <= 8; $i++) {
    switch ($i) {
      case 1: $columnName = 'loadFiles'; break;
      case 2: $columnName = 'requestRescans'; break;
      case 3: $columnName = 'makeRescans'; break;
      case 4: $columnName = 'insertRescans'; break;
      case 5: $columnName = 'renameImageFiles'; break;
      case 6: $columnName = 'imageScripts'; break;
      case 7: $columnName = 'proof'; break;
      case 8: $columnName = 'makeWebImages'; break;
    }

    if (!empty($_POST[$columnName . '_' . $id])) {
      $value = $_POST[$columnName . '_' . $id];
      if ($value == 'true') {
	if ($columnName == 'makeWebImages') {
          // update table 'bookScanning'
          $updates2 .= " $columnName = 1,";
        } else {
          // update table 'migration'
          $updates .= " $columnName = 1,";
        }
      } else {
	if ($columnName == 'makeWebImages') {
          // update table 'bookScanning'
          $updates2 .= " $columnName = 0,";
        } else {
          // update table 'migration'
          $updates .= " $columnName = 0,";
        }
      }
    }
  }

  if (empty($updates) and empty($updates2)) {
    // no updates for this ID; continue with next ID
    continue;
  }

  $updates = preg_replace('/,$/', '', $updates);  // strip final comma
  $updates2 = preg_replace('/,$/', '', $updates2);  // strip final comma

  // determine which IDs to include in email notification for makeWebImages
/*
  if ( preg_match('/makeWebImages = 1/', $updates2) ) {
    $sql =  "SELECT migration.dlpsId, textItems.title ";
    $sql .= "FROM migration LEFT JOIN textItems USING (dlpsId) LEFT JOIN bookScanning USING (dlpsId) ";
    $sql .= "WHERE migration.dlpsId = '$id' AND bookScanning.makeWebImages = 0";
    $result = query($sql, $connection);
    if ( mysql_num_rows($result) == 1 ) {
      $row = mysql_fetch_array($result);
      $makeWebImagesDoneIds[$id] = $row['title'];
    }
  }
*/

  // determine which IDs to include in email notification for requestRescans
  if ( preg_match('/requestRescans = 1/', $updates) ) {
    $sql =  "SELECT migration.dlpsId, textItems.title ";
    $sql .= "FROM migration LEFT JOIN textItems USING (dlpsId) ";
    $sql .= "WHERE migration.dlpsId = '$id' AND migration.requestRescans = 0";
    $result = query($sql, $connection);
    if ( mysql_num_rows($result) == 1 ) {
      $row = mysql_fetch_array($result);
      $requestRescansDoneIds[$id] = $row['title'];
    }
  }

  if (!empty($updates)) {
    $sql = "UPDATE migration SET $updates WHERE dlpsId = '$id'";
    if ( mysql_query($sql, $connection) ) {
      if (mysql_affected_rows() == 1) {
        $updatedIds[$id] = $id;
      }
    } else {
      die($dbErrorPreface . "Unable to update record '$id' in table migration: " . mysql_error($connection) . "<br><br>$sql");
    }
  }

  if (!empty($updates2)) {
    $sql = "UPDATE bookScanning SET $updates2 WHERE dlpsId = '$id'";
    if ( mysql_query($sql, $connection) ) {
      if (mysql_affected_rows() == 1) {
        $updatedIds[$id] = $id;
      }
    } else {
      die($dbErrorPreface . "Unable to update record '$id' in table bookScanning: " . mysql_error($connection) . "<br><br>$sql");
    }
  }
}

// send email notification for items updated to indicate 'Make web images' completed
/*
if ($makeWebImagesDoneIds) {
  $to = $makeWebImagesEmailRecipients;
  $headers = "From: $emailFrom";
  $subject = "$appTitle - Web images ready";

  $body = "User " . getUserDesc() . " has updated the $appTitle as follows:\n\n";
  $body .= "          Module: Text Tracking\n";
  $body .= "        Workflow: Migration Images\n";
  $body .= "  Step completed: Make web images\n";

  $temp = '';
  foreach ($makeWebImagesDoneIds as $id => $title) {
    $temp .= "                  $id   $title\n";
  }
  $temp = ltrim($temp);  // strip leading whitespace
  $body .= "           Items: $temp\n\n";

  $body = wordwrap($body, 70);
  mail($to, $subject, $body, $headers);
}
*/

// send email notification for items updated to indicate 'Request rescans' completed
if ($requestRescansDoneIds) {
  $to = $emailTo;
  $headers = "From: $emailFrom";
  $subject = "$appTitle - Request rescans completed";

  $body = "User " . getUserDesc() . " has updated the $appTitle as follows:\n\n";
  $body .= "          Module: Text Tracking\n";
  $body .= "        Workflow: Migration Images\n";
  $body .= "  Step completed: Request rescans\n";

  $temp = '';
  foreach ($requestRescansDoneIds as $id => $title) {
    $temp .= "                  $id   $title\n";
  }
  $temp = ltrim($temp);  // strip leading whitespace
  $body .= "           Items: $temp\n\n";

  $body = wordwrap($body, 70);
  mail($to, $subject, $body, $headers);
}

// redirect, indicating success
$ids = '';
foreach ($updatedIds as $id) {
  $ids .= $id . '|';
}
$ids = preg_replace('/\|$/', '', $ids);  // strip final |
header("Location: workflowMigration.php?status=updated&ids=$ids");
?>