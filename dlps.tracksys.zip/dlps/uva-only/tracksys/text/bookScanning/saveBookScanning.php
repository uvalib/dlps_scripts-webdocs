<?php

/*
  saveBookScanning.php
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-03-18
  Last modified: 2005-09-01

  Saves changes to database for book-scanning workflow steps.

  Receives data from: confirmBookScanning.php
  Redirects to: workflowBookScanning.php

  This page performs its work and then redirects; it does not produce
  any HTML output, so it never registers in the user's browser
  history. This makes the save process transparent to the user and
  helps avoid the possibility of the user re-submitting the same data
  by refreshing the browser.
*/

import_request_variables('P');
include '../../inc/tracksys.php';
include '../../inc/auth.php';

// connect to database
$connection = connect();

// test permissions
testPerm('textBookScanningUpdate');

// get all DLPS IDs from the posted form
$ids = array();
foreach ($_POST as $name => $value) {
  if ( preg_match('/(scanPages|scanFigures|renameFigureScans|fixPageScans|makeRescans|proof|makeWebImages|zip|sendToVendor)_(.+)/', $name, $refs) ) {
    $ids[] = $refs[2];
  }
}

// for each ID, update values as needed
$updatedIds = array();
$makeWebImagesDoneIds = array();
foreach ($ids as $id) {
  $updates = '';
  for ($i = 1; $i <= 9; $i++) {
    switch ($i) {
      case 1: $columnName = 'scanPages'; break;
      case 2: $columnName = 'scanFigures'; break;
      case 3: $columnName = 'renameFigureScans'; break;
      case 4: $columnName = 'fixPageScans'; break;
      case 5: $columnName = 'makeRescans'; break;
      case 6: $columnName = 'proof'; break;
      case 7: $columnName = 'makeWebImages'; break;
      case 8: $columnName = 'zip'; break;
      case 9: $columnName = 'sendToVendor'; break;
    }

    if (!empty($_POST[$columnName . '_' . $id])) {
      $value = $_POST[$columnName . '_' . $id];
      if ($value == 'true') {
        $updates .= " $columnName = 1,";
      } else {
        $updates .= " $columnName = 0,";
      }
    }
  }

  if (empty($updates)) {
    // no updates for this ID; continue with next ID
    continue;
  }

  $updates = preg_replace('/,$/', '', $updates);  // strip final comma

  // determine which IDs to include in email notification

  if ( preg_match('/makeWebImages = 1/', $updates) ) {
    $sql =  "SELECT bookScanning.dlpsId, textItems.title ";
    $sql .= "FROM bookScanning LEFT JOIN textItems USING (dlpsId) ";
    $sql .= "WHERE bookScanning.dlpsId = '$id' AND bookScanning.makeWebImages = 0";
    $result = query($sql, $connection);
    if ( mysql_num_rows($result) == 1 ) {
      $row = mysql_fetch_array($result);
      $makeWebImagesDoneIds[$id] = $row['title'];
    }
  }

  $sql = "UPDATE bookScanning SET $updates WHERE dlpsId = '$id' LIMIT 1";

  if ( mysql_query($sql, $connection) ) {
    if (mysql_affected_rows() == 1) {
      $updatedIds[$id] = $id;
    }
  } else {
    die($dbErrorPreface . "Unable to update record '$id' in table bookScanning: " . mysql_error($connection) . "<br><br>$sql");
  }
}

// send email notification for items updated to indicate 'make web images' completed
if ($makeWebImagesDoneIds) {
  $to = $makeWebImagesEmailRecipients;
  $headers = "From: $emailFrom";
  $subject = "$appTitle - Web images ready";

  $body = "User " . getUserDesc() . " has updated the $appTitle to indicate that web-deliverable page images have been created for the following items:\n\n";

  foreach ($makeWebImagesDoneIds as $id => $title) {
    $body .= "$id   $title\n";
  }

  $body = wordwrap($body, 70);
  mail($to, $subject, $body, $headers);
}

// redirect, indicating success
$ids = '';
foreach ($updatedIds as $id) {
  $ids .= $id . '|';
}
$ids = preg_replace('/\|$/', '', $ids);  // strip final |
header("Location: workflowBookScanning.php?status=updated&ids=$ids");
?>