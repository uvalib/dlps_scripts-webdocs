<?php

/*
  updateDlpsId.php - form for changing DLPS ID
  Greg Murray <gpm2a@virginia.edu>
  Written: 2005-06-24
  Last modified: 2005-10-07

  Shows a form allowing user to change the DLPS ID for a text item.

  Posts to: saveUpdateDlpsId.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

$siteArea = 'Text Workflow';
$pageTitle = 'Change DLPS ID';

// validate user input

$location = 'Location: ../err/badInput.php?msg=';

// DLPS ID
if (empty($dlpsId)) {
  header($location . urlencode('DLPS ID is required'));
  exit;
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
<script type="text/javascript" src="../inc/tracksys.js"></script>
</head>
<body onload="document.frm.newDlpsId.focus();">
<h1><?=$siteArea?></h1>
<h2><?=$pageTitle?></h2>
<form name="frm" method="POST" action="saveUpdateDlpsId.php" onsubmit="return testDlpsId(document.frm.newDlpsId.value);">
<table cellpadding='4'>
<tr>
<td class='label'>Current DLPS ID:</td>
<td><?=$dlpsId?> <input type='hidden' name='oldDlpsId' value='<?=$dlpsId?>'></td>
</tr>
<tr>
<td class='label'>New DLPS ID:</td>
<td><input type='text' name='newDlpsId' maxlength='$dlpsIdMaxLength'></td>
</tr>
<tr>
<td colspan='2' align='right'>
<input type="submit" name="go" value="Update">
<input type="button" value="Cancel" onclick="history.back();">
</td>
</tr>
</table>
</form>
</body>
</html>
