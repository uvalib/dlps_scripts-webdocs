<?php

/*
  textItem.php - shows data pertaining to a particular item for text digitization
  Greg Murray <gpm2a@virginia.edu>
  Written: 2004-06-21
  Last modified: 2006-09-01

  If a DLPS ID is passed on the query string, this page serves as an
  edit-existing-item form. Otherwise, it serves as an enter-new-item
  form.

  Posts to: saveTextItem.php
*/

import_request_variables('G');
include '../inc/tracksys.php';
include '../inc/maxlengths.php';
include '../inc/auth.php';

// connect to db
$connection = connect();

$siteArea = 'Text Workflow';

if ( empty($dlpsId) ) {
  // enter new item
  $mode = 'insert';
  $pageTitle = 'Enter New Item';
  $onload = ' onload="init(); document.frm.dlpsId.focus();"';
  $submitCaption = ' Add ';
  $setDefaults = true;

  // test permissions
  testPerm('textInsert');
} else {
  // edit existing item
  $mode = 'update';
  $pageTitle = 'Edit Item';
  $onload = ' onload="init();"';
  $submitCaption = 'Update';
  $returnToSearchResults = "<p><a href='search/search.php'>Return to search results</a></p>";

  $extraButtons = <<<EOD
<tr>
<td></td>
<td><input type='button' value='Update' onclick='document.frm.submit();'>
<input type='button' value='Cancel' onclick='history.back();'></td>
</tr>
EOD;

  // test permissions; need Select to view item details, Update to enable submit button
  testPerm('textSelect');
  if (!getPerm('textUpdate')) { $submitAppearance = ' disabled'; }
}


//----------------------------------------------------------------------
// get hashes for drop-down menus
//----------------------------------------------------------------------

// get associative array representing table 'transcriptionResps'
$transcriptionResps = getHashTranscriptionResps($connection);

// get associative array representing table 'pageImagesResps'
$pageImagesResps = getHashPageImagesResps($connection);

// get associative array representing table 'sets'
$sets = getHashSets($connection);

// get associative array representing table 'projects'
$projects = getHashProjects($connection);

// get associative array representing table 'groups'
$groups = getHashGroups($connection);

// get associative array representing table 'batches'
$batches = getHashBatches($connection);

// get associative array representing table 'selectors'
$selectors = getHashSelectors($connection);

// get associative array representing table 'requestors'
$requestors = getHashRequestors($connection);


//----------------------------------------------------------------------
// get data for populating form
//----------------------------------------------------------------------

if ($mode == 'insert') {
  if (isset($_SESSION['saveTextItem'])) {

    // we are returning here from confirmSaveTextItem.php where user
    // clicked "Cancel", or from an error page; re-populate form with
    // data from session variables -- data the user entered previously

    $dlpsId = $_SESSION['saveTextItem']['dlpsId'];
    $itemType = $_SESSION['saveTextItem']['itemType'];
    $virgoId = $_SESSION['saveTextItem']['virgoId'];
    $titleControlNumber = $_SESSION['saveTextItem']['titleControlNumber'];
    $callNumber = $_SESSION['saveTextItem']['callNumber'];
    $title = $_SESSION['saveTextItem']['title'];
    $volumeNumber = $_SESSION['saveTextItem']['volumeNumber'];
    $authorNameLast = $_SESSION['saveTextItem']['authorNameLast'];
    $authorNameFirst = $_SESSION['saveTextItem']['authorNameFirst'];
    $pageImagesType = $_SESSION['saveTextItem']['pageImagesType'];
    $pageImagesRespId = $_SESSION['saveTextItem']['pageImagesRespId'];
    $pageImagesRespName = $_SESSION['saveTextItem']['pageImagesRespName'];
    $pageCount = $_SESSION['saveTextItem']['pageCount'];
    $hasFigureImages = $_SESSION['saveTextItem']['hasFigureImages'];
    $transcriptionType = $_SESSION['saveTextItem']['transcriptionType'];
    $transcriptionRespId = $_SESSION['saveTextItem']['transcriptionRespId'];
    $transcriptionRespName = $_SESSION['saveTextItem']['transcriptionRespName'];
    $setId = $_SESSION['saveTextItem']['setId'];
    $setName = $_SESSION['saveTextItem']['setName'];
    $projectId = $_SESSION['saveTextItem']['projectId'];
    $projectName = $_SESSION['saveTextItem']['projectName'];
    $groupId = $_SESSION['saveTextItem']['groupId'];
    $groupName = $_SESSION['saveTextItem']['groupName'];
    $batchId = $_SESSION['saveTextItem']['batchId'];
    $selectorId = $_SESSION['saveTextItem']['selectorId'];
    $selectorNameLast = $_SESSION['saveTextItem']['selectorNameLast'];
    $selectorNameFirst = $_SESSION['saveTextItem']['selectorNameFirst'];
    $requestorId = $_SESSION['saveTextItem']['requestorId'];
    $requestorNameLast = $_SESSION['saveTextItem']['requestorNameLast'];
    $requestorNameFirst = $_SESSION['saveTextItem']['requestorNameFirst'];
    $priority = $_SESSION['saveTextItem']['priority'];
    $genre = $_SESSION['saveTextItem']['genre'];
    $publicationYear = $_SESSION['saveTextItem']['publicationYear'];
    $access = $_SESSION['saveTextItem']['access'];
    $dateReceived = $_SESSION['saveTextItem']['dateReceived'];
    $forRepo = $_SESSION['saveTextItem']['forRepo'];
    $forInternalUseOnly = $_SESSION['saveTextItem']['forInternalUseOnly'];
    $notes = $_SESSION['saveTextItem']['notes'];

    $setDefaults = false;
  }
}

if ($mode == 'update') {
  // populate form with data from database for item to be edited

  $sql = "SELECT * FROM textItems WHERE dlpsId = '$dlpsId'";
  $result = query($sql, $connection);
  if (mysql_num_rows($result) == 1) {
    $row = mysql_fetch_array($result);

    $dlpsId = $row['dlpsId'];
    $itemType = $row['itemType'];
    $virgoId = $row['virgoId'];
    $titleControlNumber = $row['titleControlNumber'];
    $callNumber = $row['callNumber'];
    $title = $row['title'];
    $volumeNumber = $row['volumeNumber'];
    $authorNameLast = $row['authorNameLast'];
    $authorNameFirst = $row['authorNameFirst'];
    $pageImagesType = $row['pageImagesType'];
    $pageImagesRespId = $row['pageImagesRespId'];
    $pageImagesRespName = $row['pageImagesRespName'];
    $pageCount = $row['pageCount'];
    $hasFigureImages = $row['hasFigureImages'];
    $transcriptionType = $row['transcriptionType'];
    $transcriptionRespId = $row['transcriptionRespId'];
    $transcriptionRespName = $row['transcriptionRespName'];
    $setId = $row['setId'];
    $setName = $row['setName'];
    $projectId = $row['projectId'];
    $projectName = $row['projectName'];
    $groupId = $row['groupId'];
    $groupName = $row['groupName'];
    $batchId = $row['batchId'];
    $selectorId = $row['selectorId'];
    $selectorNameLast = $row['selectorNameLast'];
    $selectorNameFirst = $row['selectorNameFirst'];
    $requestorId = $row['requestorId'];
    $requestorNameLast = $row['requestorNameLast'];
    $requestorNameFirst = $row['requestorNameFirst'];
    $priority = $row['priority'];
    $genre = $row['genre'];
    $publicationYear = $row['publicationYear'];
    $access = $row['access'];
    $dateReceived = $row['dateReceived'];
    $forRepo = $row['forRepo'];
    $forInternalUseOnly = $row['forInternalUseOnly'];
    $notes = $row['notes'];

    $setDefaults = false;
  } else {
    die($dbErrorPreface . "DLPS ID '$dlpsId' does not exist");
  }
}


//----------------------------------------------------------------------
// set state for GUI elements
//----------------------------------------------------------------------

if ($setDefaults) {
  // set defaults for entering a new item
  $itemType = 0;  // 0 = production
  $hasPageImagesChecked = ' checked';
  $pageImagesTypeBitonalSelected = ' selected';
  $pageImagesRespId = 1;  // 1 = DLPS
  $hasTranscriptionChecked = ' checked';
  $transcriptionTypeVendorSelected = ' selected';
  $transcriptionRespId = 2;  // 2 = Apex
  $forRepoChecked = ' checked';
  //$dateReceived = date("n/j/Y");  // today's date as m/d/yyyy - commented out at Kristy's request
} else {
  if ($pageImagesType != 0) {
    $hasPageImagesChecked = ' checked';
    switch ( $pageImagesType ) {
      case 1:
        $pageImagesTypeBitonalSelected = ' selected';
        break;
      case 2:
        $pageImagesTypeColorSelected = ' selected';
        break;
    }
  }

  if ($hasFigureImages) {
    $hasFigureImagesChecked = ' checked';
  }

  if ($transcriptionType != 0) {
    $hasTranscriptionChecked = ' checked';
    switch ( $transcriptionType ) {
      case 1:
        $transcriptionTypeVendorSelected = ' selected';
        break;
      case 2:
        $transcriptionTypeOcrSelected = ' selected';
        break;
      case 3:
        $transcriptionTypeOtherSelected = ' selected';
        break;
    }
  }

  if ($forRepo) {
    $forRepoChecked = ' checked';
  }

  if ($forInternalUseOnly) {
    $forInternalUseOnlyChecked = ' checked';
  }

  if ( preg_match('/\d{4}-\d{2}-\d{2}/', $dateReceived) ) {
    $dateReceived = formatDateUS($dateReceived);
  }
}

/* Determine whether browser is Microsoft Internet Explorer (MSIE).
   IE-only scripting features are used to hide/show certain form
   elements dynamically. This functionality is not essential -- just a
   nicety. Other browsers are completely unaffected. */
if ( ereg('MSIE', $_SERVER['HTTP_USER_AGENT']) ) {
  $IE = 'true';
} else {
  $IE = 'false';
}

?>
<html>
<head>
<title><?=$siteArea?> - <?=$pageTitle?></title>
<link rel="stylesheet" type="text/css" href="../inc/tracksys.css">
<script type="text/javascript">
  var IE = <?=$IE?>;
</script>
<script type="text/javascript" src="../inc/textItem.js"></script>
<script type="text/javascript" src="../inc/tracksys.js"></script>
</head>

<?php
if ($mode == 'insert' and getPerm('textInsert')) {
  $onSubmit = " onsubmit='return testDlpsId(document.frm.dlpsId.value);'";
}

echo <<<EOD
<body$onload>
<h1>$siteArea</h1>
<h2>$pageTitle</h2>
$returnToSearchResults
<form name="frm" method="POST" action="saveTextItem.php"$onSubmit>
<table cellpadding="4">
$extraButtons
EOD;

if ($mode == 'insert') {
  // include DLPS ID entry textbox
  echo <<<EOD
<tr>
<td class='label'>DLPS ID:</td>
<td><input type='text' name='dlpsId' maxlength='$dlpsIdMaxLength' value='$dlpsId'>
<span class='required'>(required)</span></td>
</tr>
EOD;
} else {
  // DLPS ID is not editable here
  echo <<<EOD
<tr>
<td class='label'>DLPS ID:</td>
<td>$dlpsId <input type='hidden' name='dlpsId' value='$dlpsId'>
EOD;

  if ($deleteEnabled and getPerm('textUpdateDlpsId')) {
    echo "\n<input type='button' name='updateDlpsId' value='Change DLPS ID...' onclick='window.location=\"updateDlpsId.php?dlpsId=$dlpsId\"'>";
  }

  if ($deleteEnabled and getPerm('textDelete')) {
    echo "\n<input type='button' name='deleteDlpsId' value='Delete this item...' onclick='window.location=\"confirmDeleteTextItem.php?dlpsId=$dlpsId\"'>";
  }

  echo "</td>\n</tr>\n";
}

  // item type (production or migration)
  if ($itemType == 1) {
    $itemTypeMigrationChecked = ' checked';
  } else {
    $itemTypeProductionChecked = ' checked';
  }
  echo <<<EOD
<tr>
<td class='label'>Item type:</td>
<td><input type='radio' name='itemType' value='0'$itemTypeProductionChecked> Production &nbsp;
<input type='radio' name='itemType' value='1'$itemTypeMigrationChecked> Migration</td>
</tr>
EOD;

?>
<tr>
<td class="label">Virgo ID:</td>
<td><input type="text" name="virgoId" maxlength="<?=$virgoIdMaxLength?>" value="<?=$virgoId?>"></td>
</tr>

<tr>
<td class="label">Title control number:</td>
<td><input type="text" name="titleControlNumber" maxlength="<?=$titleControlNumberMaxLength?>" value="<?=$titleControlNumber?>"></td>
</tr>

<tr>
<td class="label">Call number:</td>
<td><input type="text" name="callNumber" maxlength="<?=$callNumberMaxLength?>" value="<?=$callNumber?>"></td>
</tr>

<?php
if ( preg_match('/"/', $title) && preg_match("/'/", $title) ) {
  // title contains both " and ' characters; convert " to * and use value="..."
  $title = preg_replace('/"/', '*', $title);
  $value = 'value="' . $title . '"';
  $warning = "<br><span class='attn'>WARNING: This title contains both \" (double quote)
    and ' (single quote) characters. The \" characters have been replaced with * for display.
    Change * back to \" before saving.</span>";
} elseif ( preg_match('/"/', $title) ) {
  // title contains " character; use value='...'
  $value = "value='$title'";
} else {
  // use value="..."
  $value = 'value="' . $title . '"';
}

if ($mode == 'insert') {
  $titleRequired = ' <span class="required">(required)</span>';
}

echo <<<EOD
<tr>
<td class="label">Title:</td>
<td><input type="text" name="title" size="60" maxlength="$titleMaxLength" $value>$titleRequired $warning</td>
</tr>
EOD;
?>

<tr>
<td class="label">Volume or issue number:</td>
<td><input type="text" name="volumeNumber" size="10" maxlength="<?=$volumeNumberMaxLength?>" value="<?=$volumeNumber?>"></td>
</tr>

<tr>
<td class="label">Author:</td>
<td>Last name: <input type="text" name="authorNameLast" maxlength="<?=$authorNameLastMaxLength?>" value="<?=$authorNameLast?>">
 &nbsp; First name: <input type="text" name="authorNameFirst" maxlength="<?=$authorNameFirstMaxLength?>" value="<?=$authorNameFirst?>"></td>
</tr>

<?php
/*
if ($mode == 'update') {
  echo "<tr>
<td class='label'>Minimal header:</td>
<td><a href='minHeader.php?dlpsId=$dlpsId'>View minimal TEI header</a></td>
</tr>\n";
}
*/
?>

<tr>
<td></td>
<td><hr></td>
</tr>

<tr>
<td class="label" valign="top">Page images:</td>
<td><input type="checkbox" name="hasPageImages"<?=$hasPageImagesChecked?>> Has page images?</td>
</tr>
<tr>
<td></td>
<td>Page image type:
<select name="pageImagesType" onchange="changePageImagesType();">
<option value=''></option>
<option value='1'<?=$pageImagesTypeBitonalSelected?>>bitonal</option>
<option value='2'<?=$pageImagesTypeColorSelected?>>color</option>
</select></td>
</tr>
<tr>
<td></td>
<td class="nowrap">Page images created by:
<select name="pageImagesRespId" onchange="changePageImagesResp();">
<option value='0'></option>
<?php
foreach ($pageImagesResps as $id => $name) {
  $selected = '';
  if ($id == $pageImagesRespId) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
<option value='new'>[new page-image creator...]</option>
</select>
<span id="spanNewPageImagesResp"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
New page-image creator - Name: <input type='text' name='pageImagesRespName' maxlength='<?=$pageImagesRespNameMaxLength?>'></span>
</td>
</tr>

<tr>
<td></td>
<td class="nowrap">Page image count:
<input type="text" name="pageCount" size="10" maxlength="<?=$pageCountMaxLength?>" value="<?=$pageCount?>"></td>
</tr>

<tr>
<td class="label">Figure images:</td>
<td><input type="checkbox" name="hasFigureImages"<?=$hasFigureImagesChecked?>> Has figure images?</td>
</tr>

<tr>
<td class="label">Text:</td>
<td><input type="checkbox" name="hasTranscription"<?=$hasTranscriptionChecked?>> Has transcription?</td>
</tr>
<tr>
<td></td>
<td>Transcription type:
<select name="transcriptionType" onchange="changeTranscriptionType();">
<option value=''></option>
<option value='1'<?=$transcriptionTypeVendorSelected?>>vendor</option>
<option value='2'<?=$transcriptionTypeOcrSelected?>>OCR</option>
<option value='3'<?=$transcriptionTypeOtherSelected?>>other</option>
</select></td>
</tr>
<tr>
<td></td>
<td class="nowrap">Transcription created by:
<select name="transcriptionRespId" onchange="changeTranscriptionResp();">
<option value='0'></option>
<?php
foreach ($transcriptionResps as $id => $name) {
  $selected = '';
  if ($id == $transcriptionRespId) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
<option value='new'>[new transcription creator...]</option>
</select>
<span id="spanNewTranscriptionResp"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
New transcription creator - Name:
<input type='text' name='transcriptionRespName' maxlength='<?=$transcriptionRespNameMaxLength?>'></span>
</td>
</tr>

<tr>
<td></td>
<td><hr></td>
</tr>

<tr>
<td class="label">Multi-volume set:</td>
<td><select name="setId" onchange='changeSet();'>
<option value='0'></option>
<?php
foreach ($sets as $id => $name) {
  $selected = '';
  if ($id == $setId) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
<option value='new'>[new set...]</option>
</select>
<span id="spanNewSet"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
New set - Name: <input type='text' name='setName' maxlength='<?=$setNameMaxLength?>'></span>
</td>
</tr>

<tr>
<td class="label">Project:</td>
<td><select name="projectId" onchange='changeProject();'>
<option value='0'></option>
<?php
foreach ($projects as $id => $name) {
  $selected = '';
  if ($id == $projectId) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
<option value='new'>[new project...]</option>
</select>
<span id="spanNewProject"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
New project - Name: <input type='text' name='projectName' maxlength='<?=$projectNameMaxLength?>'></span>
</td>
</tr>

<tr>
<td class="label">Group:</td>
<td><select name="groupId" onchange='changeGroup();'>
<option value='0'></option>
<?php
foreach ($groups as $id => $name) {
  $selected = '';
  if ($id == $groupId) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
<option value='new'>[new group...]</option>
</select>
<span id="spanNewGroup"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
New group - Name: <input type='text' name='groupName' maxlength='<?=$groupNameMaxLength?>'></span>
</td>
</tr>

<tr>
<td class="label">Vendor batch:</td>
<td><select name="batchId">
<option value='0'></option>
<?php
foreach ($batches as $id => $name) {
  $selected = '';
  if ($id == $batchId) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
</select></td>
</tr>

<tr>
<td class="label">Selector:</td>
<td class="nowrap"><select name="selectorId" onchange='changeSelector();'>
<option value='0'></option>
<?php
foreach ($selectors as $id => $name) {
  $selected = '';
  if ($id == $selectorId) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
<option value='new'>[new selector...]</option>
</select>
<span id="spanNewSelector"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
New selector - Last name: <input type='text' name='selectorNameLast' maxlength='<?=$selectorNameLastMaxLength?>'>
&nbsp; First name: <input type='text' name='selectorNameFirst' maxlength='<?=$selectorNameFirstMaxLength?>'></span>
</td>
</tr>

<tr>
<td class="label">Requestor:</td>
<td class="nowrap"><select name="requestorId" onchange='changeRequestor();'>
<option value='0'></option>
<?php
foreach ($requestors as $id => $name) {
  $selected = '';
  if ($id == $requestorId) { $selected = ' selected'; }
  echo "<option value='$id'$selected>$name</option>\n";
}
?>
<option value='new'>[new requestor...]</option>
</select>
<span id="spanNewRequestor"><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
New requestor - Last name: <input type='text' name='requestorNameLast' maxlength='<?=$requestorNameLastMaxLength?>'>
&nbsp; First name: <input type='text' name='requestorNameFirst' maxlength='<?=$requestorNameFirstMaxLength?>'></span>
</td>
</tr>

<tr>
<td class="label">Priority:</td>
<td><select name="priority">
<?php
if ( empty($priority) ) {
  $selectedNormal = ' selected';
} else {
  switch ($priority) {
    case -1:
      $selectedLow = ' selected';
      break;
    case 1:
      $selectedHigh = ' selected';
      break;
    default:
      $selectedNormal = ' selected';
  }
}
echo <<<EOD
<option value='1'$selectedHigh>high</option>
<option value='0'$selectedNormal>normal</option>
<option value='-1'$selectedLow>low</option>
EOD;
?>
</select></td>
</tr>

<tr>
<td class="label">Genre:</td>
<td><select name="genre">
<?php
if ($mode == 'insert') {
  echo "<option value=''> </option>\n";
  $genreRequired = ' <span class="required">(required)</span>';
}
//if ( isset($genre) ) {
if ( preg_match('/^\d$/', $genre) ) {
  switch ($genre) {
    case GENRE_PROSE_NONFICTION:
      $selectedGenre0 = ' selected';
      break;
    case GENRE_PROSE_FICTION:
      $selectedGenre1 = ' selected';
      break;
    case GENRE_POETRY:
      $selectedGenre2 = ' selected';
      break;
    case GENRE_DRAMA:
      $selectedGenre3 = ' selected';
      break;
    case GENRE_DICTIONARY:
      $selectedGenre4 = ' selected';
      break;
    case GENRE_ENCYCLOPEDIA:
      $selectedGenre5 = ' selected';
      break;
    case GENRE_MANUSCRIPT:
      $selectedGenre6 = ' selected';
      break;
    case GENRE_NEWSPAPER:
      $selectedGenre7 = ' selected';
      break;
    case GENRE_SHEET_MUSIC:
      $selectedGenre8 = ' selected';
      break;
    case GENRE_MAP:
      $selectedGenre9 = ' selected';
      break;
  }
}
echo "<option value='0'$selectedGenre0>" . getGenre(GENRE_PROSE_NONFICTION) . "</option>\n";
echo "<option value='1'$selectedGenre1>" . getGenre(GENRE_PROSE_FICTION)    . "</option>\n";
echo "<option value='2'$selectedGenre2>" . getGenre(GENRE_POETRY)           . "</option>\n";
echo "<option value='3'$selectedGenre3>" . getGenre(GENRE_DRAMA)            . "</option>\n";
echo "<option value='4'$selectedGenre4>" . getGenre(GENRE_DICTIONARY)       . "</option>\n";
echo "<option value='5'$selectedGenre5>" . getGenre(GENRE_ENCYCLOPEDIA)     . "</option>\n";
echo "<option value='6'$selectedGenre6>" . getGenre(GENRE_MANUSCRIPT)       . "</option>\n";
echo "<option value='7'$selectedGenre7>" . getGenre(GENRE_NEWSPAPER)        . "</option>\n";
echo "<option value='8'$selectedGenre8>" . getGenre(GENRE_SHEET_MUSIC)      . "</option>\n";
echo "<option value='9'$selectedGenre9>" . getGenre(GENRE_MAP)              . "</option>\n";
echo "</select>$genreRequired</td>\n";
?>
</tr>

<?php
if ($mode == 'insert') {
  $publicationYearRequired = '<span class="required">(required, unless Genre is "Manuscript")</span>';
  $toolTip = 'Required, unless Genre is "Manuscript"; must be a 4-digit year';
}
?>
<tr>
<td class="label">Year of publication:</td>
<td><input type="text" name="publicationYear" size="5" maxlength="10" value="<?=$publicationYear?>" title='<?=$toolTip?>'>
<?=$publicationYearRequired?></td>
</tr>

<tr>
<td class="label">Access:</td>
<td><select name="access">
<?php
switch ($access) {
  case 0:
    $selectedAccessPublic = ' selected';
    break;
  case 1:
    $selectedAccessViva = ' selected';
    break;
  case 2:
    $selectedAccessUva = ' selected';
    break;
  case 3:
    $selectedAccessRestricted = ' selected';
    break;
}
echo <<<EOD
<option value='0'$selectedAccessPublic>public</option>
<option value='1'$selectedAccessViva>VIVA only</option>
<option value='2'$selectedAccessUva>UVA only</option>
<option value='3'$selectedAccessRestricted>restricted</option>
EOD;
?>
</select></td>
</tr>

<tr>
<td class="label">Date received:</td>
<td><input type="text" name="dateReceived" size="12" value="<?=$dateReceived?>"></td>
</tr>

<tr>
<td class="label" valign="top">Destined for repository:</td>
<td><input type="checkbox" name="forRepo"<?=$forRepoChecked?>> </td>
</tr>

<?php
if (!getPerm('textDelete')) {
  $forInternalUseOnlyDisabled = ' disabled';
  $forInternalUseOnlyHidden = "<input type='hidden' name='forInternalUseOnly' value='$forInternalUseOnly'>";
}
?>
<tr>
<td class="label" valign="top">For internal use only:</td>
<td><input type="checkbox" name="forInternalUseOnly"<?=$forInternalUseOnlyChecked?><?=$forInternalUseOnlyDisabled?>>
<?=$forInternalUseOnlyHidden?></td>
</tr>

<tr>
<td class="label" style="vertical-align: top">Notes:</td>
<td><textarea name="notes" cols="60" rows="6"><?=$notes?></textarea></td>
</tr>

<tr>
<td></td>
<td>
<input type="submit" name="go" value="<?=$submitCaption?>"<?=$submitAppearance?>>

<?php
if ($mode == 'insert') {
  echo "<input type='button' value='Clear' onclick='clearForm();'>";
} else {
  echo "<input type='reset' value='Reset'>";
}
?>

<input type="button" value="Cancel" onclick="history.back();">
</td>
</tr>
</table>
<input type='hidden' name='mode' value='<?=$mode?>'>
</form>
<?=$returnToSearchResults?>
</body>
</html>
