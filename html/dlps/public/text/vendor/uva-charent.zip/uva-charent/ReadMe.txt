The iso-*.ent character entity sets in this directory are the "XML
Character Entities V0.3" distributed by the OASIS DocBook Technical
Committee, containing XML encodings of the 19 standard character
entity sets defined in Non-normative Annex D of SGML (ISO 8879). These
files were obtained from:

  http://www.oasis-open.org/docbook/xmlcharent/

uva-supp.ent is a local, supplementary entity set containing
characters available in Unicode but not included in the standard SGML
(ISO 8879) entity sets.

Greg Murray <murray@virginia.edu>, Digital Library Production
  Services, University of Virginia Library
2003-02-13
