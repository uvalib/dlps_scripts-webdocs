This documentation is being served from this URL:

  http://www.lib.virginia.edu/digital/reports/teiPractices/dlpsPractices_postkb.html

which corresponds to this disk path:

  viva: /www/doc/digital/reports/teiPractices/dlpsPractices_postkb.html

Greg Murray
2006-02-08


UPDATE: These files are now under Subversion. Use a Subversion client
to access this URL:

https://subversion.lib.virginia.edu:/repos/coreWEB/branches/production/digital/reports/teiPractices

Greg Murray
2008-07-01


Addendum 2013-05-21  (sdm7g) : 
	Packaging these web pages for archiving. 
	They no longer seem to be available in subversion -- subversion history was lost after
	a restore of server and those files appear to have been deleted. 
	Web server hosting dlps documentation is being decommissioned.    



